// RSTPL HRMS - Biometric Integration Engine & Vendor Adapters
// RS Technovisions XpertSkillCop

import { BiometricDevice, RawPunch, AttendanceRecord, Employee, Shift, AttendanceStatus } from '../types/hrms';

export interface BiometricAdapterConfig {
  vendor: 'ZKTeco' | 'eSSL' | 'Realtime' | 'Matrix' | 'Suprema' | 'BioMax';
  connectionType: 'TCP_IP' | 'REST_API' | 'SQL_DB' | 'CSV_SFTP';
  host: string;
  port: number;
  commKey?: number; // ZKTeco comm key
  apiSecret?: string;
}

export interface SyncResult {
  deviceId: string;
  deviceName: string;
  punchesIngested: number;
  duplicateCount: number;
  failedCount: number;
  latencyMs: number;
  timestamp: string;
  status: 'SUCCESS' | 'PARTIAL' | 'FAILED';
  message: string;
}

/**
 * Generic vendor adapter specifications and device handshake simulator
 */
export class BiometricConnectorManager {
  static getVendorProtocolDocs(vendor: string) {
    switch (vendor) {
      case 'ZKTeco':
        return {
          protocol: 'ZKEMKeeper Standalone SDK / ZK Cloud PUSH API v2.0',
          defaultPort: 4370,
          rawFields: ['CardNo', 'VerifyMode', 'InOutMode', 'TimeStr', 'WorkCode'],
          recommendedAdapter: 'Push Listener on port 8088 or Direct TCP Socket via zk-protocol daemon',
        };
      case 'eSSL':
        return {
          protocol: 'eTimeTrackLite SDK / Web API ADMS protocol',
          defaultPort: 4370,
          rawFields: ['UserId', 'LogDate', 'Direction', 'DeviceLogId'],
          recommendedAdapter: 'HTTP Push POST to /iclock/cdata.aspx?SN={Serial}',
        };
      case 'Matrix':
        return {
          protocol: 'COSEC Web API (JSON/XML REST)',
          defaultPort: 5000,
          rawFields: ['UserID', 'Date', 'Time', 'EventType', 'DoorID'],
          recommendedAdapter: 'HTTPS Event Polling or Webhook Subscription',
        };
      case 'Suprema':
        return {
          protocol: 'BioStar 2 Local API / G-SDK (gRPC & WebSocket)',
          defaultPort: 51211,
          rawFields: ['user_id', 'datetime', 'device_id', 'event_code'],
          recommendedAdapter: 'gRPC event stream to Node.js ingestion gateway',
        };
      default:
        return {
          protocol: 'Universal TCP Socket / Standard CSV Punch Format',
          defaultPort: 4370,
          rawFields: ['EmployeeCode', 'Timestamp', 'PunchDirection'],
          recommendedAdapter: 'Automated SFTP watcher / REST endpoint',
        };
    }
  }

  /**
   * Simulates real device query & punch retrieval from active machine hardware
   */
  static simulateDeviceSync(device: BiometricDevice, employees: Employee[]): { newPunches: RawPunch[]; result: SyncResult } {
    const punches: RawPunch[] = [];
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    // Pick 2 random employees to generate a realistic punch event
    const randomEmp = employees[Math.floor(Math.random() * employees.length)];
    if (randomEmp) {
      const punchHour = 9 + Math.floor(Math.random() * 2);
      const punchMin = Math.floor(Math.random() * 60);
      const timeStr = `${todayStr}T${punchHour.toString().padStart(2, '0')}:${punchMin.toString().padStart(2, '0')}:00Z`;

      punches.push({
        id: `rp-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        orgId: device.orgId,
        deviceId: device.id,
        deviceName: device.name,
        employeeCode: randomEmp.employeeCode,
        punchTime: timeStr,
        punchType: 'IN',
        source: 'Biometric',
        status: 'Unprocessed',
        ipAddress: device.ipAddress,
      });
    }

    const baseLatency =
      device.vendor === 'eSSL'
        ? 45
        : device.vendor === 'ZKTeco'
        ? 72
        : device.vendor === 'Matrix'
        ? 148
        : device.vendor === 'Suprema'
        ? 38
        : 85;
    const latencyMs = baseLatency + Math.floor(Math.random() * 15) - 7;

    const result: SyncResult = {
      deviceId: device.id,
      deviceName: device.name,
      punchesIngested: punches.length,
      duplicateCount: 0,
      failedCount: 0,
      latencyMs,
      timestamp: new Date().toISOString(),
      status: 'SUCCESS',
      message: `Successfully connected to ${device.vendor} device at ${device.ipAddress}:${device.port}. Handshake verified in ${latencyMs}ms.`,
    };

    return { newPunches: punches, result };
  }

  /**
   * Parse CSV / Excel format attendance uploads with full validation
   */
  static parseAttendanceCSV(csvText: string, employees: Employee[]): {
    validPunches: RawPunch[];
    errors: { line: number; message: string; raw: string }[];
  } {
    const lines = csvText.trim().split('\n');
    const validPunches: RawPunch[] = [];
    const errors: { line: number; message: string; raw: string }[] = [];
    const validCodes = new Set(employees.map(e => e.employeeCode.toUpperCase()));

    // Expect header: EmployeeCode,Date,Time,Type,Device
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      const parts = line.split(',').map(p => p.trim());
      if (parts.length < 3) {
        errors.push({ line: i + 1, message: 'Invalid columns. Required: EmployeeCode, Date (YYYY-MM-DD), Time (HH:MM)', raw: line });
        continue;
      }

      const [code, date, time, type] = parts;
      if (!validCodes.has(code.toUpperCase())) {
        errors.push({ line: i + 1, message: `Unknown Employee Code: "${code}". Not found in Employee Master.`, raw: line });
        continue;
      }

      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        errors.push({ line: i + 1, message: `Invalid Date format "${date}". Must be YYYY-MM-DD`, raw: line });
        continue;
      }

      const punchIso = `${date}T${time}:00Z`;
      validPunches.push({
        id: `csv-${Date.now()}-${i}`,
        orgId: employees[0]?.orgId || 'org-rstpl-001',
        deviceId: 'manual-csv-upload',
        deviceName: 'Batch CSV Import',
        employeeCode: code.toUpperCase(),
        punchTime: punchIso,
        punchType: (type?.toUpperCase() === 'OUT' ? 'OUT' : 'IN'),
        source: 'CSV_Import',
        status: 'Unprocessed',
      });
    }

    return { validPunches, errors };
  }
}

// RSTPL HRMS - AI-Powered Geofencing Telemetry & Real-Time Alert Engine
// RS Technovisions XpertSkillCop
// Provides Haversine distance calculations, AI geofence breach detection,
// mock location / GPS spoofing anomaly checks, and multi-channel real-time notifications.

import { GoogleGenAI } from '@google/genai';
import { Unit, Employee, GeofenceBreachAlert, GeoTrackingPunch } from '../types/hrms';

export interface GeofenceEvaluationResult {
  isWithinGeofence: boolean;
  actualDistanceMeters: number;
  breachDistanceMeters: number;
  designatedRadiusMeters: number;
  accuracyMeters: number;
  speedKmh?: number;
  isMockLocationSuspicious: boolean;
  aiRiskScore: number; // 0 to 100
  aiRiskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  aiAnalysisText: string;
  aiRecommendations: string[];
  managerAlertMessage: string;
  employeeAlertMessage: string;
  suggestedAction: 'AUTO_APPROVE' | 'FLAG_FOR_REVIEW' | 'REQUIRE_REGULARIZATION' | 'REJECT_AND_LOCK';
}

/**
 * Calculates geodesic distance between two GPS coordinates using the Haversine formula
 * Returns distance in meters
 */
export function calculateHaversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000; // Earth radius in meters
  const toRad = (deg: number) => (deg * Math.PI) / 180;

  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const phi1 = toRad(lat1);
  const phi2 = toRad(lat2);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c);
}

/**
 * Formats distance in meters into human readable string (e.g., '140 m' or '3.8 km')
 */
export function formatDistance(meters: number): string {
  if (meters < 1000) {
    return `${Math.round(meters)} m`;
  }
  return `${(meters / 1000).toFixed(2)} km`;
}

/**
 * Audio synthesis helper to trigger a clean, audible real-time notification chime
 */
export function playGeofenceAlertChime() {
  try {
    if (typeof window === 'undefined') return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    // Tone 1: Warning high pitch
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(880, now); // A5
    osc1.frequency.exponentialRampToValueAtTime(587.33, now + 0.18); // D5
    gain1.gain.setValueAtTime(0.18, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.36);

    // Tone 2: Sub-harmonic chime
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(440, now + 0.08);
    gain2.gain.setValueAtTime(0.12, now + 0.08);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.08);
    osc2.stop(now + 0.46);
  } catch {
    // Audio contexts might be blocked until user interaction - ignore gracefully
  }
}

/**
 * AI Geofence Analysis & Breach Evaluation Service
 */
export class GeofenceService {
  private static getGeminiClient(): GoogleGenAI | null {
    const apiKey =
      (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) ||
      (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_GEMINI_API_KEY);

    if (!apiKey) return null;
    return new GoogleGenAI({ apiKey });
  }

  /**
   * Evaluates punch GPS coordinates against assigned Unit's designated geofence radius
   */
  static async evaluatePunch(
    punch: {
      latitude: number;
      longitude: number;
      accuracyMeters?: number;
      punchType: 'IN' | 'OUT' | 'FIELD_VISIT';
      timestamp?: string;
    },
    employee: Employee,
    unit: Unit,
    previousPunch?: {
      latitude: number;
      longitude: number;
      timestamp: string;
    }
  ): Promise<GeofenceEvaluationResult> {
    const unitLat = unit.latitude || 18.7583;
    const unitLng = unit.longitude || 73.8567;
    const designatedRadius = unit.geofenceRadiusMeters || 200;
    const accuracy = punch.accuracyMeters || 5;

    // 1. Calculate true geodesic distance
    const actualDistance = calculateHaversineDistance(
      punch.latitude,
      punch.longitude,
      unitLat,
      unitLng
    );

    const isWithin = actualDistance <= designatedRadius;
    const breachDistance = Math.max(0, actualDistance - designatedRadius);

    // 2. Compute velocity anomaly if previous punch available
    let speedKmh = 0;
    let isMockLocationSuspicious = false;

    if (previousPunch && previousPunch.timestamp && punch.timestamp) {
      const prevTime = new Date(previousPunch.timestamp).getTime();
      const currTime = new Date(punch.timestamp).getTime();
      const diffHours = Math.max(0.001, (currTime - prevTime) / (1000 * 60 * 60));

      const deltaMeters = calculateHaversineDistance(
        previousPunch.latitude,
        previousPunch.longitude,
        punch.latitude,
        punch.longitude
      );

      speedKmh = Math.round((deltaMeters / 1000) / diffHours);

      // If transit speed exceeds 250 km/h over short window, likely mock location or VPN jump
      if (speedKmh > 250 && diffHours < 1) {
        isMockLocationSuspicious = true;
      }
    }

    // 3. Risk scoring algorithm
    let aiRiskScore = 0;
    let aiRiskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW';

    if (isWithin) {
      aiRiskScore = Math.min(15, Math.round((actualDistance / designatedRadius) * 15));
      aiRiskLevel = 'LOW';
    } else {
      // Outside radius scoring
      const breachKm = breachDistance / 1000;
      if (breachDistance <= 150) {
        aiRiskScore = 35 + Math.round((breachDistance / 150) * 15); // 35 - 50
        aiRiskLevel = 'MEDIUM';
      } else if (breachKm <= 3.0) {
        aiRiskScore = 55 + Math.round((breachKm / 3.0) * 20); // 55 - 75
        aiRiskLevel = 'HIGH';
      } else {
        aiRiskScore = Math.min(99, 80 + Math.round(breachKm * 2)); // 80 - 99
        aiRiskLevel = 'CRITICAL';
      }

      if (isMockLocationSuspicious) {
        aiRiskScore = 98;
        aiRiskLevel = 'CRITICAL';
      }
    }

    // 4. Default AI reasoning and recommendations
    let aiAnalysisText = '';
    let aiRecommendations: string[] = [];

    const empFullName = `${employee.firstName} ${employee.lastName}`;
    const formattedDistance = formatDistance(actualDistance);
    const formattedBreach = formatDistance(breachDistance);

    if (isWithin) {
      aiAnalysisText = `Compliant Punch: ${empFullName} verified within assigned unit's designated boundary (${formattedDistance} from center vs ${designatedRadius}m radius limit). GPS accuracy is ±${accuracy}m.`;
      aiRecommendations = [
        'Automatic biometric/mobile punch authorization approved.',
        'No managerial regularization required.',
      ];
    } else {
      if (isMockLocationSuspicious) {
        aiAnalysisText = `CRITICAL ANOMALY: Mock GPS / Teleportation pattern detected. Transit speed reached ${speedKmh} km/h from last punch location. Coordinates place employee ${formattedDistance} outside ${unit.name}. Potential virtual GPS spoofer app used.`;
        aiRecommendations = [
          'Immediate supervisor alert dispatched.',
          'Hold punch validation pending physical verification.',
          'Request employee biometric turnstile re-punch on arrival.',
        ];
      } else if (aiRiskLevel === 'CRITICAL') {
        aiAnalysisText = `MAJOR GEOFENCE BREACH: ${empFullName} punched ${punch.punchType} at ${formattedDistance} (${formattedBreach} outside designated perimeter) from assigned unit "${unit.name}". No outdoor duty (OD) client visit logged for this time slot.`;
        aiRecommendations = [
          'Real-time alert transmitted to Reporting Manager and Unit HR.',
          'Triggered mandatory Mobile ESS Regularization ticket.',
          'Flag attendance record as "Pending Manager Regularization".',
        ];
      } else if (aiRiskLevel === 'HIGH') {
        aiAnalysisText = `SIGNIFICANT GEOFENCE BREACH: Punch logged ${formattedDistance} from ${unit.name} (${formattedBreach} past allowable ${designatedRadius}m radius). GPS reading shows stable fix (±${accuracy}m).`;
        aiRecommendations = [
          'Automated SMS warning delivered to employee.',
          'Notify Line Manager for shift regularization review.',
        ];
      } else {
        aiAnalysisText = `BORDERLINE BREACH: Punch is ${formattedDistance} from base (${formattedBreach} beyond ${designatedRadius}m perimeter). Likely plant perimeter parking, gate queue, or structural signal attenuation.`;
        aiRecommendations = [
          'Allow provisional punch with soft warning.',
          'Request employee to step closer to turnstile gates next time.',
        ];
      }
    }

    // 5. Try Gemini LLM for enhanced contextual diagnostic if API is connected
    const client = this.getGeminiClient();
    if (client && !isWithin) {
      try {
        const prompt = `You are the AI Attendance & Geofencing Security Agent for RSTPL HRMS (CodeTech Enterprise).
Analyze this outside-radius punch incident and provide a concise 2-sentence diagnostic assessment and 2 bullet recommendations:
- Employee: ${empFullName} (${employee.employeeCode}), Dept: ${employee.departmentId}
- Assigned Unit: ${unit.name} (Designated Radius: ${designatedRadius}m)
- Punch Type: ${punch.punchType}
- Punch Distance from Unit Center: ${formattedDistance} (Breach: ${formattedBreach} outside perimeter)
- GPS Accuracy: ±${accuracy}m
- Transit Speed: ${speedKmh > 0 ? speedKmh + ' km/h' : 'N/A'}
- Suspicious Speed/Mock Flag: ${isMockLocationSuspicious ? 'YES' : 'NO'}

Respond in JSON with schema:
{
  "diagnostic": "concise 2-sentence explanation",
  "recommendations": ["rec 1", "rec 2"]
}`;

        const res = await client.models.generateContent({
          model: 'gemini-flash-latest',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
        });

        if (res.text) {
          const parsed = JSON.parse(res.text);
          if (parsed.diagnostic) aiAnalysisText = parsed.diagnostic;
          if (Array.isArray(parsed.recommendations) && parsed.recommendations.length > 0) {
            aiRecommendations = parsed.recommendations;
          }
        }
      } catch (geminiErr) {
        console.warn('Gemini geofence generation fallback used:', geminiErr);
      }
    }

    // 6. Multi-channel alert messages
    const managerAlertMessage = `🚨 [RSTPL HRMS ALERT] Geofence Breach: ${empFullName} (${employee.employeeCode}) punched ${punch.punchType} ${formattedDistance} outside ${unit.name} (Breach: +${formattedBreach}). Risk: ${aiRiskLevel} (${aiRiskScore}/100). Review in Manager Portal.`;

    const employeeAlertMessage = `⚠️ [CodeTech HRMS] Warning: Your ${punch.punchType} punch was logged outside your assigned unit perimeter (${formattedDistance} from ${unit.name}). If you are on official field duty, submit an OD regularization in ESS.`;

    let suggestedAction: 'AUTO_APPROVE' | 'FLAG_FOR_REVIEW' | 'REQUIRE_REGULARIZATION' | 'REJECT_AND_LOCK' =
      'AUTO_APPROVE';
    if (aiRiskLevel === 'CRITICAL') suggestedAction = 'REJECT_AND_LOCK';
    else if (aiRiskLevel === 'HIGH') suggestedAction = 'REQUIRE_REGULARIZATION';
    else if (aiRiskLevel === 'MEDIUM') suggestedAction = 'FLAG_FOR_REVIEW';

    return {
      isWithinGeofence: isWithin,
      actualDistanceMeters: actualDistance,
      breachDistanceMeters: breachDistance,
      designatedRadiusMeters: designatedRadius,
      accuracyMeters: accuracy,
      speedKmh: speedKmh > 0 ? speedKmh : undefined,
      isMockLocationSuspicious,
      aiRiskScore,
      aiRiskLevel,
      aiAnalysisText,
      aiRecommendations,
      managerAlertMessage,
      employeeAlertMessage,
      suggestedAction,
    };
  }

  /**
   * Helper to construct a GeofenceBreachAlert record for state storage
   */
  static buildBreachAlert(
    punch: GeoTrackingPunch,
    evaluation: GeofenceEvaluationResult,
    unit: Unit
  ): GeofenceBreachAlert {
    return {
      id: `geo-alert-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      punchId: punch.id,
      employeeId: punch.employeeId,
      employeeCode: punch.employeeCode,
      employeeName: punch.employeeName,
      designation: punch.designation,
      departmentName: punch.departmentName,
      unitId: unit.id,
      unitName: unit.name,
      designatedRadiusMeters: evaluation.designatedRadiusMeters,
      actualDistanceMeters: evaluation.actualDistanceMeters,
      breachDistanceMeters: evaluation.breachDistanceMeters,
      punchType: punch.type,
      date: punch.date,
      time: punch.time,
      timestamp: new Date().toISOString(),
      coordinates: {
        lat: punch.latitude,
        lng: punch.longitude,
      },
      unitCoordinates: {
        lat: unit.latitude || 18.7583,
        lng: unit.longitude || 73.8567,
      },
      locationAddress: punch.locationAddress,
      accuracyMeters: evaluation.accuracyMeters,
      aiRiskScore: evaluation.aiRiskScore,
      aiRiskLevel: evaluation.aiRiskLevel,
      aiAnalysis: evaluation.aiAnalysisText,
      aiRecommendations: evaluation.aiRecommendations,
      alertChannels: ['Manager_Email', 'Manager_SMS', 'Employee_SMS', 'Push_Notification'],
      status: 'ACTIVE_ALERT',
    };
  }
}

export const INITIAL_BREACH_ALERTS: GeofenceBreachAlert[] = [
  {
    id: 'alert-001',
    punchId: 'geo-demo-1',
    employeeId: 'emp-u02',
    employeeCode: 'EMP002',
    employeeName: 'Amit Singh',
    designation: 'Officer',
    departmentName: 'Admin & Facilities',
    unitId: 'un-mfg1',
    unitName: 'Manufacturing Unit 1 (Assembly)',
    designatedRadiusMeters: 250,
    actualDistanceMeters: 3450,
    breachDistanceMeters: 3200,
    punchType: 'IN',
    date: '2026-10-08',
    time: '09:25',
    timestamp: '2026-10-08T09:25:00Z',
    coordinates: { lat: 18.7892, lng: 73.8712 },
    unitCoordinates: { lat: 18.7583, lng: 73.8567 },
    locationAddress: 'Pune-Nashik Highway Toll Plaza, Chakan Bypass',
    accuracyMeters: 6,
    aiRiskScore: 78,
    aiRiskLevel: 'HIGH',
    aiAnalysis: 'SIGNIFICANT GEOFENCE BREACH: Punch logged 3.45 km from Manufacturing Unit 1 (+3.20 km outside designated 250m perimeter). No field visit or client OD pass on record.',
    aiRecommendations: [
      'Automated warning dispatched to employee mobile.',
      'Sent escalation notification to Reporting Manager.',
      'Requires Line Manager approval for regularization.'
    ],
    alertChannels: ['Manager_Email', 'Manager_SMS', 'Employee_SMS', 'Push_Notification'],
    status: 'ACTIVE_ALERT'
  },
  {
    id: 'alert-002',
    punchId: 'geo-demo-2',
    employeeId: 'emp-004',
    employeeCode: 'RST-1004',
    employeeName: 'Sneha Deshmukh',
    designation: 'QA Lead',
    departmentName: 'Quality Assurance & Audit',
    unitId: 'un-mfg1',
    unitName: 'Manufacturing Unit 1 (Assembly)',
    designatedRadiusMeters: 250,
    actualDistanceMeters: 8500,
    breachDistanceMeters: 8250,
    punchType: 'FIELD_VISIT',
    date: '2026-10-08',
    time: '09:40',
    timestamp: '2026-10-08T09:40:00Z',
    coordinates: { lat: 18.7512, lng: 73.8499 },
    unitCoordinates: { lat: 18.7583, lng: 73.8567 },
    locationAddress: 'Tier 1 Supplier Foundry Unit, Chakan MIDC Phase 2',
    accuracyMeters: 8,
    aiRiskScore: 42,
    aiRiskLevel: 'MEDIUM',
    aiAnalysis: 'PPAP Quality Sample Batch Validation logged at authorized supplier premises. High accuracy GPS reading.',
    aiRecommendations: [
      'Verified client site tagged in system.',
      'Recommended one-click approval as official Outdoor Duty.'
    ],
    alertChannels: ['Manager_Email', 'Push_Notification'],
    status: 'REGULARIZED',
    resolutionNotes: 'Approved as authorized supplier QA audit by Amit Sharma.'
  },
  {
    id: 'alert-003',
    punchId: 'geo-demo-3',
    employeeId: 'emp-009',
    employeeCode: 'RST-1009',
    employeeName: 'Vikram Shinde',
    designation: 'CNC Lead Machinist',
    departmentName: 'Production & Manufacturing',
    unitId: 'un-mfg2',
    unitName: 'Heavy Fabrication Unit 2 (Chakan MIDC)',
    designatedRadiusMeters: 300,
    actualDistanceMeters: 1420,
    breachDistanceMeters: 1120,
    punchType: 'IN',
    date: '2026-10-08',
    time: '08:42',
    timestamp: '2026-10-08T08:42:00Z',
    coordinates: { lat: 18.7812, lng: 73.8745 },
    unitCoordinates: { lat: 18.7699, lng: 73.8655 },
    locationAddress: 'Talegaon Industrial Feeder Junction, Pune',
    accuracyMeters: 5,
    aiRiskScore: 64,
    aiRiskLevel: 'HIGH',
    aiAnalysis: 'OUTSIDE RADIUS PUNCH: Punch recorded 1.42 km outside Heavy Fabrication Unit 2 boundary. Transit delay reported.',
    aiRecommendations: [
      'Dispatched SMS notification to employee.',
      'Pending Plant GM shift approval.'
    ],
    alertChannels: ['Manager_SMS', 'Employee_SMS'],
    status: 'ACTIVE_ALERT'
  }
];

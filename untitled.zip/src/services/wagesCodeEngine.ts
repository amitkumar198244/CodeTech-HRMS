// RSTPL HRMS - New Code on Wages Calculation Engine & Statutory Compliance Generators
// RS Technovisions XpertSkillCop
// Implements Code on Wages 2019/2026 50% Rule & All Challan Text/Excel Generation

import { Employee, StatutoryComplianceLink } from '../types/hrms';

export interface SalaryBreakdownResult {
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  unitName: string;
  departmentName: string;
  designation: string;
  salaryEffectiveFrom: string;
  salaryRevisionDate: string;
  payType: 'Monthly' | 'CTC';

  // Earnings Components (Image 4)
  basicSalary: number; // Component Type: Salary
  hra: number; // Component Type: Allowance
  conveyance: number; // Component Type: Allowance
  specialAllowance: number; // Component Type: Allowance
  otherAllowance: number; // Component Type: Allowance
  grossSalary: number;

  // New Code on Wages Metrics
  totalAllowances: number;
  isWageCodeCompliant: boolean; // Basic >= 50% of Gross
  excessAllowanceAddedToWages: number;
  statutoryWageBase: number; // Wage used for PF/ESIC/Gratuity

  // Employer Statutory (Image 4)
  employerPf: number; // Component Type: Statutory (12%)
  employerPfEpfPart: number; // 3.67%
  employerPfEpsPart: number; // 8.33% capped at 1250
  employerPfEdliAdmin: number; // 1%
  employerEsic: number; // Component Type: Statutory (3.25% if Gross <= 21k)
  gratuity: number; // Component Type: Statutory (15/26 * Wage / 12 ~ 4.81%)
  otherEmployerCost: number;
  ctc: number; // Gross + Employer PF + Employer ESIC + Gratuity + otherEmployerCost

  // Employee Deductions (Image 4)
  employeePf: number; // Component Type: Statutory (12%)
  employeeEsic: number; // Component Type: Statutory (0.75% if Gross <= 21k)
  professionalTax: number; // Component Type: Statutory
  tds: number; // Component Type: Tax
  otherDeduction: number;
  totalDeduction: number;
  netSalary: number; // Gross - Total Deduction
  bankTransferAmount: number; // Net Salary
  salaryStatus: 'Active' | 'On-Hold' | 'Revised';
  remarks: string;
}

export const STATUTORY_COMPONENTS_LIST = [
  { name: 'Basic Salary', type: 'Salary', category: 'Earning' },
  { name: 'HRA', type: 'Allowance', category: 'Earning' },
  { name: 'Conveyance', type: 'Allowance', category: 'Earning' },
  { name: 'Special Allowance', type: 'Allowance', category: 'Earning' },
  { name: 'Other Allowance', type: 'Allowance', category: 'Earning' },
  { name: 'Employer PF', type: 'Statutory', category: 'Employer Contribution' },
  { name: 'Employer ESIC', type: 'Statutory', category: 'Employer Contribution' },
  { name: 'Gratuity', type: 'Statutory', category: 'Employer Provision' },
  { name: 'Employee PF', type: 'Statutory', category: 'Employee Deduction' },
  { name: 'Employee ESIC', type: 'Statutory', category: 'Employee Deduction' },
  { name: 'Professional Tax', type: 'Statutory', category: 'Employee Deduction' },
  { name: 'TDS', type: 'Tax', category: 'Tax Deduction' },
] as const;

export const DEFAULT_COMPLIANCE_LINKS: StatutoryComplianceLink[] = [
  {
    id: 'link-er-pf',
    name: 'Employer PF',
    componentType: 'Statutory',
    category: 'Employer',
    portalName: 'EPFO Unified Employer Portal',
    defaultUrl: 'https://unifiedportal-emp.epfindia.gov.in/epfo/',
    customUrl: 'https://unifiedportal-emp.epfindia.gov.in/epfo/',
    challanRefNo: 'TRRN-202610-PF-984412',
    trrnNumber: '341261009844',
    dueDate: '15th of every month',
    status: 'Compliant',
    lastFiledDate: '2026-10-05',
    applicableLaw: 'Employees\' Provident Funds and Miscellaneous Provisions Act, 1952',
    description: 'Monthly ECR Challan generation, electronic payment & return submission for 12% employer share.',
  },
  {
    id: 'link-er-esic',
    name: 'Employer ESIC',
    componentType: 'Statutory',
    category: 'Employer',
    portalName: 'ESIC Employer Portal',
    defaultUrl: 'https://www.esic.gov.in/',
    customUrl: 'https://www.esic.gov.in/',
    challanRefNo: 'ESIC-CHAL-OCT26-8841',
    trrnNumber: '3100098765202610',
    dueDate: '15th of every month',
    status: 'Compliant',
    lastFiledDate: '2026-10-05',
    applicableLaw: 'Employees\' State Insurance Act, 1948',
    description: 'Monthly monthly return file generation and payment of 3.25% employer ESIC contribution.',
  },
  {
    id: 'link-gratuity',
    name: 'Gratuity',
    componentType: 'Statutory',
    category: 'Employer',
    portalName: 'LIC / Group Gratuity Trust Portal',
    defaultUrl: 'https://licindia.in/en/group-schemes',
    customUrl: 'https://licindia.in/en/group-schemes',
    challanRefNo: 'GRAT-PROV-2026Q3-01',
    trrnNumber: 'LIC-GGTS-440192',
    dueDate: 'Quarterly Trust Review',
    status: 'Compliant',
    lastFiledDate: '2026-09-30',
    applicableLaw: 'Payment of Gratuity Act, 1972 & Code on Social Security 2020',
    description: 'Actuarial valuation, 15 days of wage provision per year of service for employees completed 5 years.',
  },
  {
    id: 'link-ee-pf',
    name: 'Employee PF',
    componentType: 'Statutory',
    category: 'Employee',
    portalName: 'EPFO Member Passbook & UAN Portal',
    defaultUrl: 'https://passbook.epfindia.gov.in/MemberPassBook/Login',
    customUrl: 'https://passbook.epfindia.gov.in/MemberPassBook/Login',
    challanRefNo: 'UAN-ECR-EE-984412',
    trrnNumber: '341261009844',
    dueDate: '15th of every month',
    status: 'Compliant',
    lastFiledDate: '2026-10-05',
    applicableLaw: 'Employees\' Provident Funds and Miscellaneous Provisions Act, 1952',
    description: '12% deduction from employee wage, credited directly to employee Universal Account Number (UAN).',
  },
  {
    id: 'link-ee-esic',
    name: 'Employee ESIC',
    componentType: 'Statutory',
    category: 'Employee',
    portalName: 'ESIC Pehchan / Employee Portal',
    defaultUrl: 'https://www.esic.in/EmployeePortal/login.aspx',
    customUrl: 'https://www.esic.in/EmployeePortal/login.aspx',
    challanRefNo: 'ESIC-IP-OCT26-8841',
    trrnNumber: '3100098765202610',
    dueDate: '15th of every month',
    status: 'Compliant',
    lastFiledDate: '2026-10-05',
    applicableLaw: 'Employees\' State Insurance Act, 1948',
    description: '0.75% deduction for covered employees (gross <= ₹21,000/mo) providing full medical benefits & IP card.',
  },
  {
    id: 'link-pt',
    name: 'Professional Tax',
    componentType: 'Statutory',
    category: 'State',
    portalName: 'State Commercial Tax / MahaGST / Gujarat PT Portal',
    defaultUrl: 'https://mahagst.gov.in/en/professional-tax',
    customUrl: 'https://mahagst.gov.in/en/professional-tax',
    challanRefNo: 'PT-MHA-OCT26-5521',
    trrnNumber: 'MTR-PT-27-998877',
    dueDate: 'Last day of every month',
    status: 'Compliant',
    lastFiledDate: '2026-09-30',
    applicableLaw: 'State Profession Tax Acts (e.g. Maharashtra PT Act, 1975)',
    description: 'State statutory levy deducted from employee salary (standard ₹200/mo, ₹300 in Feb).',
  },
  {
    id: 'link-tds',
    name: 'TDS',
    componentType: 'Tax',
    category: 'Central',
    portalName: 'TRACES & Income Tax e-Filing Portal',
    defaultUrl: 'https://www.tdscpc.gov.in/app/login.xhtml',
    customUrl: 'https://www.incometax.gov.in/iec/fposervices/#/login',
    challanRefNo: 'ITNS-281-BSR-0210045',
    trrnNumber: 'CHAL-281-992384',
    dueDate: '7th of following month (Form 24Q Quarterly)',
    status: 'Compliant',
    lastFiledDate: '2026-10-07',
    applicableLaw: 'Section 192 of the Income Tax Act, 1961',
    description: 'Tax Deducted at Source on Salary income, Form 24Q quarterly return e-filing & Form 16 issuance.',
  },
];

export class WagesCodeCalculator {
  /**
   * Calculates comprehensive salary master components for an employee
   * adhering strictly to the Code on Wages 2019/2026 50% Rule.
   */
  static calculate(
    emp: Employee,
    unitName = 'Corporate Office & HR Center',
    departmentName = 'Human Resources & IR',
    designationTitle = 'Staff Specialist'
  ): SalaryBreakdownResult {
    const basic = emp.basicMonthly || 25000;
    const hra = emp.hraMonthly || 12500;
    const conveyance = emp.conveyanceMonthly || 2500;
    const specialAllowance = emp.specialAllowanceMonthly || 10000;
    const otherAllowance = emp.otherAllowanceMonthly || 0;

    const grossSalary = basic + hra + conveyance + specialAllowance + otherAllowance;
    const totalAllowances = hra + conveyance + specialAllowance + otherAllowance;

    // Code on Wages 50% Rule:
    // Basic + DA must be >= 50% of Gross remuneration.
    // If allowances exceed 50% of Gross, excess is added to Statutory Wage Base!
    const maxAllowedAllowances = grossSalary * 0.50;
    const excessAllowanceAddedToWages = Math.max(0, Math.round(totalAllowances - maxAllowedAllowances));
    const isWageCodeCompliant = totalAllowances <= maxAllowedAllowances;

    // Statutory Wage Base for PF, ESIC & Gratuity
    const statutoryWageBase = basic + excessAllowanceAddedToWages;

    // 1. Employee PF (12% of Wage Base, or capped if opted)
    let employeePf = 0;
    if (emp.pfApplicable !== false) {
      // Standard: 12% of statutory wage base
      employeePf = Math.round(statutoryWageBase * 0.12);
    }

    // 2. Employer PF (12% of Wage Base)
    // Breakdown: 8.33% to Pension EPS (capped at ₹15,000 ceiling -> ₹1,250), 3.67% to EPF, 0.5% EDLI, 0.5% Admin
    let employerPf = 0;
    let employerPfEpsPart = 0;
    let employerPfEpfPart = 0;
    let employerPfEdliAdmin = 0;
    if (emp.pfApplicable !== false) {
      employerPf = Math.round(statutoryWageBase * 0.12);
      employerPfEpsPart = Math.min(1250, Math.round(Math.min(statutoryWageBase, 15000) * 0.0833));
      employerPfEpfPart = Math.max(0, employerPf - employerPfEpsPart);
      employerPfEdliAdmin = Math.round(statutoryWageBase * 0.01);
    }

    // 3. ESIC (Gross <= ₹21,000)
    // Employee: 0.75% of Gross, Employer: 3.25% of Gross
    let employeeEsic = 0;
    let employerEsic = 0;
    if (emp.esicApplicable !== false && grossSalary <= 21000) {
      employeeEsic = Math.round(grossSalary * 0.0075);
      employerEsic = Math.round(grossSalary * 0.0325);
    }

    // 4. Gratuity: (15 / 26) * Wage / 12 = ~4.8077% of Statutory Wage Base per month
    const gratuity = Math.round((statutoryWageBase * 15) / (26 * 12));

    // 5. Professional Tax: ₹200 standard (or ₹175 if low wage)
    const professionalTax = grossSalary > 10000 ? 200 : (grossSalary > 7500 ? 175 : 0);

    // 6. TDS: Annual tax deduction estimate
    let tds = emp.tdsMonthly || 0;
    if (!tds) {
      const annualGross = grossSalary * 12;
      if (annualGross > 1500000) tds = 14500;
      else if (annualGross > 1200000) tds = 9200;
      else if (annualGross > 1000000) tds = 5400;
      else if (annualGross > 750000) tds = 2500;
      else tds = 0;
    }

    const otherEmployerCost = emp.otherEmployerCostMonthly || 0;
    const ctc = grossSalary + employerPf + employerEsic + gratuity + otherEmployerCost;

    const otherDeduction = emp.otherDeductionMonthly || 0;
    const totalDeduction = employeePf + employeeEsic + professionalTax + tds + otherDeduction;
    const netSalary = Math.max(0, grossSalary - totalDeduction);
    const bankTransferAmount = netSalary;

    return {
      employeeId: emp.id,
      employeeCode: emp.employeeCode,
      employeeName: `${emp.firstName} ${emp.lastName}`.trim(),
      unitName: emp.unitId || unitName,
      departmentName: emp.departmentId || departmentName,
      designation: designationTitle,
      salaryEffectiveFrom: emp.salaryEffectiveFrom || '2026-04-01',
      salaryRevisionDate: emp.salaryRevisionDate || '2026-10-01',
      payType: emp.payType || 'Monthly',
      basicSalary: basic,
      hra,
      conveyance,
      specialAllowance,
      otherAllowance,
      grossSalary,
      totalAllowances,
      isWageCodeCompliant,
      excessAllowanceAddedToWages,
      statutoryWageBase,
      employerPf,
      employerPfEpfPart,
      employerPfEpsPart,
      employerPfEdliAdmin,
      employerEsic,
      gratuity,
      otherEmployerCost,
      ctc,
      employeePf,
      employeeEsic,
      professionalTax,
      tds,
      otherDeduction,
      totalDeduction,
      netSalary,
      bankTransferAmount,
      salaryStatus: emp.salaryStatus || 'Active',
      remarks: emp.remarks || (isWageCodeCompliant ? 'Compliant with Code on Wages' : 'Wage Base adjusted (+excess allowances)'),
    };
  }
}

// ==========================================
// CHALLAN & EXPORT GENERATORS
// ==========================================

export class ChallanFileGenerators {
  /**
   * Helper to trigger download of string content as a file
   */
  static downloadFile(content: string, filename: string, mimeType = 'text/plain;charset=utf-8;') {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /**
   * 1. EPFO Electronic Challan cum Return (ECR 2.0) Text File (.txt)
   * Government ECR standard format: #~# delimited
   * Columns: UAN#~#MemberName#~#GrossWages#~#EPFWages#~#EPSWages#~#EDLIWages#~#EE_Share#~#ER_EPS#~#ER_EPF#~#NCPDays#~#Refund
   */
  static generateEpfoEcrText(employees: Employee[], month = 'OCT-2026'): string {
    const lines = employees.map(emp => {
      const b = WagesCodeCalculator.calculate(emp);
      const uan = emp.uan || emp.uanNumber || '100987654321';
      const name = `${emp.firstName} ${emp.lastName}`.trim().toUpperCase();
      const gross = b.grossSalary;
      const epfWage = Math.min(b.statutoryWageBase, 15000);
      const epsWage = Math.min(b.statutoryWageBase, 15000);
      const edliWage = Math.min(b.statutoryWageBase, 15000);
      const eeShare = Math.round(epfWage * 0.12);
      const erEps = Math.min(1250, Math.round(epsWage * 0.0833));
      const erEpf = Math.max(0, eeShare - erEps);
      const ncpDays = 0; // Non-contributing period days
      const refund = 0;

      return `${uan}#~#${name}#~#${gross}#~#${epfWage}#~#${epsWage}#~#${edliWage}#~#${eeShare}#~#${erEps}#~#${erEpf}#~#${ncpDays}#~#${refund}`;
    });

    return lines.join('\r\n');
  }

  /**
   * 2. EPFO ECR Challan Excel / CSV File (.csv)
   */
  static generateEpfoEcrCsv(employees: Employee[], month = 'OCT-2026'): string {
    const headers = [
      'UAN',
      'Member Name',
      'Gross Wages',
      'EPF Wages',
      'EPS Wages',
      'EDLI Wages',
      'EE Share (12%)',
      'ER EPS Share (8.33%)',
      'ER EPF Share (3.67%)',
      'NCP Days',
      'Refund of Advances',
      'Total Contribution',
    ];

    const rows = employees.map(emp => {
      const b = WagesCodeCalculator.calculate(emp);
      const uan = emp.uan || emp.uanNumber || '100987654321';
      const name = `"${emp.firstName} ${emp.lastName}"`;
      const gross = b.grossSalary;
      const epfWage = Math.min(b.statutoryWageBase, 15000);
      const epsWage = Math.min(b.statutoryWageBase, 15000);
      const edliWage = Math.min(b.statutoryWageBase, 15000);
      const eeShare = Math.round(epfWage * 0.12);
      const erEps = Math.min(1250, Math.round(epsWage * 0.0833));
      const erEpf = Math.max(0, eeShare - erEps);
      const ncpDays = 0;
      const refund = 0;
      const totalContribution = eeShare + erEps + erEpf;

      return [uan, name, gross, epfWage, epsWage, edliWage, eeShare, erEps, erEpf, ncpDays, refund, totalContribution].join(',');
    });

    return [headers.join(','), ...rows].join('\r\n');
  }

  /**
   * 3. ESIC Monthly Contribution Return File (.txt / .csv)
   * Columns: IP Number, IP Name, No of Days Worked, Total Monthly Wages, Reason Code (0 for normal), Last Working Day
   */
  static generateEsicReturnCsv(employees: Employee[], month = 'OCT-2026'): string {
    const headers = [
      'IP Number (ESIC No)',
      'IP Name',
      'No of Days for which wages paid',
      'Total Monthly Wages',
      'Employee Contribution (0.75%)',
      'Employer Contribution (3.25%)',
      'Total Contribution (4.0%)',
      'Reason Code for Zero Working Days',
      'Last Working Day',
    ];

    const rows = employees.map(emp => {
      const b = WagesCodeCalculator.calculate(emp);
      const esicNo = emp.esicNumber || (emp.esicApplicable ? '3100098765' : 'N/A');
      const name = `"${emp.firstName} ${emp.lastName}"`;
      const daysWorked = 30;
      const wages = b.grossSalary <= 21000 ? b.grossSalary : 0;
      const eeContr = b.employeeEsic;
      const erContr = b.employerEsic;
      const totalContr = eeContr + erContr;
      const reasonCode = wages === 0 ? 'Exempt (>21k)' : '0';
      const lwd = '';

      return [esicNo, name, daysWorked, wages, eeContr, erContr, totalContr, reasonCode, lwd].join(',');
    });

    return [headers.join(','), ...rows].join('\r\n');
  }

  /**
   * 4. Professional Tax (PT) Challan & Return Schedule (.csv / .txt)
   */
  static generatePtReturnCsv(employees: Employee[], month = 'OCT-2026'): string {
    const headers = [
      'S.No',
      'Employee Code',
      'Employee Name',
      'Unit / Plant',
      'Gross Salary',
      'PT Slab Rate',
      'PT Deducted',
      'State PT Enrollment No',
    ];

    const rows = employees.map((emp, idx) => {
      const b = WagesCodeCalculator.calculate(emp);
      return [
        idx + 1,
        emp.employeeCode,
        `"${emp.firstName} ${emp.lastName}"`,
        `"${emp.unitId || 'Corporate'}"`,
        b.grossSalary,
        b.professionalTax,
        b.professionalTax,
        'PT-MAH-998877',
      ].join(',');
    });

    return [headers.join(','), ...rows].join('\r\n');
  }

  /**
   * 5. TDS Form 24Q Quarterly Return File (.txt / .csv)
   */
  static generateTds24QCsv(employees: Employee[], quarter = 'Q2 FY 2026-27'): string {
    const headers = [
      'Challan Ref / BSR Code',
      'PAN of Employee',
      'Employee Name',
      'Section Code',
      'Date of Payment',
      'Amount Paid / Credited (Gross)',
      'TDS Deducted',
      'Education Cess',
      'Total Tax Deposited',
      'Date of Deposit',
    ];

    const rows = employees.map(emp => {
      const b = WagesCodeCalculator.calculate(emp);
      const pan = emp.pan || emp.panNumber || 'ABCDE1234F';
      const name = `"${emp.firstName} ${emp.lastName}"`;
      const bsr = '0210045';
      const section = '192-Salaries';
      const date = '2026-10-31';
      const gross = b.grossSalary;
      const tds = b.tds;
      const cess = Math.round(tds * 0.04);
      const totalTax = tds + cess;

      return [bsr, pan, name, section, date, gross, tds, cess, totalTax, '2026-11-05'].join(',');
    });

    return [headers.join(','), ...rows].join('\r\n');
  }

  /**
   * 6. Bank NEFT / RTGS Salary Disbursement File (.txt / .csv)
   */
  static generateBankDisbursementCsv(employees: Employee[], month = 'OCT-2026'): string {
    const headers = [
      'Beneficiary Account Number',
      'Beneficiary IFSC Code',
      'Beneficiary Name',
      'Amount (Net Salary)',
      'Employee Code',
      'Narration / Remarks',
      'Bank Name',
    ];

    const rows = employees.map(emp => {
      const b = WagesCodeCalculator.calculate(emp);
      const acc = emp.bankAccountNumber || '50100987654321';
      const ifsc = emp.ifscCode || 'HDFC0001234';
      const name = `"${emp.firstName} ${emp.lastName}"`;
      const netPay = b.netSalary;
      const code = emp.employeeCode;
      const narration = `SALARY FOR ${month}`;
      const bank = `"${emp.bankName || 'HDFC Bank'}"`;

      return [acc, ifsc, name, netPay, code, narration, bank].join(',');
    });

    return [headers.join(','), ...rows].join('\r\n');
  }

  /**
   * 7. Full Salary Master Excel / CSV Export (Matching Image 2 Headers)
   */
  static generateSalaryMasterFullCsv(employees: Employee[]): string {
    const headers = [
      'S. No.',
      'Employee Code',
      'Employee Name',
      'Unit Name',
      'Department Name',
      'Designation',
      'Salary Effective From',
      'Salary Revision Date',
      'Pay Type',
      'Basic Salary',
      'HRA',
      'Conveyance',
      'Special Allowance',
      'Other Allowance',
      'Gross Salary',
      'Employer PF',
      'Employer ESIC',
      'Gratuity',
      'Other Employer Cost',
      'CTC',
      'Employee PF',
      'Employee ESIC',
      'Professional Tax',
      'TDS',
      'Other Deduction',
      'Total Deduction',
      'Net Salary',
      'Bank Transfer Amount',
      'Salary Status',
      'Remarks',
    ];

    const rows = employees.map((emp, idx) => {
      const b = WagesCodeCalculator.calculate(emp);
      return [
        idx + 1,
        `"${b.employeeCode}"`,
        `"${b.employeeName}"`,
        `"${b.unitName}"`,
        `"${b.departmentName}"`,
        `"${b.designation}"`,
        `"${b.salaryEffectiveFrom}"`,
        `"${b.salaryRevisionDate}"`,
        `"${b.payType}"`,
        b.basicSalary,
        b.hra,
        b.conveyance,
        b.specialAllowance,
        b.otherAllowance,
        b.grossSalary,
        b.employerPf,
        b.employerEsic,
        b.gratuity,
        b.otherEmployerCost,
        b.ctc,
        b.employeePf,
        b.employeeEsic,
        b.professionalTax,
        b.tds,
        b.otherDeduction,
        b.totalDeduction,
        b.netSalary,
        b.bankTransferAmount,
        `"${b.salaryStatus}"`,
        `"${b.remarks}"`,
      ].join(',');
    });

    return [headers.join(','), ...rows].join('\r\n');
  }
}

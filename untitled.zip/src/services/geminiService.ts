// RSTPL HRMS - AI HR Assistant Service (Google Gemini / AI Studio)
// RS Technovisions XpertSkillCop

import { GoogleGenAI } from '@google/genai';
import { HRMSStoreData } from './hrmsStorage';

export interface AIResponse {
  answer: string;
  sourceContext?: string;
  suggestedActions?: string[];
}

export class GeminiHRAssistant {
  private static getClient(): GoogleGenAI | null {
    const apiKey = (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) ||
      (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_GEMINI_API_KEY);

    if (!apiKey) return null;
    return new GoogleGenAI({ apiKey });
  }

  /**
   * Generates intelligent, RBAC-aware HR answers with real live data context
   */
  static async askHRAssistant(question: string, storeData: HRMSStoreData, userRole: string): Promise<AIResponse> {
    const totalEmployees = storeData.employees.length;
    const presentToday = storeData.attendance.filter(a => a.status === 'Present' || a.status === 'Late').length;
    const absentToday = storeData.attendance.filter(a => a.status === 'Absent').length;
    const onLeaveToday = storeData.attendance.filter(a => a.status === 'On Leave').length;
    const pendingLeaves = storeData.leaveRequests.filter(l => l.status === 'Pending').length;
    const openVacancies = storeData.jobOpenings.reduce((acc, j) => acc + (j.status === 'Open' ? j.openingsCount : 0), 0);
    const activeBiometrics = storeData.biometricDevices.filter(d => d.status === 'Online').length;
    const latestPayroll = storeData.payrollRuns[0];

    // Local context summary to supply to the AI
    const liveContext = `
Live Enterprise HR System Context (RSTPL Demo Manufacturing Pvt. Ltd.):
- Total Active Employees: ${totalEmployees}
- Attendance Today: ${presentToday} Present, ${absentToday} Absent, ${onLeaveToday} On Approved Leave
- Pending Leave Requests: ${pendingLeaves}
- Open Job Vacancies: ${openVacancies} (across ${storeData.jobOpenings.length} requisitions)
- Biometric Devices Online: ${activeBiometrics} of ${storeData.biometricDevices.length} (eSSL, ZKTeco, Matrix, Suprema)
- Latest Payroll Month: ${latestPayroll ? latestPayroll.month : 'September 2026'} (Net Payout: ₹${latestPayroll ? latestPayroll.totalNetPay.toLocaleString('en-IN') : '0'})
- Departments: ${storeData.departments.map(d => d.name).join(', ')}
- Shifts Active: General Corporate (09:00 - 18:00), Plant Shift A (06:00 - 14:30), Shift B (14:30 - 23:00), Shift C Night (23:00 - 06:30)
- Requesting User Role: ${userRole}
`;

    const client = this.getClient();

    if (client) {
      try {
        const response = await client.models.generateContent({
          model: 'gemini-flash-latest',
          contents: `You are the executive AI HR Assistant for RSTPL HRMS (Powered by RS Technovisions XpertSkillCop).
Answer the user's inquiry based strictly on the live HR enterprise context provided below. Be professional, concise, authoritative, and structured. Include actionable recommendations.

${liveContext}

User Question: "${question}"`,
        });

        const text = response.text || '';
        return {
          answer: text,
          sourceContext: 'RSTPL HRMS Live Enterprise Data Engine (Gemini Verified)',
          suggestedActions: [
            'View Attendance Finalization',
            'Review Pending Leave Requests',
            'Check Biometric Terminal Status',
          ],
        };
      } catch (err) {
        console.warn('Gemini API call failed, switching to rule-based contextual engine', err);
      }
    }

    // High quality intelligent offline/fallback response engine
    const qLower = question.toLowerCase();

    if (qLower.includes('absent') || qLower.includes('absenteeism')) {
      return {
        answer: `Today, there are **${absentToday} employee(s) marked absent** and **${onLeaveToday} employee(s) on authorized leave** out of ${totalEmployees} total personnel. Production & Manufacturing has 1 employee on scheduled Casual Leave (Suresh Yadav). The overall attendance rate is **${Math.round((presentToday / totalEmployees) * 100)}%**.`,
        sourceContext: 'Attendance Daily Engine & Biometric Synced Logs',
        suggestedActions: ['Open Attendance Roster', 'Send Absentee Notification', 'Check Overtime Replacement'],
      };
    }

    if (qLower.includes('leave') || qLower.includes('pending')) {
      return {
        answer: `There are currently **${pendingLeaves} pending leave application(s)** awaiting managerial review:\n- **Vikram Singhania** (IT Dept): 3 days Privilege Leave (EL) for 14-16 Oct 2026.\n\nAll prior Casual Leave (CL) requests for plant floor personnel have been resolved.`,
        sourceContext: 'RSTPL Leave Policy Engine',
        suggestedActions: ['Go to Leave Approvals', 'Check Department Leave Calendar'],
      };
    }

    if (qLower.includes('payroll') || qLower.includes('salary') || qLower.includes('cost')) {
      return {
        answer: `For **September 2026**, the total processed payroll was **₹${latestPayroll ? latestPayroll.totalGrossPay.toLocaleString('en-IN') : '5,12,200'}** with total statutory deductions (PF, ESIC, PT, TDS) of **₹${latestPayroll ? latestPayroll.totalDeductions.toLocaleString('en-IN') : '24,522.50'}**, yielding a net employee payout of **₹${latestPayroll ? latestPayroll.totalNetPay.toLocaleString('en-IN') : '4,87,677.50'}**. October 2026 payroll is currently in **Draft** status.`,
        sourceContext: 'RSTPL Statutory Payroll Engine (Locked Period)',
        suggestedActions: ['View September Payslips', 'Process October Draft Payroll', 'Export Statutory PF/ESIC ECR'],
      };
    }

    if (qLower.includes('vacancy') || qLower.includes('hiring') || qLower.includes('open') || qLower.includes('recruitment')) {
      return {
        answer: `There are **${openVacancies} active vacancies** across 2 open job postings:\n1. **Assistant Manager - IR & Compliance** (Chakan Plant) - 2 positions (24 applicants)\n2. **Senior CNC / VMC Machining Engineer** (Chakan Machining Unit) - 4 positions (38 applicants, 1 offer extended).`,
        sourceContext: 'RSTPL Recruitment & ATS Pipeline',
        suggestedActions: ['Open Recruitment Pipeline', 'Schedule CNC Interview Panel', 'Draft Offer Letter'],
      };
    }

    if (qLower.includes('biometric') || qLower.includes('device') || qLower.includes('machine')) {
      return {
        answer: `All **${activeBiometrics} Biometric Terminals** (eSSL, ZKTeco, Matrix, Suprema) are **Online** and healthy. The most recent automatic sync occurred within the last 15 minutes, with zero packet drops recorded.`,
        sourceContext: 'Biometric Integration Controller',
        suggestedActions: ['Trigger Live Biometric Sync', 'View Raw Punch Table', 'Download Device Error Logs'],
      };
    }

    return {
      answer: `As your **RSTPL HR Assistant**, I am tracking ${totalEmployees} active personnel across Pune Corporate HQ, Chakan Heavy Engineering, and Sanand Plant. Today's workforce presence is at **${Math.round((presentToday / totalEmployees) * 100)}%** (${presentToday} present, ${absentToday} absent, ${onLeaveToday} on leave). ${pendingLeaves} leave requests and ${openVacancies} open requisitions are currently active.`,
      sourceContext: 'RSTPL Enterprise Multi-Tenant Knowledge Graph',
      suggestedActions: ['Run Monthly Attendance Finalization', 'View Executive Dashboard', 'Generate HR Letter'],
    };
  }

  /**
   * Generates professional HR letters (Appointment, Offer, Increment, Relieving)
   */
  static generateHRLetterTemplate(type: string, employeeName: string, designation: string, companyName: string): string {
    const today = new Date().toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' });
    switch (type) {
      case 'Appointment Letter':
        return `REF: RSTPL/HR/APPT/2026/894\nDate: ${today}\n\nTo,\n${employeeName}\n\nSub: Letter of Appointment\n\nDear ${employeeName},\n\nWe have great pleasure in appointing you as "${designation}" at ${companyName}. Your employment will be governed by the standard terms and conditions of our company code of conduct.\n\nWe warmly welcome you to the RSTPL family and look forward to an enduring and rewarding association.\n\nYours faithfully,\nFor ${companyName}\n\nAuthorized Signatory\nHuman Resources & IR`;
      case 'Increment Letter':
        return `REF: RSTPL/HR/REV/2026/302\nDate: ${today}\n\nTo,\n${employeeName}\nDesignation: ${designation}\n\nSub: Annual Performance & Compensation Revision\n\nDear ${employeeName},\n\nIn recognition of your exceptional performance and dedication towards ${companyName}'s strategic objectives during the appraisal cycle, management is delighted to revise your compensation structure effective this quarter.\n\nKeep up the high standard of excellence!\n\nWarm regards,\nVP - Human Resources\n${companyName}`;
      case 'Relieving Letter':
        return `REF: RSTPL/HR/REL/2026/112\nDate: ${today}\n\nTo,\n${employeeName}\n\nSub: Relieving Letter & Service Certificate\n\nDear ${employeeName},\n\nThis has reference to your formal resignation letter. We hereby confirm that you have been relieved from your duties as "${designation}" with ${companyName} effective closing of business hours on ${today}.\n\nAll company assets have been returned and full & final clearances have been cleared. We wish you every success in your future endeavors.\n\nAuthorized Signatory\n${companyName}`;
      default:
        return `REF: RSTPL/HR/CERT/2026/044\nDate: ${today}\n\nTO WHOMSOEVER IT MAY CONCERN\n\nThis is to certify that ${employeeName} is a bonafide employee of ${companyName}, currently serving as ${designation}.\n\nThis certificate is issued upon employee request for official administrative purposes.\n\nAuthorized Signatory\nHuman Resources Department`;
    }
  }
}

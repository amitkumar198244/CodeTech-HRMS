// RSTPL HRMS - Attendance Rules Engine & Finalization
// RS Technovisions XpertSkillCop

import { AttendanceRecord, Employee, RawPunch, Shift, AttendanceStatus } from '../types/hrms';

export interface ProcessAttendanceOptions {
  date: string; // YYYY-MM-DD
  employees: Employee[];
  shifts: Shift[];
  rawPunches: RawPunch[];
  existingAttendance: AttendanceRecord[];
}

export class AttendanceProcessingEngine {
  /**
   * Evaluates raw punches for all employees on a given date against their assigned shift.
   */
  static processDailyAttendance(options: ProcessAttendanceOptions): AttendanceRecord[] {
    const { date, employees, shifts, rawPunches, existingAttendance } = options;
    const shiftMap = new Map(shifts.map(s => [s.id, s]));
    const results: AttendanceRecord[] = [];

    // Group raw punches by employeeCode for this specific date
    const punchesByEmp = new Map<string, RawPunch[]>();
    for (const punch of rawPunches) {
      const punchDate = punch.punchTime.split('T')[0];
      if (punchDate === date) {
        const code = punch.employeeCode.toUpperCase();
        if (!punchesByEmp.has(code)) punchesByEmp.set(code, []);
        punchesByEmp.get(code)!.push(punch);
      }
    }

    for (const emp of employees) {
      // Check if existing record is already finalized
      const existing = existingAttendance.find(a => a.employeeId === emp.id && a.date === date);
      if (existing && existing.isFinalized) {
        results.push(existing);
        continue;
      }

      // If user is already on approved leave
      if (existing && existing.status === 'On Leave') {
        results.push(existing);
        continue;
      }

      const shift = shiftMap.get(emp.shiftId) || shifts[0];
      const empPunches = punchesByEmp.get(emp.employeeCode.toUpperCase()) || [];

      // Sort punches chronologically
      empPunches.sort((a, b) => new Date(a.punchTime).getTime() - new Date(b.punchTime).getTime());

      if (empPunches.length === 0) {
        // Absent unless on leave/OD
        results.push({
          id: existing ? existing.id : `att-${emp.id}-${date}`,
          orgId: emp.orgId,
          employeeId: emp.id,
          employeeCode: emp.employeeCode,
          employeeName: `${emp.firstName} ${emp.lastName}`,
          departmentName: 'General',
          date,
          shiftId: shift.id,
          totalHours: 0,
          status: 'Absent',
          isLate: false,
          lateMinutes: 0,
          isEarlyOut: false,
          earlyOutMinutes: 0,
          isOvertime: false,
          overtimeHours: 0,
          isRegularized: false,
          isFinalized: false,
          remarks: 'No biometric punches recorded for date',
        });
        continue;
      }

      // First IN and Last OUT
      const firstPunch = empPunches[0];
      const lastPunch = empPunches[empPunches.length - 1];

      const firstInDate = new Date(firstPunch.punchTime);
      const firstInStr = `${firstInDate.getUTCHours().toString().padStart(2, '0')}:${firstInDate.getUTCMinutes().toString().padStart(2, '0')}`;

      let lastOutStr: string | undefined = undefined;
      let totalWorkingHours = 8.0; // default standard if single punch

      if (empPunches.length > 1) {
        const lastOutDate = new Date(lastPunch.punchTime);
        lastOutStr = `${lastOutDate.getUTCHours().toString().padStart(2, '0')}:${lastOutDate.getUTCMinutes().toString().padStart(2, '0')}`;
        const diffMs = lastOutDate.getTime() - firstInDate.getTime();
        totalWorkingHours = Math.max(0, parseFloat((diffMs / (1000 * 60 * 60)).toFixed(2)));
      } else {
        lastOutStr = '18:00'; // Default exit if single punch logged
      }

      // Parse shift start time (e.g. "09:00")
      const [shiftHour, shiftMin] = shift.startTime.split(':').map(Number);
      const shiftStartInMins = shiftHour * 60 + shiftMin;
      const punchInMins = firstInDate.getUTCHours() * 60 + firstInDate.getUTCMinutes();
      const lateDiff = punchInMins - shiftStartInMins;

      const isLate = lateDiff > shift.graceTimeMinutes;
      const lateMinutes = isLate ? lateDiff : 0;

      // Status evaluation based on threshold
      let status: AttendanceStatus = 'Present';
      if (totalWorkingHours < shift.halfDayThresholdHours) {
        status = 'Half Day';
      } else if (isLate) {
        status = 'Late';
      }

      // Overtime
      const isOvertime = totalWorkingHours > shift.fullDayThresholdHours;
      const overtimeHours = isOvertime ? parseFloat((totalWorkingHours - shift.fullDayThresholdHours).toFixed(2)) : 0;

      results.push({
        id: existing ? existing.id : `att-${emp.id}-${date}`,
        orgId: emp.orgId,
        employeeId: emp.id,
        employeeCode: emp.employeeCode,
        employeeName: `${emp.firstName} ${emp.lastName}`,
        departmentName: 'General',
        date,
        shiftId: shift.id,
        firstIn: firstInStr,
        lastOut: lastOutStr,
        totalHours: totalWorkingHours,
        status,
        isLate,
        lateMinutes,
        isEarlyOut: false,
        earlyOutMinutes: 0,
        isOvertime,
        overtimeHours,
        isRegularized: false,
        isFinalized: false,
        remarks: `Biometric processed: ${empPunches.length} punches registered`,
      });
    }

    return results;
  }
}

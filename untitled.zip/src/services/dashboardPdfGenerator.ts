// RSTPL HRMS - Executive Dashboard KPI PDF Generator
// RS Technovisions XpertSkillCop
// Generates a comprehensive, corporate-grade PDF snapshot of dashboard metrics

import { jsPDF } from 'jspdf';
import { BiometricDevice, Department } from '../types/hrms';

export interface DashboardMetricsSnapshot {
  organizationName: string;
  generatedByRole: string;
  generatedAt: Date;
  kpis: {
    activeEmployees: number;
    totalEmployees: number;
    employeeTrendPct: number;
    prevMonthActiveEmployees: number;
    probationEmployees: number;

    pendingLeaves: number;
    approvedLeavesThisMonth: number;
    leaveBacklogTrendPct: number;
    prevMonthPendingLeaves: number;

    totalPayrollExpense: number;
    totalNetSalaryDisbursed: number;
    payrollTrendPct: number;
    prevMonthPayrollExpense: number;
    payrollMonth: string;

    attendanceRate: number;
    presentToday: number;
    absentToday: number;
    onLeaveToday: number;
    lateToday: number;
    attendanceTrendPct: number;
    prevMonthAttendanceRate: number;
  };
  biometrics: {
    devices: BiometricDevice[];
    onlineCount: number;
    totalCount: number;
    averageLatency: number;
    totalPunchesSynced: number;
    criticalAlertsCount: number;
  };
  workforce: {
    departments: { name: string; count: number; code: string }[];
    openVacancies: number;
  };
}

export const generateDashboardPdfReport = (snapshot: DashboardMetricsSnapshot): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const margin = 14;
  const contentWidth = pageWidth - margin * 2; // 182mm
  let y = 0;

  // 1. TOP EXECUTIVE HEADER BANNER (Navy #0F172A)
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, pageWidth, 32, 'F');

  // Accent line (Sky-500)
  doc.setFillColor(14, 165, 233);
  doc.rect(0, 31, pageWidth, 1.5, 'F');

  // Header Title
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('RSTPL HRMS - EXECUTIVE DASHBOARD REPORT', margin, 12);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(186, 230, 253); // sky-200
  doc.text(
    `Smart HR Solutions | ${snapshot.organizationName} | Generated for ${snapshot.generatedByRole}`,
    margin,
    18
  );

  // Timestamp and Document ID
  const dateStr = snapshot.generatedAt.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  const timeStr = snapshot.generatedAt.toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
  const docId = `RSTPL-KPI-${snapshot.generatedAt.getTime().toString().slice(-6)}`;

  doc.setFontSize(8);
  doc.setTextColor(226, 232, 240); // slate-200
  doc.text(`Date: ${dateStr} ${timeStr}`, pageWidth - margin, 12, { align: 'right' });
  doc.text(`Doc Ref: ${docId}`, pageWidth - margin, 17, { align: 'right' });
  doc.text(`Compliance: Factory Act & Statutory PF/ESIC`, pageWidth - margin, 22, { align: 'right' });

  y = 40;

  // 2. EXECUTIVE BRIEF & REPORT SUMMARY
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('1. EXECUTIVE WORKFORCE & OPERATIONAL SUMMARY', margin, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    `This report provides a verified snapshot of monthly operational KPIs, attendance rates, payroll liabilities,`,
    margin,
    y
  );
  y += 4.5;
  doc.text(
    `and biometric terminal hardware telemetry across all manufacturing and corporate sites (HQ, Chakan & Sanand).`,
    margin,
    y
  );
  y += 7;

  // 3. CORE KPI 4-CARD METRIC BLOCKS
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('2. CORE PERFORMANCE INDICATORS (KPIs) & MOM TRENDS', margin, y);
  y += 6;

  const cardWidth = (contentWidth - 6) / 2; // 88mm each
  const cardHeight = 32;

  // --- CARD 1: Active Workforce ---
  doc.setFillColor(248, 250, 252); // slate-50
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.roundedRect(margin, y, cardWidth, cardHeight, 2, 2, 'FD');

  // Accent bar left
  doc.setFillColor(2, 132, 199); // sky-600
  doc.rect(margin, y, 2.5, cardHeight, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  doc.text('TOTAL ACTIVE WORKFORCE', margin + 6, y + 6);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(15, 23, 42);
  doc.text(
    `${snapshot.kpis.activeEmployees}`,
    margin + 6,
    y + 14
  );

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(148, 163, 184);
  doc.text(`/ ${snapshot.kpis.totalEmployees} on Master Roster`, margin + 22, y + 14);

  // Trend
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(5, 150, 105); // emerald-600
  doc.text(
    `[+] ${snapshot.kpis.employeeTrendPct}% MoM growth`,
    margin + 6,
    y + 21
  );
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`(vs prev month: ${snapshot.kpis.prevMonthActiveEmployees} staff)`, margin + 42, y + 21);

  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Probation: ${snapshot.kpis.probationEmployees} | Headcount stability: 100%`, margin + 6, y + 27);

  // --- CARD 2: Pending Leave Requests ---
  const card2X = margin + cardWidth + 6;
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(card2X, y, cardWidth, cardHeight, 2, 2, 'FD');

  doc.setFillColor(217, 119, 6); // amber-600
  doc.rect(card2X, y, 2.5, cardHeight, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  doc.text('PENDING LEAVE REQUESTS', card2X + 6, y + 6);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(15, 23, 42);
  doc.text(`${snapshot.kpis.pendingLeaves}`, card2X + 6, y + 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(148, 163, 184);
  doc.text('Awaiting Department Approval', card2X + 16, y + 14);

  // Trend
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  const leaveColor = snapshot.kpis.leaveBacklogTrendPct <= 0 ? [5, 150, 105] : [217, 119, 6];
  doc.setTextColor(leaveColor[0], leaveColor[1], leaveColor[2]);
  doc.text(
    `[${snapshot.kpis.leaveBacklogTrendPct <= 0 ? 'v' : '^'}] ${snapshot.kpis.leaveBacklogTrendPct}% backlog delta`,
    card2X + 6,
    y + 21
  );
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`(vs prev month: ${snapshot.kpis.prevMonthPendingLeaves} reqs)`, card2X + 46, y + 21);

  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Approved MTD: ${snapshot.kpis.approvedLeavesThisMonth} approved requests`, card2X + 6, y + 27);

  y += cardHeight + 4;

  // --- CARD 3: Current Month Payroll ---
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin, y, cardWidth, cardHeight, 2, 2, 'FD');

  doc.setFillColor(16, 185, 129); // emerald-500
  doc.rect(margin, y, 2.5, cardHeight, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  doc.text(`TOTAL PAYROLL EXPENSE (${snapshot.kpis.payrollMonth.toUpperCase()})`, margin + 6, y + 6);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42);
  doc.text(
    `INR ${snapshot.kpis.totalPayrollExpense.toLocaleString('en-IN')}`,
    margin + 6,
    y + 14
  );

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(5, 150, 105);
  doc.text(
    `[+] ${snapshot.kpis.payrollTrendPct}% MoM increase`,
    margin + 6,
    y + 21
  );
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(
    `(prev: INR ${snapshot.kpis.prevMonthPayrollExpense.toLocaleString('en-IN')})`,
    margin + 45,
    y + 21
  );

  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    `Net Disbursed: INR ${snapshot.kpis.totalNetSalaryDisbursed.toLocaleString('en-IN')} | PF & ESIC incl.`,
    margin + 6,
    y + 27
  );

  // --- CARD 4: Attendance Rate ---
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(card2X, y, cardWidth, cardHeight, 2, 2, 'FD');

  doc.setFillColor(99, 102, 241); // indigo-500
  doc.rect(card2X, y, 2.5, cardHeight, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  doc.text("TODAY'S SHIFT ATTENDANCE RATE", card2X + 6, y + 6);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.setTextColor(15, 23, 42);
  doc.text(`${snapshot.kpis.attendanceRate}%`, card2X + 6, y + 14);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(148, 163, 184);
  doc.text(`(${snapshot.kpis.presentToday} Present on floor)`, card2X + 24, y + 14);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(snapshot.kpis.attendanceTrendPct >= 0 ? 5 : 225, snapshot.kpis.attendanceTrendPct >= 0 ? 150 : 29, snapshot.kpis.attendanceTrendPct >= 0 ? 105 : 72);
  doc.text(
    `[${snapshot.kpis.attendanceTrendPct >= 0 ? '+' : ''}${snapshot.kpis.attendanceTrendPct}%] vs Sept benchmark`,
    card2X + 6,
    y + 21
  );
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`(${snapshot.kpis.prevMonthAttendanceRate}% benchmark)`, card2X + 48, y + 21);

  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    `Leave: ${snapshot.kpis.onLeaveToday} | Absent: ${snapshot.kpis.absentToday} | Late marks: ${snapshot.kpis.lateToday}`,
    card2X + 6,
    y + 27
  );

  y += cardHeight + 8;

  // 4. BIOMETRIC HARDWARE FLEET TELEMETRY SECTION
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('3. BIOMETRIC HARDWARE FLEET & SITE CONNECTIVITY TELEMETRY', margin, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    `Fleet Status: ${snapshot.biometrics.onlineCount}/${snapshot.biometrics.totalCount} Terminals Online | Fleet Average Latency: ${snapshot.biometrics.averageLatency}ms (SLA Tolerance: <500ms) | Punches Ingested: ${snapshot.biometrics.totalPunchesSynced.toLocaleString('en-IN')}`,
    margin,
    y
  );
  y += 5;

  // Table Header
  const colX = [margin, margin + 46, margin + 86, margin + 118, margin + 146, margin + 168];
  doc.setFillColor(241, 245, 249); // slate-100
  doc.rect(margin, y, contentWidth, 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(51, 65, 85);

  doc.text('TERMINAL NAME', colX[0] + 2, y + 4.2);
  doc.text('SITE / LOCATION', colX[1], y + 4.2);
  doc.text('VENDOR & IP', colX[2], y + 4.2);
  doc.text('LATENCY (SLA)', colX[3], y + 4.2);
  doc.text('SYNCED PUNCHES', colX[4], y + 4.2);
  doc.text('STATUS', colX[5], y + 4.2);
  y += 6;

  // Table Rows
  snapshot.biometrics.devices.forEach((dev, idx) => {
    const rowBg = idx % 2 === 0 ? 255 : 248;
    doc.setFillColor(rowBg, rowBg, rowBg);
    doc.rect(margin, y, contentWidth, 6, 'F');

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(15, 23, 42);

    doc.text(dev.name.slice(0, 26), colX[0] + 2, y + 4.2);
    doc.text(dev.location.slice(0, 24), colX[1], y + 4.2);
    doc.text(`${dev.vendor} (${dev.ipAddress})`, colX[2], y + 4.2);

    const lat = dev.syncLatencyMs ?? 0;
    const latColor = dev.status === 'Offline' ? [100, 116, 139] : lat > 500 ? [225, 29, 72] : [5, 150, 105];
    doc.setTextColor(latColor[0], latColor[1], latColor[2]);
    doc.setFont('helvetica', 'bold');
    doc.text(dev.status === 'Offline' ? 'OFFLINE' : `${lat}ms (<500ms)`, colX[3], y + 4.2);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(51, 65, 85);
    doc.text(dev.totalSyncedPunches.toLocaleString(), colX[4], y + 4.2);

    const statusColor = dev.status === 'Online' ? [5, 150, 105] : [225, 29, 72];
    doc.setTextColor(statusColor[0], statusColor[1], statusColor[2]);
    doc.setFont('helvetica', 'bold');
    doc.text(dev.status.toUpperCase(), colX[5], y + 4.2);

    y += 6;
  });

  y += 6;

  // 5. DEPARTMENT HEADCOUNT & TALENT REQUISITIONS
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(15, 23, 42);
  doc.text('4. DEPARTMENTAL DISTRIBUTION & RECRUITMENT PIPELINE', margin, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  const deptSummaryStr = snapshot.workforce.departments
    .map(d => `${d.name}: ${d.count} staff`)
    .join('  |  ');
  doc.text(deptSummaryStr, margin, y);
  y += 4.5;
  doc.text(
    `Open Talent Requisitions: ${snapshot.workforce.openVacancies} approved vacancies actively sourcing candidates across manufacturing and operations.`,
    margin,
    y
  );
  y += 9;

  // 6. COMPLIANCE AUDIT & AUTHORIZED SIGN-OFF
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(margin, y, contentWidth, 24, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.text('STATUTORY COMPLIANCE & HR AUDIT SIGN-OFF BLOCK', margin + 4, y + 5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    'This operational summary is generated under digital authorization of RSTPL HRMS Enterprise Suite.',
    margin + 4,
    y + 10
  );
  doc.text(
    'Attendance records and biometric telemetry are cryptographically timestamped and reconciled with statutory PF & ESIC registers.',
    margin + 4,
    y + 14
  );
  doc.text(
    `Prepared by: Authorized HRMS User (${snapshot.generatedByRole})  |  Verification Code: ${docId}`,
    margin + 4,
    y + 19
  );

  // FOOTER
  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184);
  doc.text(
    `Confidential - RS Technovisions XpertSkillCop (RSTPL) - Page 1 of 1`,
    pageWidth / 2,
    290,
    { align: 'center' }
  );

  // Save PDF
  const filename = `RSTPL_Dashboard_KPI_Report_${dateStr.replace(/\s+/g, '_')}.pdf`;
  doc.save(filename);
};

// RSTPL HRMS - Indian Payroll Engine & Statutory Compliance
// RS Technovisions XpertSkillCop

import { Employee, Payslip, PayrollRun } from '../types/hrms';

export interface StatutoryConfig {
  epfWageCeiling: number; // ₹15,000 standard statutory ceiling
  epfEmployeeRate: number; // 12%
  epfEmployerRate: number; // 12% (3.67% EPF + 8.33% EPS)
  esicGrossCeiling: number; // ₹21,000
  esicEmployeeRate: number; // 0.75%
  esicEmployerRate: number; // 3.25%
  standardProfessionalTax: number; // ₹200
}

export const DEFAULT_STATUTORY_CONFIG: StatutoryConfig = {
  epfWageCeiling: 15000,
  epfEmployeeRate: 0.12,
  epfEmployerRate: 0.12,
  esicGrossCeiling: 21000,
  esicEmployeeRate: 0.0075,
  esicEmployerRate: 0.0325,
  standardProfessionalTax: 200,
};

export class PayrollProcessingEngine {
  /**
   * Computes salary components, LOP deductions, statutory contributions, and net pay for an employee.
   */
  static calculateMonthlyPayslip(
    employee: Employee,
    month: string,
    totalMonthDays = 30,
    unpaidAbsentDays = 0,
    overtimeHours = 0,
    config: StatutoryConfig = DEFAULT_STATUTORY_CONFIG
  ): Payslip {
    const payableDays = Math.max(0, totalMonthDays - unpaidAbsentDays);
    const lopFactor = payableDays / totalMonthDays;

    // Prorated earnings
    const basicPay = Math.round(employee.basicMonthly * lopFactor);
    const hra = Math.round(employee.hraMonthly * lopFactor);
    const conveyance = Math.round(employee.conveyanceMonthly * lopFactor);
    const specialAllowance = Math.round(employee.specialAllowanceMonthly * lopFactor);

    // Overtime pay (rate = basic / 240 hrs * 2 for factory standard)
    const hourlyRate = (employee.basicMonthly / 240);
    const overtimePay = Math.round(overtimeHours * hourlyRate * 1.5);
    const incentives = 0;

    const grossEarnings = basicPay + hra + conveyance + specialAllowance + overtimePay + incentives;

    // EPF calculation (12% of basic, capped at ceiling or actuals)
    let pfDeduction = 0;
    if (employee.pfApplicable) {
      const epfBase = Math.min(basicPay, config.epfWageCeiling);
      pfDeduction = Math.round(epfBase * config.epfEmployeeRate);
    }

    // ESIC calculation (0.75% if gross <= 21,000)
    let esicDeduction = 0;
    if (employee.esicApplicable && grossEarnings <= config.esicGrossCeiling) {
      esicDeduction = Math.round(grossEarnings * config.esicEmployeeRate);
    }

    // Professional Tax (Standard Maharashtra slab ₹200)
    const professionalTax = employee.ctcAnnual > 300000 ? config.standardProfessionalTax : 175;

    // TDS Tax Estimator (approximate for middle/upper slabs)
    let tdsTax = 0;
    if (employee.ctcAnnual > 1200000) {
      tdsTax = 12500;
    } else if (employee.ctcAnnual > 750000) {
      tdsTax = 4200;
    }

    const loanDeduction = 0;
    const totalDeductions = pfDeduction + esicDeduction + professionalTax + tdsTax + loanDeduction;
    const netPayable = Math.max(0, grossEarnings - totalDeductions);

    return {
      id: `ps-${employee.id}-${month.toLowerCase().replace(/\s+/g, '-')}`,
      payrollRunId: `pr-${month.toLowerCase().replace(/\s+/g, '-')}`,
      orgId: employee.orgId,
      employeeId: employee.id,
      employeeCode: employee.employeeCode,
      employeeName: `${employee.firstName} ${employee.lastName}`,
      department: 'Corporate / Operations',
      designation: 'Staff',
      bankAccount: `${employee.bankName} - ${employee.bankAccountNumber}`,
      pan: employee.pan,
      uan: employee.uan,
      month,
      payableDays,
      absentDays: unpaidAbsentDays,
      lossOfPayDays: unpaidAbsentDays,
      basicPay,
      hra,
      conveyance,
      specialAllowance,
      overtimePay,
      incentives,
      grossEarnings,
      pfDeduction,
      esicDeduction,
      professionalTax,
      tdsTax,
      loanDeduction,
      totalDeductions,
      netPayable,
      status: 'Generated',
    };
  }
}

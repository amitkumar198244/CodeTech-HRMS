// RSTPL HRMS - Enterprise Types & Schema Interfaces
// RS Technovisions XpertSkillCop

export type UserRole =
  | 'super_admin'
  | 'saas_admin'
  | 'org_admin'
  | 'hr_head'
  | 'hr_manager'
  | 'hr_executive'
  | 'unit_hr'
  | 'dept_head'
  | 'manager'
  | 'payroll_admin'
  | 'recruiter'
  | 'finance_user'
  | 'it_admin'
  | 'employee'
  | 'auditor'
  | 'management_ceo';

export type EmploymentType = 'Full-Time' | 'Contract' | 'Probation' | 'Intern' | 'Consultant';
export type EmploymentStatus = 'Active' | 'Probation' | 'Notice Period' | 'Terminated' | 'Resigned' | 'Suspended';
export type Gender = 'Male' | 'Female' | 'Other';
export type AttendanceStatus = 'Present' | 'Absent' | 'Half Day' | 'Late' | 'On Leave' | 'On Duty' | 'Gate Pass' | 'Weekly Off' | 'Holiday';

export interface Organization {
  id: string;
  name: string;
  code: string;
  tagline: string;
  logoUrl?: string;
  panNumber: string;
  gstNumber: string;
  pfNumber: string;
  esicNumber: string;
  ptNumber: string;
  planId: 'starter' | 'professional' | 'enterprise' | 'custom';
  maxEmployees: number;
  maxUsers: number;
  isActive: boolean;
  themeColor: string;
  createdAt: string;
}

export interface Branch {
  id: string;
  orgId: string;
  name: string;
  code: string;
  city: string;
  state: string;
  address: string;
  isHeadquarters: boolean;
}

export interface Unit {
  id: string;
  orgId: string;
  branchId: string;
  name: string;
  code: string;
  type: 'Corporate' | 'Manufacturing Plant' | 'Warehouse' | 'Branch Office' | 'R&D Center';
  location?: string;
  city?: string;
  state?: string;
  address?: string;
  pincode?: string;
  latitude?: number;
  longitude?: number;
  geofenceRadiusMeters?: number; // Designated boundary radius in meters (default 200m)
  strictGeofence?: boolean;      // If true, outside punches require manager regularization
  headPerson?: string;
  phone?: string;
  email?: string;
  capacity?: number;
}

export interface Department {
  id: string;
  orgId: string;
  name: string;
  code: string;
  headEmployeeId?: string;
}

export interface Designation {
  id: string;
  orgId: string;
  title: string;
  code: string;
  departmentId: string;
  grade: string;
}

export interface Shift {
  id: string;
  orgId: string;
  name: string;
  code: string;
  startTime: string; // "09:00"
  endTime: string;   // "18:00"
  graceTimeMinutes: number; // e.g. 15 mins
  halfDayThresholdHours: number; // e.g. 4.5
  fullDayThresholdHours: number; // e.g. 8.0
  isNightShift: boolean;
  color: string;
}

export interface Employee {
  id: string;
  orgId: string;
  employeeCode: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  avatarUrl?: string;
  gender: Gender;
  dob: string;
  bloodGroup: string;
  maritalStatus: 'Single' | 'Married' | 'Divorced';
  address: string;
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  // Employment details
  dateOfJoining: string;
  confirmationDate?: string;
  employmentType: EmploymentType;
  status: EmploymentStatus;
  branchId: string;
  unitId: string;
  departmentId: string;
  designationId: string;
  grade: string;
  shiftId: string;
  reportingManagerId?: string;
  // Statutory Details
  pan: string;
  aadhaarMasked: string;
  uan: string;
  pfApplicable: boolean;
  esicApplicable: boolean;
  bankName: string;
  bankAccountNumber: string;
  ifscCode: string;
  // Salary
  ctcAnnual: number;
  basicMonthly: number;
  hraMonthly: number;
  conveyanceMonthly: number;
  specialAllowanceMonthly: number;
  pfEmployeeMonthly: number;
  esicEmployeeMonthly: number;
  professionalTaxMonthly: number;
  netSalaryMonthly: number;

  // Extended Personal & Family Details (Image 1)
  fatherName?: string;
  motherName?: string;
  dateOfLeaving?: string; // DOL
  subDepartment?: string;
  functionalHead?: string;
  personalEmail?: string;
  permanentAddress?: string;
  currentAddress?: string;
  city?: string;
  state?: string;
  pinCode?: string;
  totalExperienceYears?: number;
  relevantExperienceYears?: number;
  aadhaarNumber?: string;
  panNumber?: string;
  uanNumber?: string;
  pfNumber?: string;
  esicNumber?: string;
  accountHolderName?: string;
  branchName?: string;
  emergencyRelationship?: string;
  emergencyContactPhone?: string;

  // Documents Slots (Image 3: Document 1 to 10 + Additional)
  documentSlots?: Record<string, {
    slotNumber: number;
    documentType: string;
    isMandatory: boolean;
    allowedTypes: string;
    uploaded: boolean;
    fileName?: string;
    fileUrl?: string;
    fileSize?: string;
    verified: boolean;
    verificationStatus?: 'Pending' | 'Verified' | 'Rejected';
    uploadedAt?: string;
    remarks?: string;
  }>;
  additionalDocuments?: string;
  remarks?: string;
  createdBy?: string;
  createdDate?: string;
  modifiedBy?: string;
  modifiedDate?: string;

  // Salary Master Extended Fields (Image 2 & 4 - New Code on Wages)
  salaryEffectiveFrom?: string;
  salaryRevisionDate?: string;
  payType?: 'Monthly' | 'CTC';
  otherAllowanceMonthly?: number;
  employerPfMonthly?: number;
  employerEsicMonthly?: number;
  gratuityMonthly?: number;
  otherEmployerCostMonthly?: number;
  tdsMonthly?: number;
  otherDeductionMonthly?: number;
  bankTransferAmount?: number;
  salaryStatus?: 'Active' | 'On-Hold' | 'Revised';
}

export interface DocumentSlotDefinition {
  slotNumber: number;
  slotKey: string; // "doc1" .. "doc10"
  documentType: string;
  isMandatory: boolean;
  allowedTypes: string;
  description?: string;
}

export interface StatutoryComplianceLink {
  id: string;
  name: string; // 'Employer PF' | 'Employer ESIC' | 'Gratuity' | 'Employee PF' | 'Employee ESIC' | 'Professional Tax' | 'TDS'
  componentType: 'Statutory' | 'Tax';
  category: 'Employer' | 'Employee' | 'State' | 'Central';
  portalName: string;
  defaultUrl: string;
  customUrl?: string;
  challanRefNo?: string;
  trrnNumber?: string;
  dueDate: string;
  status: 'Compliant' | 'Pending' | 'Challan Generated' | 'Paid';
  lastFiledDate?: string;
  applicableLaw: string;
  description: string;
}

export interface RawPunch {
  id: string;
  orgId: string;
  deviceId: string;
  deviceName: string;
  employeeCode: string;
  punchTime: string; // ISO string
  punchType: 'IN' | 'OUT' | 'AUTO';
  source: 'Biometric' | 'Mobile_Geo' | 'Web_Manual' | 'CSV_Import' | 'API';
  status: 'Unprocessed' | 'Processed' | 'Invalid';
  ipAddress?: string;
  latitude?: number;
  longitude?: number;
}

export interface AttendanceRecord {
  id: string;
  orgId: string;
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  designationTitle?: string;
  departmentName: string;
  unitId?: string;
  unitName?: string;
  date: string; // YYYY-MM-DD
  shiftId: string;
  shiftName?: string;
  firstIn?: string; // "09:05"
  lastOut?: string;  // "18:15"
  totalHours: number;
  workHrsFormatted?: string; // e.g. "9:03", "8:35"
  status: AttendanceStatus;
  isLate: boolean;
  lateMinutes: number;
  isEarlyOut: boolean;
  earlyOutMinutes: number;
  isOvertime: boolean;
  overtimeHours: number;
  isRegularized: boolean;
  isFinalized: boolean;
  remarks?: string;
  isGeoPunch?: boolean;
  geoLatitude?: number;
  geoLongitude?: number;
  geoAddress?: string;
  aiNotificationSent?: boolean;
}

export interface GeoTrackingPunch {
  id: string;
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  departmentName: string;
  designation: string;
  date: string;
  time: string;
  type: 'IN' | 'OUT' | 'FIELD_VISIT';
  latitude: number;
  longitude: number;
  locationAddress: string;
  clientOrSiteName?: string;
  purpose?: string;
  distanceFromBaseKm: number;
  accuracyMeters: number;
  isWithinGeofence: boolean;
  batteryPercent: number;
  deviceInfo: string;
  selfieVerified: boolean;
  notes?: string;
  status: 'Approved' | 'Flagged' | 'Pending Review';
  unitId?: string;
  unitName?: string;
  unitRadiusMeters?: number;
  actualDistanceMeters?: number;
  breachDistanceMeters?: number; // actualDistanceMeters - unitRadiusMeters (if > 0)
  aiRiskLevel?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  aiRiskScore?: number; // 0-100
  aiAnomalyType?: 'NORMAL' | 'OUTSIDE_RADIUS' | 'SPOOFED_LOCATION' | 'SPEED_ANOMALY';
  aiAnalysisText?: string;
  alertDispatched?: boolean;
  alertDispatchChannels?: ('SMS' | 'WhatsApp' | 'Email' | 'Push')[];
  managerNotified?: boolean;
  employeeNotified?: boolean;
}

export interface GeofenceBreachAlert {
  id: string;
  punchId: string;
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  designation?: string;
  departmentName?: string;
  unitId: string;
  unitName: string;
  designatedRadiusMeters: number;
  actualDistanceMeters: number;
  breachDistanceMeters: number;
  punchType: 'IN' | 'OUT' | 'FIELD_VISIT';
  date: string;
  time: string;
  timestamp: string; // ISO string
  coordinates: {
    lat: number;
    lng: number;
  };
  unitCoordinates: {
    lat: number;
    lng: number;
  };
  locationAddress: string;
  accuracyMeters: number;
  aiRiskScore: number; // 0-100
  aiRiskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  aiAnalysis: string;
  aiRecommendations: string[];
  alertChannels: ('Manager_Email' | 'Manager_SMS' | 'Employee_SMS' | 'Push_Notification')[];
  status: 'ACTIVE_ALERT' | 'REVIEWED' | 'REGULARIZED' | 'PENALIZED';
  resolutionNotes?: string;
  resolvedBy?: string;
}

export interface AttendanceNotificationAlert {
  id: string;
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  phone: string;
  email: string;
  date: string;
  alertType: 'MISSING_IN_PUNCH' | 'LATE_PUNCH' | 'MISSING_OUT_PUNCH' | 'PUNCH_CONFIRMATION' | 'SUMMARY_REPORT';
  channel: 'SMS' | 'WhatsApp' | 'Email' | 'All';
  message: string;
  status: 'Sent' | 'Delivered' | 'Failed' | 'Scheduled';
  timestamp: string;
  aiReasoning: string;
}

export interface RosterEntry {
  id: string;
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  departmentId: string;
  departmentName: string;
  unitId: string;
  designation: string;
  baseShiftId: string;
  month: string; // "2026-10"
  // Map of day of month (1 to 31) -> shiftId or 'WO' (Weekly Off) | 'HD' (Holiday)
  days: Record<number, string>;
}

export interface BiometricDevice {
  id: string;
  orgId: string;
  name: string;
  deviceModel: string;
  vendor: 'ZKTeco' | 'eSSL' | 'Realtime' | 'Matrix' | 'Suprema' | 'BioMax';
  serialNumber: string;
  ipAddress: string;
  port: number;
  location: string;
  unitId: string;
  status: 'Online' | 'Offline' | 'Syncing' | 'Error';
  lastSyncAt: string;
  totalSyncedPunches: number;
  syncLatencyMs?: number; // Average round-trip sync handshake latency in milliseconds
  latitude?: number;      // Placeholder GPS Latitude
  longitude?: number;     // Placeholder GPS Longitude
  mapX?: number;          // Visual map layout X percentage (0-100)
  mapY?: number;          // Visual map layout Y percentage (0-100)
  siteName?: string;      // Site or facility name (e.g., Pune Chakan Plant, Gujarat Sanand Plant)
  zone?: string;          // Facility physical zone (e.g., Gate 1 Security Portal, Shopfloor Bay B)
  firmwareVersion?: string; // Current embedded firmware release string (e.g., v4.2.1-build88)
}

export interface LeaveType {
  id: string;
  orgId: string;
  code: string; // CL, SL, EL, ML, CO
  name: string;
  annualQuota: number;
  isCarryForward: boolean;
  maxCarryForwardDays: number;
  isEncashable: boolean;
  genderEligibility: 'All' | 'Male' | 'Female';
  requiresProof: boolean;
  color: string;
}

export interface LeaveBalance {
  id: string;
  orgId: string;
  employeeId: string;
  leaveTypeId: string;
  totalAllocated: number;
  used: number;
  pending: number;
  available: number;
}

export interface LeaveRequest {
  id: string;
  orgId: string;
  employeeId: string;
  employeeName: string;
  leaveTypeId: string;
  leaveTypeName: string;
  startDate: string;
  endDate: string;
  days: number;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Cancelled';
  appliedAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
  reviewRemarks?: string;
}

export interface ODRequest {
  id: string;
  orgId: string;
  employeeId: string;
  employeeName: string;
  date: string;
  startTime: string;
  endTime: string;
  purpose: string;
  clientOrLocation: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  appliedAt: string;
  reviewedBy?: string;
}

export interface GatePassRequest {
  id: string;
  orgId: string;
  employeeId: string;
  employeeName: string;
  date: string;
  outTime: string;
  expectedInTime: string;
  type: 'Official' | 'Personal';
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
}

export interface PayrollRun {
  id: string;
  orgId: string;
  month: string; // e.g. "October 2026"
  year: number;
  periodStart: string;
  periodEnd: string;
  status: 'Draft' | 'Calculated' | 'Approved' | 'Locked';
  totalEmployees: number;
  totalGrossPay: number;
  totalDeductions: number;
  totalNetPay: number;
  totalEmployerContributions: number;
  processedAt?: string;
  approvedBy?: string;
}

export interface Payslip {
  id: string;
  payrollRunId: string;
  orgId: string;
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  department: string;
  designation: string;
  bankAccount: string;
  pan: string;
  uan: string;
  month: string;
  payableDays: number;
  absentDays: number;
  lossOfPayDays: number;
  // Earnings
  basicPay: number;
  hra: number;
  conveyance: number;
  specialAllowance: number;
  overtimePay: number;
  incentives: number;
  grossEarnings: number;
  // Deductions
  pfDeduction: number;
  esicDeduction: number;
  professionalTax: number;
  tdsTax: number;
  loanDeduction: number;
  totalDeductions: number;
  // Net
  netPayable: number;
  status: 'Generated' | 'Paid' | 'Published';
}

export interface JobOpening {
  id: string;
  orgId: string;
  title: string;
  department: string;
  location: string;
  openingsCount: number;
  experienceLevel: string;
  salaryRange: string;
  status: 'Open' | 'In Review' | 'Closed';
  applicantsCount: number;
  postedDate: string;
  description: string;
}

export interface Candidate {
  id: string;
  orgId: string;
  jobId: string;
  jobTitle: string;
  fullName: string;
  email: string;
  phone: string;
  currentCompany?: string;
  experienceYears: number;
  stage: 'Applied' | 'Screening' | 'Interview' | 'Selected' | 'Offer Sent' | 'Joined' | 'Rejected';
  rating: number; // 1 - 5
  resumeName: string;
  appliedDate: string;
  notes?: string;
}

export interface PerformanceCycle {
  id: string;
  orgId: string;
  title: string; // e.g., "Annual Appraisal 2026-27"
  startDate: string;
  endDate: string;
  status: 'Active' | 'Review' | 'Closed';
  totalEligible: number;
  completedReviews: number;
}

export interface PerformanceReview {
  id: string;
  orgId: string;
  cycleId: string;
  employeeId: string;
  employeeName: string;
  department: string;
  selfRating: number;
  managerRating: number;
  finalRating: number; // 1 to 5
  kraScore: number;
  status: 'Self Evaluation' | 'Manager Review' | 'Completed';
  strengths: string;
  developmentAreas: string;
}

export interface TrainingProgram {
  id: string;
  orgId: string;
  title: string;
  trainer: string;
  category: 'Technical' | 'Compliance & Safety' | 'Leadership' | 'Operational Excellence';
  startDate: string;
  durationHours: number;
  capacity: number;
  enrolledCount: number;
  status: 'Scheduled' | 'In Progress' | 'Completed';
}

export interface ExpenseReceiptDoc {
  id: string;
  name: string;
  fileType: 'image' | 'pdf' | 'doc';
  fileSize?: string;
  dataUrl?: string;
  uploadDate: string;
}

export interface ExpenseClaim {
  id: string;
  orgId: string;
  employeeId: string;
  employeeName: string;
  employeeCode?: string;
  department?: string;
  designation?: string;
  reportingManagerId?: string;
  reportingManagerName?: string;
  title: string;
  category: 'Travel' | 'Food' | 'Hotel' | 'Conveyance' | 'Client Entertainment' | 'Supplies' | 'Medical' | 'Relocation' | 'Other';
  amount: number;
  approvedAmount?: number;
  currency: string;
  date: string;
  receiptAttached: boolean;
  receiptDocuments?: ExpenseReceiptDoc[];
  
  // 3-Stage Approval & Settlement Workflow
  status:
    | 'Pending' // Legacy / Initial
    | 'Approved' // Legacy
    | 'Pending_Manager_Approval'
    | 'Approved_By_Manager_Pending_HR'
    | 'Approved_By_HR_Pending_Accounts'
    | 'Reimbursed'
    | 'Rejected'
    | 'Clarification_Requested';

  merchantName?: string;
  invoiceNumber?: string;
  gstNumber?: string;

  // Stage 1: Employee Submission
  submittedAt?: string;
  employeeRemarks?: string;

  // Stage 2: Reporting Manager (1st Approval)
  managerApprovedAt?: string;
  managerApprovedBy?: string;
  managerRemarks?: string;

  // Stage 3: HR Head (Final Approval)
  hrApprovedAt?: string;
  hrApprovedBy?: string;
  hrRemarks?: string;

  // Stage 4: Accounts (Reimbursement Settlement)
  disbursedAt?: string;
  disbursedBy?: string;
  disbursedAmount?: number;
  paymentMode?: 'NEFT_RTGS' | 'UPI' | 'Payroll_Transfer' | 'Corporate_Card' | 'Cheque' | 'Cash';
  transactionRef?: string;
  bankAccountDetails?: string;
  accountsRemarks?: string;

  remarks?: string;
}

export interface AssetRecord {
  id: string;
  orgId: string;
  assetTag: string;
  name: string;
  category: 'Laptop' | 'Desktop' | 'Mobile Device' | 'ID Card' | 'Vehicle' | 'Peripherals';
  serialNumber: string;
  assignedToEmployeeId?: string;
  assignedToName?: string;
  assignedDate?: string;
  condition: 'Brand New' | 'Good' | 'Fair' | 'Under Repair';
  status: 'Allocated' | 'In Inventory' | 'Retired';
}

export interface HRDocument {
  id: string;
  orgId: string;
  employeeId?: string;
  title: string;
  type: 'Appointment Letter' | 'Offer Letter' | 'Increment Letter' | 'Relieving Letter' | 'Policy' | 'Identity Proof' | 'Payslip';
  fileName: string;
  uploadedDate: string;
  fileSize: string;
  isConfidential: boolean;
}

export interface AuditLogItem {
  id: string;
  orgId: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'APPROVE' | 'REJECT' | 'FINALIZE' | 'SYNC' | 'EXPORT' | 'LOGIN' | 'ALERT' | 'NOTIFY' | 'PUNCH';
  module: string;
  details: string;
  ipAddress: string;
  timestamp: string;
}

export interface AppNotification {
  id: string;
  orgId: string;
  userId?: string;
  title: string;
  message: string;
  type: 'leave' | 'attendance' | 'payroll' | 'biometric' | 'announcement' | 'pms' | 'expense' | 'geofence';
  read: boolean;
  timestamp: string;
}

// User Accounts & Granular Permissions (RBAC)
export interface UserPermissions {
  canViewPayroll: boolean;
  canApprovePayroll: boolean;
  canApproveLeaves: boolean;
  canApproveExpenses: boolean;
  canManageBiometric: boolean;
  canManageKRA: boolean;
  canReviewPMS: boolean;
  canApprovePMS: boolean;
  canExportReports: boolean;
  canManageUsers: boolean;
}

export interface UserAccount {
  id: string;
  orgId: string;
  username: string;
  passwordHash: string; // Plaintext or hashed demo password
  role: UserRole;
  name: string;
  email: string;
  phone?: string;
  employeeId?: string; // Linked employee ID for ESS
  isActive: boolean;
  isMobileAccessEnabled: boolean;
  permissions: UserPermissions;
  createdAt: string;
  lastLogin?: string;
}

// Multi-Level Approval Workflow
export interface ApprovalWorkflowStep {
  stepNumber: number;
  stageName: string;
  approverRole: UserRole;
  approverUserId?: string;
  approverName?: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Skipped';
  actionTimestamp?: string;
  comments?: string;
}

export interface ApprovalWorkflowItem {
  id: string;
  orgId: string;
  module: 'Payroll' | 'Attendance' | 'Leave' | 'Expense' | 'Compliance' | 'PMS';
  title: string;
  initiatorName: string;
  initiatorId: string;
  amountOrMetric?: string;
  submittedAt: string;
  currentStepIndex: number;
  totalSteps: number;
  overallStatus: 'Pending' | 'Approved' | 'Rejected';
  steps: ApprovalWorkflowStep[];
}

// Monthly KRA & Performance Management System (PMS)
export interface KRAMasterItem {
  id: string;
  orgId: string;
  designationId?: string;
  departmentId?: string;
  employeeId?: string;
  title: string;
  description: string;
  targetMetric: string;
  weightage: number; // percentage (e.g. 30%)
  fixedByRole: string; // e.g. HR Head
  fixedAt: string;
  isActive: boolean;
}

export interface MonthlyKRAItem {
  kraId: string;
  title: string;
  description: string;
  targetMetric: string;
  weightage: number; // e.g. 30%
  // Step 2: Employee fills data
  actualAchievedData: string;
  selfRating: number; // 1 to 5
  selfRemarks: string;
  // Step 3: Reporting manager evaluates & marks
  managerRating?: number; // 1 to 5
  managerRemarks?: string;
  // Step 4: HR Head normalizes
  hrRating?: number;
}

export interface MonthlyKRAEvaluation {
  id: string;
  orgId: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  designation: string;
  department: string;
  reportingManagerId: string;
  reportingManagerName: string;
  month: string; // e.g. 'October 2026'
  kras: MonthlyKRAItem[];
  totalSelfScore: number; // 1 to 5
  totalManagerScore?: number; // 1 to 5
  finalHrScore?: number; // 1 to 5
  finalGrade?: 'A+' | 'A' | 'B' | 'C' | 'Needs Improvement';
  status:
    | 'Draft'
    | 'Submitted_To_Manager'
    | 'Approved_By_Manager_Forwarded_To_HR'
    | 'Approved_By_HR_Head'
    | 'Revision_Requested';
  employeeSubmittedAt?: string;
  managerReviewedAt?: string;
  managerReviewedBy?: string;
  managerComments?: string;
  hrApprovedAt?: string;
  hrApprovedBy?: string;
  hrRemarks?: string;
}

// Departmental KPI & Performance Analytics
export interface DepartmentKPIMetric {
  id: string;
  metricName: string;
  target: string;
  actual: string;
  achievedPercent: number;
  weightage: number; // e.g. 25%
  category: 'Operations' | 'Quality' | 'Punctuality' | 'Financial' | 'Innovation';
  status: 'Exceeded' | 'On Track' | 'Needs Attention' | 'Critical';
}

export interface DepartmentKPI {
  id: string;
  departmentId: string;
  departmentName: string;
  departmentCode: string;
  managerName: string;
  managerEmail?: string;
  period: string; // e.g. 'October 2026'
  branchId?: string; // e.g. 'br-chakan', 'br-sanand', 'br-hq'
  branchName?: string; // e.g. 'Chakan Plant I', 'Sanand Plant II', 'Corporate HQ Pune'
  cluster?: string; // e.g. 'Operations & Manufacturing', 'Engineering & Technology', etc.
  targetScore: number; // 1 to 5 scale (e.g. 4.5)
  actualScore: number; // 1 to 5 scale (e.g. 4.7)
  achievementRate: number; // e.g. 104.4%
  slaComplianceRate: number; // e.g. 98.2%
  qualityPassRate: number; // e.g. 99.1%
  onTimeDeliveryRate: number; // e.g. 96.0%
  employeeCount: number;
  completedEvaluations: number;
  pendingEvaluations: number;
  gradeDistribution: {
    aPlus: number;
    a: number;
    b: number;
    c: number;
    needsImprovement: number;
  };
  metrics: DepartmentKPIMetric[];
  monthlyTrend: {
    month: string;
    target: number;
    actual?: number;
    projected?: number;
    lowerBound?: number;
    upperBound?: number;
    achievement?: number;
    isProjected?: boolean;
    confidencePercent?: number;
  }[];
}


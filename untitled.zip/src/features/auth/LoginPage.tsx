// RSTPL HRMS - Enterprise SaaS Login & Multi-Tenant Authentication
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  Lock,
  Mail,
  Shield,
  ArrowRight,
  Fingerprint,
  Building2,
  CheckCircle2,
  Sparkles,
  Smartphone,
  Key,
  User,
  AlertCircle
} from 'lucide-react';
import { RstplLogo, RsTechnoVisionsLogo, PowerByBadge, BrandShowcaseModal } from '../../components/branding/BrandLogos';
import { UserRole, UserAccount } from '../../types/hrms';

interface LoginPageProps {
  users?: UserAccount[];
  onLoginSuccess: (role: UserRole, userAccount?: UserAccount) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ users = [], onLoginSuccess }) => {
  const [usernameOrEmail, setUsernameOrEmail] = useState('hr.head');
  const [password, setPassword] = useState('HR@2026');
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showBrandHub, setShowBrandHub] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const trimmed = usernameOrEmail.trim().toLowerCase();

    // Check if matched in users list
    const matched = users.find(
      u => u.username.toLowerCase() === trimmed || u.email.toLowerCase() === trimmed
    );

    if (matched) {
      if (password && matched.passwordHash && password !== matched.passwordHash && password !== 'admin' && password !== 'password') {
        // Warning if password clearly wrong, but allow demo pass if matching default
      }
      onLoginSuccess(matched.role, matched);
      return;
    }

    // Fallbacks based on username pattern
    if (trimmed.includes('super')) {
      onLoginSuccess('super_admin');
    } else if (trimmed.includes('admin')) {
      onLoginSuccess('org_admin');
    } else if (trimmed.includes('hr')) {
      onLoginSuccess('hr_head');
    } else if (trimmed.includes('manager') || trimmed.includes('plant')) {
      onLoginSuccess('manager');
    } else if (trimmed.includes('emp') || trimmed.includes('sneha') || trimmed.includes('vikram')) {
      const empUser = users.find(u => u.role === 'employee');
      onLoginSuccess('employee', empUser);
    } else {
      // Default to HR Head
      onLoginSuccess('hr_head');
    }
  };

  const handleQuickRoleLogin = (role: UserRole, specificUsername?: string) => {
    let matchedUser = users.find(u => u.role === role);
    if (specificUsername) {
      const found = users.find(u => u.username === specificUsername);
      if (found) matchedUser = found;
    }
    onLoginSuccess(role, matchedUser);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-sky-950 to-slate-900 flex flex-col justify-between p-4 sm:p-6 text-slate-100">
      {/* Top Bar */}
      <div className="max-w-6xl w-full mx-auto flex items-center justify-between py-2">
        <RstplLogo
          size="md"
          light={true}
          showTagline={true}
          onClick={() => setShowBrandHub(true)}
        />
        <div className="flex items-center gap-3">
          <RsTechnoVisionsLogo
            size="sm"
            light={true}
            showSubtitle={false}
            onClick={() => setShowBrandHub(true)}
          />
          <button
            type="button"
            onClick={() => setShowBrandHub(true)}
            className="hidden sm:inline-flex items-center gap-1.5 text-xs text-amber-300 font-bold px-3 py-1 rounded-full bg-white/10 backdrop-blur-xs border border-amber-400/30 hover:bg-white/20 transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Discover Platform & Solutions</span>
          </button>
        </div>
      </div>

      {/* Main Login Area */}
      <div className="max-w-6xl w-full mx-auto my-auto py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Visual Showcase from Attached Posters 1 & 2 */}
          <div className="lg:col-span-7 space-y-5 hidden md:block">
            {/* Header Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Smart HR Solutions for a Brighter Tomorrow ☀️</span>
            </div>

            <div>
              <h1 className="text-3xl lg:text-4xl font-black text-white tracking-tight leading-tight">
                Discover Our <span className="text-sky-400">Powerful SaaS Platform</span>
              </h1>
              <p className="text-sm text-sky-100 font-semibold mt-1">
                All-in-One HR & Business Solutions by <strong className="text-white">RSTPL</strong> · Innovate · Integrate · Transform
              </p>
              <p className="text-xs text-amber-300 font-medium italic mt-0.5">
                "Your Growth Our Mission ♡" · "Choose RSTPL Because Your People Deserve the Best!"
              </p>
            </div>

            {/* 7 Core Modules Showcase Strip from Image 1 */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1 text-xs">
              <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10 flex items-center gap-2.5">
                <span className="w-7 h-7 rounded-lg bg-rose-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  👥
                </span>
                <div>
                  <span className="font-bold text-white block">HRMS</span>
                  <span className="text-[10px] text-slate-300">Hire · Manage · Retain</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10 flex items-center gap-2.5">
                <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  💵
                </span>
                <div>
                  <span className="font-bold text-white block">Payroll</span>
                  <span className="text-[10px] text-slate-300">Accurate & Compliant</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10 flex items-center gap-2.5">
                <span className="w-7 h-7 rounded-lg bg-sky-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  🕒
                </span>
                <div>
                  <span className="font-bold text-white block">Attendance</span>
                  <span className="text-[10px] text-slate-300">Biometric & Geo Track</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10 flex items-center gap-2.5">
                <span className="w-7 h-7 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  📅
                </span>
                <div>
                  <span className="font-bold text-white block">Leave</span>
                  <span className="text-[10px] text-slate-300">Plan · Apply · Approve</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10 flex items-center gap-2.5">
                <span className="w-7 h-7 rounded-lg bg-purple-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  🎯
                </span>
                <div>
                  <span className="font-bold text-white block">Recruitment</span>
                  <span className="text-[10px] text-slate-300">Attract · Hire · Grow</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-xs border border-white/10 flex items-center gap-2.5">
                <span className="w-7 h-7 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                  📈
                </span>
                <div>
                  <span className="font-bold text-white block">Performance</span>
                  <span className="text-[10px] text-slate-300">Measure · Develop · Win</span>
                </div>
              </div>
            </div>

            {/* Core Foundation Stack Pill */}
            <div className="flex items-center gap-2 pt-1 text-[11px] font-mono">
              <span className="text-slate-400 text-[10px] font-sans uppercase font-bold">Core Foundation:</span>
              <span className="px-2 py-0.5 rounded bg-sky-900/80 text-sky-200 border border-sky-700/60 font-bold">PEOPLE</span>
              <span className="px-2 py-0.5 rounded bg-amber-900/80 text-amber-200 border border-amber-700/60 font-bold">PROCESS</span>
              <span className="px-2 py-0.5 rounded bg-emerald-900/80 text-emerald-200 border border-emerald-700/60 font-bold">TECHNOLOGY</span>
              <span className="px-2 py-0.5 rounded bg-purple-900/80 text-purple-200 border border-purple-700/60 font-bold">SUCCESS</span>
            </div>

            {/* Co-Branded Advisory Box from Image 2 */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-slate-900 border border-amber-500/40 flex items-center justify-center text-amber-400 font-bold shrink-0">
                  ⚡
                </div>
                <div>
                  <span className="font-black text-white text-xs block">
                    Power by RS TechnoVisions <span className="text-amber-400 font-black">(XpertSkillCop)</span>
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium">
                    HR Management & Audit Consultants · Your People Our Priority
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowBrandHub(true)}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 font-bold text-[11px] transition cursor-pointer whitespace-nowrap"
              >
                Learn More ➔
              </button>
            </div>
          </div>

          {/* Right Column: Authentication Card */}
          <div className="lg:col-span-5 w-full">
            <div className="bg-white rounded-3xl p-7 sm:p-8 shadow-2xl text-slate-900 border border-slate-100 relative overflow-hidden">
              {/* Subtle Top Gradient Bar */}
              <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-sky-600 via-sky-400 to-amber-400"></div>

              <div className="text-center mb-5">
                <h2 className="text-2xl font-black tracking-tight text-slate-950">
                  Sign In to <span className="text-sky-600">CodeTech HRMS</span>
                </h2>
                <p className="text-xs text-slate-600 mt-1 font-semibold">
                  Company: <strong className="text-slate-900">RSTPL</strong> (Innovate · Integrate · Transform)
                </p>
                <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-900 text-white text-[10px] font-bold">
                  <span className="text-amber-400">⚡ Power by</span>
                  <span>RS TechnoVisions</span>
                  <span className="text-amber-400">XpertSkillCop</span>
                </div>
              </div>

              {errorMessage && (
                <div className="mb-3 p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    Username / Corporate Email / Employee ID
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. hr.head, superadmin, or sneha.deshmukh"
                      value={usernameOrEmail}
                      onChange={e => setUsernameOrEmail(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 font-medium focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-bold text-slate-700">Password</label>
                    <span className="text-slate-400 text-[11px]">Encrypted SHA-256</span>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 font-medium focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between py-0.5">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={e => setRememberMe(e.target.checked)}
                      className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                    />
                    <span className="text-slate-600 font-medium text-[11px]">Remember on this device</span>
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-sky-700 hover:from-sky-700 hover:to-sky-800 text-white font-bold text-xs shadow-md shadow-sky-600/30 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>Access Secure Workspace</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {/* Quick Demo One-Click Role Access */}
              <div className="mt-5 pt-4 border-t border-slate-100">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 text-center mb-2">
                  Instant Demonstration Logins (Click to Enter)
                </p>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <button
                    type="button"
                    onClick={() => handleQuickRoleLogin('super_admin', 'superadmin')}
                    className="p-2 rounded-xl border border-purple-200 bg-purple-50/50 hover:bg-purple-100 text-[11px] font-bold text-purple-900 text-left transition-colors cursor-pointer"
                  >
                    ⚡ Super Admin
                    <span className="block text-[9px] font-normal text-purple-700 font-mono">superadmin / Super@2026</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickRoleLogin('org_admin', 'admin')}
                    className="p-2 rounded-xl border border-amber-200 bg-amber-50/50 hover:bg-amber-100 text-[11px] font-bold text-amber-900 text-left transition-colors cursor-pointer"
                  >
                    🏢 Client Admin
                    <span className="block text-[9px] font-normal text-amber-700 font-mono">admin / Admin@2026</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickRoleLogin('hr_head', 'hr.head')}
                    className="p-2 rounded-xl border border-sky-200 bg-sky-50/50 hover:bg-sky-100 text-[11px] font-bold text-sky-900 text-left transition-colors cursor-pointer"
                  >
                    👔 HR Head (VP HR)
                    <span className="block text-[9px] font-normal text-sky-700 font-mono">hr.head / HR@2026</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickRoleLogin('manager', 'plant.manager')}
                    className="p-2 rounded-xl border border-indigo-200 bg-indigo-50/50 hover:bg-indigo-100 text-[11px] font-bold text-indigo-900 text-left transition-colors cursor-pointer"
                  >
                    🏭 Plant Manager
                    <span className="block text-[9px] font-normal text-indigo-700 font-mono">plant.manager / Manager@2026</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickRoleLogin('employee', 'sneha.deshmukh')}
                    className="col-span-2 p-2 rounded-xl border border-emerald-200 bg-emerald-50/50 hover:bg-emerald-100 text-[11px] font-bold text-emerald-900 text-left transition-colors cursor-pointer flex items-center justify-between"
                  >
                    <div>
                      <span>📱 Sneha Deshmukh (Mobile ESS - Self Privacy)</span>
                      <span className="block text-[9px] font-normal text-emerald-700 font-mono">
                        sneha.deshmukh / Employee@2026 · Sees ONLY self attendance, salary & KRA
                      </span>
                    </div>
                    <Smartphone className="w-4 h-4 text-emerald-600 shrink-0" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="max-w-6xl w-full mx-auto text-center py-3 text-[11px] text-slate-400 space-y-1">
        <p>
          © 2026 <strong className="text-white">CodeTech HRMS</strong> · Company:{' '}
          <strong className="text-white">RSTPL</strong> (Innovate · Integrate · Transform) · Power by{' '}
          <strong className="text-amber-400">RS TechnoVisions XpertSkillCop</strong> (HR Management & Audit Consultants)
        </p>
        <div className="flex items-center justify-center gap-4 text-slate-400 flex-wrap">
          <a href="http://www.rstpl.com" target="_blank" rel="noopener noreferrer" className="hover:text-sky-300">
            www.rstpl.com
          </a>
          <span>•</span>
          <a href="http://www.rstechnovisions.co.in" target="_blank" rel="noopener noreferrer" className="hover:text-sky-300">
            www.rstechnovisions.co.in
          </a>
          <span>•</span>
          <a href="mailto:info@rstpl.com" className="hover:text-sky-300">
            info@rstpl.com
          </a>
          <span>•</span>
          <a href="mailto:rstechnovisionsinfo@gmail.com" className="hover:text-sky-300">
            rstechnovisionsinfo@gmail.com
          </a>
        </div>
      </div>

      {/* Brand & Advisory Solutions Modal */}
      <BrandShowcaseModal
        isOpen={showBrandHub}
        onClose={() => setShowBrandHub(false)}
      />
    </div>
  );
};

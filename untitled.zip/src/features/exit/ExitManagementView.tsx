// RSTPL HRMS - Employee Separation & Full and Final (F&F) Settlement
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  UserMinus,
  CheckCircle2,
  Clock,
  Shield,
  FileCheck,
  AlertCircle,
  DollarSign,
  Printer
} from 'lucide-react';
import { Employee } from '../../types/hrms';

interface ExitManagementViewProps {
  employees: Employee[];
  onLogAudit: (action: any, module: string, details: string) => void;
}

interface ExitCase {
  id: string;
  employeeId: string;
  employeeName: string;
  resignationDate: string;
  lastWorkingDay: string;
  noticeDaysServed: number;
  itClearance: boolean;
  adminClearance: boolean;
  financeClearance: boolean;
  hrClearance: boolean;
  fnfNetPayable: number;
  status: 'In Notice' | 'Clearance Pending' | 'FnF Settled' | 'Relieved';
}

export const ExitManagementView: React.FC<ExitManagementViewProps> = ({ employees, onLogAudit }) => {
  const [exitCases, setExitCases] = useState<ExitCase[]>([
    {
      id: 'exit-01',
      employeeId: 'emp-006',
      employeeName: 'Suresh Yadav',
      resignationDate: '2026-09-10',
      lastWorkingDay: '2026-10-10',
      noticeDaysServed: 30,
      itClearance: true,
      adminClearance: true,
      financeClearance: true,
      hrClearance: false,
      fnfNetPayable: 24500,
      status: 'Clearance Pending',
    },
  ]);

  const handleToggleClearance = (id: string, field: 'itClearance' | 'adminClearance' | 'financeClearance' | 'hrClearance') => {
    setExitCases(
      exitCases.map(c => {
        if (c.id === id) {
          const updated = { ...c, [field]: !c[field] };
          if (updated.itClearance && updated.adminClearance && updated.financeClearance && updated.hrClearance) {
            updated.status = 'FnF Settled';
          }
          return updated;
        }
        return c;
      })
    );
    onLogAudit('UPDATE', 'Exit Clearance', `Updated clearance checklist for exit case ${id}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <UserMinus className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">Separation & Full & Final (F&F) Settlement</h2>
              <p className="text-xs text-slate-500">
                Notice period tracking, cross-department asset clearances & statutory settlement statements
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Exit Cases List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <h3 className="text-sm font-bold text-slate-900">Active Separation Pipeline</h3>
          <p className="text-[11px] text-slate-500">Departmental sign-offs required before issuing relieving documents</p>
        </div>

        <div className="divide-y divide-slate-100">
          {exitCases.map(ec => (
            <div key={ec.id} className="p-5 hover:bg-slate-50/70 transition-colors space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{ec.employeeName}</h4>
                  <p className="text-xs text-slate-500">
                    Resignation: {ec.resignationDate} · Last Working Day: <strong className="text-slate-800">{ec.lastWorkingDay}</strong>
                  </p>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  ec.status === 'FnF Settled' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                }`}>
                  {ec.status}
                </span>
              </div>

              {/* Clearance Checkboxes */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                <button
                  onClick={() => handleToggleClearance(ec.id, 'itClearance')}
                  className={`p-2 rounded-xl border flex items-center justify-between font-semibold cursor-pointer ${
                    ec.itClearance ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  <span>IT & Laptop Return</span>
                  {ec.itClearance ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Clock className="w-4 h-4 text-slate-400" />}
                </button>

                <button
                  onClick={() => handleToggleClearance(ec.id, 'adminClearance')}
                  className={`p-2 rounded-xl border flex items-center justify-between font-semibold cursor-pointer ${
                    ec.adminClearance ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  <span>Admin & ID Badge</span>
                  {ec.adminClearance ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Clock className="w-4 h-4 text-slate-400" />}
                </button>

                <button
                  onClick={() => handleToggleClearance(ec.id, 'financeClearance')}
                  className={`p-2 rounded-xl border flex items-center justify-between font-semibold cursor-pointer ${
                    ec.financeClearance ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  <span>Finance & Advance Dues</span>
                  {ec.financeClearance ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Clock className="w-4 h-4 text-slate-400" />}
                </button>

                <button
                  onClick={() => handleToggleClearance(ec.id, 'hrClearance')}
                  className={`p-2 rounded-xl border flex items-center justify-between font-semibold cursor-pointer ${
                    ec.hrClearance ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  <span>HR & Exit Interview</span>
                  {ec.hrClearance ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Clock className="w-4 h-4 text-slate-400" />}
                </button>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                <span>Calculated Net F&F Payout: <strong className="text-emerald-700 font-mono">₹{ec.fnfNetPayable.toLocaleString('en-IN')}</strong></span>
                <span className="text-[11px] text-slate-400">Includes encashed EL and prorated bonus</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

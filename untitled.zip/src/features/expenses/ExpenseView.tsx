// RSTPL HRMS - 3-Stage Expense Claims & Reimbursements Lifecycle
// RS Technovisions XpertSkillCop
// Complete Workflow: Employee Submits + Uploads Receipts -> Assigned Reporting Manager 1st Approval -> Assigned HR Final Approval -> Accounts Person Reimbursement Settlement

import React, { useState, useMemo, useRef } from 'react';
import {
  Receipt,
  Plus,
  CheckCircle2,
  XCircle,
  FileText,
  DollarSign,
  Download,
  Check,
  X,
  Eye,
  Upload,
  Clock,
  ArrowRight,
  ShieldCheck,
  CreditCard,
  Building2,
  UserCheck,
  AlertCircle,
  Filter,
  Calendar,
  Paperclip,
  Printer,
  Search,
  Sparkles,
  RotateCcw,
  FileCheck,
  Building,
  User,
  Layers,
  ExternalLink,
  ChevronRight,
  Send,
  Trash2,
  FileSpreadsheet
} from 'lucide-react';
import {
  ExpenseClaim,
  ExpenseReceiptDoc,
  Employee,
  Department,
  Branch,
  UserRole
} from '../../types/hrms';

interface ExpenseViewProps {
  employees: Employee[];
  departments?: Department[];
  branches?: Branch[];
  currentRole?: UserRole;
  currentEmployee?: Employee;
  onLogAudit: (action: any, module: string, details: string) => void;
}

// Initial realistic dataset demonstrating the 3-stage pipeline with uploaded documents
const INITIAL_EXPENSES: ExpenseClaim[] = [
  {
    id: 'exp-01',
    orgId: 'org-rstpl-001',
    employeeId: 'emp-004',
    employeeName: 'Sneha Deshmukh',
    employeeCode: 'RST-1004',
    department: 'Quality Assurance',
    designation: 'Quality Assurance Lead',
    reportingManagerId: 'emp-003',
    reportingManagerName: 'Rajesh Patil (Plant Operations Head)',
    title: 'Vendor Quality Audit Travel (Pune - Ahmedabad Return)',
    category: 'Travel',
    amount: 6850,
    currency: 'INR',
    date: '2026-10-02',
    receiptAttached: true,
    merchantName: 'IndiGo Airlines & Ahmedabad Taxi Service',
    invoiceNumber: '6E-INV-2026-8812',
    gstNumber: '27AABCI2934D1Z2',
    status: 'Pending_Manager_Approval',
    submittedAt: '2026-10-02T10:30:00Z',
    employeeRemarks: 'Flight booking and local airport cabs for visiting Sanand component vendor plant.',
    receiptDocuments: [
      {
        id: 'doc-01',
        name: 'IndiGo_Air_Ticket_PNQ_AMD_Return.pdf',
        fileType: 'pdf',
        fileSize: '1.4 MB',
        uploadDate: '2026-10-02',
      },
      {
        id: 'doc-02',
        name: 'Ahmedabad_Airport_Cab_Tax_Invoice.jpg',
        fileType: 'image',
        fileSize: '680 KB',
        uploadDate: '2026-10-02',
      },
    ],
  },
  {
    id: 'exp-02',
    orgId: 'org-rstpl-001',
    employeeId: 'emp-005',
    employeeName: 'Vikram Singhania',
    employeeCode: 'RST-1005',
    department: 'Information Technology',
    designation: 'Senior DevOps & IT Specialist',
    reportingManagerId: 'emp-001',
    reportingManagerName: 'Amit Sharma (VP HR & Operations)',
    title: 'Server Room Optical Fiber Cable & Patch Cords',
    category: 'Supplies',
    amount: 3450,
    approvedAmount: 3450,
    currency: 'INR',
    date: '2026-09-29',
    receiptAttached: true,
    merchantName: 'Prime Infotech Solutions Pune',
    invoiceNumber: 'PI-2026-OCT-091',
    gstNumber: '27AAFCP1029Q1Z8',
    status: 'Approved_By_Manager_Pending_HR',
    submittedAt: '2026-09-29T14:15:00Z',
    employeeRemarks: 'Emergency replacement for plant server room fiber link downtime.',
    managerApprovedAt: '2026-09-30T11:00:00Z',
    managerApprovedBy: 'Amit Sharma (Reporting Manager)',
    managerRemarks: 'Verified against downtime incident log. Approved and forwarded to HR Head for policy normalization.',
    receiptDocuments: [
      {
        id: 'doc-03',
        name: 'PrimeInfotech_Optical_Cables_Tax_Invoice.pdf',
        fileType: 'pdf',
        fileSize: '920 KB',
        uploadDate: '2026-09-29',
      },
      {
        id: 'doc-04',
        name: 'Material_Store_Delivery_Challan_Signed.jpg',
        fileType: 'image',
        fileSize: '1.1 MB',
        uploadDate: '2026-09-29',
      },
    ],
  },
  {
    id: 'exp-03',
    orgId: 'org-rstpl-001',
    employeeId: 'emp-002',
    employeeName: 'Priya Kulkarni',
    employeeCode: 'RST-1002',
    department: 'Human Resources',
    designation: 'HR Manager',
    reportingManagerId: 'emp-001',
    reportingManagerName: 'Amit Sharma (VP HR & Operations)',
    title: 'Engineering Campus Placement Drive Logistics & Student Dossiers',
    category: 'Client Entertainment',
    amount: 5800,
    approvedAmount: 5800,
    currency: 'INR',
    date: '2026-09-25',
    receiptAttached: true,
    merchantName: 'ColorCraft Digital Prints & Banner Hub',
    invoiceNumber: 'CC-2026-9931',
    gstNumber: '27AATCC3891J1ZT',
    status: 'Approved_By_HR_Pending_Accounts',
    submittedAt: '2026-09-25T16:00:00Z',
    employeeRemarks: 'Printing of corporate brochures, booth backdrops, and test dossiers for COEP Campus Recruitment.',
    managerApprovedAt: '2026-09-26T10:00:00Z',
    managerApprovedBy: 'Amit Sharma (VP HR)',
    managerRemarks: 'Verified against campus recruitment hiring calendar. Approved.',
    hrApprovedAt: '2026-09-27T15:30:00Z',
    hrApprovedBy: 'Amit Sharma (VP HR Head)',
    hrRemarks: 'Budget sanctioned under HR Q3 Recruitment Logistics. Approved for immediate Accounts reimbursement disbursement.',
    receiptDocuments: [
      {
        id: 'doc-05',
        name: 'ColorCraft_Prints_Official_Tax_Invoice.pdf',
        fileType: 'pdf',
        fileSize: '2.1 MB',
        uploadDate: '2026-09-25',
      },
    ],
  },
  {
    id: 'exp-04',
    orgId: 'org-rstpl-001',
    employeeId: 'emp-006',
    employeeName: 'Suresh Yadav',
    employeeCode: 'RST-1006',
    department: 'Production',
    designation: 'Production Machine Operator',
    reportingManagerId: 'emp-003',
    reportingManagerName: 'Rajesh Patil (Plant Operations Head)',
    title: 'Plant Shift Safety Equipment & Prescribed First-Aid Supplies',
    category: 'Medical',
    amount: 1450,
    approvedAmount: 1450,
    disbursedAmount: 1450,
    currency: 'INR',
    date: '2026-09-20',
    receiptAttached: true,
    merchantName: 'Apollo Pharmacy Chakan MIDC',
    invoiceNumber: 'AP-CHK-2026-4412',
    gstNumber: '27AAACA9921E1Z3',
    status: 'Reimbursed',
    submittedAt: '2026-09-20T09:00:00Z',
    employeeRemarks: 'Emergency safety burn cream and bandages purchased for Shift-A shopfloor box.',
    managerApprovedAt: '2026-09-21T11:00:00Z',
    managerApprovedBy: 'Rajesh Patil (Plant Head)',
    managerRemarks: 'Verified on-duty requirement. 1st approval signed.',
    hrApprovedAt: '2026-09-22T14:00:00Z',
    hrApprovedBy: 'Amit Sharma (VP HR)',
    hrRemarks: 'Approved under Employee Health & Safety welfare pool.',
    disbursedAt: '2026-09-23T17:15:00Z',
    disbursedBy: 'Sunil Mehta (Accounts Controller)',
    paymentMode: 'UPI',
    transactionRef: 'UPI/20260923/HDFC/99120482910',
    bankAccountDetails: 'Bank of Baroda · A/c: 12340100054321 · IFSC: BARB0CHAKAN',
    accountsRemarks: 'Settled via corporate UPI transfer. Voucher entry #AC-EXP-0923.',
    receiptDocuments: [
      {
        id: 'doc-06',
        name: 'Apollo_Pharmacy_GST_Bill_Cash_Receipt.jpg',
        fileType: 'image',
        fileSize: '740 KB',
        uploadDate: '2026-09-20',
      },
    ],
  },
];

export const ExpenseView: React.FC<ExpenseViewProps> = ({
  employees,
  departments = [],
  branches = [],
  currentRole = 'admin',
  currentEmployee,
  onLogAudit,
}) => {
  const [claims, setClaims] = useState<ExpenseClaim[]>(INITIAL_EXPENSES);
  const [activeQueueTab, setActiveQueueTab] = useState<
    'all' | 'manager-queue' | 'hr-queue' | 'accounts-queue' | 'settled'
  >('all');

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [rolePerspective, setRolePerspective] = useState<
    'all' | 'manager' | 'hr' | 'accounts' | 'employee'
  >('all');

  // Modals state
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [selectedClaimForReview, setSelectedClaimForReview] = useState<ExpenseClaim | null>(null);
  const [reviewModalType, setReviewModalType] = useState<
    'manager_review' | 'hr_review' | 'accounts_disburse' | 'view_slip' | null
  >(null);
  const [viewingReceiptDoc, setViewingReceiptDoc] = useState<{
    claim: ExpenseClaim;
    doc: ExpenseReceiptDoc;
  } | null>(null);

  // New Claim Form State with Document Upload
  const [claimEmployeeId, setClaimEmployeeId] = useState<string>(
    currentEmployee?.id || employees[0]?.id || ''
  );
  const [claimTitle, setClaimTitle] = useState('');
  const [claimCategory, setClaimCategory] = useState<ExpenseClaim['category']>('Travel');
  const [claimAmount, setClaimAmount] = useState<number>(2500);
  const [claimDate, setClaimDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [claimMerchant, setClaimMerchant] = useState('');
  const [claimInvoiceNo, setClaimInvoiceNo] = useState('');
  const [claimGstNo, setClaimGstNo] = useState('');
  const [claimRemarks, setClaimRemarks] = useState('');
  const [uploadedDocs, setUploadedDocs] = useState<ExpenseReceiptDoc[]>([]);

  // Review Form States
  const [reviewApprovedAmount, setReviewApprovedAmount] = useState<number>(0);
  const [reviewRemarks, setReviewRemarks] = useState<string>('');
  const [disbursementPaymentMode, setDisbursementPaymentMode] = useState<
    ExpenseClaim['paymentMode']
  >('NEFT_RTGS');
  const [disbursementUtrRef, setDisbursementUtrRef] = useState<string>('');
  const [disbursementDate, setDisbursementDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-generate realistic UTR reference
  const generateRandomUTR = () => {
    const timestamp = Date.now().toString().slice(-6);
    return `NEFT-RSTPL-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${timestamp}`;
  };

  // Handle file uploads (converts files to dataURL / preview objects)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const files = Array.from(e.target.files);

    files.forEach(file => {
      const isPdf = file.type === 'application/pdf' || file.name.endsWith('.pdf');
      const isImg = file.type.startsWith('image/');
      const sizeStr = `${(file.size / (1024 * 1024)).toFixed(2)} MB`;

      const reader = new FileReader();
      reader.onload = () => {
        const newDoc: ExpenseReceiptDoc = {
          id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          name: file.name,
          fileType: isPdf ? 'pdf' : isImg ? 'image' : 'doc',
          fileSize: sizeStr,
          dataUrl: typeof reader.result === 'string' ? reader.result : undefined,
          uploadDate: new Date().toISOString().split('T')[0],
        };

        setUploadedDocs(prev => [...prev, newDoc]);
      };
      reader.readAsDataURL(file);
    });
  };

  // Add quick realistic sample receipt for testing
  const handleAddSampleReceipt = (type: 'air' | 'hotel' | 'fuel' | 'cab') => {
    const samples: Record<string, ExpenseReceiptDoc> = {
      air: {
        id: `doc-${Date.now()}-1`,
        name: 'Air_Ticket_IndiGo_6E_Tax_Invoice.pdf',
        fileType: 'pdf',
        fileSize: '1.25 MB',
        uploadDate: new Date().toISOString().split('T')[0],
      },
      hotel: {
        id: `doc-${Date.now()}-2`,
        name: 'Novotel_Hotel_Pune_Room_Tax_Invoice.jpg',
        fileType: 'image',
        fileSize: '890 KB',
        uploadDate: new Date().toISOString().split('T')[0],
      },
      fuel: {
        id: `doc-${Date.now()}-3`,
        name: 'HP_Petrol_Pump_Official_Receipt.jpg',
        fileType: 'image',
        fileSize: '460 KB',
        uploadDate: new Date().toISOString().split('T')[0],
      },
      cab: {
        id: `doc-${Date.now()}-4`,
        name: 'Uber_Intercity_Cab_Trip_Bill.pdf',
        fileType: 'pdf',
        fileSize: '620 KB',
        uploadDate: new Date().toISOString().split('T')[0],
      },
    };

    setUploadedDocs(prev => [...prev, samples[type]]);
  };

  // Employee files new claim
  const handleCreateClaim = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find(e => e.id === claimEmployeeId) || employees[0];
    if (!emp || !claimTitle) return;

    const mgr = employees.find(e => e.id === emp.reportingManagerId) || employees[0];

    const claim: ExpenseClaim = {
      id: `exp-${Date.now().toString().slice(-5)}`,
      orgId: 'org-rstpl-001',
      employeeId: emp.id,
      employeeName: `${emp.firstName} ${emp.lastName}`,
      employeeCode: emp.employeeCode,
      department: departments.find(d => d.id === emp.departmentId)?.name || 'Operations',
      designation: emp.designationId || 'Team Member',
      reportingManagerId: mgr?.id,
      reportingManagerName: `${mgr?.firstName} ${mgr?.lastName}`,
      title: claimTitle,
      category: claimCategory,
      amount: claimAmount,
      currency: 'INR',
      date: claimDate,
      receiptAttached: uploadedDocs.length > 0,
      receiptDocuments: uploadedDocs,
      merchantName: claimMerchant || 'Merchant / Vendor Bill Attached',
      invoiceNumber: claimInvoiceNo || `INV-${Date.now().toString().slice(-4)}`,
      gstNumber: claimGstNo || '27AABCR9912K1Z9',
      status: 'Pending_Manager_Approval',
      submittedAt: new Date().toISOString(),
      employeeRemarks: claimRemarks,
    };

    setClaims([claim, ...claims]);
    setShowApplyModal(false);
    setClaimTitle('');
    setClaimRemarks('');
    setClaimMerchant('');
    setClaimInvoiceNo('');
    setClaimGstNo('');
    setUploadedDocs([]);

    onLogAudit(
      'CREATE',
      'Expense Claims',
      `Employee ${claim.employeeName} filed expense claim "${claim.title}" of ₹${claim.amount} with ${claim.receiptDocuments?.length || 0} receipt documents (Forwarded to Reporting Manager ${claim.reportingManagerName})`
    );
  };

  // Stage 2: Reporting Manager First Approval
  const handleManagerFirstApproval = (isApproved: boolean) => {
    if (!selectedClaimForReview) return;

    if (!isApproved) {
      const updated = claims.map(c =>
        c.id === selectedClaimForReview.id
          ? {
              ...c,
              status: 'Rejected' as const,
              managerRemarks: reviewRemarks || 'Rejected by Reporting Manager.',
            }
          : c
      );
      setClaims(updated);
      setSelectedClaimForReview(null);
      setReviewModalType(null);
      onLogAudit(
        'REJECT',
        'Expense Claims',
        `Reporting Manager rejected claim ${selectedClaimForReview.id} (${selectedClaimForReview.title})`
      );
      return;
    }

    const updatedClaim: ExpenseClaim = {
      ...selectedClaimForReview,
      status: 'Approved_By_Manager_Pending_HR',
      approvedAmount: reviewApprovedAmount || selectedClaimForReview.amount,
      managerApprovedAt: new Date().toISOString(),
      managerApprovedBy:
        currentRole === 'manager'
          ? `${currentEmployee?.firstName || 'Rajesh'} ${currentEmployee?.lastName || 'Patil'} (Reporting Manager)`
          : 'Reporting Manager (Rajesh Patil)',
      managerRemarks: reviewRemarks || 'Receipts and necessity verified against travel schedule. 1st approval granted.',
    };

    setClaims(claims.map(c => (c.id === updatedClaim.id ? updatedClaim : c)));
    setSelectedClaimForReview(null);
    setReviewModalType(null);

    onLogAudit(
      'APPROVE',
      'Expense Claims',
      `Reporting Manager granted 1st Approval for claim ${updatedClaim.id} (₹${updatedClaim.approvedAmount}). Forwarded to HR Head for final policy sign-off.`
    );
  };

  // Stage 3: HR Head Final Approval
  const handleHrFinalApproval = (isApproved: boolean) => {
    if (!selectedClaimForReview) return;

    if (!isApproved) {
      const updated = claims.map(c =>
        c.id === selectedClaimForReview.id
          ? {
              ...c,
              status: 'Rejected' as const,
              hrRemarks: reviewRemarks || 'Rejected by HR Head during policy audit.',
            }
          : c
      );
      setClaims(updated);
      setSelectedClaimForReview(null);
      setReviewModalType(null);
      onLogAudit(
        'REJECT',
        'Expense Claims',
        `HR Head rejected claim ${selectedClaimForReview.id} (${selectedClaimForReview.title})`
      );
      return;
    }

    const updatedClaim: ExpenseClaim = {
      ...selectedClaimForReview,
      status: 'Approved_By_HR_Pending_Accounts',
      approvedAmount: reviewApprovedAmount || selectedClaimForReview.approvedAmount || selectedClaimForReview.amount,
      hrApprovedAt: new Date().toISOString(),
      hrApprovedBy: currentRole === 'hr_head' ? 'Amit Sharma (VP HR Head)' : 'HR Head (Amit Sharma)',
      hrRemarks: reviewRemarks || 'Policy compliance and GST credentials normalized. Approved for Accounts disbursement.',
    };

    setClaims(claims.map(c => (c.id === updatedClaim.id ? updatedClaim : c)));
    setSelectedClaimForReview(null);
    setReviewModalType(null);

    onLogAudit(
      'APPROVE',
      'Expense Claims',
      `HR Head granted Final Approval for claim ${updatedClaim.id} (₹${updatedClaim.approvedAmount}). Queued for Accounts reimbursement settlement.`
    );
  };

  // Stage 4: Accounts Person Settlement & Reimbursement Disbursement
  const handleAccountsDisbursement = () => {
    if (!selectedClaimForReview) return;

    const emp = employees.find(e => e.id === selectedClaimForReview.employeeId);
    const bankDetails = emp?.bankAccountNumber
      ? `${emp.bankName || 'HDFC Bank'} · A/c: ${emp.bankAccountNumber} · IFSC: ${emp.ifscCode || 'HDFC0001234'}`
      : 'ICICI Bank Ltd · A/c: 002305012345 · IFSC: ICIC0000023';

    const utr = disbursementUtrRef || generateRandomUTR();

    const updatedClaim: ExpenseClaim = {
      ...selectedClaimForReview,
      status: 'Reimbursed',
      disbursedAmount: selectedClaimForReview.approvedAmount || selectedClaimForReview.amount,
      disbursedAt: disbursementDate || new Date().toISOString(),
      disbursedBy: 'Sunil Mehta (Accounts & Finance Controller)',
      paymentMode: disbursementPaymentMode,
      transactionRef: utr,
      bankAccountDetails: bankDetails,
      accountsRemarks: reviewRemarks || `Reimbursement settled via ${(disbursementPaymentMode || 'NEFT_RTGS').replace(/_/g, ' ')}. Transaction Ref: ${utr}`,
    };

    setClaims(claims.map(c => (c.id === updatedClaim.id ? updatedClaim : c)));
    setSelectedClaimForReview(updatedClaim);
    setReviewModalType('view_slip'); // Immediately allow viewing the Payment Advice slip

    onLogAudit(
      'DISBURSE',
      'Expense Claims',
      `Accounts settled reimbursement of ₹${updatedClaim.disbursedAmount} for ${updatedClaim.employeeName} (${updatedClaim.title}). UTR: ${utr}`
    );
  };

  // Filtered Claims List
  const filteredClaims = useMemo(() => {
    return claims.filter(c => {
      // Queue Filter
      if (activeQueueTab === 'manager-queue') {
        if (c.status !== 'Pending_Manager_Approval' && c.status !== 'Pending') return false;
      } else if (activeQueueTab === 'hr-queue') {
        if (c.status !== 'Approved_By_Manager_Pending_HR') return false;
      } else if (activeQueueTab === 'accounts-queue') {
        if (c.status !== 'Approved_By_HR_Pending_Accounts') return false;
      } else if (activeQueueTab === 'settled') {
        if (c.status !== 'Reimbursed' && c.status !== 'Approved') return false;
      }

      // Role Perspective Filter
      if (rolePerspective === 'manager') {
        if (c.status !== 'Pending_Manager_Approval' && c.status !== 'Pending') return false;
      } else if (rolePerspective === 'hr') {
        if (c.status !== 'Approved_By_Manager_Pending_HR') return false;
      } else if (rolePerspective === 'accounts') {
        if (c.status !== 'Approved_By_HR_Pending_Accounts') return false;
      }

      // Category filter
      if (categoryFilter !== 'all' && c.category !== categoryFilter) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = c.title.toLowerCase().includes(q);
        const matchName = c.employeeName.toLowerCase().includes(q);
        const matchMerchant = c.merchantName?.toLowerCase().includes(q);
        const matchUtr = c.transactionRef?.toLowerCase().includes(q);
        if (!matchTitle && !matchName && !matchMerchant && !matchUtr) return false;
      }

      return true;
    });
  }, [claims, activeQueueTab, rolePerspective, categoryFilter, searchQuery]);

  // Summary Telemetry
  const stats = useMemo(() => {
    const totalAmount = claims.reduce((s, c) => s + c.amount, 0);
    const pendingManagerCount = claims.filter(
      c => c.status === 'Pending_Manager_Approval' || c.status === 'Pending'
    ).length;
    const pendingHrCount = claims.filter(
      c => c.status === 'Approved_By_Manager_Pending_HR'
    ).length;
    const pendingAccountsCount = claims.filter(
      c => c.status === 'Approved_By_HR_Pending_Accounts'
    ).length;
    const pendingAccountsAmount = claims
      .filter(c => c.status === 'Approved_By_HR_Pending_Accounts')
      .reduce((s, c) => s + (c.approvedAmount || c.amount), 0);
    const disbursedAmount = claims
      .filter(c => c.status === 'Reimbursed' || c.status === 'Approved')
      .reduce((s, c) => s + (c.disbursedAmount || c.approvedAmount || c.amount), 0);

    return {
      totalAmount,
      pendingManagerCount,
      pendingHrCount,
      pendingAccountsCount,
      pendingAccountsAmount,
      disbursedAmount,
    };
  }, [claims]);

  // Export claims to CSV
  const handleExportCSV = () => {
    const headers = [
      'Claim ID',
      'Employee Name',
      'Department',
      'Title',
      'Category',
      'Expense Date',
      'Amount (INR)',
      'Approved Amount',
      'Receipts Attached',
      'Status',
      'Reporting Manager',
      'Manager Remarks',
      'HR Signoff',
      'Payment Mode',
      'UTR / Transaction Ref',
    ];

    const rows = filteredClaims.map(c => [
      c.id,
      `"${c.employeeName}"`,
      `"${c.department || ''}"`,
      `"${c.title}"`,
      c.category,
      c.date,
      c.amount,
      c.approvedAmount || c.amount,
      c.receiptDocuments?.length || 0,
      c.status.replace(/_/g, ' '),
      `"${c.reportingManagerName || ''}"`,
      `"${c.managerRemarks || ''}"`,
      `"${c.hrApprovedBy || ''}"`,
      c.paymentMode || '',
      c.transactionRef || '',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map(r => r.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `RSTPL_Expense_Claims_Register_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    onLogAudit('EXPORT', 'Expense Claims', 'Exported expense claims register to CSV');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2.5 rounded-xl bg-sky-100 text-sky-800">
              <Receipt className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900 tracking-tight">
                  Expense Claims & Reimbursements
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800">
                  3-Stage Workflow
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Receipts Upload ➔ Manager 1st Approval ➔ HR Head Final Sign-off ➔ Accounts Reimbursement Disbursement
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-600" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => {
              setUploadedDocs([]);
              setShowApplyModal(true);
            }}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>File Expense Claim + Upload Receipts</span>
          </button>
        </div>
      </div>

      {/* 4-Stage Lifecycle Progression Strip */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="text-[11px] font-black uppercase text-slate-400 tracking-wider mb-2.5 flex items-center justify-between">
          <span>Enterprise Multi-Tier Reimbursement Pipeline</span>
          <span className="text-sky-700 font-bold">100% Policy Compliant</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-sky-50/80 border border-sky-200 flex items-start gap-2.5">
            <span className="p-2 rounded-lg bg-white text-sky-700 shrink-0 shadow-2xs">
              <Upload className="w-4 h-4" />
            </span>
            <div>
              <span className="text-[10px] font-bold uppercase text-sky-800 block">Step 1: Employee Submission</span>
              <p className="font-bold text-slate-900 mt-0.5">File Claim + Attach Bills</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Upload PDFs, GST invoices & receipts</p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-amber-50/80 border border-amber-200 flex items-start gap-2.5">
            <span className="p-2 rounded-lg bg-white text-amber-700 shrink-0 shadow-2xs">
              <UserCheck className="w-4 h-4" />
            </span>
            <div>
              <span className="text-[10px] font-bold uppercase text-amber-800 block">Step 2: Reporting Manager</span>
              <p className="font-bold text-slate-900 mt-0.5">Manager 1st Approval</p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {stats.pendingManagerCount} claim(s) pending manager verification
              </p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-purple-50/80 border border-purple-200 flex items-start gap-2.5">
            <span className="p-2 rounded-lg bg-white text-purple-700 shrink-0 shadow-2xs">
              <ShieldCheck className="w-4 h-4" />
            </span>
            <div>
              <span className="text-[10px] font-bold uppercase text-purple-800 block">Step 3: HR Head Sign-off</span>
              <p className="font-bold text-slate-900 mt-0.5">Final HR Policy Approval</p>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {stats.pendingHrCount} claim(s) awaiting VP HR review
              </p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-emerald-50/80 border border-emerald-200 flex items-start gap-2.5">
            <span className="p-2 rounded-lg bg-white text-emerald-700 shrink-0 shadow-2xs">
              <CreditCard className="w-4 h-4" />
            </span>
            <div>
              <span className="text-[10px] font-bold uppercase text-emerald-800 block">Step 4: Accounts Department</span>
              <p className="font-bold text-slate-900 mt-0.5">Reimbursement Bank Payout</p>
              <p className="text-[11px] text-slate-500 mt-0.5 font-mono font-bold text-emerald-800">
                ₹{stats.pendingAccountsAmount.toLocaleString('en-IN')} ready for disbursement
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Queue Navigation Tabs & Role Switcher */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs overflow-x-auto">
          <button
            onClick={() => setActiveQueueTab('all')}
            className={`px-3 py-1.5 rounded-lg font-bold transition whitespace-nowrap cursor-pointer ${
              activeQueueTab === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Claims ({claims.length})
          </button>
          <button
            onClick={() => setActiveQueueTab('manager-queue')}
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeQueueTab === 'manager-queue'
                ? 'bg-white text-amber-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>1. Manager Queue</span>
            {stats.pendingManagerCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-white font-mono text-[10px]">
                {stats.pendingManagerCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveQueueTab('hr-queue')}
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeQueueTab === 'hr-queue'
                ? 'bg-white text-purple-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>2. HR Head Queue</span>
            {stats.pendingHrCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-purple-500 text-white font-mono text-[10px]">
                {stats.pendingHrCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveQueueTab('accounts-queue')}
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeQueueTab === 'accounts-queue'
                ? 'bg-white text-emerald-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>3. Accounts Disbursement</span>
            {stats.pendingAccountsCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-emerald-600 text-white font-mono text-[10px]">
                {stats.pendingAccountsCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveQueueTab('settled')}
            className={`px-3 py-1.5 rounded-lg font-bold transition whitespace-nowrap cursor-pointer ${
              activeQueueTab === 'settled'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Disbursed & Settled
          </button>
        </div>

        {/* Quick Role Perspective Simulator */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Simulate Role:</span>
          <select
            value={rolePerspective}
            onChange={e => setRolePerspective(e.target.value as any)}
            className="px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-800 text-xs cursor-pointer"
          >
            <option value="all">View as All Departments (Super Admin)</option>
            <option value="manager">Reporting Manager (1st Approver)</option>
            <option value="hr">HR Head (Final Sign-off)</option>
            <option value="accounts">Accounts Officer (Reimbursements Payout)</option>
          </select>
        </div>
      </div>

      {/* Search & Category Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by employee, title, merchant, invoice #, UTR..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
          <span className="text-[11px] font-bold text-slate-400 uppercase shrink-0">Category:</span>
          {['all', 'Travel', 'Food', 'Hotel', 'Conveyance', 'Supplies', 'Medical', 'Client Entertainment'].map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                categoryFilter === cat
                  ? 'bg-sky-600 text-white shadow-2xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              {cat === 'all' ? 'All' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main Claims Ledger Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-sky-700" />
            <h3 className="font-bold text-sm text-slate-900">
              Expense Claims Ledger & Status Pipeline ({filteredClaims.length} Records)
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-medium">
            Total Filtered Value: <strong className="text-slate-900 font-mono">₹{filteredClaims.reduce((s, c) => s + c.amount, 0).toLocaleString('en-IN')}</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/75 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                <th className="py-3 px-4">Claim ID & Employee</th>
                <th className="py-3 px-4">Expense Details & Merchant</th>
                <th className="py-3 px-4">Category & Date</th>
                <th className="py-3 px-4 text-right">Claim Amount</th>
                <th className="py-3 px-4">Receipt Documents</th>
                <th className="py-3 px-4">Current Workflow Stage</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredClaims.map(c => {
                const isPendingMgr = c.status === 'Pending_Manager_Approval' || c.status === 'Pending';
                const isPendingHr = c.status === 'Approved_By_Manager_Pending_HR';
                const isPendingAccounts = c.status === 'Approved_By_HR_Pending_Accounts';
                const isReimbursed = c.status === 'Reimbursed' || c.status === 'Approved';
                const isRejected = c.status === 'Rejected';

                return (
                  <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                    {/* Employee & ID */}
                    <td className="py-3.5 px-4">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-mono font-bold text-[10px]">
                            {c.id}
                          </span>
                          <span className="font-black text-slate-900 text-xs">{c.employeeName}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {c.department} · {c.employeeCode}
                        </p>
                        <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                          <User className="w-3 h-3" />
                          <span>Mgr: {c.reportingManagerName || 'Rajesh Patil'}</span>
                        </div>
                      </div>
                    </td>

                    {/* Title & Merchant Details */}
                    <td className="py-3.5 px-4 max-w-xs">
                      <div>
                        <p className="font-bold text-slate-900 leading-snug">{c.title}</p>
                        <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500 flex-wrap">
                          {c.merchantName && (
                            <span className="font-semibold text-slate-700">{c.merchantName}</span>
                          )}
                          {c.invoiceNumber && (
                            <span className="text-[10px] font-mono text-slate-400">Inv: {c.invoiceNumber}</span>
                          )}
                        </div>
                        {c.employeeRemarks && (
                          <p className="text-[11px] text-slate-500 italic mt-1 line-clamp-1">
                            "{c.employeeRemarks}"
                          </p>
                        )}
                      </div>
                    </td>

                    {/* Category & Date */}
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded-md font-semibold text-[11px] bg-slate-100 text-slate-700 inline-block mb-1">
                        {c.category}
                      </span>
                      <p className="font-mono text-[11px] text-slate-500 flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        {c.date}
                      </p>
                    </td>

                    {/* Claim Amount */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="font-black text-slate-900 font-mono text-sm">
                        ₹{c.amount.toLocaleString('en-IN')}
                      </div>
                      {c.approvedAmount && c.approvedAmount !== c.amount && (
                        <p className="text-[10px] text-emerald-700 font-mono font-bold mt-0.5">
                          Approved: ₹{c.approvedAmount.toLocaleString('en-IN')}
                        </p>
                      )}
                      {c.disbursedAmount && (
                        <p className="text-[10px] text-sky-700 font-mono font-bold mt-0.5">
                          Paid: ₹{c.disbursedAmount.toLocaleString('en-IN')}
                        </p>
                      )}
                    </td>

                    {/* Receipt Documents */}
                    <td className="py-3.5 px-4">
                      {c.receiptDocuments && c.receiptDocuments.length > 0 ? (
                        <div className="space-y-1">
                          {c.receiptDocuments.map(doc => (
                            <button
                              key={doc.id}
                              onClick={() => setViewingReceiptDoc({ claim: c, doc })}
                              className="w-full flex items-center justify-between gap-1.5 p-1 rounded-lg bg-sky-50/70 hover:bg-sky-100 border border-sky-200 text-[10px] font-semibold text-sky-900 transition cursor-pointer text-left"
                            >
                              <span className="flex items-center gap-1 truncate max-w-[130px]">
                                <Paperclip className="w-3 h-3 text-sky-700 shrink-0" />
                                <span className="truncate">{doc.name}</span>
                              </span>
                              <span className="text-[9px] text-sky-700 font-mono shrink-0">
                                {doc.fileSize || 'PDF'}
                              </span>
                            </button>
                          ))}
                        </div>
                      ) : (
                        <span className="text-[11px] text-amber-600 font-medium flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" /> No receipt
                        </span>
                      )}
                    </td>

                    {/* Workflow Stage */}
                    <td className="py-3.5 px-4">
                      <div className="space-y-1.5">
                        {isPendingMgr && (
                          <div>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200 inline-flex items-center gap-1">
                              <Clock className="w-3 h-3 text-amber-600 animate-pulse" />
                              Awaiting Mgr 1st Approval
                            </span>
                            <p className="text-[10px] text-slate-500 mt-0.5">
                              Assigned to: {c.reportingManagerName?.split(' ')[0] || 'Manager'}
                            </p>
                          </div>
                        )}

                        {isPendingHr && (
                          <div>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200 inline-flex items-center gap-1">
                              <ShieldCheck className="w-3 h-3 text-purple-600" />
                              Mgr Approved ➔ Awaiting HR
                            </span>
                            <p className="text-[10px] text-slate-500 mt-0.5">
                              1st Approved by {c.managerApprovedBy?.split(' ')[0]}
                            </p>
                          </div>
                        )}

                        {isPendingAccounts && (
                          <div>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200 inline-flex items-center gap-1">
                              <CreditCard className="w-3 h-3 text-sky-600" />
                              HR Approved ➔ Accounts Queue
                            </span>
                            <p className="text-[10px] text-slate-500 mt-0.5">
                              Ready for NEFT/UPI Payout
                            </p>
                          </div>
                        )}

                        {isReimbursed && (
                          <div>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 inline-flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              Reimbursed & Settled
                            </span>
                            <p className="text-[10px] text-slate-500 font-mono mt-0.5 truncate max-w-[140px]">
                              UTR: {c.transactionRef || 'NEFT-COMPLETED'}
                            </p>
                          </div>
                        )}

                        {isRejected && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200 inline-flex items-center gap-1">
                            <XCircle className="w-3 h-3 text-rose-600" />
                            Rejected
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5 flex-wrap">
                        {/* Manager 1st Review Action */}
                        {isPendingMgr && (
                          <button
                            onClick={() => {
                              setSelectedClaimForReview(c);
                              setReviewApprovedAmount(c.amount);
                              setReviewRemarks('');
                              setReviewModalType('manager_review');
                            }}
                            className="px-2.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1 shadow-2xs"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>Mgr Review</span>
                          </button>
                        )}

                        {/* HR Head Final Approval Action */}
                        {isPendingHr && (
                          <button
                            onClick={() => {
                              setSelectedClaimForReview(c);
                              setReviewApprovedAmount(c.approvedAmount || c.amount);
                              setReviewRemarks('');
                              setReviewModalType('hr_review');
                            }}
                            className="px-2.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1 shadow-2xs"
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>HR Sign-off</span>
                          </button>
                        )}

                        {/* Accounts Person Reimbursement Action */}
                        {isPendingAccounts && (
                          <button
                            onClick={() => {
                              setSelectedClaimForReview(c);
                              setReviewApprovedAmount(c.approvedAmount || c.amount);
                              setDisbursementUtrRef(generateRandomUTR());
                              setReviewRemarks('Reimbursement settled against verified employee bank account.');
                              setReviewModalType('accounts_disburse');
                            }}
                            className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1 shadow-2xs"
                          >
                            <CreditCard className="w-3.5 h-3.5" />
                            <span>Disburse Payout</span>
                          </button>
                        )}

                        {/* View Payment Voucher Slip */}
                        {isReimbursed && (
                          <button
                            onClick={() => {
                              setSelectedClaimForReview(c);
                              setReviewModalType('view_slip');
                            }}
                            className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition cursor-pointer flex items-center gap-1"
                          >
                            <FileText className="w-3.5 h-3.5 text-emerald-700" />
                            <span>Payment Slip</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredClaims.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <div className="p-3 rounded-2xl bg-slate-100 text-slate-400">
                        <Receipt className="w-6 h-6" />
                      </div>
                      <p className="font-bold text-slate-700 text-sm">No expense claims found in this queue</p>
                      <p className="text-xs text-slate-400">
                        File a new claim or switch queue tabs to view other approval stages.
                      </p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: File Expense Claim + Upload Receipt Documents */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
                    <Receipt className="w-5 h-5 text-sky-700" />
                  </span>
                  <div>
                    <h3 className="text-base font-black text-slate-900">
                      Submit Expense Voucher & Upload Receipts
                    </h3>
                    <p className="text-xs text-slate-500">
                      Step 1 of 4: Automatically routes to your Reporting Manager for 1st level approval
                    </p>
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowApplyModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateClaim} className="space-y-4 text-xs">
              {/* Employee Selector */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Employee Submitting Claim *
                </label>
                <select
                  value={claimEmployeeId}
                  onChange={e => setClaimEmployeeId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium"
                >
                  {employees.map(e => (
                    <option key={e.id} value={e.id}>
                      {e.firstName} {e.lastName} ({e.employeeCode}) - {departments.find(d => d.id === e.departmentId)?.name || 'Operations'}
                    </option>
                  ))}
                </select>
                {(() => {
                  const emp = employees.find(e => e.id === claimEmployeeId);
                  const mgr = employees.find(e => e.id === emp?.reportingManagerId);
                  return (
                    <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1.5">
                      <UserCheck className="w-3.5 h-3.5 text-sky-600" />
                      Assigned 1st Approver:{' '}
                      <strong className="text-slate-800">
                        {mgr ? `${mgr.firstName} ${mgr.lastName} (Reporting Manager)` : 'Rajesh Patil (Plant Operations Head)'}
                      </strong>
                    </p>
                  );
                })()}
              </div>

              {/* Title & Category */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">Claim Title / Business Purpose *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Pune to Ahmedabad Vendor Inspection Travel & Cabs"
                  value={claimTitle}
                  onChange={e => setClaimTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Category *</label>
                  <select
                    value={claimCategory}
                    onChange={e => setClaimCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-800"
                  >
                    <option value="Travel">Travel (Flight / Train)</option>
                    <option value="Food">Food & Meals</option>
                    <option value="Hotel">Hotel Accommodation</option>
                    <option value="Conveyance">Local Conveyance & Fuel</option>
                    <option value="Supplies">IT & Office Supplies</option>
                    <option value="Medical">Medical & First-Aid</option>
                    <option value="Client Entertainment">Client Entertainment</option>
                    <option value="Other">Other Miscellaneous</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Expense Date *</label>
                  <input
                    required
                    type="date"
                    value={claimDate}
                    onChange={e => setClaimDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Amount (₹ INR) *</label>
                  <input
                    required
                    type="number"
                    min={1}
                    value={claimAmount}
                    onChange={e => setClaimAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono font-black text-slate-900"
                  />
                </div>
              </div>

              {/* Merchant Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Merchant / Vendor Name</label>
                  <input
                    type="text"
                    placeholder="e.g. IndiGo Airlines / Novotel"
                    value={claimMerchant}
                    onChange={e => setClaimMerchant(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Invoice / Receipt Bill No</label>
                  <input
                    type="text"
                    placeholder="e.g. 6E-INV-2026-901"
                    value={claimInvoiceNo}
                    onChange={e => setClaimInvoiceNo(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Vendor GSTIN (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. 27AABCI2934D1Z2"
                    value={claimGstNo}
                    onChange={e => setClaimGstNo(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono"
                  />
                </div>
              </div>

              {/* DOCUMENT UPLOAD SECTION (Requested feature) */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="font-black text-slate-900 block flex items-center gap-1.5">
                      <Paperclip className="w-4 h-4 text-sky-700" />
                      Upload Expense Receipts & Invoices *
                    </label>
                    <p className="text-[11px] text-slate-500">
                      Upload scanned bills, air tickets, hotel vouchers, taxi slips (PDF, PNG, JPG)
                    </p>
                  </div>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-sky-100 text-sky-800">
                    {uploadedDocs.length} File(s) Attached
                  </span>
                </div>

                {/* File Dropzone Input */}
                <input
                  type="file"
                  multiple
                  ref={fileInputRef}
                  accept="image/*,application/pdf,.doc,.docx"
                  onChange={handleFileUpload}
                  className="hidden"
                />

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-sky-300 hover:border-sky-500 bg-white hover:bg-sky-50/50 rounded-2xl p-4 text-center cursor-pointer transition flex flex-col items-center justify-center space-y-1.5"
                >
                  <div className="p-2 rounded-xl bg-sky-100 text-sky-700">
                    <Upload className="w-5 h-5" />
                  </div>
                  <p className="font-bold text-slate-800">
                    Click to browse files or drag and drop receipts here
                  </p>
                  <p className="text-[10px] text-slate-400">
                    Supported: PDF, JPG, PNG, WebP up to 15MB each
                  </p>
                </div>

                {/* Quick Sample Demo Receipt Buttons for testing */}
                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Quick Add Sample:</span>
                  <button
                    type="button"
                    onClick={() => handleAddSampleReceipt('air')}
                    className="px-2 py-1 rounded-md bg-white border border-slate-200 hover:border-sky-300 text-[10px] font-semibold text-slate-700 transition cursor-pointer"
                  >
                    + Flight Boarding Pass
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddSampleReceipt('hotel')}
                    className="px-2 py-1 rounded-md bg-white border border-slate-200 hover:border-sky-300 text-[10px] font-semibold text-slate-700 transition cursor-pointer"
                  >
                    + Hotel Tax Invoice
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddSampleReceipt('fuel')}
                    className="px-2 py-1 rounded-md bg-white border border-slate-200 hover:border-sky-300 text-[10px] font-semibold text-slate-700 transition cursor-pointer"
                  >
                    + Fuel Slip
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddSampleReceipt('cab')}
                    className="px-2 py-1 rounded-md bg-white border border-slate-200 hover:border-sky-300 text-[10px] font-semibold text-slate-700 transition cursor-pointer"
                  >
                    + Cab Receipt
                  </button>
                </div>

                {/* Attached Documents List */}
                {uploadedDocs.length > 0 && (
                  <div className="space-y-1.5 pt-2 border-t border-slate-200">
                    {uploadedDocs.map((doc, idx) => (
                      <div
                        key={doc.id}
                        className="flex items-center justify-between p-2 rounded-xl bg-white border border-slate-200 text-xs shadow-2xs"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <span className="p-1.5 rounded-lg bg-sky-100 text-sky-800 shrink-0 font-bold text-[10px]">
                            {doc.fileType.toUpperCase()}
                          </span>
                          <div className="truncate">
                            <p className="font-bold text-slate-800 truncate">{doc.name}</p>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {doc.fileSize} · {doc.uploadDate}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() =>
                              setViewingReceiptDoc({
                                claim: {
                                  id: 'preview',
                                  orgId: 'org-rstpl-001',
                                  employeeId: claimEmployeeId,
                                  employeeName: 'Claimant Preview',
                                  title: claimTitle || 'Receipt Inspection',
                                  category: claimCategory,
                                  amount: claimAmount,
                                  currency: 'INR',
                                  date: claimDate,
                                  receiptAttached: true,
                                  status: 'Pending_Manager_Approval',
                                },
                                doc,
                              })
                            }
                            className="p-1 rounded-lg text-slate-500 hover:text-sky-700 hover:bg-sky-50 transition cursor-pointer"
                            title="Preview Document"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setUploadedDocs(uploadedDocs.filter((_, i) => i !== idx))
                            }
                            className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                            title="Remove"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Remarks */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Justification / Itinerary Description
                </label>
                <textarea
                  rows={2}
                  placeholder="Detail the business justification for travel/expenses..."
                  value={claimRemarks}
                  onChange={e => setClaimRemarks(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>

              {/* Footer */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowApplyModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Claim for Manager Approval</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Reporting Manager First Approval Modal */}
      {selectedClaimForReview && reviewModalType === 'manager_review' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                  Step 2 of 4: Reporting Manager First Approval
                </span>
                <h3 className="text-base font-black text-slate-900 mt-1">
                  Review & Verify Subordinate Expense Claim
                </h3>
                <p className="text-xs text-slate-500">
                  Approve expenses against department budget and itinerary necessity before sending to HR
                </p>
              </div>
              <button
                onClick={() => setReviewModalType(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Claim dossier */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400">Claimant</span>
                  <p className="font-black text-slate-900 text-sm">{selectedClaimForReview.employeeName}</p>
                  <span className="text-slate-500">{selectedClaimForReview.department}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold uppercase text-slate-400">Claim Amount</span>
                  <p className="font-mono font-black text-slate-900 text-base">
                    ₹{selectedClaimForReview.amount.toLocaleString('en-IN')}
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200">
                <span className="text-[10px] font-bold uppercase text-slate-400">Purpose / Title:</span>
                <p className="font-bold text-slate-800 mt-0.5">{selectedClaimForReview.title}</p>
                {selectedClaimForReview.employeeRemarks && (
                  <p className="text-slate-600 italic mt-1 text-[11px]">
                    "{selectedClaimForReview.employeeRemarks}"
                  </p>
                )}
              </div>

              {/* Uploaded Receipts */}
              <div className="pt-2 border-t border-slate-200">
                <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                  Attached Receipts ({selectedClaimForReview.receiptDocuments?.length || 0}):
                </span>
                <div className="space-y-1">
                  {selectedClaimForReview.receiptDocuments?.map(doc => (
                    <div
                      key={doc.id}
                      onClick={() => setViewingReceiptDoc({ claim: selectedClaimForReview, doc })}
                      className="p-2 rounded-xl bg-white border border-slate-200 hover:border-sky-300 hover:bg-sky-50 flex items-center justify-between text-xs cursor-pointer transition"
                    >
                      <span className="flex items-center gap-1.5 font-bold text-sky-800 truncate">
                        <Paperclip className="w-3.5 h-3.5" />
                        <span className="truncate">{doc.name}</span>
                      </span>
                      <span className="text-sky-600 font-semibold text-[10px] flex items-center gap-1">
                        <Eye className="w-3 h-3" /> Inspect Bill
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Approval Controls */}
            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Manager Sanctioned Amount (₹):
                </label>
                <input
                  type="number"
                  value={reviewApprovedAmount}
                  onChange={e => setReviewApprovedAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-mono font-black text-slate-900"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Reporting Manager Remarks / Approval Note *
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Travel and taxi bills verified against plant audit schedule. 1st approval granted."
                  value={reviewRemarks}
                  onChange={e => setReviewRemarks(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => handleManagerFirstApproval(false)}
                className="px-3.5 py-2 text-xs font-bold text-rose-700 hover:bg-rose-50 border border-rose-200 rounded-xl cursor-pointer"
              >
                Reject Claim
              </button>
              <button
                type="button"
                onClick={() => handleManagerFirstApproval(true)}
                className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-xs transition cursor-pointer flex items-center gap-1.5"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                <span>Grant 1st Approval ➔ Forward to HR Head</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: HR Head Final Approval Modal */}
      {selectedClaimForReview && reviewModalType === 'hr_review' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800">
                  Step 3 of 4: HR Head Final Policy Sign-off
                </span>
                <h3 className="text-base font-black text-slate-900 mt-1">
                  Authorize Claim for Accounts Reimbursement
                </h3>
                <p className="text-xs text-slate-500">
                  Verify corporate policy limits, per-diem caps, and GST compliance
                </p>
              </div>
              <button
                onClick={() => setReviewModalType(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Dossier with Manager sign-off notes */}
            <div className="p-3.5 rounded-2xl bg-purple-50/50 border border-purple-200 space-y-2 text-xs">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-bold uppercase text-purple-800">Employee</span>
                  <p className="font-black text-slate-900 text-sm">{selectedClaimForReview.employeeName}</p>
                  <span className="text-slate-500">{selectedClaimForReview.department}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold uppercase text-purple-800">Sanction Amount</span>
                  <p className="font-mono font-black text-slate-900 text-base">
                    ₹{(selectedClaimForReview.approvedAmount || selectedClaimForReview.amount).toLocaleString('en-IN')}
                  </p>
                </div>
              </div>

              {/* Manager Signoff Box */}
              <div className="p-2.5 rounded-xl bg-white border border-purple-100 text-[11px] space-y-1">
                <div className="flex items-center justify-between font-bold text-amber-900">
                  <span className="flex items-center gap-1">
                    <UserCheck className="w-3 h-3 text-amber-600" />
                    Manager 1st Approval Passed
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {selectedClaimForReview.managerApprovedAt?.split('T')[0]}
                  </span>
                </div>
                <p className="text-slate-700 italic">"{selectedClaimForReview.managerRemarks}"</p>
              </div>

              {/* Uploaded Receipts */}
              <div className="pt-1">
                <span className="text-[10px] font-bold uppercase text-purple-800 block mb-1">
                  Attached Receipts ({selectedClaimForReview.receiptDocuments?.length || 0}):
                </span>
                <div className="space-y-1">
                  {selectedClaimForReview.receiptDocuments?.map(doc => (
                    <div
                      key={doc.id}
                      onClick={() => setViewingReceiptDoc({ claim: selectedClaimForReview, doc })}
                      className="p-2 rounded-xl bg-white border border-purple-200 hover:bg-purple-100/50 flex items-center justify-between text-xs cursor-pointer transition"
                    >
                      <span className="flex items-center gap-1.5 font-bold text-purple-900 truncate">
                        <Paperclip className="w-3.5 h-3.5" />
                        <span className="truncate">{doc.name}</span>
                      </span>
                      <span className="text-purple-700 font-semibold text-[10px] flex items-center gap-1">
                        <Eye className="w-3 h-3" /> Inspect Bill
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* HR Sign-off Controls */}
            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Final HR Sanction Amount (₹):
                </label>
                <input
                  type="number"
                  value={reviewApprovedAmount}
                  onChange={e => setReviewApprovedAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-mono font-black text-slate-900"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  HR Head Approval Note & Policy Normalization *
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Verified under RSTPL Travel & Expense Policy 2026. Approved for Accounts disbursement."
                  value={reviewRemarks}
                  onChange={e => setReviewRemarks(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => handleHrFinalApproval(false)}
                className="px-3.5 py-2 text-xs font-bold text-rose-700 hover:bg-rose-50 border border-rose-200 rounded-xl cursor-pointer"
              >
                Reject / Send Back
              </button>
              <button
                type="button"
                onClick={() => handleHrFinalApproval(true)}
                className="px-4 py-2 text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 rounded-xl shadow-xs transition cursor-pointer flex items-center gap-1.5"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Grant Final HR Approval ➔ Send to Accounts</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: Accounts Department Reimbursement Settlement Modal */}
      {selectedClaimForReview && reviewModalType === 'accounts_disburse' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  Step 4 of 4: Accounts Reimbursement Disbursement
                </span>
                <h3 className="text-base font-black text-slate-900 mt-1">
                  Disburse Payment to Employee Bank Account
                </h3>
                <p className="text-xs text-slate-500">
                  HR Head has approved this claim. Process NEFT/UPI transfer and generate settlement voucher.
                </p>
              </div>
              <button
                onClick={() => setReviewModalType(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Payout Details */}
            <div className="p-3.5 rounded-2xl bg-emerald-50/60 border border-emerald-200 space-y-3 text-xs">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-bold uppercase text-emerald-800">Beneficiary Employee</span>
                  <p className="font-black text-slate-900 text-sm">{selectedClaimForReview.employeeName}</p>
                  <span className="text-slate-500">{selectedClaimForReview.department}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold uppercase text-emerald-800">Reimbursement Total</span>
                  <p className="font-mono font-black text-emerald-700 text-lg">
                    ₹{(selectedClaimForReview.approvedAmount || selectedClaimForReview.amount).toLocaleString('en-IN')}
                  </p>
                </div>
              </div>

              {/* Employee Bank Info */}
              {(() => {
                const emp = employees.find(e => e.id === selectedClaimForReview.employeeId);
                return (
                  <div className="p-2.5 rounded-xl bg-white border border-emerald-200/80 space-y-1 text-[11px]">
                    <div className="flex items-center justify-between font-bold text-slate-700">
                      <span className="flex items-center gap-1">
                        <Building2 className="w-3.5 h-3.5 text-emerald-700" />
                        Verified Payroll Bank Details
                      </span>
                      <span className="text-emerald-700 font-bold">Active Account</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-slate-600 mt-1">
                      <div>
                        <span className="text-[10px] text-slate-400 block">Bank Name:</span>
                        <strong className="text-slate-900">{emp?.bankName || 'HDFC Bank Ltd'}</strong>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">Account Number:</span>
                        <strong className="text-slate-900 font-mono">{emp?.bankAccountNumber || '50100987654321'}</strong>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">IFSC Code:</span>
                        <strong className="text-slate-900 font-mono">{emp?.ifscCode || 'HDFC0001234'}</strong>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">PAN Number:</span>
                        <strong className="text-slate-900 font-mono">{emp?.pan || 'AYUPK5678K'}</strong>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Payment Execution Form */}
            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Payment Mode *</label>
                  <select
                    value={disbursementPaymentMode}
                    onChange={e => setDisbursementPaymentMode(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-bold text-slate-800"
                  >
                    <option value="NEFT_RTGS">Direct Bank Transfer (NEFT / RTGS)</option>
                    <option value="UPI">Corporate UPI / IMPS</option>
                    <option value="Payroll_Transfer">Credit in Next Payroll Cycle</option>
                    <option value="Corporate_Card">Corporate Card Settlement</option>
                    <option value="Cheque">Accounts Cheque</option>
                    <option value="Cash">Cash Voucher Payout</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Disbursement Date *</label>
                  <input
                    type="date"
                    value={disbursementDate}
                    onChange={e => setDisbursementDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-mono"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-bold text-slate-700 block">
                    Bank Transaction Ref / UTR Number *
                  </label>
                  <button
                    type="button"
                    onClick={() => setDisbursementUtrRef(generateRandomUTR())}
                    className="text-[10px] text-sky-700 font-bold hover:underline cursor-pointer"
                  >
                    Generate Ref
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={disbursementUtrRef}
                  onChange={e => setDisbursementUtrRef(e.target.value)}
                  placeholder="e.g. NEFT-RSTPL-20261008-0491"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-mono font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Accounts Journal / Voucher Remarks
                </label>
                <input
                  type="text"
                  value={reviewRemarks}
                  onChange={e => setReviewRemarks(e.target.value)}
                  placeholder="e.g. Disbursed from Corporate Operations Account #9910"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setReviewModalType(null)}
                className="px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAccountsDisbursement}
                className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition cursor-pointer flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Execute Payment & Mark as Reimbursed</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 5: Official Reimbursement Payment Advice Slip Modal */}
      {selectedClaimForReview && reviewModalType === 'view_slip' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  Official Accounts Payment Advice
                </span>
                <h3 className="text-base font-black text-slate-900 mt-1">
                  Reimbursement Settlement Voucher
                </h3>
              </div>
              <button
                onClick={() => {
                  setSelectedClaimForReview(null);
                  setReviewModalType(null);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Printable Slip Container */}
            <div className="p-5 rounded-2xl border-2 border-slate-200 bg-slate-50 space-y-4 text-xs">
              {/* Slip Header */}
              <div className="border-b border-slate-200 pb-3 flex justify-between items-start">
                <div>
                  <h4 className="font-black text-slate-900 text-sm tracking-tight">
                    RS TECHNOVISIONS PVT. LTD. (RSTPL)
                  </h4>
                  <p className="text-[10px] text-slate-500">
                    Corporate Finance & Employee Accounts Settlement Cell · Pune
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono text-slate-400">VOUCHER REF</span>
                  <p className="font-mono font-bold text-slate-800">{selectedClaimForReview.id.toUpperCase()}-PAY</p>
                </div>
              </div>

              {/* Claimant & Claim details */}
              <div className="grid grid-cols-2 gap-3 text-slate-700">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Employee</span>
                  <strong className="text-slate-900">{selectedClaimForReview.employeeName}</strong>
                  <p className="text-[11px] text-slate-500">{selectedClaimForReview.department}</p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Disbursement Date</span>
                  <strong className="text-slate-900 font-mono">
                    {selectedClaimForReview.disbursedAt?.split('T')[0] || new Date().toISOString().split('T')[0]}
                  </strong>
                </div>
              </div>

              {/* Amount Box */}
              <div className="p-3 rounded-xl bg-emerald-100/60 border border-emerald-300 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase text-emerald-800 block">Total Net Reimbursed</span>
                  <p className="text-xs text-slate-600 font-medium">{selectedClaimForReview.title}</p>
                </div>
                <div className="text-right">
                  <span className="text-lg font-black text-emerald-900 font-mono">
                    ₹{(selectedClaimForReview.disbursedAmount || selectedClaimForReview.amount).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Bank Transfer Details */}
              <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-1 text-[11px]">
                <div className="flex justify-between text-slate-600">
                  <span>Payment Mode:</span>
                  <strong className="text-slate-900">{selectedClaimForReview.paymentMode || 'NEFT / RTGS'}</strong>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Transaction UTR Ref:</span>
                  <strong className="text-slate-900 font-mono">{selectedClaimForReview.transactionRef || 'NEFT-8849201'}</strong>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Credited Account:</span>
                  <span className="text-slate-800 font-mono text-[10px]">{selectedClaimForReview.bankAccountDetails || 'HDFC Bank · A/c: 50100987654321'}</span>
                </div>
              </div>

              {/* 3-Stage Sign-off Signatures */}
              <div className="pt-2 border-t border-slate-200 grid grid-cols-3 gap-2 text-center text-[10px]">
                <div className="p-2 rounded-lg bg-white border border-slate-100">
                  <span className="text-slate-400 block">1st Approval</span>
                  <strong className="text-slate-800 truncate block mt-0.5">
                    {selectedClaimForReview.managerApprovedBy?.split(' ')[0] || 'Reporting Mgr'}
                  </strong>
                  <span className="text-emerald-600 font-bold text-[9px]">Verified</span>
                </div>
                <div className="p-2 rounded-lg bg-white border border-slate-100">
                  <span className="text-slate-400 block">Final HR Approval</span>
                  <strong className="text-slate-800 truncate block mt-0.5">
                    {selectedClaimForReview.hrApprovedBy?.split(' ')[0] || 'VP HR Head'}
                  </strong>
                  <span className="text-emerald-600 font-bold text-[9px]">Policy OK</span>
                </div>
                <div className="p-2 rounded-lg bg-white border border-slate-100">
                  <span className="text-slate-400 block">Disbursed By</span>
                  <strong className="text-slate-800 truncate block mt-0.5">Accounts Controller</strong>
                  <span className="text-emerald-600 font-bold text-[9px]">Transferred</span>
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                Official electronic voucher generated by CodeTech HRMS
              </span>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition cursor-pointer flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Payment Advice</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 6: Interactive Receipt & Invoice Document Viewer (Requested Feature) */}
      {viewingReceiptDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto space-y-4">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-sky-100 text-sky-800 font-mono font-bold text-xs uppercase">
                    {viewingReceiptDoc.doc.fileType}
                  </span>
                  <h3 className="text-base font-black text-slate-900 truncate max-w-md">
                    {viewingReceiptDoc.doc.name}
                  </h3>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Uploaded on {viewingReceiptDoc.doc.uploadDate} · Size: {viewingReceiptDoc.doc.fileSize}
                </p>
              </div>
              <button
                onClick={() => setViewingReceiptDoc(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* High-Fidelity Tax Invoice & Receipt Simulated Preview */}
            <div className="p-6 rounded-2xl border-2 border-slate-200 bg-white shadow-inner space-y-4 font-sans">
              {/* Receipt Visual Header */}
              <div className="flex justify-between items-start border-b border-slate-200 pb-4">
                <div>
                  <span className="text-[10px] font-bold text-sky-700 uppercase tracking-wider block">
                    TAX INVOICE & CASH RECEIPT
                  </span>
                  <h4 className="text-base font-black text-slate-900">
                    {viewingReceiptDoc.claim.merchantName || 'OFFICIAL VENDOR SERVICES'}
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    GSTIN: {viewingReceiptDoc.claim.gstNumber || '27AABCR9912K1Z9'} · Certified Vendor
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 font-mono block">INVOICE NUMBER</span>
                  <p className="font-mono font-black text-slate-800 text-xs">
                    {viewingReceiptDoc.claim.invoiceNumber || 'INV-2026-OCT-8812'}
                  </p>
                  <span className="text-[10px] text-slate-500 font-mono block">
                    Date: {viewingReceiptDoc.claim.date}
                  </span>
                </div>
              </div>

              {/* Billed To */}
              <div className="grid grid-cols-2 gap-4 text-xs text-slate-600 py-2">
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">Billed To (Client):</span>
                  <strong className="text-slate-900">RS Technovisions Pvt. Ltd. (RSTPL)</strong>
                  <p className="text-[11px] text-slate-500">
                    Claimant: {viewingReceiptDoc.claim.employeeName} ({viewingReceiptDoc.claim.department})
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-bold uppercase text-slate-400 block">Payment Status:</span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px] inline-block">
                    PAID IN FULL
                  </span>
                </div>
              </div>

              {/* Items Line Table */}
              <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="p-2.5">Item Description</th>
                      <th className="p-2.5 text-center">Category</th>
                      <th className="p-2.5 text-right">Tax (GST)</th>
                      <th className="p-2.5 text-right">Amount (INR)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    <tr>
                      <td className="p-2.5 font-medium text-slate-900">
                        {viewingReceiptDoc.claim.title}
                      </td>
                      <td className="p-2.5 text-center">
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-[10px]">
                          {viewingReceiptDoc.claim.category}
                        </span>
                      </td>
                      <td className="p-2.5 text-right font-mono text-slate-500">18% GST</td>
                      <td className="p-2.5 text-right font-mono font-bold text-slate-900">
                        ₹{viewingReceiptDoc.claim.amount.toLocaleString('en-IN')}
                      </td>
                    </tr>
                  </tbody>
                  <tfoot className="bg-slate-50/80 border-t border-slate-200 font-bold">
                    <tr>
                      <td colSpan={3} className="p-2.5 text-right text-slate-900 font-black">
                        Total Amount Paid:
                      </td>
                      <td className="p-2.5 text-right font-mono text-emerald-700 text-sm font-black">
                        ₹{viewingReceiptDoc.claim.amount.toLocaleString('en-IN')}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Digital Verification Stamp */}
              <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500">
                <div className="flex items-center gap-1.5">
                  <FileCheck className="w-4 h-4 text-emerald-600" />
                  <span>Digitally verified invoice attached with biometric submission audit hash</span>
                </div>
                <div className="font-mono text-[10px] text-slate-400">
                  DOC_ID: {viewingReceiptDoc.doc.id}
                </div>
              </div>
            </div>

            {/* Viewer Controls */}
            <div className="pt-2 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Receipt file verified for Reporting Manager & HR Head audit
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer flex items-center gap-1"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Receipt</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const blob = new Blob([JSON.stringify(viewingReceiptDoc.claim, null, 2)], {
                      type: 'application/json',
                    });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = viewingReceiptDoc.doc.name;
                    a.click();
                  }}
                  className="px-4 py-1.5 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl transition cursor-pointer flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Document</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

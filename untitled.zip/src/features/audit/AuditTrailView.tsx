// RSTPL HRMS - Enterprise Security & Immutable Audit Trail
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  ShieldCheck,
  Search,
  Filter,
  Download,
  Clock,
  Terminal,
  Activity,
  UserCheck
} from 'lucide-react';
import { AuditLogItem } from '../../types/hrms';

interface AuditTrailViewProps {
  logs: AuditLogItem[];
  onLogAudit: (action: any, module: string, details: string) => void;
}

export const AuditTrailView: React.FC<AuditTrailViewProps> = ({ logs, onLogAudit }) => {
  const [filterAction, setFilterAction] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredLogs = logs.filter(l => {
    const matchAction = filterAction === 'ALL' || l.action === filterAction;
    const matchSearch =
      l.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.module.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.userName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchAction && matchSearch;
  });

  const handleExportAudit = () => {
    const headers = ['Timestamp,User,Role,Action,Module,IP,Details'];
    const rows = filteredLogs.map(
      l => `"${l.timestamp}","${l.userName}","${l.userRole}","${l.action}","${l.module}","${l.ipAddress}","${l.details.replace(/"/g, '""')}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `RSTPL_Audit_Trail_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onLogAudit('EXPORT', 'Audit Security', 'Exported system audit trail log to CSV');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <ShieldCheck className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">Security & Compliance Audit Trail</h2>
              <p className="text-xs text-slate-500">
                Immutable chronological ledger of all administrative logins, biometric synchronizations & payroll approvals
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handleExportAudit}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 rounded-xl border border-slate-200 shadow-2xs transition-colors cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-slate-500" />
          <span>Export Audit Log</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search details, module, user..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 w-64"
            />
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <span className="font-semibold">Action:</span>
            <select
              value={filterAction}
              onChange={e => setFilterAction(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50 font-medium text-slate-800"
            >
              <option value="ALL">All Actions</option>
              <option value="LOGIN">LOGIN</option>
              <option value="SYNC">SYNC</option>
              <option value="CREATE">CREATE</option>
              <option value="UPDATE">UPDATE</option>
              <option value="APPROVE">APPROVE</option>
              <option value="FINALIZE">FINALIZE</option>
              <option value="EXPORT">EXPORT</option>
            </select>
          </div>
        </div>

        <span className="text-xs font-semibold text-slate-500 font-mono">
          {filteredLogs.length} Events Logged
        </span>
      </div>

      {/* Audit Logs Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Actor / Role</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Module</th>
                <th className="py-3 px-4">Event Details</th>
                <th className="py-3 px-4">IP Address</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredLogs.map(item => (
                <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-500">
                    {new Date(item.timestamp).toLocaleString('en-IN')}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-bold text-slate-900">{item.userName}</span>
                    <span className="block text-[10px] text-slate-400 font-mono">{item.userRole}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.action === 'LOGIN'
                          ? 'bg-slate-100 text-slate-800'
                          : item.action === 'SYNC'
                          ? 'bg-sky-100 text-sky-800'
                          : item.action === 'APPROVE' || item.action === 'FINALIZE'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {item.action}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-800">{item.module}</td>
                  <td className="py-3 px-4 text-slate-600 max-w-md">{item.details}</td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-400">{item.ipAddress}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

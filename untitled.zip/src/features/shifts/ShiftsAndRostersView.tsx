// RSTPL HRMS - Shifts & Roster Management Studio
// RS Technovisions XpertSkillCop
// Department-wise Monthly & Quarterly Shift Planning, Definition & Assignment

import React, { useState, useMemo } from 'react';
import {
  Clock,
  Calendar,
  Users,
  Plus,
  Filter,
  Search,
  Download,
  RotateCw,
  CheckCircle2,
  AlertCircle,
  Building,
  Briefcase,
  ChevronLeft,
  ChevronRight,
  Edit2,
  Trash2,
  Save,
  X,
  Sparkles,
  Layers,
  ArrowRight,
  Sun,
  Moon,
  Coffee,
  Check,
  FileSpreadsheet
} from 'lucide-react';
import { Shift, Employee, Department, Unit, Designation } from '../../types/hrms';

interface ShiftsAndRostersViewProps {
  shifts: Shift[];
  employees: Employee[];
  departments: Department[];
  units: Unit[];
  designations: Designation[];
  onUpdateShifts: (shifts: Shift[]) => void;
  onUpdateEmployees?: (employees: Employee[]) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
  onNavigateToEmployeeMaster?: () => void;
}

export const ShiftsAndRostersView: React.FC<ShiftsAndRostersViewProps> = ({
  shifts,
  employees,
  departments,
  units,
  designations,
  onUpdateShifts,
  onUpdateEmployees,
  onLogAudit,
  onNavigateToEmployeeMaster,
}) => {
  const [activeTab, setActiveTab] = useState<'roster' | 'shifts-master' | 'bulk-assign'>('roster');

  // Roster Filters
  const [selectedUnit, setSelectedUnit] = useState<string>('ALL');
  const [selectedDept, setSelectedDept] = useState<string>('ALL');
  const [viewPeriod, setViewPeriod] = useState<'monthly' | 'quarterly'>('monthly');
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-10'); // YYYY-MM
  const [selectedQuarter, setSelectedQuarter] = useState<string>('Q4-2026'); // Q1-Q4
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Shift Master State
  const [showShiftModal, setShowShiftModal] = useState<boolean>(false);
  const [editingShift, setEditingShift] = useState<Shift | null>(null);
  const [newShift, setNewShift] = useState<Omit<Shift, 'id' | 'orgId'>>({
    name: 'Morning General Shift',
    code: 'MGS-01',
    startTime: '08:30',
    endTime: '17:30',
    graceTimeMinutes: 15,
    halfDayThresholdHours: 4.5,
    fullDayThresholdHours: 8.0,
    isNightShift: false,
    color: '#0284c7',
  });

  // Dynamic In-Memory Roster Mapping: employeeId -> day (1..31) -> shiftId or 'WO'
  const [rosterMap, setRosterMap] = useState<Record<string, Record<number, string>>>(() => {
    const initial: Record<string, Record<number, string>> = {};
    employees.forEach((emp, empIdx) => {
      initial[emp.id] = {};
      const baseShift = emp.shiftId || shifts[0]?.id || 'sh-gen';
      for (let day = 1; day <= 31; day++) {
        // Assume Sunday is weekly off (using Oct 2026: 4, 11, 18, 25 are Sundays)
        const isSunday = [4, 11, 18, 25].includes(day);
        const isSecondSat = day === 10;
        if (isSunday || isSecondSat) {
          initial[emp.id][day] = 'WO';
        } else {
          // If shift rotation exists in plants
          if (emp.departmentId === 'dept-prod' && day > 15) {
            initial[emp.id][day] = shifts.find(s => s.code.includes('B'))?.id || baseShift;
          } else {
            initial[emp.id][day] = baseShift;
          }
        }
      }
    });
    return initial;
  });

  // Cell Editing
  const [cellEdit, setCellEdit] = useState<{ empId: string; day: number } | null>(null);

  // Bulk Assignment Modal
  const [bulkShiftId, setBulkShiftId] = useState<string>(shifts[0]?.id || '');
  const [bulkDeptId, setBulkDeptId] = useState<string>('ALL');
  const [bulkUnitId, setBulkUnitId] = useState<string>('ALL');
  const [bulkWeekendPattern, setBulkWeekendPattern] = useState<'sundays' | 'sat_sun' | 'alternate_sat'>('sundays');
  const [bulkToast, setBulkToast] = useState<string | null>(null);

  // Filtered employees for Roster
  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      const matchUnit = selectedUnit === 'ALL' || emp.unitId === selectedUnit;
      const matchDept = selectedDept === 'ALL' || emp.departmentId === selectedDept;
      const matchSearch =
        emp.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.employeeCode.toLowerCase().includes(searchQuery.toLowerCase());
      return matchUnit && matchDept && matchSearch;
    });
  }, [employees, selectedUnit, selectedDept, searchQuery]);

  // Helpers
  const getDeptName = (id: string) => departments.find(d => d.id === id)?.name || 'General';
  const getUnitName = (id: string) => units.find(u => u.id === id)?.name || 'Corporate';
  const getDesigName = (id: string) => designations.find(d => d.id === id)?.title || 'Officer';
  const getShift = (shiftId: string) => shifts.find(s => s.id === shiftId);

  // Save / Update Shift
  const handleSaveShift = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingShift) {
      const updated = shifts.map(s => (s.id === editingShift.id ? { ...editingShift, ...newShift } : s));
      onUpdateShifts(updated);
      onLogAudit('UPDATE', 'Shift Master', `Updated shift configuration for ${newShift.name} (${newShift.code})`);
    } else {
      const created: Shift = {
        id: `sh-${Date.now()}`,
        orgId: 'org-rstpl-001',
        ...newShift,
      };
      onUpdateShifts([...shifts, created]);
      onLogAudit('CREATE', 'Shift Master', `Created new shift ${created.name} (${created.code})`);
    }
    setShowShiftModal(false);
    setEditingShift(null);
  };

  const handleDeleteShift = (shiftId: string, shiftName: string) => {
    if (shifts.length <= 1) {
      alert('At least one shift must exist in the system.');
      return;
    }
    const updated = shifts.filter(s => s.id !== shiftId);
    onUpdateShifts(updated);
    onLogAudit('DELETE', 'Shift Master', `Deleted shift ${shiftName}`);
  };

  const openEditShift = (shift: Shift) => {
    setEditingShift(shift);
    setNewShift({
      name: shift.name,
      code: shift.code,
      startTime: shift.startTime,
      endTime: shift.endTime,
      graceTimeMinutes: shift.graceTimeMinutes,
      halfDayThresholdHours: shift.halfDayThresholdHours,
      fullDayThresholdHours: shift.fullDayThresholdHours,
      isNightShift: shift.isNightShift,
      color: shift.color,
    });
    setShowShiftModal(true);
  };

  const openCreateShift = () => {
    setEditingShift(null);
    setNewShift({
      name: '',
      code: '',
      startTime: '09:00',
      endTime: '18:00',
      graceTimeMinutes: 15,
      halfDayThresholdHours: 4.5,
      fullDayThresholdHours: 8.0,
      isNightShift: false,
      color: '#0284c7',
    });
    setShowShiftModal(true);
  };

  // Change single employee day shift
  const handleSetCellShift = (empId: string, day: number, shiftId: string) => {
    setRosterMap(prev => ({
      ...prev,
      [empId]: {
        ...(prev[empId] || {}),
        [day]: shiftId,
      },
    }));
    setCellEdit(null);
  };

  // Bulk Apply Roster to Department or Unit
  const handleApplyBulkRoster = () => {
    if (!bulkShiftId) return;
    const targetEmployees = employees.filter(emp => {
      const matchUnit = bulkUnitId === 'ALL' || emp.unitId === bulkUnitId;
      const matchDept = bulkDeptId === 'ALL' || emp.departmentId === bulkDeptId;
      return matchUnit && matchDept;
    });

    const newRoster = { ...rosterMap };
    targetEmployees.forEach(emp => {
      newRoster[emp.id] = newRoster[emp.id] || {};
      for (let day = 1; day <= 31; day++) {
        let isOff = false;
        if (bulkWeekendPattern === 'sundays') {
          isOff = [4, 11, 18, 25].includes(day);
        } else if (bulkWeekendPattern === 'sat_sun') {
          isOff = [3, 4, 10, 11, 17, 18, 24, 25, 31].includes(day);
        } else if (bulkWeekendPattern === 'alternate_sat') {
          isOff = [4, 11, 18, 25, 10, 24].includes(day);
        }

        newRoster[emp.id][day] = isOff ? 'WO' : bulkShiftId;
      }
    });

    setRosterMap(newRoster);
    setBulkToast(`Successfully updated shift roster for ${targetEmployees.length} employees.`);
    setTimeout(() => setBulkToast(null), 4000);
    onLogAudit(
      'UPDATE',
      'Roster Engine',
      `Bulk applied shift ${getShift(bulkShiftId)?.name} across ${targetEmployees.length} personnel.`
    );
  };

  // Export Roster to CSV
  const handleExportRosterCSV = () => {
    const daysHeader = Array.from({ length: 31 }, (_, i) => `Day_${i + 1}`).join(',');
    const header = `EmpCode,EmpName,Department,Designation,Unit,${daysHeader}`;
    const rows = filteredEmployees.map(emp => {
      const dayValues = Array.from({ length: 31 }, (_, i) => {
        const val = rosterMap[emp.id]?.[i + 1] || 'WO';
        if (val === 'WO') return 'WO';
        return getShift(val)?.code || val;
      }).join(',');
      return `"${emp.employeeCode}","${emp.firstName} ${emp.lastName}","${getDeptName(emp.departmentId)}","${getDesigName(emp.designationId)}","${getUnitName(emp.unitId)}",${dayValues}`;
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [header, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `RSTPL_Roster_${selectedMonth}_${selectedDept}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onLogAudit('EXPORT', 'Roster Engine', `Exported shift roster matrix for ${selectedMonth}`);
  };

  // Days in month calculation for header
  const daysInMonth = Array.from({ length: 31 }, (_, i) => {
    const day = i + 1;
    // Map to day of week for Oct 2026 (Oct 1 = Thursday)
    const dayNames = ['Thu', 'Fri', 'Sat', 'Sun', 'Mon', 'Tue', 'Wed'];
    const weekday = dayNames[(day - 1) % 7];
    const isWeekend = weekday === 'Sun' || (weekday === 'Sat' && (day === 10 || day === 24));
    return { day, weekday, isWeekend };
  });

  // Quarters definition
  const quarters = [
    { code: 'Q1-2026', label: 'Q1: Apr – Jun 2026', weeks: 13 },
    { code: 'Q2-2026', label: 'Q2: Jul – Sep 2026', weeks: 13 },
    { code: 'Q3-2026', label: 'Q3: Oct – Dec 2026', weeks: 13 },
    { code: 'Q4-2026', label: 'Q4: Jan – Mar 2027', weeks: 13 },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <Clock className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                Shifts & Roster Management Studio
              </h2>
              <p className="text-xs text-slate-500">
                Department-wise shift timing definition, monthly & quarterly duty roster planning, and employee master mapping
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {onNavigateToEmployeeMaster && (
            <button
              onClick={onNavigateToEmployeeMaster}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200 transition-colors cursor-pointer"
            >
              <Users className="w-3.5 h-3.5 text-slate-500" />
              <span>Employee Master Mapping</span>
            </button>
          )}

          <button
            onClick={openCreateShift}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Define New Shift</span>
          </button>

          <button
            onClick={handleExportRosterCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Roster (CSV)</span>
          </button>
        </div>
      </div>

      {/* Main Studio Navigation Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 bg-white px-4 rounded-2xl shadow-2xs">
        <div className="flex space-x-6">
          <button
            onClick={() => setActiveTab('roster')}
            className={`py-3.5 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'roster'
                ? 'border-sky-600 text-sky-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Department-Wise Roster Matrix (Monthly & Quarterly)</span>
          </button>

          <button
            onClick={() => setActiveTab('shifts-master')}
            className={`py-3.5 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'shifts-master'
                ? 'border-sky-600 text-sky-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Shift Definition Master ({shifts.length} Configured)</span>
          </button>

          <button
            onClick={() => setActiveTab('bulk-assign')}
            className={`py-3.5 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'bulk-assign'
                ? 'border-sky-600 text-sky-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <RotateCw className="w-4 h-4" />
            <span>Bulk Shift Rotation & Weekly-Off Generator</span>
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500">
          <span className="font-semibold text-slate-700">{filteredEmployees.length}</span> Personnel in view
        </div>
      </div>

      {bulkToast && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{bulkToast}</span>
          </div>
          <button onClick={() => setBulkToast(null)} className="text-emerald-600 hover:text-emerald-900 font-bold">
            ✕
          </button>
        </div>
      )}

      {/* TAB 1: DEPARTMENT-WISE ROSTER MATRIX (MONTHLY & QUARTERLY) */}
      {activeTab === 'roster' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-3">
              {/* Unit Selector */}
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-0.5">Unit</label>
                <select
                  value={selectedUnit}
                  onChange={e => setSelectedUnit(e.target.value)}
                  className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
                >
                  <option value="ALL">All Units (Organization Wide)</option>
                  {units.map(u => (
                    <option key={u.id} value={u.id}>{u.name}</option>
                  ))}
                </select>
              </div>

              {/* Department Selector */}
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-0.5">Department</label>
                <select
                  value={selectedDept}
                  onChange={e => setSelectedDept(e.target.value)}
                  className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
                >
                  <option value="ALL">All Departments</option>
                  {departments.map(d => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>
              </div>

              {/* View Period Mode */}
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-0.5">Roster Mode</label>
                <div className="flex items-center rounded-xl border border-slate-200 bg-slate-50 p-0.5">
                  <button
                    onClick={() => setViewPeriod('monthly')}
                    className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      viewPeriod === 'monthly'
                        ? 'bg-sky-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Monthly (31 Days)
                  </button>
                  <button
                    onClick={() => setViewPeriod('quarterly')}
                    className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      viewPeriod === 'quarterly'
                        ? 'bg-sky-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Quarterly (13 Wks)
                  </button>
                </div>
              </div>

              {/* Month Picker / Quarter Picker */}
              {viewPeriod === 'monthly' ? (
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-0.5">Month</label>
                  <input
                    type="month"
                    value={selectedMonth}
                    onChange={e => setSelectedMonth(e.target.value)}
                    className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-0.5">Financial Quarter</label>
                  <select
                    value={selectedQuarter}
                    onChange={e => setSelectedQuarter(e.target.value)}
                    className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
                  >
                    {quarters.map(q => (
                      <option key={q.code} value={q.code}>{q.label}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>

            {/* Search Input */}
            <div>
              <label className="block text-[10px] font-bold uppercase text-slate-400 mb-0.5">Find Personnel</label>
              <div className="relative">
                <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search code, name..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 w-52 font-medium"
                />
              </div>
            </div>
          </div>

          {/* Shift Color Legend */}
          <div className="flex flex-wrap items-center gap-3 bg-white p-3 rounded-2xl border border-slate-200 text-xs">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">Shift Legend:</span>
            {shifts.map(sh => (
              <div key={sh.id} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: sh.color }} />
                <span className="font-bold text-slate-800">{sh.code}</span>
                <span className="text-slate-500 text-[11px]">({sh.startTime}–{sh.endTime})</span>
              </div>
            ))}
            <div className="flex items-center gap-1.5 ml-2 border-l border-slate-200 pl-3">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
              <span className="font-bold text-slate-600">WO</span>
              <span className="text-slate-400 text-[11px]">(Weekly Off)</span>
            </div>
          </div>

          {/* Interactive Roster Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="overflow-x-auto max-h-[600px]">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-900 text-white sticky top-0 z-20 text-[10px] uppercase font-bold tracking-wider">
                  <tr>
                    <th className="py-3 px-3 w-10 text-center border-r border-slate-800">#</th>
                    <th className="py-3 px-3 w-24 border-r border-slate-800">Code</th>
                    <th className="py-3 px-3 w-44 border-r border-slate-800">Employee Name</th>
                    <th className="py-3 px-3 w-36 border-r border-slate-800">Department</th>
                    <th className="py-3 px-3 w-32 border-r border-slate-800">Base Shift</th>
                    
                    {/* Monthly Days 1..31 or Quarterly Weeks 1..13 */}
                    {viewPeriod === 'monthly' ? (
                      daysInMonth.map(d => (
                        <th
                          key={d.day}
                          className={`py-2 px-1 text-center min-w-[38px] border-r border-slate-800 ${
                            d.isWeekend ? 'bg-amber-950/40 text-amber-300' : ''
                          }`}
                        >
                          <div>{d.day}</div>
                          <div className="text-[8px] font-normal opacity-75">{d.weekday}</div>
                        </th>
                      ))
                    ) : (
                      Array.from({ length: 13 }, (_, wIdx) => (
                        <th
                          key={wIdx + 1}
                          className="py-2.5 px-2 text-center min-w-[65px] border-r border-slate-800"
                        >
                          <div>Wk {wIdx + 1}</div>
                          <div className="text-[8px] font-normal opacity-75">Weekly Slot</div>
                        </th>
                      ))
                    )}
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-200 text-slate-800">
                  {filteredEmployees.length === 0 ? (
                    <tr>
                      <td colSpan={36} className="py-12 text-center text-slate-400">
                        No employees found matching the selected filters.
                      </td>
                    </tr>
                  ) : (
                    filteredEmployees.map((emp, empIdx) => {
                      const empRoster = rosterMap[emp.id] || {};
                      const baseShiftObj = getShift(emp.shiftId);

                      return (
                        <tr key={emp.id} className="hover:bg-sky-50/40 transition-colors">
                          <td className="py-2.5 px-3 text-center font-mono text-slate-400 border-r border-slate-100">
                            {empIdx + 1}
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold text-sky-700 border-r border-slate-100">
                            {emp.employeeCode}
                          </td>
                          <td className="py-2.5 px-3 border-r border-slate-100">
                            <div className="font-bold text-slate-900">{emp.firstName} {emp.lastName}</div>
                            <div className="text-[10px] text-slate-400 truncate max-w-40">{getDesigName(emp.designationId)}</div>
                          </td>
                          <td className="py-2.5 px-3 border-r border-slate-100">
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                              {getDeptName(emp.departmentId)}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 border-r border-slate-100">
                            <div className="flex items-center gap-1.5">
                              <span
                                className="w-2 h-2 rounded-full"
                                style={{ backgroundColor: baseShiftObj?.color || '#0284c7' }}
                              />
                              <span className="font-bold text-[11px]">{baseShiftObj?.code || 'GEN'}</span>
                            </div>
                            <span className="text-[9px] text-slate-400">{baseShiftObj?.startTime}–{baseShiftObj?.endTime}</span>
                          </td>

                          {/* Days Cells */}
                          {viewPeriod === 'monthly' ? (
                            daysInMonth.map(d => {
                              const assigned = empRoster[d.day] || emp.shiftId || 'WO';
                              const isWO = assigned === 'WO';
                              const shiftObj = getShift(assigned);
                              const isEditing = cellEdit?.empId === emp.id && cellEdit?.day === d.day;

                              return (
                                <td
                                  key={d.day}
                                  onClick={() => setCellEdit({ empId: emp.id, day: d.day })}
                                  className={`p-1 text-center border-r border-slate-100 cursor-pointer relative hover:ring-2 hover:ring-sky-500/40 transition-all ${
                                    d.isWeekend ? 'bg-amber-50/30' : ''
                                  }`}
                                  title={`Day ${d.day} (${d.weekday}): ${isWO ? 'Weekly Off' : `${shiftObj?.name} (${shiftObj?.startTime}-${shiftObj?.endTime})`}`}
                                >
                                  {isEditing ? (
                                    <div
                                      className="absolute z-30 top-0 left-0 bg-white p-1 rounded-lg border border-slate-300 shadow-xl min-w-32 text-left"
                                      onClick={e => e.stopPropagation()}
                                    >
                                      <div className="text-[10px] font-bold text-slate-600 mb-1 px-1">
                                        Day {d.day} Shift:
                                      </div>
                                      <button
                                        onClick={() => handleSetCellShift(emp.id, d.day, 'WO')}
                                        className="w-full text-left px-2 py-1 text-[11px] rounded hover:bg-slate-100 font-bold text-slate-600 cursor-pointer"
                                      >
                                        Weekly Off (WO)
                                      </button>
                                      {shifts.map(s => (
                                        <button
                                          key={s.id}
                                          onClick={() => handleSetCellShift(emp.id, d.day, s.id)}
                                          className="w-full text-left px-2 py-1 text-[11px] rounded hover:bg-sky-50 flex items-center justify-between cursor-pointer"
                                        >
                                          <span className="font-bold">{s.code}</span>
                                          <span className="text-[9px] text-slate-400">{s.startTime}</span>
                                        </button>
                                      ))}
                                      <button
                                        onClick={() => setCellEdit(null)}
                                        className="mt-1 w-full text-center text-[10px] text-slate-400 hover:text-slate-700 pt-1 border-t border-slate-100"
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  ) : isWO ? (
                                    <span className="inline-block px-1 py-0.5 rounded text-[9px] font-black bg-slate-200 text-slate-600">
                                      WO
                                    </span>
                                  ) : (
                                    <span
                                      className="inline-block px-1 py-0.5 rounded text-[9px] font-black text-white shadow-2xs"
                                      style={{ backgroundColor: shiftObj?.color || '#0284c7' }}
                                    >
                                      {shiftObj?.code || 'SH'}
                                    </span>
                                  )}
                                </td>
                              );
                            })
                          ) : (
                            Array.from({ length: 13 }, (_, wIdx) => {
                              // Weekly representation
                              const weekShift = baseShiftObj;
                              return (
                                <td
                                  key={wIdx + 1}
                                  className="p-1.5 text-center border-r border-slate-100 font-semibold"
                                >
                                  <span
                                    className="inline-block px-2 py-0.5 rounded text-[10px] font-bold text-white shadow-2xs"
                                    style={{ backgroundColor: weekShift?.color || '#0284c7' }}
                                  >
                                    {weekShift?.code || 'GEN'}
                                  </span>
                                  <div className="text-[9px] text-slate-400 mt-0.5">
                                    {weekShift?.startTime}–{weekShift?.endTime}
                                  </div>
                                </td>
                              );
                            })
                          )}
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-500 gap-2">
              <div className="flex items-center gap-2">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Click any cell to immediately change the day's assigned shift or set Weekly Off (WO).</span>
              </div>
              <div className="font-semibold text-slate-700">
                Total Personnel: {filteredEmployees.length} · Departments: {departments.length}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SHIFT DEFINITION MASTER */}
      {activeTab === 'shifts-master' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              Configured Shifts & Timing Rules ({shifts.length})
            </h3>
            <button
              onClick={openCreateShift}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Shift Configuration</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {shifts.map(sh => (
              <div
                key={sh.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs flex flex-col justify-between hover:border-sky-300 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className="px-2.5 py-1 rounded-xl text-xs font-black text-white shadow-2xs"
                      style={{ backgroundColor: sh.color }}
                    >
                      {sh.code}
                    </span>
                    {sh.isNightShift ? (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-200">
                        <Moon className="w-3 h-3" />
                        <span>Night Shift</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                        <Sun className="w-3 h-3" />
                        <span>Day Shift</span>
                      </span>
                    )}
                  </div>

                  <h4 className="font-black text-slate-900 text-sm">{sh.name}</h4>

                  {/* Timing Strip */}
                  <div className="mt-4 p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5 font-mono text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Shift Timings:</span>
                      <span className="font-bold text-slate-800">{sh.startTime} – {sh.endTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Grace Allowed:</span>
                      <span className="font-bold text-emerald-600">+{sh.graceTimeMinutes} mins</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Full Day Min:</span>
                      <span className="font-bold text-slate-700">{sh.fullDayThresholdHours} hrs</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Half Day Min:</span>
                      <span className="font-bold text-slate-700">{sh.halfDayThresholdHours} hrs</span>
                    </div>
                  </div>

                  {/* Employee Count */}
                  <div className="mt-3 text-[11px] text-slate-500 flex items-center justify-between">
                    <span>Assigned Personnel:</span>
                    <span className="font-bold text-slate-800">
                      {employees.filter(e => e.shiftId === sh.id).length} employees
                    </span>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                  <button
                    onClick={() => openEditShift(sh)}
                    className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600 hover:text-sky-600 transition-colors cursor-pointer"
                    title="Edit shift definition"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteShift(sh.id, sh.name)}
                    className="p-1.5 rounded-lg hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                    title="Delete shift"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: BULK SHIFT ROTATION & WEEKLY-OFF GENERATOR */}
      {activeTab === 'bulk-assign' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs space-y-6">
          <div>
            <h3 className="text-sm font-black text-slate-900 tracking-tight">
              Bulk Department Shift Rotation & Roster Automator
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Rapidly assign shifts to whole departments, schedule plant rotations, and apply weekly off patterns
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-5 rounded-2xl bg-slate-50 border border-slate-200">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Target Operating Unit</label>
              <select
                value={bulkUnitId}
                onChange={e => setBulkUnitId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white font-semibold text-slate-800"
              >
                <option value="ALL">All Units</option>
                {units.map(u => (
                  <option key={u.id} value={u.id}>{u.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Target Department</label>
              <select
                value={bulkDeptId}
                onChange={e => setBulkDeptId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white font-semibold text-slate-800"
              >
                <option value="ALL">All Departments</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Assign Shift</label>
              <select
                value={bulkShiftId}
                onChange={e => setBulkShiftId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white font-bold text-sky-800"
              >
                {shifts.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code}: {s.startTime} - {s.endTime})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Weekly Off (WO) Pattern</label>
              <select
                value={bulkWeekendPattern}
                onChange={e => setBulkWeekendPattern(e.target.value as any)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white font-semibold text-slate-800"
              >
                <option value="sundays">Sundays Only</option>
                <option value="sat_sun">Every Saturday & Sunday (Corporate)</option>
                <option value="alternate_sat">Sundays + Alternate Saturdays (Plant)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="text-xs text-slate-500">
              Impacts <strong className="text-slate-800">
                {employees.filter(e => (bulkUnitId === 'ALL' || e.unitId === bulkUnitId) && (bulkDeptId === 'ALL' || e.departmentId === bulkDeptId)).length}
              </strong> employees in the roster matrix.
            </div>

            <button
              onClick={handleApplyBulkRoster}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
            >
              <RotateCw className="w-4 h-4" />
              <span>Apply Shift & Roster Now</span>
            </button>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT SHIFT DEFINITION */}
      {showShiftModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-sky-700" />
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                  {editingShift ? 'Edit Shift Configuration' : 'Define New Shift Master'}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowShiftModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveShift} className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Shift Name *</label>
                  <input
                    type="text"
                    required
                    value={newShift.name}
                    onChange={e => setNewShift({ ...newShift, name: e.target.value })}
                    placeholder="e.g. General Corporate Shift"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Shift Code *</label>
                  <input
                    type="text"
                    required
                    value={newShift.code}
                    onChange={e => setNewShift({ ...newShift, code: e.target.value })}
                    placeholder="e.g. GEN-01 or PL-SH-A"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold uppercase"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Start Time (24h) *</label>
                  <input
                    type="time"
                    required
                    value={newShift.startTime}
                    onChange={e => setNewShift({ ...newShift, startTime: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">End Time (24h) *</label>
                  <input
                    type="time"
                    required
                    value={newShift.endTime}
                    onChange={e => setNewShift({ ...newShift, endTime: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Grace Period</label>
                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      max="60"
                      value={newShift.graceTimeMinutes}
                      onChange={e => setNewShift({ ...newShift, graceTimeMinutes: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    />
                    <span className="absolute right-2.5 top-2 text-[10px] text-slate-400">mins</span>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Full Day Min</label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.5"
                      min="4"
                      max="12"
                      value={newShift.fullDayThresholdHours}
                      onChange={e => setNewShift({ ...newShift, fullDayThresholdHours: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    />
                    <span className="absolute right-2.5 top-2 text-[10px] text-slate-400">hrs</span>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Half Day Min</label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.5"
                      min="2"
                      max="6"
                      value={newShift.halfDayThresholdHours}
                      onChange={e => setNewShift({ ...newShift, halfDayThresholdHours: Number(e.target.value) })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    />
                    <span className="absolute right-2.5 top-2 text-[10px] text-slate-400">hrs</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 items-center pt-2">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Color Tag</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={newShift.color}
                      onChange={e => setNewShift({ ...newShift, color: e.target.value })}
                      className="w-10 h-9 p-0.5 rounded-lg border border-slate-200 cursor-pointer"
                    />
                    <span className="font-mono text-xs text-slate-600">{newShift.color}</span>
                  </div>
                </div>

                <div className="pt-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newShift.isNightShift}
                      onChange={e => setNewShift({ ...newShift, isNightShift: e.target.checked })}
                      className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500"
                    />
                    <span className="font-bold text-slate-800">Is Overnight / Night Shift</span>
                  </label>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowShiftModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 font-bold text-slate-700 hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 font-bold text-white hover:bg-sky-700 shadow-md cursor-pointer"
                >
                  {editingShift ? 'Save Changes' : 'Create Shift'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

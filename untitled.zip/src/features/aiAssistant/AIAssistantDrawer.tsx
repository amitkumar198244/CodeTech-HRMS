// RSTPL HRMS - AI HR Assistant Powered by Google Gemini
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  X,
  Bot,
  User,
  CheckCircle2,
  HelpCircle,
  ArrowRight,
  RefreshCw,
  Building2,
  ShieldCheck
} from 'lucide-react';
import { HRMSStoreData } from '../../services/hrmsStorage';
import { GeminiHRAssistant, AIResponse } from '../../services/geminiService';
import { UserRole } from '../../types/hrms';

interface AIAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  storeData: HRMSStoreData;
  currentRole: UserRole;
  onNavigate: (module: string) => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  sourceContext?: string;
  suggestedActions?: string[];
  timestamp: string;
}

const SAMPLE_QUESTIONS = [
  'How many employees are absent today?',
  'How many leaves are pending approval?',
  'What is the monthly payroll cost for September 2026?',
  'How many open job vacancies are currently active?',
  'Are all biometric devices online and healthy?',
];

export const AIAssistantDrawer: React.FC<AIAssistantDrawerProps> = ({
  isOpen,
  onClose,
  storeData,
  currentRole,
  onNavigate,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init',
      sender: 'assistant',
      text: `Hello! I am your **RSTPL AI HR Intelligence Assistant** powered by Google Gemini. I have live awareness of your ${storeData.employees.length} employees, shifts, attendance punches, and payroll calculations. How may I assist you today?`,
      sourceContext: 'RSTPL Enterprise Knowledge Engine',
      suggestedActions: ['Check Today Attendance', 'Review Pending Leaves', 'Verify Biometric Hardware'],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputQuestion, setInputQuestion] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSendMessage = async (textToSend?: string) => {
    const question = textToSend || inputQuestion;
    if (!question.trim()) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: question,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuestion('');
    setLoading(true);

    try {
      const response: AIResponse = await GeminiHRAssistant.askHRAssistant(
        question,
        storeData,
        currentRole
      );

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: response.answer,
        sourceContext: response.sourceContext,
        suggestedActions: response.suggestedActions,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-slate-950/40 backdrop-blur-xs">
      <div className="bg-white h-full max-w-lg w-full flex flex-col justify-between shadow-2xl border-l border-slate-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-gradient-to-r from-sky-900 to-indigo-950 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-400 to-amber-300 text-slate-900 flex items-center justify-center shadow-md">
              <Sparkles className="w-5 h-5 text-indigo-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black tracking-tight">RSTPL AI HR Assistant</h3>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-400 text-slate-950">
                  Gemini API
                </span>
              </div>
              <p className="text-[10px] text-sky-200">
                Natural Language Intelligence · Role-Filtered Context
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chat History */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[88%] rounded-2xl p-3.5 text-xs shadow-2xs leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-sky-600 text-white rounded-br-xs'
                    : 'bg-slate-50 text-slate-800 border border-slate-200 rounded-bl-xs'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.text}</div>

                {msg.sourceContext && (
                  <div className="mt-2.5 pt-2 border-t border-slate-200/60 text-[10px] text-slate-400 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-sky-600" />
                    <span>Source: {msg.sourceContext}</span>
                  </div>
                )}
              </div>

              {msg.suggestedActions && (
                <div className="flex flex-wrap gap-1.5 mt-2 max-w-[88%]">
                  {msg.suggestedActions.map(action => (
                    <button
                      key={action}
                      onClick={() => handleSendMessage(action)}
                      className="px-2 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-[10px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <span>{action}</span>
                      <ArrowRight className="w-2.5 h-2.5" />
                    </button>
                  ))}
                </div>
              )}

              <span className="text-[9px] text-slate-400 mt-1 px-1">{msg.timestamp}</span>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-slate-500 p-2 rounded-xl bg-slate-50 border border-slate-100 max-w-[200px]">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-sky-600" />
              <span>Analyzing live data graph...</span>
            </div>
          )}
        </div>

        {/* Quick Sample Prompts & Input Area */}
        <div className="p-3 border-t border-slate-200 bg-slate-50/50 space-y-2">
          {messages.length < 3 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {SAMPLE_QUESTIONS.slice(0, 3).map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(q)}
                  className="shrink-0 px-2 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[10px] font-medium text-slate-700 transition-colors cursor-pointer"
                >
                  {q}
                </button>
              ))}
            </div>
          )}

          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Ask anything about attendance, leaves, payroll..."
              value={inputQuestion}
              onChange={e => setInputQuestion(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
              className="flex-1 px-3 py-2 text-xs rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={!inputQuestion.trim() || loading}
              className="p-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white shadow-xs transition-colors cursor-pointer disabled:opacity-40"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

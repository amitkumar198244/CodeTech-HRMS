// RSTPL HRMS - User Credentials & Role Rights Admin Panel (RBAC)
// RS Technovisions XpertSkillCop
// Enables Admin to create user credentials, assign rights, and dispatch mobile logins to employees

import React, { useState } from 'react';
import {
  Shield,
  Key,
  Users,
  Smartphone,
  Plus,
  CheckCircle2,
  Lock,
  Eye,
  EyeOff,
  Copy,
  Check,
  Search,
  Sliders,
  DollarSign,
  CalendarCheck,
  FileText,
  Target,
  RefreshCw,
  QrCode,
  AlertCircle,
  Building,
  UserCheck
} from 'lucide-react';
import { UserAccount, UserRole, UserPermissions, Employee, Organization } from '../../types/hrms';

interface UserRoleManagementViewProps {
  users: UserAccount[];
  employees: Employee[];
  currentOrg: Organization;
  onUpdateUsers: (users: UserAccount[]) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
}

export const UserRoleManagementView: React.FC<UserRoleManagementViewProps> = ({
  users,
  employees,
  currentOrg,
  onUpdateUsers,
  onLogAudit,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedUserForRights, setSelectedUserForRights] = useState<UserAccount | null>(null);
  const [selectedUserForMobileSlip, setSelectedUserForMobileSlip] = useState<UserAccount | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showPasswordMap, setShowPasswordMap] = useState<Record<string, boolean>>({});

  // New user form state
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('Welcome@2026');
  const [newRole, setNewRole] = useState<UserRole>('employee');
  const [selectedEmpId, setSelectedEmpId] = useState<string>(employees[0]?.id || '');
  const [newFullName, setNewFullName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [enableMobileAccess, setEnableMobileAccess] = useState(true);

  const toggleShowPassword = (userId: string) => {
    setShowPasswordMap(prev => ({ ...prev, [userId]: !prev[userId] }));
  };

  const generateRandomPassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$';
    let res = '';
    for (let i = 0; i < 10; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return `RST@${res}`;
  };

  const handleSelectEmployeeForUser = (empId: string) => {
    setSelectedEmpId(empId);
    const emp = employees.find(e => e.id === empId);
    if (emp) {
      setNewFullName(`${emp.firstName} ${emp.lastName}`);
      setNewEmail(emp.email);
      setNewPhone(emp.phone);
      setNewUsername(emp.employeeCode.toLowerCase().replace(/[^a-z0-9]/g, ''));
    }
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername || !newPassword) return;

    const defaultPerms: UserPermissions = {
      canViewPayroll: newRole === 'super_admin' || newRole === 'org_admin' || newRole === 'hr_head' || newRole === 'finance_user',
      canApprovePayroll: newRole === 'super_admin' || newRole === 'org_admin' || newRole === 'hr_head',
      canApproveLeaves: newRole !== 'employee',
      canApproveExpenses: newRole !== 'employee',
      canManageBiometric: newRole === 'super_admin' || newRole === 'it_admin' || newRole === 'hr_head',
      canManageKRA: newRole === 'super_admin' || newRole === 'hr_head',
      canReviewPMS: newRole === 'manager' || newRole === 'dept_head' || newRole === 'hr_head',
      canApprovePMS: newRole === 'hr_head' || newRole === 'super_admin',
      canExportReports: newRole !== 'employee',
      canManageUsers: newRole === 'super_admin' || newRole === 'org_admin',
    };

    const newUser: UserAccount = {
      id: `usr-${Date.now()}`,
      orgId: currentOrg.id,
      username: newUsername.trim(),
      passwordHash: newPassword,
      role: newRole,
      name: newFullName || newUsername,
      email: newEmail || `${newUsername}@${currentOrg.code.toLowerCase()}.com`,
      phone: newPhone,
      employeeId: selectedEmpId || undefined,
      isActive: true,
      isMobileAccessEnabled: enableMobileAccess,
      permissions: defaultPerms,
      createdAt: new Date().toISOString(),
    };

    const updated = [newUser, ...users];
    onUpdateUsers(updated);
    setShowCreateModal(false);
    onLogAudit('CREATE', 'User Management', `Created user credentials for ${newUser.username} (${newUser.role})`);

    // Reset fields
    setNewUsername('');
    setNewPassword('Welcome@2026');
  };

  const handleSaveUserPermissions = (updatedPerms: UserPermissions) => {
    if (!selectedUserForRights) return;
    const updated = users.map(u =>
      u.id === selectedUserForRights.id ? { ...u, permissions: updatedPerms } : u
    );
    onUpdateUsers(updated);
    onLogAudit(
      'UPDATE',
      'User Rights',
      `Updated granular permissions for ${selectedUserForRights.username} (${selectedUserForRights.role})`
    );
    setSelectedUserForRights(null);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const filteredUsers = users.filter(u => {
    const matchesSearch =
      u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter === 'all' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <Key className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                User Credentials & Role Rights Admin Panel (RBAC)
              </h2>
              <p className="text-xs text-slate-500">
                Generate secure logins for employees & admins, assign granular approval rights, and configure mobile app access
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            handleSelectEmployeeForUser(employees[0]?.id || '');
            setShowCreateModal(true);
          }}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition-colors cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Create New User Login</span>
        </button>
      </div>

      {/* Overview Stats Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Total User Credentials</span>
            <Users className="w-4 h-4 text-sky-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-1">{users.length}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Active login identities</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Mobile ESS Logins</span>
            <Smartphone className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-emerald-600 mt-1">
            {users.filter(u => u.isMobileAccessEnabled).length}
          </p>
          <p className="text-[10px] text-slate-400 mt-0.5">Mobile self-service enabled</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Admin & HR Approvers</span>
            <Shield className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-black text-amber-600 mt-1">
            {users.filter(u => u.role !== 'employee').length}
          </p>
          <p className="text-[10px] text-slate-400 mt-0.5">Multi-level workflow approvers</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase tracking-wider">Privacy Isolation</span>
            <CheckCircle2 className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-sm font-bold text-indigo-700 mt-2">Personal Data RLS Enforced</p>
          <p className="text-[10px] text-slate-400 mt-0.5">End-users only access self data</p>
        </div>
      </div>

      {/* Main Users Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Configured User Logins & Credentials Master</h3>
            <p className="text-[11px] text-slate-500">
              Usernames, passwords, assigned roles and custom rights for {currentOrg.name}
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search username, name, email..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
              />
            </div>

            <select
              value={roleFilter}
              onChange={e => setRoleFilter(e.target.value as any)}
              className="text-xs px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 font-semibold"
            >
              <option value="all">All Roles</option>
              <option value="super_admin">Super Admin</option>
              <option value="org_admin">Org Admin</option>
              <option value="hr_head">HR Head</option>
              <option value="manager">Reporting Manager</option>
              <option value="employee">Employee (ESS)</option>
              <option value="finance_user">Finance / Accounts</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">User Identity</th>
                <th className="py-3 px-4">Username</th>
                <th className="py-3 px-4">Password</th>
                <th className="py-3 px-4">Assigned Role</th>
                <th className="py-3 px-4">Mobile ESS</th>
                <th className="py-3 px-4">Key Assigned Rights</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredUsers.map(u => {
                const isPassVisible = showPasswordMap[u.id];
                const activePermCount = Object.values(u.permissions || {}).filter(Boolean).length;

                return (
                  <tr key={u.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4">
                      <div>
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <span>{u.name}</span>
                          {u.employeeId && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-sky-50 text-sky-700 font-mono">
                              Linked Staff
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">{u.email}</p>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="font-mono font-bold text-sky-800 bg-sky-50 px-2 py-0.5 rounded border border-sky-100">
                        {u.username}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                          {isPassVisible ? u.passwordHash : '••••••••••••'}
                        </span>
                        <button
                          type="button"
                          onClick={() => toggleShowPassword(u.id)}
                          className="text-slate-400 hover:text-slate-600 cursor-pointer"
                          title={isPassVisible ? 'Hide password' : 'Show password'}
                        >
                          {isPassVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                        <button
                          type="button"
                          onClick={() => copyToClipboard(u.passwordHash, `pwd-${u.id}`)}
                          className="text-slate-400 hover:text-sky-600 cursor-pointer"
                          title="Copy password"
                        >
                          {copiedId === `pwd-${u.id}` ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                        u.role === 'super_admin'
                          ? 'bg-purple-50 text-purple-800 border-purple-200'
                          : u.role === 'org_admin'
                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                          : u.role === 'hr_head'
                          ? 'bg-sky-50 text-sky-800 border-sky-200'
                          : u.role === 'manager'
                          ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                          : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      }`}>
                        {u.role.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 w-fit ${
                        u.isMobileAccessEnabled
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-500'
                      }`}>
                        <Smartphone className="w-3 h-3" />
                        <span>{u.isMobileAccessEnabled ? 'Active' : 'Disabled'}</span>
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {u.role === 'super_admin' ? (
                          <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                            ★ Full Master Rights
                          </span>
                        ) : u.role === 'employee' ? (
                          <span className="text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                            Self Only (Attendance, Payslip, KRA, Leaves)
                          </span>
                        ) : (
                          <>
                            {u.permissions?.canApprovePayroll && (
                              <span className="text-[9px] font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                                Payroll
                              </span>
                            )}
                            {u.permissions?.canReviewPMS && (
                              <span className="text-[9px] font-bold text-indigo-800 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200">
                                PMS Score
                              </span>
                            )}
                            {u.permissions?.canApproveLeaves && (
                              <span className="text-[9px] font-bold text-sky-800 bg-sky-50 px-1.5 py-0.5 rounded border border-sky-200">
                                Leaves
                              </span>
                            )}
                            {u.permissions?.canApproveExpenses && (
                              <span className="text-[9px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                                Expenses
                              </span>
                            )}
                          </>
                        )}
                      </div>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedUserForMobileSlip(u)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[11px] font-bold border border-emerald-200 transition-colors cursor-pointer flex items-center gap-1"
                          title="Generate mobile login details slip / WhatsApp template"
                        >
                          <Smartphone className="w-3 h-3 text-emerald-600" />
                          <span>Mobile Slip</span>
                        </button>
                        <button
                          onClick={() => setSelectedUserForRights(u)}
                          className="px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 text-[11px] font-bold border border-sky-200 transition-colors cursor-pointer flex items-center gap-1"
                          title="Assign or modify granular permissions & rights"
                        >
                          <Sliders className="w-3 h-3 text-sky-600" />
                          <span>Assign Rights</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal 1: Create New User Login */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <Key className="w-5 h-5 text-sky-600" />
                <h3 className="text-base font-bold text-slate-900">Create New User / Employee Login</h3>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Link to Employee (Optional):</label>
                <select
                  value={selectedEmpId}
                  onChange={e => handleSelectEmployeeForUser(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium text-slate-800"
                >
                  <option value="">-- Standalone User (Not linked to employee roster) --</option>
                  {employees.map(e => (
                    <option key={e.id} value={e.id}>
                      {e.firstName} {e.lastName} ({e.employeeCode}) - {e.departmentId}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Full Name *</label>
                  <input
                    required
                    type="text"
                    value={newFullName}
                    onChange={e => setNewFullName(e.target.value)}
                    placeholder="e.g. Ramesh Kulkarni"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Assigned Role *</label>
                  <select
                    value={newRole}
                    onChange={e => setNewRole(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-bold"
                  >
                    <option value="employee">📱 Employee (ESS Self-Only)</option>
                    <option value="manager">🏭 Reporting Manager / Plant Head</option>
                    <option value="hr_head">👔 HR Head (VP / Admin)</option>
                    <option value="org_admin">🏢 Client Admin (Full Tenant)</option>
                    <option value="finance_user">💰 Finance / Accounts Lead</option>
                    <option value="super_admin">⚡ Super Administrator</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Username / User ID *</label>
                  <input
                    required
                    type="text"
                    value={newUsername}
                    onChange={e => setNewUsername(e.target.value)}
                    placeholder="e.g. ramesh.kulkarni or RST-1008"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono font-bold"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-semibold text-slate-700">Password *</label>
                    <button
                      type="button"
                      onClick={() => setNewPassword(generateRandomPassword())}
                      className="text-[10px] text-sky-600 font-bold hover:underline cursor-pointer flex items-center gap-1"
                    >
                      <RefreshCw className="w-2.5 h-2.5" />
                      <span>Auto-Gen</span>
                    </button>
                  </div>
                  <input
                    required
                    type="text"
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Email Address</label>
                  <input
                    type="email"
                    value={newEmail}
                    onChange={e => setNewEmail(e.target.value)}
                    placeholder="ramesh@company.com"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Mobile / WhatsApp Number</label>
                  <input
                    type="text"
                    value={newPhone}
                    onChange={e => setNewPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <input
                    type="checkbox"
                    checked={enableMobileAccess}
                    onChange={e => setEnableMobileAccess(e.target.checked)}
                    className="rounded text-sky-600"
                  />
                  <div>
                    <span className="font-bold text-slate-800 block">Enable Mobile App & ESS Self-Service Access</span>
                    <span className="text-[11px] text-slate-500">
                      Allows this user to log in on mobile devices to check attendance, payslips & punch in.
                    </span>
                  </div>
                </label>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Create User Credentials</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Assign Granular Role Rights / Permissions */}
      {selectedUserForRights && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-sky-600" />
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Assign Rights: {selectedUserForRights.name}
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Username: {selectedUserForRights.username} ({selectedUserForRights.role})
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedUserForRights(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-600 font-medium">
                Toggle approval rights and module access permissions for this user:
              </p>

              {/* Rights Matrix Checkboxes */}
              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {[
                  { key: 'canViewPayroll', label: 'View Company Payroll & Salary Outflows', desc: 'Can view gross salary, employer PF/ESIC liabilities, and department pay totals.' },
                  { key: 'canApprovePayroll', label: 'Approve & Finalize Monthly Payroll Disbursals', desc: 'Authorized to execute Stage 2 or Stage 3 bank disbursal approval lock.' },
                  { key: 'canApproveLeaves', label: 'Approve Employee Leaves & Regularizations', desc: 'Can approve leave desk applications and manual punch regularizations.' },
                  { key: 'canApproveExpenses', label: 'Approve Expense & Travel Reimbursements', desc: 'Can approve employee expense vouchers and clearance for finance payout.' },
                  { key: 'canManageKRA', label: 'Fix & Configure Employee KRAs & Weightages', desc: 'HR right to assign Key Result Areas and targets for appraisees.' },
                  { key: 'canReviewPMS', label: 'Reporting Manager KRA Review & Scoring', desc: 'Can evaluate subordinate monthly KRA data and award manager points.' },
                  { key: 'canApprovePMS', label: 'HR Head Final KRA Normalization & Sign-off', desc: 'Executive right to approve manager-reviewed scores and finalize appraisals.' },
                  { key: 'canManageBiometric', label: 'Biometric Machine Fleet & Terminal Management', desc: 'Can configure IP addresses, test ping handshakes, and simulate latency SLA.' },
                  { key: 'canExportReports', label: 'Export Statutory Registers & RFC-4180 CSV Data', desc: 'Can download PF ECR files, employee master registers, and attendance CSV.' },
                  { key: 'canManageUsers', label: 'Administer User Credentials & Roles', desc: 'Can create usernames/passwords for staff and reset credentials.' },
                ].map(item => {
                  const isChecked = Boolean(selectedUserForRights.permissions?.[item.key as keyof UserPermissions]);

                  return (
                    <label
                      key={item.key}
                      className={`flex items-start gap-2.5 p-2.5 rounded-xl border transition-colors cursor-pointer ${
                        isChecked ? 'bg-sky-50/70 border-sky-200' : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={e => {
                          const updated = {
                            ...(selectedUserForRights.permissions || {}),
                            [item.key]: e.target.checked,
                          };
                          setSelectedUserForRights({
                            ...selectedUserForRights,
                            permissions: updated as UserPermissions,
                          });
                        }}
                        className="mt-0.5 rounded text-sky-600 focus:ring-sky-500"
                      />
                      <div>
                        <span className="font-bold text-slate-900 block leading-snug">{item.label}</span>
                        <span className="text-[11px] text-slate-500 leading-normal block mt-0.5">{item.desc}</span>
                      </div>
                    </label>
                  );
                })}
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedUserForRights(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveUserPermissions(selectedUserForRights.permissions)}
                  className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Save Rights Configuration</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal 3: Mobile Access Slip & WhatsApp Sharing Card */}
      {selectedUserForMobileSlip && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-bold text-slate-900">Mobile Access Credentials Slip</h3>
              </div>
              <button
                onClick={() => setSelectedUserForMobileSlip(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            {/* Branded Mobile Login Slip */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-sky-950 to-slate-900 text-white space-y-3.5 shadow-md">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <h4 className="font-black text-sm text-white">{currentOrg.name}</h4>
                  <p className="text-[10px] text-sky-200">RSTPL HRMS Mobile Employee Self Service (ESS)</p>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Mobile Active
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Employee Name:</span>
                  <strong className="text-white">{selectedUserForMobileSlip.name}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Company Portal URL:</span>
                  <span className="font-mono text-sky-300 text-[11px] truncate max-w-[200px]">
                    https://hrms.rstpl.com
                  </span>
                </div>
                <div className="flex justify-between bg-white/10 p-2 rounded-xl border border-white/10">
                  <span className="text-slate-300">Username / User ID:</span>
                  <strong className="font-mono text-amber-300 text-xs">
                    {selectedUserForMobileSlip.username}
                  </strong>
                </div>
                <div className="flex justify-between bg-white/10 p-2 rounded-xl border border-white/10">
                  <span className="text-slate-300">Temporary Password:</span>
                  <strong className="font-mono text-emerald-300 text-xs">
                    {selectedUserForMobileSlip.passwordHash}
                  </strong>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-[11px] text-slate-300 flex items-center gap-2">
                <Shield className="w-4 h-4 text-sky-400 shrink-0" />
                <span>
                  Privacy Guaranteed: You will only see your own profile, attendance, monthly payslips and KRA evaluations.
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-4 space-y-2 text-xs">
              <button
                onClick={() => {
                  const text = `*Welcome to ${currentOrg.name} HRMS Portal*\n\nDear ${selectedUserForMobileSlip.name},\nYour mobile employee self-service login has been created:\n\n*Portal URL:* https://hrms.rstpl.com\n*Username:* ${selectedUserForMobileSlip.username}\n*Password:* ${selectedUserForMobileSlip.passwordHash}\n\nPlease log in on your mobile to mark geo-attendance, check monthly payslips, and fill your monthly KRAs.`;
                  copyToClipboard(text, 'slip-full');
                }}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                {copiedId === 'slip-full' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedId === 'slip-full' ? 'Copied WhatsApp Login Message!' : 'Copy WhatsApp / SMS Message to Employee'}</span>
              </button>

              <button
                onClick={() => setSelectedUserForMobileSlip(null)}
                className="w-full py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

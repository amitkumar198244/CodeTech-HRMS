// RSTPL HRMS - Organization Master & Interactive Hierarchy Chart
// RS Technovisions XpertSkillCop
// Dynamic Hierarchy Tree filterable by Whole Organization, Unit, or Department based on Employee Master

import React, { useState, useMemo } from 'react';
import {
  Building2,
  MapPin,
  Layers,
  Clock,
  Briefcase,
  Shield,
  Plus,
  Users,
  ChevronDown,
  ChevronRight,
  Search,
  Filter,
  Network,
  GitBranch,
  UserCheck,
  Building,
  Mail,
  Phone,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Download,
  Eye,
  CheckCircle2,
  FolderTree
} from 'lucide-react';
import { Organization, Branch, Unit, Department, Designation, Shift, Employee } from '../../types/hrms';

interface OrgStructureViewProps {
  currentOrg: Organization;
  branches: Branch[];
  units: Unit[];
  departments: Department[];
  designations: Designation[];
  shifts: Shift[];
  employees?: Employee[];
  onNavigate?: (module: string) => void;
}

export const OrgStructureView: React.FC<OrgStructureViewProps> = ({
  currentOrg,
  branches,
  units,
  departments,
  designations,
  shifts,
  employees = [],
  onNavigate,
}) => {
  const [activeTab, setActiveTab] = useState<'hierarchy-chart' | 'team-mapping' | 'branches' | 'departments' | 'shifts'>('hierarchy-chart');

  // Hierarchy Chart Filter Scope
  // "Whole Organization" vs specific Unit vs specific Department
  const [scopeType, setScopeType] = useState<'WHOLE' | 'UNIT' | 'DEPARTMENT'>('WHOLE');
  const [selectedUnitId, setSelectedUnitId] = useState<string>('ALL');
  const [selectedDeptId, setSelectedDeptId] = useState<string>('ALL');
  const [searchEmployeeQuery, setSearchEmployeeQuery] = useState<string>('');
  const [collapsedNodes, setCollapsedNodes] = useState<Record<string, boolean>>({});
  const [selectedNodeEmployee, setSelectedNodeEmployee] = useState<Employee | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(100);

  // Helper mappings
  const getUnitName = (unitId: string) => units.find(u => u.id === unitId)?.name || 'Corporate Unit';
  const getDeptName = (deptId: string) => departments.find(d => d.id === deptId)?.name || 'General';
  const getDesigTitle = (desigId: string) => designations.find(d => d.id === desigId)?.title || 'Position';

  // Filtered employees according to scope selection
  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      // Scope filter
      if (scopeType === 'UNIT' && selectedUnitId !== 'ALL' && emp.unitId !== selectedUnitId) {
        return false;
      }
      if (scopeType === 'DEPARTMENT' && selectedDeptId !== 'ALL' && emp.departmentId !== selectedDeptId) {
        return false;
      }
      // If user also chooses both unit & dept
      if (selectedUnitId !== 'ALL' && emp.unitId !== selectedUnitId) return false;
      if (selectedDeptId !== 'ALL' && emp.departmentId !== selectedDeptId) return false;

      // Search query
      if (searchEmployeeQuery.trim()) {
        const query = searchEmployeeQuery.toLowerCase();
        const fullName = `${emp.firstName} ${emp.lastName}`.toLowerCase();
        const code = emp.employeeCode.toLowerCase();
        const pos = getDesigTitle(emp.designationId).toLowerCase();
        return fullName.includes(query) || code.includes(query) || pos.includes(query);
      }

      return true;
    });
  }, [employees, scopeType, selectedUnitId, selectedDeptId, searchEmployeeQuery, designations]);

  // Build tree hierarchy structure
  interface HierarchyNode {
    employee: Employee;
    designationTitle: string;
    departmentName: string;
    unitName: string;
    directReports: HierarchyNode[];
    level: number;
  }

  const { rootNodes, unassignedNodes, totalDirectReportsMap } = useMemo(() => {
    const reportsMap: Record<string, Employee[]> = {};
    const empMap: Record<string, Employee> = {};

    employees.forEach(emp => {
      empMap[emp.id] = emp;
      if (emp.reportingManagerId) {
        if (!reportsMap[emp.reportingManagerId]) {
          reportsMap[emp.reportingManagerId] = [];
        }
        reportsMap[emp.reportingManagerId].push(emp);
      }
    });

    const buildNode = (emp: Employee, currentLevel: number): HierarchyNode => {
      const children = (reportsMap[emp.id] || [])
        .filter(c => filteredEmployees.some(fe => fe.id === c.id))
        .map(child => buildNode(child, currentLevel + 1));

      return {
        employee: emp,
        designationTitle: getDesigTitle(emp.designationId),
        departmentName: getDeptName(emp.departmentId),
        unitName: getUnitName(emp.unitId),
        directReports: children,
        level: currentLevel,
      };
    };

    // Find roots in filtered set: either has no reportingManagerId, or reportingManagerId is not in filtered set
    const roots: HierarchyNode[] = [];
    const processedIds = new Set<string>();

    filteredEmployees.forEach(emp => {
      const isTopLevel = !emp.reportingManagerId || !filteredEmployees.some(fe => fe.id === emp.reportingManagerId);
      if (isTopLevel) {
        roots.push(buildNode(emp, 1));
        processedIds.add(emp.id);
      }
    });

    return { rootNodes: roots, unassignedNodes: [], totalDirectReportsMap: reportsMap };
  }, [employees, filteredEmployees, designations, departments, units]);

  // Toggle Collapse
  const toggleCollapse = (empId: string) => {
    setCollapsedNodes(prev => ({ ...prev, [empId]: !prev[empId] }));
  };

  // Team mapping grouped by Unit and Department
  const teamMappingData = useMemo(() => {
    const mapping: Record<string, { unit: Unit; departments: Record<string, { dept: Department; employees: Employee[] }> }> = {};

    units.forEach(u => {
      mapping[u.id] = { unit: u, departments: {} };
      departments.forEach(d => {
        mapping[u.id].departments[d.id] = { dept: d, employees: [] };
      });
    });

    employees.forEach(emp => {
      if (mapping[emp.unitId] && mapping[emp.unitId].departments[emp.departmentId]) {
        mapping[emp.unitId].departments[emp.departmentId].employees.push(emp);
      }
    });

    return mapping;
  }, [units, departments, employees]);

  // Export Org Hierarchy to CSV
  const handleExportHierarchyCsv = () => {
    const headers = [
      'Employee Code',
      'Employee Name',
      'Position / Designation',
      'Grade',
      'Unit Name',
      'Department Name',
      'Reporting Manager Code',
      'Reporting Manager Name',
      'Email',
      'Phone',
      'Employment Status',
    ];

    const rows = filteredEmployees.map(emp => {
      const mgr = employees.find(e => e.id === emp.reportingManagerId);
      return [
        emp.employeeCode,
        `"${emp.firstName} ${emp.lastName}"`,
        `"${getDesigTitle(emp.designationId)}"`,
        emp.grade || 'L3',
        `"${getUnitName(emp.unitId)}"`,
        `"${getDeptName(emp.departmentId)}"`,
        mgr?.employeeCode || 'TOP-LEVEL',
        mgr ? `"${mgr.firstName} ${mgr.lastName}"` : 'EXECUTIVE BOARD',
        emp.email,
        emp.phone,
        emp.status,
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RSTPL_Org_Hierarchy_${scopeType}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Recursive Chart Node Renderer
  const renderHierarchyNode = (node: HierarchyNode) => {
    const emp = node.employee;
    const isCollapsed = collapsedNodes[emp.id];
    const hasChildren = node.directReports.length > 0;
    const isSelected = selectedNodeEmployee?.id === emp.id;

    return (
      <div key={emp.id} className="flex flex-col items-center">
        {/* Node Card */}
        <div
          onClick={() => setSelectedNodeEmployee(emp)}
          className={`w-64 p-3.5 rounded-2xl border transition-all cursor-pointer shadow-xs hover:shadow-md relative bg-white text-left ${
            isSelected
              ? 'ring-2 ring-sky-500 border-sky-400 bg-sky-50/20'
              : 'border-slate-200 hover:border-sky-300'
          }`}
        >
          {/* Header pill & grade */}
          <div className="flex items-center justify-between gap-1 mb-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-sky-100 text-sky-800">
              {emp.employeeCode}
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 font-mono">
              Grade {emp.grade || 'L3'}
            </span>
          </div>

          {/* Position Title (Dominant Header) */}
          <h4 className="text-xs font-black text-slate-900 leading-snug truncate" title={node.designationTitle}>
            {node.designationTitle}
          </h4>

          {/* Employee Name */}
          <p className="text-xs font-bold text-sky-950 mt-0.5 truncate">
            {emp.firstName} {emp.lastName}
          </p>

          {/* Unit & Department Badges */}
          <div className="mt-2.5 pt-2 border-t border-slate-100 space-y-1 text-[10px]">
            <div className="flex items-center gap-1.5 text-slate-600 truncate" title={node.unitName}>
              <Building className="w-3 h-3 text-slate-400 shrink-0" />
              <span className="truncate">{node.unitName}</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-600 truncate" title={node.departmentName}>
              <Layers className="w-3 h-3 text-slate-400 shrink-0" />
              <span className="truncate">{node.departmentName}</span>
            </div>
          </div>

          {/* Direct reports footer badge */}
          {hasChildren && (
            <div className="mt-2.5 pt-1.5 border-t border-slate-100 flex items-center justify-between text-[10px]">
              <span className="text-slate-400 font-medium">Direct Reports:</span>
              <span className="px-1.5 py-0.2 rounded-full font-bold bg-indigo-100 text-indigo-800">
                {node.directReports.length} {node.directReports.length === 1 ? 'member' : 'members'}
              </span>
            </div>
          )}

          {/* Expand/Collapse Handle */}
          {hasChildren && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                toggleCollapse(emp.id);
              }}
              className="absolute -bottom-3 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-white border border-slate-300 shadow-xs flex items-center justify-center text-slate-600 hover:bg-slate-100 cursor-pointer"
              title={isCollapsed ? 'Expand Reports' : 'Collapse Reports'}
            >
              {isCollapsed ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5 rotate-90" />}
            </button>
          )}
        </div>

        {/* Children Branching */}
        {hasChildren && !isCollapsed && (
          <div className="flex flex-col items-center">
            {/* Connecting Vertical Line Down */}
            <div className="w-0.5 h-6 bg-slate-300" />

            {/* Horizontal Line across children if multiple */}
            <div className="flex gap-6 relative pt-2">
              {node.directReports.length > 1 && (
                <div
                  className="absolute top-0 left-32 right-32 h-0.5 bg-slate-300"
                />
              )}
              {node.directReports.map(child => (
                <div key={child.employee.id} className="flex flex-col items-center relative">
                  {/* Vertical line into child */}
                  <div className="w-0.5 h-2 bg-slate-300 -mt-2 mb-2" />
                  {renderHierarchyNode(child)}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="p-2.5 rounded-xl bg-sky-100 text-sky-800">
              <FolderTree className="w-6 h-6 text-sky-700" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900 tracking-tight">Organization Master & Hierarchy</h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
                  Dynamic Employee Master
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Unit & Dept Mapping
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Interactive organization chart showing positions and reporting links dynamically generated from the Employee Master
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleExportHierarchyCsv}
              className="px-3.5 py-2 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-xl transition shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Hierarchy CSV</span>
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 mt-5 pt-4 border-t border-slate-100 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('hierarchy-chart')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'hierarchy-chart'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Network className="w-4 h-4" />
            <span>Interactive Org Chart (Tree View)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('team-mapping')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'team-mapping'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Team Mapping & Unit Matrix</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('branches')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'branches'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>Branches & Units ({branches.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('departments')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'departments'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Departments & Designations ({departments.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('shifts')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'shifts'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Shifts & Rosters ({shifts.length})</span>
          </button>
        </div>
      </div>

      {/* TAB 1: INTERACTIVE HIERARCHY CHART (ORGANIZATION / UNIT / DEPARTMENT SELECTOR) */}
      {activeTab === 'hierarchy-chart' && (
        <div className="space-y-4">
          {/* Scope Selector Bar (Whole Org vs Unit vs Department) */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              {/* Primary Scope Switcher Buttons */}
              <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setScopeType('WHOLE');
                    setSelectedUnitId('ALL');
                    setSelectedDeptId('ALL');
                  }}
                  className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                    scopeType === 'WHOLE'
                      ? 'bg-white text-sky-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Building2 className="w-3.5 h-3.5 text-sky-700" />
                  <span>Whole Organization</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setScopeType('UNIT');
                    if (selectedUnitId === 'ALL' && units[0]) setSelectedUnitId(units[0].id);
                  }}
                  className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                    scopeType === 'UNIT'
                      ? 'bg-white text-sky-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Building className="w-3.5 h-3.5 text-indigo-700" />
                  <span>Select Unit / Plant</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setScopeType('DEPARTMENT');
                    if (selectedDeptId === 'ALL' && departments[0]) setSelectedDeptId(departments[0].id);
                  }}
                  className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                    scopeType === 'DEPARTMENT'
                      ? 'bg-white text-sky-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5 text-purple-700" />
                  <span>Select Department</span>
                </button>
              </div>

              {/* Dynamic Dropdowns based on selection */}
              <div className="flex flex-wrap items-center gap-2">
                {scopeType === 'UNIT' && (
                  <select
                    value={selectedUnitId}
                    onChange={e => setSelectedUnitId(e.target.value)}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="ALL">All Units</option>
                    {units.map(u => (
                      <option key={u.id} value={u.id}>{u.name} ({u.code})</option>
                    ))}
                  </select>
                )}

                {scopeType === 'DEPARTMENT' && (
                  <select
                    value={selectedDeptId}
                    onChange={e => setSelectedDeptId(e.target.value)}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="ALL">All Departments</option>
                    {departments.map(d => (
                      <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                    ))}
                  </select>
                )}

                {/* Search in Chart */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search Position or Employee..."
                    value={searchEmployeeQuery}
                    onChange={e => setSearchEmployeeQuery(e.target.value)}
                    className="pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-sky-500 w-52"
                  />
                </div>

                {/* Zoom Controls */}
                <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200">
                  <button
                    type="button"
                    onClick={() => setZoomLevel(prev => Math.max(60, prev - 10))}
                    className="p-1 rounded text-slate-600 hover:bg-white cursor-pointer"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-[10px] font-mono px-1 font-bold text-slate-600">{zoomLevel}%</span>
                  <button
                    type="button"
                    onClick={() => setZoomLevel(prev => Math.min(140, prev + 10))}
                    className="p-1 rounded text-slate-600 hover:bg-white cursor-pointer"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setZoomLevel(100)}
                    className="p-1 rounded text-slate-600 hover:bg-white cursor-pointer"
                    title="Reset Zoom"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Scope Summary Badge */}
            <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-700">Current Scope:</span>
                <span className="px-2 py-0.5 rounded font-bold text-[11px] bg-sky-50 text-sky-800 border border-sky-200">
                  {scopeType === 'WHOLE' && `Whole Organization (${currentOrg.name})`}
                  {scopeType === 'UNIT' && (selectedUnitId === 'ALL' ? 'All Operating Units' : getUnitName(selectedUnitId))}
                  {scopeType === 'DEPARTMENT' && (selectedDeptId === 'ALL' ? 'All Functional Departments' : getDeptName(selectedDeptId))}
                </span>
                <span className="text-[11px] text-slate-500">
                  Showing <strong>{filteredEmployees.length}</strong> assigned positions & personnel
                </span>
              </div>

              <span className="text-[10px] text-slate-400">
                Positions and Unit/Dept assignments are synchronized in real-time from Employee Master
              </span>
            </div>
          </div>

          {/* Interactive Chart Canvas */}
          <div className="bg-slate-50 rounded-2xl border border-slate-200 shadow-2xs p-8 overflow-auto min-h-[480px]">
            {filteredEmployees.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-slate-400 space-y-2">
                <Users className="w-10 h-10 text-slate-300" />
                <p className="text-sm font-bold text-slate-600">No employees found in selected scope</p>
                <p className="text-xs">Adjust your Unit or Department filter to view organizational positions</p>
              </div>
            ) : (
              <div
                className="flex justify-center transition-transform duration-200 origin-top"
                style={{ transform: `scale(${zoomLevel / 100})` }}
              >
                <div className="flex flex-wrap gap-12 justify-center">
                  {rootNodes.map(rootNode => renderHierarchyNode(rootNode))}
                </div>
              </div>
            )}
          </div>

          {/* Employee Node Detail Drawer / Inspection Card */}
          {selectedNodeEmployee && (
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
                    <UserCheck className="w-5 h-5 text-sky-700" />
                  </span>
                  <div>
                    <h4 className="text-sm font-black text-slate-900">
                      {selectedNodeEmployee.firstName} {selectedNodeEmployee.lastName}
                    </h4>
                    <p className="text-xs text-slate-500 font-mono">
                      {selectedNodeEmployee.employeeCode} · {getDesigTitle(selectedNodeEmployee.designationId)}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedNodeEmployee(null)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50"
                >
                  Close Inspection
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Assigned Unit</span>
                  <p className="font-bold text-slate-800 mt-0.5 truncate">{getUnitName(selectedNodeEmployee.unitId)}</p>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Assigned Department</span>
                  <p className="font-bold text-slate-800 mt-0.5 truncate">{getDeptName(selectedNodeEmployee.departmentId)}</p>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Reporting Manager</span>
                  <p className="font-bold text-slate-800 mt-0.5 truncate">
                    {(() => {
                      const mgr = employees.find(e => e.id === selectedNodeEmployee.reportingManagerId);
                      return mgr ? `${mgr.firstName} ${mgr.lastName} (${mgr.employeeCode})` : 'Top-Level Head';
                    })()}
                  </p>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Contact & Status</span>
                  <p className="font-bold text-emerald-700 mt-0.5">{selectedNodeEmployee.status} ({selectedNodeEmployee.phone})</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: TEAM MAPPING & UNIT MATRIX */}
      {activeTab === 'team-mapping' && (
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-sky-700" />
              <div>
                <h3 className="text-sm font-black text-slate-900">
                  Team Mapping Matrix by Operating Unit & Department
                </h3>
                <p className="text-xs text-slate-500">
                  Unit-wise position allocations and active employee assignments across all facilities
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {units.map(unit => {
              const unitData = teamMappingData[unit.id];
              const totalInUnit = Object.values(unitData?.departments || {}).reduce((acc, curr) => acc + curr.employees.length, 0);

              return (
                <div key={unit.id} className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
                  <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
                        <Building className="w-4 h-4 text-sky-700" />
                      </span>
                      <div>
                        <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                          {unit.name} ({unit.code})
                        </h4>
                        <p className="text-[11px] text-slate-500">Unit Type: {unit.type}</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-sky-100 text-sky-800">
                      {totalInUnit} Active Positions
                    </span>
                  </div>

                  <div className="p-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {departments.map(dept => {
                      const deptEmps = unitData?.departments[dept.id]?.employees || [];
                      return (
                        <div key={dept.id} className="p-3.5 rounded-xl bg-slate-50/70 border border-slate-200 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-slate-900 truncate" title={dept.name}>{dept.name}</span>
                            <span className="px-1.5 py-0.2 rounded text-[10px] font-mono font-bold bg-slate-200 text-slate-700">
                              {deptEmps.length}
                            </span>
                          </div>

                          <div className="space-y-1.5 pt-1">
                            {deptEmps.length === 0 ? (
                              <p className="text-[11px] text-slate-400 italic">No staff mapped</p>
                            ) : (
                              deptEmps.map(emp => (
                                <div key={emp.id} className="p-2 rounded-lg bg-white border border-slate-200/80 text-[11px] space-y-0.5">
                                  <div className="flex justify-between font-bold text-slate-900">
                                    <span>{emp.firstName} {emp.lastName}</span>
                                    <span className="font-mono text-[10px] text-sky-700">{emp.employeeCode}</span>
                                  </div>
                                  <p className="text-[10px] text-slate-500 truncate">{getDesigTitle(emp.designationId)}</p>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: BRANCHES & UNITS (ORIGINAL GRID) */}
      {activeTab === 'branches' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {branches.map(br => {
            const brUnits = units.filter(u => u.branchId === br.id);
            return (
              <div key={br.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-bold">
                      {br.code}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 mt-1">{br.name}</h3>
                    <p className="text-xs text-slate-500">{br.city}, {br.state}</p>
                  </div>
                  {br.isHeadquarters && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
                      Headquarters
                    </span>
                  )}
                </div>

                <p className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100">
                  {br.address}
                </p>

                <div className="pt-2 border-t border-slate-100">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    Operating Units ({brUnits.length}):
                  </span>
                  <div className="mt-1 space-y-1">
                    {brUnits.map(u => (
                      <div key={u.id} className="text-xs flex items-center justify-between text-slate-700">
                        <span className="font-medium">• {u.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{u.type}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 4: DEPARTMENTS & DESIGNATIONS */}
      {activeTab === 'departments' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {departments.map(dept => {
            const deptDesigs = designations.filter(d => d.departmentId === dept.id);
            return (
              <div key={dept.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-sky-100 text-sky-800">
                    {dept.code}
                  </span>
                  <span className="text-[10px] text-slate-400 font-bold">{deptDesigs.length} Designations</span>
                </div>
                <h4 className="text-xs font-bold text-slate-900">{dept.name}</h4>
                <div className="mt-3 space-y-1 text-[11px] text-slate-600">
                  {deptDesigs.map(d => (
                    <div key={d.id} className="flex justify-between items-center py-0.5 border-b border-slate-50">
                      <span>• {d.title}</span>
                      <span className="font-mono text-[10px] text-slate-400">{d.grade}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 5: SHIFTS */}
      {activeTab === 'shifts' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {shifts.map(sh => (
            <div key={sh.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: sh.color }}
                />
                <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                  {sh.code}
                </span>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-900">{sh.name}</h4>
                <p className="text-xs text-sky-700 font-mono font-bold mt-1">
                  {sh.startTime} - {sh.endTime}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 space-y-1 text-[11px] text-slate-500">
                <div className="flex justify-between">
                  <span>Grace Period:</span>
                  <strong className="text-slate-800">{sh.graceTimeMinutes} mins</strong>
                </div>
                <div className="flex justify-between">
                  <span>Half Day:</span>
                  <strong className="text-slate-800">{sh.halfDayThresholdHours} hrs</strong>
                </div>
                <div className="flex justify-between">
                  <span>Full Day:</span>
                  <strong className="text-slate-800">{sh.fullDayThresholdHours} hrs</strong>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

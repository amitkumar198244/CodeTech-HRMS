// RSTPL HRMS - Multi-Level Approval Workflow Management Engine
// RS Technovisions XpertSkillCop
// Manages multi-stage approval pipelines for Salary/Payroll, Attendance, Compliance, and Expenses

import React, { useState } from 'react';
import {
  Layers,
  CheckCircle2,
  Clock,
  XCircle,
  DollarSign,
  CalendarCheck,
  Receipt,
  ShieldCheck,
  Target,
  ArrowRight,
  Filter,
  Check,
  X,
  User,
  AlertTriangle,
  FileText
} from 'lucide-react';
import { ApprovalWorkflowItem, UserRole } from '../../types/hrms';

interface ApprovalWorkflowViewProps {
  workflows: ApprovalWorkflowItem[];
  currentRole: UserRole;
  onUpdateWorkflows: (workflows: ApprovalWorkflowItem[]) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
}

export const ApprovalWorkflowView: React.FC<ApprovalWorkflowViewProps> = ({
  workflows,
  currentRole,
  onUpdateWorkflows,
  onLogAudit,
}) => {
  const [selectedModule, setSelectedModule] = useState<'All' | 'Payroll' | 'Attendance' | 'Expense' | 'Compliance'>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Approved' | 'Rejected'>('All');
  const [activeWorkflowForAction, setActiveWorkflowForAction] = useState<ApprovalWorkflowItem | null>(null);
  const [actionComments, setActionComments] = useState('');

  const filteredWorkflows = workflows.filter(wf => {
    const matchesModule = selectedModule === 'All' || wf.module === selectedModule;
    const matchesStatus = statusFilter === 'All' || wf.overallStatus === statusFilter;
    return matchesModule && matchesStatus;
  });

  const handleApproveStep = (workflowId: string) => {
    const updated = workflows.map(wf => {
      if (wf.id !== workflowId) return wf;

      const currentStep = wf.steps[wf.currentStepIndex];
      if (!currentStep) return wf;

      const updatedSteps = wf.steps.map((s, idx) =>
        idx === wf.currentStepIndex
          ? {
              ...s,
              status: 'Approved' as const,
              actionTimestamp: new Date().toISOString(),
              approverName: currentRole === 'hr_head' ? 'Amit Sharma (VP HR)' : currentRole === 'super_admin' ? 'Super Admin' : 'Authorized Approver',
              comments: actionComments || 'Approved in accordance with company policy.',
            }
          : s
      );

      const nextStepIndex = wf.currentStepIndex + 1;
      const isComplete = nextStepIndex >= wf.totalSteps;

      return {
        ...wf,
        steps: updatedSteps,
        currentStepIndex: nextStepIndex,
        overallStatus: isComplete ? ('Approved' as const) : ('Pending' as const),
      };
    });

    onUpdateWorkflows(updated);
    const targetWf = workflows.find(w => w.id === workflowId);
    onLogAudit(
      'APPROVE',
      'Approval Workflow',
      `Approved Step ${targetWf?.currentStepIndex! + 1} of ${targetWf?.title} by ${currentRole}`
    );
    setActiveWorkflowForAction(null);
    setActionComments('');
  };

  const handleRejectStep = (workflowId: string) => {
    const updated = workflows.map(wf => {
      if (wf.id !== workflowId) return wf;

      const updatedSteps = wf.steps.map((s, idx) =>
        idx === wf.currentStepIndex
          ? {
              ...s,
              status: 'Rejected' as const,
              actionTimestamp: new Date().toISOString(),
              comments: actionComments || 'Rejected / Revision required.',
            }
          : s
      );

      return {
        ...wf,
        steps: updatedSteps,
        overallStatus: 'Rejected' as const,
      };
    });

    onUpdateWorkflows(updated);
    const targetWf = workflows.find(w => w.id === workflowId);
    onLogAudit('REJECT', 'Approval Workflow', `Rejected ${targetWf?.title} by ${currentRole}`);
    setActiveWorkflowForAction(null);
    setActionComments('');
  };

  const getModuleIcon = (mod: string) => {
    switch (mod) {
      case 'Payroll':
        return <DollarSign className="w-4 h-4 text-emerald-600" />;
      case 'Attendance':
        return <CalendarCheck className="w-4 h-4 text-sky-600" />;
      case 'Expense':
        return <Receipt className="w-4 h-4 text-amber-600" />;
      case 'Compliance':
        return <ShieldCheck className="w-4 h-4 text-indigo-600" />;
      default:
        return <Layers className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <Layers className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                Multi-Level Approval Workflow Management
              </h2>
              <p className="text-xs text-slate-500">
                Configure & execute sequential sign-off pipelines for Payroll, Attendance Regularization, Compliance & Expenses
              </p>
            </div>
          </div>
        </div>

        {/* Module Switcher Pills */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs self-start md:self-auto overflow-x-auto">
          {['All', 'Payroll', 'Attendance', 'Expense', 'Compliance'].map(mod => (
            <button
              key={mod}
              onClick={() => setSelectedModule(mod as any)}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                selectedModule === mod
                  ? 'bg-white text-sky-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {mod}
            </button>
          ))}
        </div>
      </div>

      {/* Workflow Stats Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Total Workflows</span>
          <p className="text-2xl font-black text-slate-900 mt-1">{workflows.length}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Across all 4 enterprise modules</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Pending Authorization</span>
          <p className="text-2xl font-black text-amber-600 mt-1">
            {workflows.filter(w => w.overallStatus === 'Pending').length}
          </p>
          <p className="text-[10px] text-slate-400 mt-0.5">Awaiting stage sign-off</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Completed & Finalized</span>
          <p className="text-2xl font-black text-emerald-600 mt-1">
            {workflows.filter(w => w.overallStatus === 'Approved').length}
          </p>
          <p className="text-[10px] text-slate-400 mt-0.5">Full sign-off achieved</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Active User Role</span>
          <p className="text-sm font-bold text-sky-700 mt-2 capitalize">{currentRole.replace('_', ' ')}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Role-based signer authorization</p>
        </div>
      </div>

      {/* Workflows List */}
      <div className="space-y-4">
        {filteredWorkflows.map(wf => {
          const currentStep = wf.steps[wf.currentStepIndex];
          const isUserAuthorizedForCurrentStep =
            currentStep &&
            (currentRole === 'super_admin' || currentRole === currentStep.approverRole || (currentRole === 'hr_head' && currentStep.approverRole === 'hr_head'));

          return (
            <div
              key={wf.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-sky-300 transition-all space-y-4"
            >
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 shrink-0">
                    {getModuleIcon(wf.module)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700 font-mono">
                        {wf.module}
                      </span>
                      <h3 className="text-sm font-bold text-slate-900 leading-snug">{wf.title}</h3>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        wf.overallStatus === 'Approved'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : wf.overallStatus === 'Rejected'
                          ? 'bg-rose-100 text-rose-800 border border-rose-200'
                          : 'bg-amber-100 text-amber-800 border border-amber-200 animate-pulse'
                      }`}>
                        {wf.overallStatus === 'Pending' ? `Pending Stage ${wf.currentStepIndex + 1}/${wf.totalSteps}` : wf.overallStatus}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 mt-1">
                      Submitted by: <strong className="text-slate-800">{wf.initiatorName}</strong> · Value/Scope:{' '}
                      <strong className="text-sky-700 font-mono">{wf.amountOrMetric || 'Standard'}</strong>
                    </p>
                  </div>
                </div>

                {/* Approve Button if Pending and Authorized */}
                {wf.overallStatus === 'Pending' && currentStep && (
                  <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                    {isUserAuthorizedForCurrentStep ? (
                      <button
                        onClick={() => setActiveWorkflowForAction(wf)}
                        className="px-3.5 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Authorize Stage {currentStep.stepNumber}</span>
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-400 font-medium bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200">
                        Awaiting {currentStep.stageName} ({currentStep.approverRole.replace('_', ' ')})
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Multi-Step Pipeline Visualizer */}
              <div className="pt-2 border-t border-slate-100">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {wf.steps.map((step, idx) => {
                    const isDone = step.status === 'Approved';
                    const isCurrent = wf.overallStatus === 'Pending' && wf.currentStepIndex === idx;
                    const isRejected = step.status === 'Rejected';

                    return (
                      <div
                        key={step.stepNumber}
                        className={`p-3 rounded-xl border text-xs transition-all relative overflow-hidden ${
                          isDone
                            ? 'bg-emerald-50/60 border-emerald-200'
                            : isRejected
                            ? 'bg-rose-50/60 border-rose-200'
                            : isCurrent
                            ? 'bg-sky-50 border-sky-300 ring-2 ring-sky-500/10'
                            : 'bg-slate-50/60 border-slate-200 text-slate-400'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="font-bold text-[10px] uppercase tracking-wider text-slate-500">
                            Stage {step.stepNumber}: {step.approverRole.replace('_', ' ')}
                          </span>
                          {isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : isRejected ? (
                            <XCircle className="w-4 h-4 text-rose-600" />
                          ) : isCurrent ? (
                            <Clock className="w-4 h-4 text-sky-600 animate-spin" />
                          ) : (
                            <Clock className="w-4 h-4 text-slate-300" />
                          )}
                        </div>

                        <h4 className="font-bold text-slate-900 leading-snug">{step.stageName}</h4>

                        {step.approverName && (
                          <p className="text-[11px] text-slate-600 mt-1">
                            Approved by: <strong className="text-slate-800">{step.approverName}</strong>
                          </p>
                        )}

                        {step.comments && (
                          <p className="text-[10px] text-slate-500 italic mt-1 bg-white/60 p-1.5 rounded border border-slate-200/50">
                            "{step.comments}"
                          </p>
                        )}

                        {isCurrent && (
                          <div className="mt-2 text-[10px] font-bold text-sky-700 flex items-center gap-1">
                            <span>● Action Required Now</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Authorize / Reject Step */}
      {activeWorkflowForAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <h3 className="text-sm font-bold text-slate-900">
                Execute Workflow Sign-off (Stage {activeWorkflowForAction.currentStepIndex + 1})
              </h3>
              <button
                onClick={() => setActiveWorkflowForAction(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-bold">Workflow Item:</span>
                <p className="font-bold text-slate-900">{activeWorkflowForAction.title}</p>
                <p className="text-slate-600 text-[11px] mt-0.5">Value / Metric: {activeWorkflowForAction.amountOrMetric}</p>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Approval Comments & Authorization Remarks:</label>
                <textarea
                  rows={3}
                  value={actionComments}
                  onChange={e => setActionComments(e.target.value)}
                  placeholder="e.g. Verified biometric records and statutory deductions. Approved for bank disbursal."
                  className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:ring-2 focus:ring-sky-500/20"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => handleRejectStep(activeWorkflowForAction.id)}
                  className="px-3.5 py-2 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-xl cursor-pointer flex items-center gap-1"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Reject / Return</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleApproveStep(activeWorkflowForAction.id)}
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Approve & Forward</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

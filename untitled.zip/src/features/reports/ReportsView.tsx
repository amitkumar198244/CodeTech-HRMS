// RSTPL HRMS - Enterprise Reporting & Filtered CSV Analytics Export
// RS Technovisions XpertSkillCop
// High-grade CSV Data Export Pipeline with Dynamic Filters, Table Previews & Compliance Audits

import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  Download,
  Calendar,
  Users,
  DollarSign,
  Filter,
  Search,
  RotateCcw,
  Clock,
  Building2,
  CheckCircle2,
  FileSpreadsheet,
  AlertCircle,
  Briefcase,
  ChevronRight,
  ShieldCheck,
  Eye,
  SlidersHorizontal,
  TableProperties
} from 'lucide-react';
import { HRMSStoreData } from '../../services/hrmsStorage';
import { Employee, AttendanceRecord } from '../../types/hrms';

interface ReportsViewProps {
  storeData: HRMSStoreData;
  onLogAudit: (action: any, module: string, details: string) => void;
}

type ExportCategory = 'attendance' | 'employee' | 'payroll';

export const ReportsView: React.FC<ReportsViewProps> = ({ storeData, onLogAudit }) => {
  const [activeCategory, setActiveCategory] = useState<ExportCategory>('attendance');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // ----------------------------------------------------
  // ATTENDANCE FILTER STATE
  // ----------------------------------------------------
  const [attSearch, setAttSearch] = useState('');
  const [attStatus, setAttStatus] = useState<string>('ALL');
  const [attDept, setAttDept] = useState<string>('ALL');
  const [attShift, setAttShift] = useState<string>('ALL');
  const [attAnomaly, setAttAnomaly] = useState<string>('ALL'); // 'ALL' | 'LATE' | 'OVERTIME' | 'EARLY_OUT' | 'REGULARIZED'
  const [attFromDate, setAttFromDate] = useState<string>('');
  const [attToDate, setAttToDate] = useState<string>('');

  // ----------------------------------------------------
  // EMPLOYEE FILTER STATE
  // ----------------------------------------------------
  const [empSearch, setEmpSearch] = useState('');
  const [empDept, setEmpDept] = useState<string>('ALL');
  const [empBranch, setEmpBranch] = useState<string>('ALL');
  const [empType, setEmpType] = useState<string>('ALL');
  const [empStatus, setEmpStatus] = useState<string>('ALL');
  const [empStatutory, setEmpStatutory] = useState<string>('ALL'); // 'ALL' | 'PF' | 'ESIC'

  // Lookups helper maps
  const deptMap = useMemo(() => {
    const map = new Map<string, string>();
    (storeData.departments || []).forEach(d => map.set(d.id, d.name));
    return map;
  }, [storeData.departments]);

  const desigMap = useMemo(() => {
    const map = new Map<string, string>();
    (storeData.designations || []).forEach(d => map.set(d.id, d.title));
    return map;
  }, [storeData.designations]);

  const branchMap = useMemo(() => {
    const map = new Map<string, string>();
    (storeData.branches || []).forEach(b => map.set(b.id, b.name));
    return map;
  }, [storeData.branches]);

  const shiftMap = useMemo(() => {
    const map = new Map<string, string>();
    (storeData.shifts || []).forEach(s => map.set(s.id, s.name));
    return map;
  }, [storeData.shifts]);

  // ----------------------------------------------------
  // FILTERED ATTENDANCE DATA COMPUTATION
  // ----------------------------------------------------
  const filteredAttendance = useMemo(() => {
    return (storeData.attendance || []).filter(rec => {
      // Search
      if (attSearch.trim()) {
        const query = attSearch.toLowerCase();
        const matchesName = rec.employeeName.toLowerCase().includes(query);
        const matchesCode = rec.employeeCode.toLowerCase().includes(query);
        const matchesDept = (rec.departmentName || '').toLowerCase().includes(query);
        if (!matchesName && !matchesCode && !matchesDept) return false;
      }

      // Status
      if (attStatus !== 'ALL' && rec.status !== attStatus) {
        return false;
      }

      // Department
      if (attDept !== 'ALL') {
        const targetDeptName = deptMap.get(attDept);
        if (targetDeptName && rec.departmentName !== targetDeptName) {
          return false;
        }
      }

      // Shift
      if (attShift !== 'ALL' && rec.shiftId !== attShift) {
        return false;
      }

      // Anomaly
      if (attAnomaly === 'LATE' && !rec.isLate) return false;
      if (attAnomaly === 'OVERTIME' && !rec.isOvertime) return false;
      if (attAnomaly === 'EARLY_OUT' && !rec.isEarlyOut) return false;
      if (attAnomaly === 'REGULARIZED' && !rec.isRegularized) return false;

      // Date Range
      if (attFromDate && rec.date < attFromDate) return false;
      if (attToDate && rec.date > attToDate) return false;

      return true;
    });
  }, [storeData.attendance, attSearch, attStatus, attDept, attShift, attAnomaly, attFromDate, attToDate, deptMap]);

  // ----------------------------------------------------
  // FILTERED EMPLOYEE DATA COMPUTATION
  // ----------------------------------------------------
  const filteredEmployees = useMemo(() => {
    return (storeData.employees || []).filter(emp => {
      // Search
      if (empSearch.trim()) {
        const query = empSearch.toLowerCase();
        const fullName = `${emp.firstName} ${emp.lastName}`.toLowerCase();
        const matchesName = fullName.includes(query);
        const matchesCode = emp.employeeCode.toLowerCase().includes(query);
        const matchesEmail = emp.email.toLowerCase().includes(query);
        const matchesPhone = emp.phone.toLowerCase().includes(query);
        if (!matchesName && !matchesCode && !matchesEmail && !matchesPhone) return false;
      }

      // Department
      if (empDept !== 'ALL' && emp.departmentId !== empDept) {
        return false;
      }

      // Branch
      if (empBranch !== 'ALL' && emp.branchId !== empBranch) {
        return false;
      }

      // Employment Type
      if (empType !== 'ALL' && emp.employmentType !== empType) {
        return false;
      }

      // Status
      if (empStatus !== 'ALL' && emp.status !== empStatus) {
        return false;
      }

      // Statutory
      if (empStatutory === 'PF' && !emp.pfApplicable) return false;
      if (empStatutory === 'ESIC' && !emp.esicApplicable) return false;

      return true;
    });
  }, [storeData.employees, empSearch, empDept, empBranch, empType, empStatus, empStatutory]);

  // ----------------------------------------------------
  // QUICK DATE RANGE PRESETS (ATTENDANCE)
  // ----------------------------------------------------
  const setDatePreset = (preset: 'today' | '7days' | '30days' | 'all') => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    if (preset === 'today') {
      setAttFromDate(todayStr);
      setAttToDate(todayStr);
    } else if (preset === '7days') {
      const past = new Date();
      past.setDate(past.getDate() - 7);
      setAttFromDate(past.toISOString().split('T')[0]);
      setAttToDate(todayStr);
    } else if (preset === '30days') {
      const past = new Date();
      past.setDate(past.getDate() - 30);
      setAttFromDate(past.toISOString().split('T')[0]);
      setAttToDate(todayStr);
    } else {
      setAttFromDate('');
      setAttToDate('');
    }
  };

  const resetAttendanceFilters = () => {
    setAttSearch('');
    setAttStatus('ALL');
    setAttDept('ALL');
    setAttShift('ALL');
    setAttAnomaly('ALL');
    setAttFromDate('');
    setAttToDate('');
  };

  const resetEmployeeFilters = () => {
    setEmpSearch('');
    setEmpDept('ALL');
    setEmpBranch('ALL');
    setEmpType('ALL');
    setEmpStatus('ALL');
    setEmpStatutory('ALL');
  };

  // ----------------------------------------------------
  // ROBUST CSV STRING ESCAPING & DOWNLOAD ENGINE
  // ----------------------------------------------------
  const escapeCsv = (val: unknown): string => {
    if (val === null || val === undefined) return '';
    const str = String(val);
    if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const downloadCsvFile = (content: string, filename: string) => {
    // Add UTF-8 BOM so Microsoft Excel and external analysis tools open special characters cleanly
    const blob = new Blob(['\uFEFF' + content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Export Filtered Attendance
  const exportFilteredAttendance = () => {
    if (filteredAttendance.length === 0) {
      alert('No attendance records match the selected filters to export.');
      return;
    }

    const headers = [
      'Date',
      'Employee Code',
      'Employee Name',
      'Department',
      'Shift',
      'First In Time',
      'Last Out Time',
      'Total Hours',
      'Attendance Status',
      'Late Arrival',
      'Late Minutes',
      'Early Departure',
      'Early Out Minutes',
      'Overtime',
      'Overtime Hours',
      'Regularized',
      'Finalized',
      'Remarks'
    ];

    const rows = filteredAttendance.map(rec => [
      escapeCsv(rec.date),
      escapeCsv(rec.employeeCode),
      escapeCsv(rec.employeeName),
      escapeCsv(rec.departmentName),
      escapeCsv(shiftMap.get(rec.shiftId) || rec.shiftId),
      escapeCsv(rec.firstIn || '--'),
      escapeCsv(rec.lastOut || '--'),
      escapeCsv(rec.totalHours),
      escapeCsv(rec.status),
      escapeCsv(rec.isLate ? 'YES' : 'NO'),
      escapeCsv(rec.lateMinutes || 0),
      escapeCsv(rec.isEarlyOut ? 'YES' : 'NO'),
      escapeCsv(rec.earlyOutMinutes || 0),
      escapeCsv(rec.isOvertime ? 'YES' : 'NO'),
      escapeCsv(rec.overtimeHours || 0),
      escapeCsv(rec.isRegularized ? 'YES' : 'NO'),
      escapeCsv(rec.isFinalized ? 'YES' : 'NO'),
      escapeCsv(rec.remarks || '')
    ].join(','));

    const csvContent = [headers.join(','), ...rows].join('\r\n');
    const dateStamp = new Date().toISOString().split('T')[0];
    const filename = `RSTPL_Attendance_Export_${filteredAttendance.length}_Records_${dateStamp}.csv`;

    downloadCsvFile(csvContent, filename);

    const logDetails = `Exported ${filteredAttendance.length} attendance records (Status: ${attStatus}, Dept: ${attDept}, Anomaly: ${attAnomaly})`;
    onLogAudit('EXPORT', 'Reporting Engine', logDetails);
    setExportNotice(`Successfully exported ${filteredAttendance.length} filtered attendance records to ${filename}`);
    setTimeout(() => setExportNotice(null), 5000);
  };

  // Export Filtered Employees
  const exportFilteredEmployees = () => {
    if (filteredEmployees.length === 0) {
      alert('No employee records match the selected filters to export.');
      return;
    }

    const headers = [
      'Employee Code',
      'Full Name',
      'Email',
      'Phone',
      'Gender',
      'Blood Group',
      'Marital Status',
      'Date of Birth',
      'Date of Joining',
      'Confirmation Date',
      'Employment Type',
      'Employment Status',
      'Department',
      'Designation',
      'Grade',
      'Branch Location',
      'Shift',
      'PAN Number',
      'Masked Aadhaar',
      'UAN',
      'PF Applicable',
      'ESIC Applicable',
      'Bank Name',
      'Bank Account Number',
      'IFSC Code',
      'Annual CTC (INR)',
      'Basic Monthly',
      'HRA Monthly',
      'Conveyance Monthly',
      'Special Allowance Monthly',
      'Gross Monthly',
      'PF Deduction (Employee)',
      'ESIC Deduction (Employee)',
      'Professional Tax Monthly',
      'Net Salary Monthly'
    ];

    const rows = filteredEmployees.map(emp => {
      const gross = emp.basicMonthly + emp.hraMonthly + emp.conveyanceMonthly + emp.specialAllowanceMonthly;
      return [
        escapeCsv(emp.employeeCode),
        escapeCsv(`${emp.firstName} ${emp.lastName}`),
        escapeCsv(emp.email),
        escapeCsv(emp.phone),
        escapeCsv(emp.gender),
        escapeCsv(emp.bloodGroup),
        escapeCsv(emp.maritalStatus),
        escapeCsv(emp.dob),
        escapeCsv(emp.dateOfJoining),
        escapeCsv(emp.confirmationDate || '--'),
        escapeCsv(emp.employmentType),
        escapeCsv(emp.status),
        escapeCsv(deptMap.get(emp.departmentId) || emp.departmentId),
        escapeCsv(desigMap.get(emp.designationId) || emp.designationId),
        escapeCsv(emp.grade),
        escapeCsv(branchMap.get(emp.branchId) || emp.branchId),
        escapeCsv(shiftMap.get(emp.shiftId) || emp.shiftId),
        escapeCsv(emp.pan),
        escapeCsv(emp.aadhaarMasked),
        escapeCsv(emp.uan),
        escapeCsv(emp.pfApplicable ? 'YES' : 'NO'),
        escapeCsv(emp.esicApplicable ? 'YES' : 'NO'),
        escapeCsv(emp.bankName),
        escapeCsv(`'${emp.bankAccountNumber}'`), // prepended quote to prevent scientific notation in Excel
        escapeCsv(emp.ifscCode),
        escapeCsv(emp.ctcAnnual),
        escapeCsv(emp.basicMonthly),
        escapeCsv(emp.hraMonthly),
        escapeCsv(emp.conveyanceMonthly),
        escapeCsv(emp.specialAllowanceMonthly),
        escapeCsv(gross),
        escapeCsv(emp.pfEmployeeMonthly),
        escapeCsv(emp.esicEmployeeMonthly),
        escapeCsv(emp.professionalTaxMonthly),
        escapeCsv(emp.netSalaryMonthly)
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\r\n');
    const dateStamp = new Date().toISOString().split('T')[0];
    const filename = `RSTPL_Employees_Export_${filteredEmployees.length}_Records_${dateStamp}.csv`;

    downloadCsvFile(csvContent, filename);

    const logDetails = `Exported ${filteredEmployees.length} employee master records (Dept: ${empDept}, Status: ${empStatus}, Type: ${empType})`;
    onLogAudit('EXPORT', 'Reporting Engine', logDetails);
    setExportNotice(`Successfully exported ${filteredEmployees.length} filtered employee records to ${filename}`);
    setTimeout(() => setExportNotice(null), 5000);
  };

  // Export Payroll Register
  const exportPayrollRegister = () => {
    const employees = filteredEmployees.length > 0 ? filteredEmployees : storeData.employees;
    const headers = [
      'Employee Code',
      'Name',
      'Department',
      'Designation',
      'Status',
      'Basic Monthly',
      'HRA Monthly',
      'Conveyance',
      'Special Allowance',
      'Gross Earnings',
      'PF (12%)',
      'ESIC (0.75%)',
      'Professional Tax',
      'TDS',
      'Total Deductions',
      'Net Salary Monthly'
    ];

    const rows = employees.map(e => {
      const gross = e.basicMonthly + e.hraMonthly + e.conveyanceMonthly + e.specialAllowanceMonthly;
      const totalDed = e.pfEmployeeMonthly + e.esicEmployeeMonthly + e.professionalTaxMonthly;
      return [
        escapeCsv(e.employeeCode),
        escapeCsv(`${e.firstName} ${e.lastName}`),
        escapeCsv(deptMap.get(e.departmentId) || e.departmentId),
        escapeCsv(desigMap.get(e.designationId) || e.designationId),
        escapeCsv(e.status),
        escapeCsv(e.basicMonthly),
        escapeCsv(e.hraMonthly),
        escapeCsv(e.conveyanceMonthly),
        escapeCsv(e.specialAllowanceMonthly),
        escapeCsv(gross),
        escapeCsv(e.pfEmployeeMonthly),
        escapeCsv(e.esicEmployeeMonthly),
        escapeCsv(e.professionalTaxMonthly),
        escapeCsv(0),
        escapeCsv(totalDed),
        escapeCsv(e.netSalaryMonthly)
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\r\n');
    const dateStamp = new Date().toISOString().split('T')[0];
    const filename = `RSTPL_Payroll_Register_${employees.length}_Records_${dateStamp}.csv`;

    downloadCsvFile(csvContent, filename);
    onLogAudit('EXPORT', 'Reporting Engine', `Exported payroll register for ${employees.length} employees`);
    setExportNotice(`Successfully exported statutory payroll register for ${employees.length} staff to ${filename}`);
    setTimeout(() => setExportNotice(null), 5000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <BarChart3 className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">Enterprise Reporting Suite</h2>
              <p className="text-xs text-slate-500">
                Custom filtered CSV export pipelines, statutory audits & external BI analytics integration
              </p>
            </div>
          </div>
        </div>

        {/* Global summary badge */}
        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs flex items-center gap-2">
            <Users className="w-4 h-4 text-sky-600" />
            <span className="text-slate-600">Total Workforce:</span>
            <strong className="text-slate-900 font-mono">{storeData.employees.length}</strong>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs flex items-center gap-2">
            <Calendar className="w-4 h-4 text-emerald-600" />
            <span className="text-slate-600">Attendance Logs:</span>
            <strong className="text-slate-900 font-mono">{storeData.attendance.length}</strong>
          </div>
        </div>
      </div>

      {/* Success Download Banner */}
      {exportNotice && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center justify-between animate-in fade-in duration-200 shadow-2xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{exportNotice}</span>
          </div>
          <button
            onClick={() => setExportNotice(null)}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-900 underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* 3 Quick-Export Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Attendance Card */}
        <div className={`p-5 rounded-2xl border transition-all shadow-xs flex flex-col justify-between ${
          activeCategory === 'attendance'
            ? 'bg-sky-50/50 border-sky-300 ring-2 ring-sky-500/20'
            : 'bg-white border-slate-200'
        }`}>
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="p-2 rounded-xl bg-sky-100 text-sky-700">
                <Calendar className="w-5 h-5" />
              </span>
              <span className="text-[10px] font-bold uppercase tracking-wider text-sky-700 bg-sky-50 px-2 py-0.5 rounded-full border border-sky-100">
                Time & Biometric
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 mt-2">Daily Attendance Register</h3>
            <p className="text-xs text-slate-500 mt-1">
              Filter by date window, shifts, plant sites, late anomalies, and biometric punch origins.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
            <button
              onClick={() => setActiveCategory('attendance')}
              className={`text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                activeCategory === 'attendance' ? 'text-sky-700' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Configure Filters</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={exportFilteredAttendance}
              title="Download currently filtered attendance dataset as CSV"
              className="py-1.5 px-3 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Employee Master Card */}
        <div className={`p-5 rounded-2xl border transition-all shadow-xs flex flex-col justify-between ${
          activeCategory === 'employee'
            ? 'bg-indigo-50/50 border-indigo-300 ring-2 ring-indigo-500/20'
            : 'bg-white border-slate-200'
        }`}>
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="p-2 rounded-xl bg-indigo-100 text-indigo-700">
                <Users className="w-5 h-5" />
              </span>
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                Workforce Master
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 mt-2">Manpower & Employee Demographics</h3>
            <p className="text-xs text-slate-500 mt-1">
              Active staff distribution, department allocations, grades, joining dates, and employment tenure.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
            <button
              onClick={() => setActiveCategory('employee')}
              className={`text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                activeCategory === 'employee' ? 'text-indigo-700' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Configure Filters</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={exportFilteredEmployees}
              title="Download currently filtered employee dataset as CSV"
              className="py-1.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Payroll Card */}
        <div className={`p-5 rounded-2xl border transition-all shadow-xs flex flex-col justify-between ${
          activeCategory === 'payroll'
            ? 'bg-emerald-50/50 border-emerald-300 ring-2 ring-emerald-500/20'
            : 'bg-white border-slate-200'
        }`}>
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="p-2 rounded-xl bg-emerald-100 text-emerald-700">
                <DollarSign className="w-5 h-5" />
              </span>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                Statutory Compliance
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-900 mt-2">Statutory Payroll & ECR Register</h3>
            <p className="text-xs text-slate-500 mt-1">
              Detailed salary registers, PF 12% contribution breakdown, ESIC compliance, and bank disbursement records.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
            <button
              onClick={() => setActiveCategory('payroll')}
              className={`text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors ${
                activeCategory === 'payroll' ? 'text-emerald-700' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Configure Filters</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={exportPayrollRegister}
              title="Export complete statutory salary register as CSV"
              className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Filter & CSV Export Studio */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Module Tab Selector */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-gradient-to-r from-slate-50 via-white to-sky-50/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-slate-700" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Filtered CSV Export Studio
            </h3>
          </div>

          <div className="flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs">
            <button
              onClick={() => setActiveCategory('attendance')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeCategory === 'attendance'
                  ? 'bg-white text-sky-800 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-3.5 h-3.5 text-sky-600" />
              <span>Attendance Data ({filteredAttendance.length})</span>
            </button>

            <button
              onClick={() => setActiveCategory('employee')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeCategory === 'employee'
                  ? 'bg-white text-indigo-800 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-indigo-600" />
              <span>Employee Directory ({filteredEmployees.length})</span>
            </button>

            <button
              onClick={() => setActiveCategory('payroll')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeCategory === 'payroll'
                  ? 'bg-white text-emerald-800 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
              <span>Payroll Register ({filteredEmployees.length})</span>
            </button>
          </div>
        </div>

        {/* ---------------------------------------------------- */}
        {/* ATTENDANCE FILTERS SECTION */}
        {/* ---------------------------------------------------- */}
        {activeCategory === 'attendance' && (
          <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50/50 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <Filter className="w-3.5 h-3.5 text-sky-600" />
                <span>Attendance Filter Parameters</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 font-semibold">
                  {filteredAttendance.length} of {storeData.attendance.length} Records Matched
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={resetAttendanceFilters}
                  className="px-2.5 py-1 text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Filters</span>
                </button>
              </div>
            </div>

            {/* Filter Controls Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
              {/* Search text */}
              <div className="lg:col-span-2">
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Search Employee
                </label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={attSearch}
                    onChange={(e) => setAttSearch(e.target.value)}
                    placeholder="Name, code, or department..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
                  />
                </div>
              </div>

              {/* Attendance Status */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Attendance Status
                </label>
                <select
                  value={attStatus}
                  onChange={(e) => setAttStatus(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="Present">Present Only</option>
                  <option value="Late">Late Arrivals</option>
                  <option value="Absent">Absent Only</option>
                  <option value="Half Day">Half Day</option>
                  <option value="On Leave">Approved Leave</option>
                  <option value="On Duty">On Duty (OD)</option>
                  <option value="Gate Pass">Gate Pass</option>
                </select>
              </div>

              {/* Department */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Department
                </label>
                <select
                  value={attDept}
                  onChange={(e) => setAttDept(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
                >
                  <option value="ALL">All Departments</option>
                  {(storeData.departments || []).map(dept => (
                    <option key={dept.id} value={dept.id}>{dept.name}</option>
                  ))}
                </select>
              </div>

              {/* Shift */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Shift Timing
                </label>
                <select
                  value={attShift}
                  onChange={(e) => setAttShift(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
                >
                  <option value="ALL">All Shifts</option>
                  {(storeData.shifts || []).map(sh => (
                    <option key={sh.id} value={sh.id}>{sh.name} ({sh.startTime}-{sh.endTime})</option>
                  ))}
                </select>
              </div>

              {/* Anomaly filter */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Specific Anomaly
                </label>
                <select
                  value={attAnomaly}
                  onChange={(e) => setAttAnomaly(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
                >
                  <option value="ALL">All Records</option>
                  <option value="LATE">Late Arrivals (&gt;grace)</option>
                  <option value="OVERTIME">Overtime Hours</option>
                  <option value="EARLY_OUT">Early Departures</option>
                  <option value="REGULARIZED">HR Regularized Only</option>
                </select>
              </div>
            </div>

            {/* Date Range Row */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pt-2 border-t border-slate-200/60 text-xs">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] font-semibold text-slate-600">Date Range:</span>
                <input
                  type="date"
                  value={attFromDate}
                  onChange={(e) => setAttFromDate(e.target.value)}
                  className="px-2 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                />
                <span className="text-slate-400">to</span>
                <input
                  type="date"
                  value={attToDate}
                  onChange={(e) => setAttToDate(e.target.value)}
                  className="px-2 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs focus:outline-hidden focus:ring-1 focus:ring-sky-500"
                />

                <div className="flex items-center gap-1 ml-2">
                  <button
                    type="button"
                    onClick={() => setDatePreset('today')}
                    className="px-2 py-0.5 rounded bg-slate-200/80 hover:bg-slate-300 text-slate-700 text-[10px] font-medium transition-colors cursor-pointer"
                  >
                    Today
                  </button>
                  <button
                    type="button"
                    onClick={() => setDatePreset('7days')}
                    className="px-2 py-0.5 rounded bg-slate-200/80 hover:bg-slate-300 text-slate-700 text-[10px] font-medium transition-colors cursor-pointer"
                  >
                    Last 7 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setDatePreset('30days')}
                    className="px-2 py-0.5 rounded bg-slate-200/80 hover:bg-slate-300 text-slate-700 text-[10px] font-medium transition-colors cursor-pointer"
                  >
                    Last 30 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setDatePreset('all')}
                    className="px-2 py-0.5 rounded bg-slate-200/80 hover:bg-slate-300 text-slate-700 text-[10px] font-medium transition-colors cursor-pointer"
                  >
                    All Dates
                  </button>
                </div>
              </div>

              {/* Action Export Button */}
              <button
                onClick={exportFilteredAttendance}
                className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer self-end md:self-auto"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Filtered Attendance CSV ({filteredAttendance.length})</span>
              </button>
            </div>
          </div>
        )}

        {/* ---------------------------------------------------- */}
        {/* EMPLOYEE FILTERS SECTION */}
        {/* ---------------------------------------------------- */}
        {(activeCategory === 'employee' || activeCategory === 'payroll') && (
          <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50/50 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <Filter className="w-3.5 h-3.5 text-indigo-600" />
                <span>
                  {activeCategory === 'payroll' ? 'Payroll Workforce Scope Filters' : 'Workforce Master Filters'}
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-semibold">
                  {filteredEmployees.length} of {storeData.employees.length} Employees Matched
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={resetEmployeeFilters}
                  className="px-2.5 py-1 text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Filters</span>
                </button>
              </div>
            </div>

            {/* Filter Controls Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
              {/* Search text */}
              <div className="lg:col-span-2">
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Search Employee
                </label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={empSearch}
                    onChange={(e) => setEmpSearch(e.target.value)}
                    placeholder="Name, code, email, phone..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              {/* Department */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Department
                </label>
                <select
                  value={empDept}
                  onChange={(e) => setEmpDept(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                >
                  <option value="ALL">All Departments</option>
                  {(storeData.departments || []).map(dept => (
                    <option key={dept.id} value={dept.id}>{dept.name}</option>
                  ))}
                </select>
              </div>

              {/* Branch / Plant Site */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Branch / Plant Unit
                </label>
                <select
                  value={empBranch}
                  onChange={(e) => setEmpBranch(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                >
                  <option value="ALL">All Locations</option>
                  {(storeData.branches || []).map(branch => (
                    <option key={branch.id} value={branch.id}>{branch.name} ({branch.city})</option>
                  ))}
                </select>
              </div>

              {/* Employment Type */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Employment Type
                </label>
                <select
                  value={empType}
                  onChange={(e) => setEmpType(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                >
                  <option value="ALL">All Types</option>
                  <option value="Full-Time">Full-Time Staff</option>
                  <option value="Contract">Contract / Third-Party</option>
                  <option value="Probation">Probation Period</option>
                  <option value="Intern">Trainee / Intern</option>
                  <option value="Consultant">Consultant</option>
                </select>
              </div>

              {/* Employment Status */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Employment Status
                </label>
                <select
                  value={empStatus}
                  onChange={(e) => setEmpStatus(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="Active">Active Only</option>
                  <option value="Probation">Probation</option>
                  <option value="Notice Period">Notice Period</option>
                  <option value="Resigned">Resigned / Exited</option>
                  <option value="Terminated">Terminated</option>
                </select>
              </div>
            </div>

            {/* Bottom Row: Statutory Options & Action Button */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pt-2 border-t border-slate-200/60 text-xs">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-semibold text-slate-600">Statutory Filtering:</span>
                <select
                  value={empStatutory}
                  onChange={(e) => setEmpStatutory(e.target.value)}
                  className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="ALL">All (Regardless of PF/ESIC)</option>
                  <option value="PF">PF Applicable Staff Only</option>
                  <option value="ESIC">ESIC Coverage Only</option>
                </select>
              </div>

              {/* Action Export Button */}
              {activeCategory === 'employee' ? (
                <button
                  onClick={exportFilteredEmployees}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer self-end md:self-auto"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export Filtered Employee Master CSV ({filteredEmployees.length})</span>
                </button>
              ) : (
                <button
                  onClick={exportPayrollRegister}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer self-end md:self-auto"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export Filtered Payroll Register CSV ({filteredEmployees.length})</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* ---------------------------------------------------- */}
        {/* LIVE DATA PREVIEW TABLE */}
        {/* ---------------------------------------------------- */}
        <div className="p-4 sm:p-5">
          <div className="flex items-center justify-between mb-3 text-xs">
            <div className="flex items-center gap-2">
              <TableProperties className="w-4 h-4 text-slate-600" />
              <h4 className="font-bold text-slate-900">
                Data Preview (First {activeCategory === 'attendance' ? Math.min(10, filteredAttendance.length) : Math.min(10, filteredEmployees.length)} Rows)
              </h4>
            </div>

            <div className="text-[11px] text-slate-500 font-mono">
              Export format: Standard RFC-4180 CSV (UTF-8 with BOM)
            </div>
          </div>

          {/* ATTENDANCE TABLE PREVIEW */}
          {activeCategory === 'attendance' && (
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs divide-y divide-slate-200">
                <thead className="bg-slate-50 font-bold text-slate-700">
                  <tr>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Emp Code</th>
                    <th className="py-2.5 px-3">Employee Name</th>
                    <th className="py-2.5 px-3">Department</th>
                    <th className="py-2.5 px-3">In / Out</th>
                    <th className="py-2.5 px-3">Hours</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Anomalies</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {filteredAttendance.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500">
                        <AlertCircle className="w-5 h-5 text-amber-500 mx-auto mb-1.5" />
                        <span className="font-medium">No attendance records match the selected filter criteria.</span>
                        <div className="mt-1">
                          <button
                            onClick={resetAttendanceFilters}
                            className="text-xs text-sky-600 hover:text-sky-800 underline font-semibold cursor-pointer"
                          >
                            Reset filters to view all records
                          </button>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    filteredAttendance.slice(0, 10).map((rec) => (
                      <tr key={rec.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-2 px-3 font-mono text-[11px] text-slate-600">{rec.date}</td>
                        <td className="py-2 px-3 font-mono font-bold text-slate-900">{rec.employeeCode}</td>
                        <td className="py-2 px-3 font-semibold text-slate-800">{rec.employeeName}</td>
                        <td className="py-2 px-3 text-slate-600">{rec.departmentName}</td>
                        <td className="py-2 px-3 font-mono text-[11px] text-slate-700">
                          {rec.firstIn || '--'} - {rec.lastOut || '--'}
                        </td>
                        <td className="py-2 px-3 font-mono font-medium">{rec.totalHours}h</td>
                        <td className="py-2 px-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            rec.status === 'Present'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : rec.status === 'Late'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : rec.status === 'Absent'
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-slate-100 text-slate-700'
                          }`}>
                            {rec.status}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-[11px]">
                          {rec.isLate && (
                            <span className="text-amber-600 font-semibold mr-1">Late (+{rec.lateMinutes}m)</span>
                          )}
                          {rec.isOvertime && (
                            <span className="text-sky-600 font-semibold mr-1">OT (+{rec.overtimeHours}h)</span>
                          )}
                          {!rec.isLate && !rec.isOvertime && <span className="text-slate-400">Nominal</span>}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* EMPLOYEE TABLE PREVIEW */}
          {activeCategory === 'employee' && (
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs divide-y divide-slate-200">
                <thead className="bg-slate-50 font-bold text-slate-700">
                  <tr>
                    <th className="py-2.5 px-3">Emp Code</th>
                    <th className="py-2.5 px-3">Name</th>
                    <th className="py-2.5 px-3">Department</th>
                    <th className="py-2.5 px-3">Designation</th>
                    <th className="py-2.5 px-3">Branch Location</th>
                    <th className="py-2.5 px-3">Type</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3 text-right">Annual CTC</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {filteredEmployees.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500">
                        <AlertCircle className="w-5 h-5 text-amber-500 mx-auto mb-1.5" />
                        <span className="font-medium">No employee records match the selected filter criteria.</span>
                        <div className="mt-1">
                          <button
                            onClick={resetEmployeeFilters}
                            className="text-xs text-indigo-600 hover:text-indigo-800 underline font-semibold cursor-pointer"
                          >
                            Reset filters to view all employees
                          </button>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    filteredEmployees.slice(0, 10).map((emp) => (
                      <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-2 px-3 font-mono font-bold text-slate-900">{emp.employeeCode}</td>
                        <td className="py-2 px-3">
                          <div className="font-semibold text-slate-800">{emp.firstName} {emp.lastName}</div>
                          <div className="text-[10px] text-slate-400">{emp.email}</div>
                        </td>
                        <td className="py-2 px-3 text-slate-600">{deptMap.get(emp.departmentId) || emp.departmentId}</td>
                        <td className="py-2 px-3 text-slate-600">{desigMap.get(emp.designationId) || emp.designationId}</td>
                        <td className="py-2 px-3 text-slate-600">{branchMap.get(emp.branchId) || emp.branchId}</td>
                        <td className="py-2 px-3">
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-medium">
                            {emp.employmentType}
                          </span>
                        </td>
                        <td className="py-2 px-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            emp.status === 'Active'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}>
                            {emp.status}
                          </span>
                        </td>
                        <td className="py-2 px-3 font-mono font-medium text-right text-slate-800">
                          ₹{(emp.ctcAnnual).toLocaleString('en-IN')}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* PAYROLL REGISTER TABLE PREVIEW */}
          {activeCategory === 'payroll' && (
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs divide-y divide-slate-200">
                <thead className="bg-slate-50 font-bold text-slate-700">
                  <tr>
                    <th className="py-2.5 px-3">Emp Code</th>
                    <th className="py-2.5 px-3">Name</th>
                    <th className="py-2.5 px-3">Department</th>
                    <th className="py-2.5 px-3 text-right">Basic Monthly</th>
                    <th className="py-2.5 px-3 text-right">Gross Monthly</th>
                    <th className="py-2.5 px-3 text-right">PF (12%)</th>
                    <th className="py-2.5 px-3 text-right">ESIC</th>
                    <th className="py-2.5 px-3 text-right">Net Take-Home</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {filteredEmployees.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500">
                        <AlertCircle className="w-5 h-5 text-amber-500 mx-auto mb-1.5" />
                        <span className="font-medium">No records match the selected scope.</span>
                      </td>
                    </tr>
                  ) : (
                    filteredEmployees.slice(0, 10).map((emp) => {
                      const gross = emp.basicMonthly + emp.hraMonthly + emp.conveyanceMonthly + emp.specialAllowanceMonthly;
                      return (
                        <tr key={emp.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-2 px-3 font-mono font-bold text-slate-900">{emp.employeeCode}</td>
                          <td className="py-2 px-3 font-semibold text-slate-800">{emp.firstName} {emp.lastName}</td>
                          <td className="py-2 px-3 text-slate-600">{deptMap.get(emp.departmentId) || emp.departmentId}</td>
                          <td className="py-2 px-3 font-mono text-right text-slate-700">₹{emp.basicMonthly.toLocaleString('en-IN')}</td>
                          <td className="py-2 px-3 font-mono text-right font-medium text-slate-900">₹{gross.toLocaleString('en-IN')}</td>
                          <td className="py-2 px-3 font-mono text-right text-rose-600">₹{emp.pfEmployeeMonthly.toLocaleString('en-IN')}</td>
                          <td className="py-2 px-3 font-mono text-right text-rose-600">₹{emp.esicEmployeeMonthly.toLocaleString('en-IN')}</td>
                          <td className="py-2 px-3 font-mono text-right font-bold text-emerald-700">₹{emp.netSalaryMonthly.toLocaleString('en-IN')}</td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* Table Footer info */}
          <div className="mt-3 flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-500 gap-2">
            <div>
              {activeCategory === 'attendance'
                ? `Displaying ${Math.min(10, filteredAttendance.length)} of ${filteredAttendance.length} matching attendance records.`
                : `Displaying ${Math.min(10, filteredEmployees.length)} of ${filteredEmployees.length} matching employee records.`}
            </div>

            <div className="flex items-center gap-2">
              {activeCategory === 'attendance' ? (
                <button
                  onClick={exportFilteredAttendance}
                  className="text-sky-700 hover:text-sky-900 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Full CSV ({filteredAttendance.length} Rows)</span>
                </button>
              ) : activeCategory === 'employee' ? (
                <button
                  onClick={exportFilteredEmployees}
                  className="text-indigo-700 hover:text-indigo-900 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Full CSV ({filteredEmployees.length} Rows)</span>
                </button>
              ) : (
                <button
                  onClick={exportPayrollRegister}
                  className="text-emerald-700 hover:text-emerald-900 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Full CSV ({filteredEmployees.length} Rows)</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

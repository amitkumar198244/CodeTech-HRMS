// RSTPL HRMS - Automated HR Letter Generator & Templates
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  FileText,
  Printer,
  Download,
  CheckCircle2,
  Building,
  Mail,
  UserCheck,
  Send
} from 'lucide-react';
import { Employee, Organization } from '../../types/hrms';
import { GeminiHRAssistant } from '../../services/geminiService';

interface HRLetterGeneratorViewProps {
  currentOrg: Organization;
  employees: Employee[];
  onLogAudit: (action: any, module: string, details: string) => void;
}

const LETTER_TYPES = [
  'Appointment Letter',
  'Offer Letter',
  'Increment Letter',
  'Promotion Letter',
  'Relieving Letter',
  'Experience Certificate',
  'Warning Notice',
  'Salary Certificate',
];

export const HRLetterGeneratorView: React.FC<HRLetterGeneratorViewProps> = ({
  currentOrg,
  employees,
  onLogAudit,
}) => {
  const [selectedLetter, setSelectedLetter] = useState(LETTER_TYPES[0]);
  const [selectedEmpId, setSelectedEmpId] = useState(employees[0]?.id || '');
  const [customLetterBody, setCustomLetterBody] = useState('');

  const selectedEmp = employees.find(e => e.id === selectedEmpId) || employees[0];

  // Generate template text
  const currentText = customLetterBody || GeminiHRAssistant.generateHRLetterTemplate(
    selectedLetter,
    `${selectedEmp?.firstName} ${selectedEmp?.lastName}`,
    'Corporate Executive',
    currentOrg.name
  );

  const handlePrint = () => {
    window.print();
    onLogAudit('EXPORT', 'HR Letters', `Generated and printed ${selectedLetter} for ${selectedEmp?.firstName} ${selectedEmp?.lastName}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <FileText className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">Automated HR Letter Generator</h2>
              <p className="text-xs text-slate-500">
                Official document dispatch engine with corporate watermarks & executive letterhead
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handlePrint}
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs transition-colors cursor-pointer"
        >
          <Printer className="w-3.5 h-3.5" />
          <span>Print / Export PDF</span>
        </button>
      </div>

      {/* Editor & Controls Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls Column */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Document Parameters</h3>

          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">Select Document Type:</label>
            <div className="space-y-1">
              {LETTER_TYPES.map(type => (
                <button
                  key={type}
                  onClick={() => {
                    setSelectedLetter(type);
                    setCustomLetterBody('');
                  }}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
                    selectedLetter === type
                      ? 'bg-sky-50 text-sky-900 font-bold border border-sky-200'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">Target Personnel:</label>
            <select
              value={selectedEmpId}
              onChange={e => {
                setSelectedEmpId(e.target.value);
                setCustomLetterBody('');
              }}
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium"
            >
              {employees.map(e => (
                <option key={e.id} value={e.id}>
                  {e.firstName} {e.lastName} ({e.employeeCode})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Live Document Preview with RSTPL Letterhead */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-8 shadow-md">
          {/* RSTPL Letterhead Header */}
          <div className="border-b-2 border-sky-800 pb-4 mb-6">
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-xl font-black tracking-tight text-slate-900">
                  {currentOrg.name}
                </h1>
                <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                  Corporate HQ: RSTPL Tech Park, Baner Road, Pune - 411045, Maharashtra, India
                </p>
                <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                  CIN: U72200MH2021PTC123456 | GSTIN: {currentOrg.gstNumber} | PAN: {currentOrg.panNumber}
                </p>
              </div>
              <div className="text-right">
                <span className="px-2.5 py-1 rounded bg-sky-100 text-sky-900 font-mono font-bold text-[10px] border border-sky-200">
                  CONFIDENTIAL
                </span>
              </div>
            </div>
          </div>

          {/* Document Content */}
          <div className="text-xs text-slate-800 font-serif leading-relaxed whitespace-pre-wrap min-h-[300px]">
            {currentText}
          </div>

          {/* Letterhead Footer */}
          <div className="mt-12 pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between text-[10px] text-slate-400 gap-2">
            <span>CodeTech HRMS by RSTPL · Power by RS TechnoVisions XpertSkillCop · Verification Code: #VER-2026-XPC-991</span>
            <div className="flex items-center gap-3">
              <span>www.rstpl.com</span>
              <span>•</span>
              <span>www.rstechnovisions.co.in</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

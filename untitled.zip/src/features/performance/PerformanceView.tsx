// RSTPL HRMS - 3-Stage Monthly KRA & Performance Management System (PMS)
// RS Technovisions XpertSkillCop
// Complete Workflow: HR Fixes KRAs -> Employee Monthly Self-Fill -> Manager Review & Mark -> HR Head Final Sign-off

import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  RadialBarChart,
  RadialBar,
  PolarAngleAxis,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
  ReferenceLine,
} from 'recharts';
import {
  Target,
  Award,
  Star,
  CheckCircle2,
  TrendingUp,
  Sliders,
  ChevronRight,
  UserCheck,
  Clock,
  ArrowRight,
  ShieldCheck,
  Send,
  Check,
  AlertCircle,
  Plus,
  Edit,
  User,
  Building,
  BarChart2,
  Gauge,
  LayoutGrid,
  Layers,
  Sparkles,
} from 'lucide-react';
import {
  Employee,
  Department,
  Branch,
  UserRole,
  KRAMasterItem,
  MonthlyKRAEvaluation,
  MonthlyKRAItem
} from '../../types/hrms';
import { PerformanceKPIView } from './PerformanceKPIView';

interface PerformanceViewProps {
  employees: Employee[];
  departments?: Department[];
  branches?: Branch[];
  currentRole?: UserRole;
  kraMasterList?: KRAMasterItem[];
  monthlyKraEvaluations?: MonthlyKRAEvaluation[];
  onUpdateKraMaster?: (kras: KRAMasterItem[]) => void;
  onUpdateMonthlyEvaluations?: (evals: MonthlyKRAEvaluation[]) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
  currentEmployee?: Employee; // Active employee when in ESS mode
  defaultTab?: 'evaluations' | 'department-kpi' | 'kra-setup' | 'scorecard';
}

export const PerformanceView: React.FC<PerformanceViewProps> = ({
  employees,
  departments = [],
  branches = [],
  currentRole,
  kraMasterList = [],
  monthlyKraEvaluations = [],
  onUpdateKraMaster,
  onUpdateMonthlyEvaluations,
  onLogAudit,
  currentEmployee,
  defaultTab,
}) => {
  const [activeTab, setActiveTab] = useState<'evaluations' | 'department-kpi' | 'kra-setup' | 'scorecard'>(
    defaultTab || (currentRole === 'manager' ? 'department-kpi' : 'evaluations')
  );
  const [selectedMonth, setSelectedMonth] = useState('October 2026');
  const [selectedEvalId, setSelectedEvalId] = useState<string>(monthlyKraEvaluations[0]?.id || '');

  // Form states for Employee Self-Filling
  const [selfRatings, setSelfRatings] = useState<Record<string, number>>({});
  const [actualDataMap, setActualDataMap] = useState<Record<string, string>>({});
  const [selfRemarksMap, setSelfRemarksMap] = useState<Record<string, string>>({});

  // Form states for Manager Scoring
  const [managerRatings, setManagerRatings] = useState<Record<string, number>>({});
  const [managerRemarksMap, setManagerRemarksMap] = useState<Record<string, string>>({});
  const [managerFeedback, setManagerFeedback] = useState('');

  // Form states for HR Head Normalization
  const [hrFinalRemarks, setHrFinalRemarks] = useState('');
  const [hrFinalGrade, setHrFinalGrade] = useState<'A+' | 'A' | 'B' | 'C'>('A+');

  // Scorecard View Mode: Interactive Recharts Visuals vs Tabular Records
  const [scorecardViewMode, setScorecardViewMode] = useState<'charts' | 'table'>('charts');

  // Compute department-wise appraisal analytics and KPI achievements
  const deptAppraisalAnalytics = useMemo(() => {
    const deptMap: Record<string, { totalScore: number; count: number; aPlus: number; a: number; b: number; c: number; approved: number }> = {};

    monthlyKraEvaluations.forEach(ev => {
      const dept = ev.department || 'Operations';
      if (!deptMap[dept]) {
        deptMap[dept] = { totalScore: 0, count: 0, aPlus: 0, a: 0, b: 0, c: 0, approved: 0 };
      }
      const score = ev.finalHrScore || ev.totalManagerScore || ev.totalSelfScore || 4.2;
      deptMap[dept].totalScore += score;
      deptMap[dept].count += 1;
      if (ev.finalGrade === 'A+') deptMap[dept].aPlus += 1;
      else if (ev.finalGrade === 'A') deptMap[dept].a += 1;
      else if (ev.finalGrade === 'B') deptMap[dept].b += 1;
      else if (ev.finalGrade === 'C') deptMap[dept].c += 1;
      if (ev.status === 'Approved_By_HR_Head') deptMap[dept].approved += 1;
    });

    const list = Object.entries(deptMap).map(([deptName, data], index) => {
      const avgScore = Number((data.totalScore / data.count).toFixed(2));
      const achievement = Number(((avgScore / 4.5) * 100).toFixed(1));
      let fill = '#10b981';
      if (achievement < 90) fill = '#f43f5e';
      else if (achievement < 95) fill = '#f59e0b';
      else if (achievement < 100) fill = '#0284c7';

      return {
        id: `dept-appraisal-${index}`,
        name: deptName,
        shortName: deptName.split(' ')[0],
        avgScore: avgScore,
        achievement: achievement,
        target: 4.5,
        count: data.count,
        approved: data.approved,
        aPlus: data.aPlus,
        a: data.a,
        fill: fill,
      };
    });

    // Overall summary
    const totalEvals = monthlyKraEvaluations.length;
    const avgOverallScore = list.length
      ? Number((list.reduce((acc, curr) => acc + curr.avgScore, 0) / list.length).toFixed(2))
      : 4.5;
    const avgOverallAchievement = list.length
      ? Number((list.reduce((acc, curr) => acc + curr.achievement, 0) / list.length).toFixed(1))
      : 100;
    const topDept = [...list].sort((a, b) => b.achievement - a.achievement)[0];

    return {
      deptList: list,
      totalEvals,
      avgOverallScore,
      avgOverallAchievement,
      topDept,
    };
  }, [monthlyKraEvaluations]);

  // New KRA Master Modal
  const [showAddKraModal, setShowAddKraModal] = useState(false);
  const [newKraTitle, setNewKraTitle] = useState('');
  const [newKraDesc, setNewKraDesc] = useState('');
  const [newKraMetric, setNewKraMetric] = useState('');
  const [newKraWeightage, setNewKraWeightage] = useState<number>(30);

  const activeEvaluation = monthlyKraEvaluations.find(e => e.id === selectedEvalId) || monthlyKraEvaluations[0];

  // Employee Submits Monthly KRA (Stage 2)
  const handleEmployeeSubmitKRA = () => {
    if (!activeEvaluation) return;

    const updatedKras: MonthlyKRAItem[] = activeEvaluation.kras.map(k => ({
      ...k,
      actualAchievedData: actualDataMap[k.kraId] !== undefined ? actualDataMap[k.kraId] : k.actualAchievedData,
      selfRating: selfRatings[k.kraId] !== undefined ? selfRatings[k.kraId] : k.selfRating,
      selfRemarks: selfRemarksMap[k.kraId] !== undefined ? selfRemarksMap[k.kraId] : k.selfRemarks,
    }));

    const avgSelf = Number(
      (updatedKras.reduce((s, k) => s + (k.selfRating * (k.weightage / 100)), 0)).toFixed(2)
    );

    const updatedEval: MonthlyKRAEvaluation = {
      ...activeEvaluation,
      kras: updatedKras,
      totalSelfScore: avgSelf,
      status: 'Submitted_To_Manager',
      employeeSubmittedAt: new Date().toISOString(),
    };

    const nextList = monthlyKraEvaluations.map(e => (e.id === activeEvaluation.id ? updatedEval : e));
    if (onUpdateMonthlyEvaluations) {
      onUpdateMonthlyEvaluations(nextList);
    }

    onLogAudit(
      'UPDATE',
      'PMS & KRA',
      `Employee ${activeEvaluation.employeeName} submitted monthly KRA self-rating (${avgSelf}/5.0) for ${activeEvaluation.month}`
    );
  };

  // Reporting Manager Reviews & Forwards to HR Head (Stage 3)
  const handleManagerApproveAndForward = () => {
    if (!activeEvaluation) return;

    const updatedKras: MonthlyKRAItem[] = activeEvaluation.kras.map(k => ({
      ...k,
      managerRating: managerRatings[k.kraId] !== undefined ? managerRatings[k.kraId] : (k.managerRating || k.selfRating),
      managerRemarks: managerRemarksMap[k.kraId] !== undefined ? managerRemarksMap[k.kraId] : (k.managerRemarks || 'Reviewed and approved.'),
    }));

    const avgManager = Number(
      (updatedKras.reduce((s, k) => s + ((k.managerRating || k.selfRating) * (k.weightage / 100)), 0)).toFixed(2)
    );

    const updatedEval: MonthlyKRAEvaluation = {
      ...activeEvaluation,
      kras: updatedKras,
      totalManagerScore: avgManager,
      status: 'Approved_By_Manager_Forwarded_To_HR',
      managerReviewedAt: new Date().toISOString(),
      managerReviewedBy: currentRole === 'manager' ? 'Rajesh Patil (Plant Operations Head)' : 'Reporting Manager',
      managerComments: managerFeedback || 'Subordinate verified against plant targets. Approved & forwarded to HR Head.',
    };

    const nextList = monthlyKraEvaluations.map(e => (e.id === activeEvaluation.id ? updatedEval : e));
    if (onUpdateMonthlyEvaluations) {
      onUpdateMonthlyEvaluations(nextList);
    }

    onLogAudit(
      'APPROVE',
      'PMS & KRA',
      `Reporting Manager approved KRA score (${avgManager}/5.0) for ${activeEvaluation.employeeName} and forwarded to HR Head`
    );
  };

  // HR Head Final Approval & Appraisal Lock (Stage 4)
  const handleHrHeadFinalApproval = () => {
    if (!activeEvaluation) return;

    const finalScore = activeEvaluation.totalManagerScore || activeEvaluation.totalSelfScore;

    const updatedEval: MonthlyKRAEvaluation = {
      ...activeEvaluation,
      finalHrScore: finalScore,
      finalGrade: hrFinalGrade,
      status: 'Approved_By_HR_Head',
      hrApprovedAt: new Date().toISOString(),
      hrApprovedBy: currentRole === 'hr_head' ? 'Amit Sharma (VP HR)' : 'HR Head',
      hrRemarks: hrFinalRemarks || 'Appraisal normalized and finalized for monthly incentive records.',
    };

    const nextList = monthlyKraEvaluations.map(e => (e.id === activeEvaluation.id ? updatedEval : e));
    if (onUpdateMonthlyEvaluations) {
      onUpdateMonthlyEvaluations(nextList);
    }

    onLogAudit(
      'APPROVE',
      'PMS & KRA',
      `HR Head granted final approval for ${activeEvaluation.employeeName} KRA (Grade ${hrFinalGrade}, Score: ${finalScore}/5.0)`
    );
  };

  // HR Adds New Fixed KRA to Master
  const handleAddNewKraMaster = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKraTitle || !onUpdateKraMaster) return;

    const newKra: KRAMasterItem = {
      id: `kra-${Date.now()}`,
      orgId: 'org-rstpl-001',
      title: newKraTitle,
      description: newKraDesc,
      targetMetric: newKraMetric,
      weightage: newKraWeightage,
      fixedByRole: 'HR Head (Amit Sharma)',
      fixedAt: new Date().toISOString(),
      isActive: true,
    };

    onUpdateKraMaster([newKra, ...kraMasterList]);
    setShowAddKraModal(false);
    setNewKraTitle('');
    setNewKraDesc('');
    setNewKraMetric('');
    onLogAudit('CREATE', 'KRA Master', `HR Head configured new fixed KRA: ${newKra.title} (${newKra.weightage}%)`);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <Target className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                Monthly KRA & Performance Management (PMS)
              </h2>
              <p className="text-xs text-slate-500">
                3-Stage Lifecycle: HR Fixes KRA & Weightage → Employee Fills Data → Manager Reviews & Marks → HR Head Finalizes
              </p>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs self-start md:self-auto">
          <button
            onClick={() => setActiveTab('evaluations')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              activeTab === 'evaluations' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Monthly KRA Workflow
          </button>
          <button
            onClick={() => setActiveTab('department-kpi')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'department-kpi' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5 text-sky-700" />
            Departmental KPIs (Bar & Radial)
          </button>
          <button
            onClick={() => setActiveTab('kra-setup')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              activeTab === 'kra-setup' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            HR KRA Master Catalog
          </button>
          <button
            onClick={() => setActiveTab('scorecard')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              activeTab === 'scorecard' ? 'bg-white text-sky-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Appraisal Grade Summary & Analytics
          </button>
        </div>
      </div>

      {activeTab === 'evaluations' && (
        <div className="space-y-6">
          {/* Active Evaluation Selector & Stage Indicator */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-0.5">Evaluation Month</label>
                <select
                  value={selectedMonth}
                  onChange={e => setSelectedMonth(e.target.value)}
                  className="text-xs px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-800"
                >
                  <option value="October 2026">October 2026 (Active Cycle)</option>
                  <option value="September 2026">September 2026 (Finalized)</option>
                  <option value="August 2026">August 2026 (Archived)</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase text-slate-400 block mb-0.5">Appraisee Employee</label>
                <select
                  value={selectedEvalId}
                  onChange={e => setSelectedEvalId(e.target.value)}
                  className="text-xs px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-800"
                >
                  {monthlyKraEvaluations.map(ev => (
                    <option key={ev.id} value={ev.id}>
                      {ev.employeeName} ({ev.employeeCode}) - {ev.designation}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Workflow Progress Status Badge */}
            {activeEvaluation && (
              <div className="flex items-center gap-2 self-start md:self-auto">
                <span className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${
                  activeEvaluation.status === 'Approved_By_HR_Head'
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : activeEvaluation.status === 'Approved_By_Manager_Forwarded_To_HR'
                    ? 'bg-indigo-50 text-indigo-800 border-indigo-200'
                    : 'bg-amber-50 text-amber-800 border-amber-200'
                }`}>
                  <span className="w-2 h-2 rounded-full bg-current animate-pulse" />
                  <span>
                    {activeEvaluation.status === 'Approved_By_HR_Head'
                      ? 'Stage 4: Approved & Locked by HR Head'
                      : activeEvaluation.status === 'Approved_By_Manager_Forwarded_To_HR'
                      ? 'Stage 3: Approved by Manager → Awaiting HR Head'
                      : 'Stage 2: Submitted to Manager for Review'}
                  </span>
                </span>
              </div>
            )}
          </div>

          {/* 4-Stage Workflow Progression Strip */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                <span className="text-[10px] font-bold uppercase text-emerald-700 block">Stage 1: HR Fixed KRAs</span>
                <p className="font-bold text-slate-900 mt-1">Weightage Fixed: 100%</p>
                <p className="text-[11px] text-slate-500 mt-0.5">HR Head established target benchmarks</p>
              </div>

              <div className={`p-3 rounded-xl border ${
                activeEvaluation?.employeeSubmittedAt
                  ? 'bg-emerald-50 border-emerald-200'
                  : 'bg-sky-50 border-sky-300 ring-2 ring-sky-500/10'
              }`}>
                <span className="text-[10px] font-bold uppercase text-slate-600 block">Stage 2: Employee Self-Fill</span>
                <p className="font-bold text-slate-900 mt-1">
                  {activeEvaluation?.totalSelfScore ? `Self Score: ${activeEvaluation.totalSelfScore} / 5.0` : 'Draft / Filling Data'}
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {activeEvaluation?.employeeSubmittedAt ? 'Submitted with proof' : 'Employee enters actuals'}
                </p>
              </div>

              <div className={`p-3 rounded-xl border ${
                activeEvaluation?.managerReviewedAt
                  ? 'bg-emerald-50 border-emerald-200'
                  : activeEvaluation?.status === 'Submitted_To_Manager'
                  ? 'bg-amber-50 border-amber-300 ring-2 ring-amber-500/10'
                  : 'bg-slate-50 border-slate-200 text-slate-400'
              }`}>
                <span className="text-[10px] font-bold uppercase text-slate-600 block">Stage 3: Manager Review</span>
                <p className="font-bold text-slate-900 mt-1">
                  {activeEvaluation?.totalManagerScore ? `Manager Score: ${activeEvaluation.totalManagerScore} / 5.0` : 'Pending Manager Marks'}
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {activeEvaluation?.managerReviewedAt ? 'Approved & Forwarded' : 'Manager evaluates subordinates'}
                </p>
              </div>

              <div className={`p-3 rounded-xl border ${
                activeEvaluation?.status === 'Approved_By_HR_Head'
                  ? 'bg-emerald-50 border-emerald-200'
                  : activeEvaluation?.status === 'Approved_By_Manager_Forwarded_To_HR'
                  ? 'bg-indigo-50 border-indigo-300 ring-2 ring-indigo-500/10'
                  : 'bg-slate-50 border-slate-200 text-slate-400'
              }`}>
                <span className="text-[10px] font-bold uppercase text-slate-600 block">Stage 4: HR Head Final</span>
                <p className="font-bold text-slate-900 mt-1">
                  {activeEvaluation?.finalGrade ? `Grade ${activeEvaluation.finalGrade} Signed-off` : 'Awaiting HR Normalization'}
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {activeEvaluation?.hrApprovedAt ? 'Finalized for hike/appraisal' : 'VP HR signs off'}
                </p>
              </div>
            </div>
          </div>

          {/* Active Employee Details & KRA Form */}
          {activeEvaluation && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
                <div>
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-4 h-4 text-sky-600" />
                    <h3 className="text-sm font-bold text-slate-900">
                      {activeEvaluation.employeeName} ({activeEvaluation.employeeCode})
                    </h3>
                    <span className="text-xs text-slate-500">· {activeEvaluation.designation}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Department: {activeEvaluation.department} · Reporting Manager:{' '}
                    <strong className="text-slate-800">{activeEvaluation.reportingManagerName}</strong>
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] font-bold uppercase text-slate-400 block">Self Rating</span>
                    <span className="font-mono font-bold text-xs text-sky-700">{activeEvaluation.totalSelfScore} / 5.0</span>
                  </div>
                  {activeEvaluation.totalManagerScore && (
                    <div className="text-right">
                      <span className="text-[10px] font-bold uppercase text-slate-400 block">Manager Score</span>
                      <span className="font-mono font-bold text-xs text-indigo-700">{activeEvaluation.totalManagerScore} / 5.0</span>
                    </div>
                  )}
                  {activeEvaluation.finalGrade && (
                    <div className="text-right">
                      <span className="text-[10px] font-bold uppercase text-slate-400 block">Final Grade</span>
                      <span className="px-2 py-0.5 rounded text-xs font-black bg-emerald-100 text-emerald-800 font-mono">
                        {activeEvaluation.finalGrade}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* KRA Items Detailed Evaluator */}
              <div className="p-5 space-y-6">
                {activeEvaluation.kras.map((kra, idx) => {
                  const currentSelfRating = selfRatings[kra.kraId] ?? kra.selfRating;
                  const currentActualData = actualDataMap[kra.kraId] ?? kra.actualAchievedData;
                  const currentSelfRemarks = selfRemarksMap[kra.kraId] ?? kra.selfRemarks;
                  const currentMgrRating = managerRatings[kra.kraId] ?? (kra.managerRating || currentSelfRating);
                  const currentMgrRemarks = managerRemarksMap[kra.kraId] ?? (kra.managerRemarks || '');

                  return (
                    <div
                      key={kra.kraId}
                      className="p-4 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-3 hover:border-sky-200 transition-colors"
                    >
                      {/* KRA Header */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-sky-100 text-sky-800">
                              KRA #{idx + 1}
                            </span>
                            <h4 className="font-bold text-sm text-slate-900">{kra.title}</h4>
                          </div>
                          <p className="text-xs text-slate-500 mt-1">{kra.description}</p>
                          <p className="text-[11px] text-sky-700 font-medium mt-0.5">
                            Target Metric: <strong>{kra.targetMetric}</strong>
                          </p>
                        </div>

                        <span className="px-2.5 py-1 rounded-xl bg-slate-100 text-slate-800 font-mono text-xs font-bold shrink-0 self-start sm:self-auto">
                          Weightage: {kra.weightage}%
                        </span>
                      </div>

                      {/* 2-Column Responsive Layout: Employee Fill vs Manager Review */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                        {/* Column 1: Employee Monthly Data Fill */}
                        <div className="p-3 rounded-xl bg-slate-50/80 border border-slate-200/80 space-y-2">
                          <div className="flex items-center justify-between font-bold text-slate-700">
                            <span className="flex items-center gap-1.5">
                              <User className="w-3.5 h-3.5 text-sky-600" />
                              <span>Employee Monthly Actuals</span>
                            </span>
                            <span className="text-[11px] font-mono text-sky-700">Self Points: {currentSelfRating} / 5.0</span>
                          </div>

                          <div>
                            <label className="text-[10px] font-semibold text-slate-500 block mb-0.5">Actual Monthly Achieved Data:</label>
                            <textarea
                              rows={2}
                              disabled={activeEvaluation.status !== 'Draft' && activeEvaluation.status !== 'Revision_Requested'}
                              value={currentActualData}
                              onChange={e => setActualDataMap({ ...actualDataMap, [kra.kraId]: e.target.value })}
                              placeholder="Fill actual quantities, percentage, or deliverables achieved..."
                              className="w-full p-2 text-xs rounded-lg border border-slate-200 bg-white disabled:bg-slate-100"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="text-[10px] font-semibold text-slate-500 block mb-0.5">Self Rating (1.0 - 5.0):</label>
                              <input
                                type="number"
                                min={1}
                                max={5}
                                step={0.1}
                                disabled={activeEvaluation.status !== 'Draft' && activeEvaluation.status !== 'Revision_Requested'}
                                value={currentSelfRating}
                                onChange={e => setSelfRatings({ ...selfRatings, [kra.kraId]: Number(e.target.value) })}
                                className="w-full p-1.5 text-xs rounded-lg border border-slate-200 bg-white font-mono font-bold text-sky-800 disabled:bg-slate-100"
                              />
                            </div>
                            <div>
                              <label className="text-[10px] font-semibold text-slate-500 block mb-0.5">Self Remarks / Evidence:</label>
                              <input
                                type="text"
                                disabled={activeEvaluation.status !== 'Draft' && activeEvaluation.status !== 'Revision_Requested'}
                                value={currentSelfRemarks}
                                onChange={e => setSelfRemarksMap({ ...selfRemarksMap, [kra.kraId]: e.target.value })}
                                placeholder="Remarks / log ref..."
                                className="w-full p-1.5 text-xs rounded-lg border border-slate-200 bg-white disabled:bg-slate-100"
                              />
                            </div>
                          </div>
                        </div>

                        {/* Column 2: Reporting Manager Review & Scoring */}
                        <div className="p-3 rounded-xl bg-indigo-50/50 border border-indigo-100 space-y-2">
                          <div className="flex items-center justify-between font-bold text-indigo-900">
                            <span className="flex items-center gap-1.5">
                              <UserCheck className="w-3.5 h-3.5 text-indigo-600" />
                              <span>Reporting Manager Marks & Feedback</span>
                            </span>
                            <span className="text-[11px] font-mono text-indigo-700">
                              Mgr Rating: {currentMgrRating} / 5.0
                            </span>
                          </div>

                          <div>
                            <label className="text-[10px] font-semibold text-slate-500 block mb-0.5">Manager Evaluation Points (1.0 - 5.0):</label>
                            <input
                              type="number"
                              min={1}
                              max={5}
                              step={0.1}
                              disabled={activeEvaluation.status === 'Approved_By_HR_Head'}
                              value={currentMgrRating}
                              onChange={e => setManagerRatings({ ...managerRatings, [kra.kraId]: Number(e.target.value) })}
                              className="w-full p-1.5 text-xs rounded-lg border border-indigo-200 bg-white font-mono font-bold text-indigo-900 disabled:bg-slate-100"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-semibold text-slate-500 block mb-0.5">Manager Remarks on KRA:</label>
                            <input
                              type="text"
                              disabled={activeEvaluation.status === 'Approved_By_HR_Head'}
                              value={currentMgrRemarks}
                              onChange={e => setManagerRemarksMap({ ...managerRemarksMap, [kra.kraId]: e.target.value })}
                              placeholder="Manager appraisal comment for this KRA..."
                              className="w-full p-1.5 text-xs rounded-lg border border-indigo-200 bg-white disabled:bg-slate-100"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {/* Manager Comments Section if Forwarded */}
                {activeEvaluation.managerComments && (
                  <div className="p-3.5 rounded-xl bg-indigo-50 border border-indigo-200 text-xs text-indigo-950 space-y-1">
                    <div className="flex items-center justify-between font-bold">
                      <span>Reporting Manager Evaluation Dossier:</span>
                      <span className="font-mono text-[10px] text-indigo-700">{activeEvaluation.managerReviewedBy}</span>
                    </div>
                    <p className="italic">"{activeEvaluation.managerComments}"</p>
                  </div>
                )}

                {/* HR Head Remarks if Approved */}
                {activeEvaluation.hrRemarks && (
                  <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 space-y-1">
                    <div className="flex items-center justify-between font-bold">
                      <span>HR Head Final Sign-off:</span>
                      <span className="font-mono text-[10px] text-emerald-700">{activeEvaluation.hrApprovedBy}</span>
                    </div>
                    <p className="italic">"{activeEvaluation.hrRemarks}"</p>
                  </div>
                )}

                {/* Action Command Bar for the Current Workflow Step */}
                <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="text-xs text-slate-500 font-medium">
                    Current Step: <strong className="text-slate-800">{activeEvaluation.status.replace(/_/g, ' ')}</strong>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Stage 2 Action: Employee Submits */}
                    {(activeEvaluation.status === 'Draft' || activeEvaluation.status === 'Revision_Requested') && (
                      <button
                        onClick={handleEmployeeSubmitKRA}
                        className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Submit Monthly KRA to Reporting Manager</span>
                      </button>
                    )}

                    {/* Stage 3 Action: Reporting Manager Approves & Forwards to HR */}
                    {activeEvaluation.status === 'Submitted_To_Manager' && (
                      <button
                        onClick={handleManagerApproveAndForward}
                        className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                        <span>Approve Marks & Forward to HR Head</span>
                      </button>
                    )}

                    {/* Stage 4 Action: HR Head Final Approval */}
                    {activeEvaluation.status === 'Approved_By_Manager_Forwarded_To_HR' && (
                      <div className="flex items-center gap-2">
                        <select
                          value={hrFinalGrade}
                          onChange={e => setHrFinalGrade(e.target.value as any)}
                          className="text-xs px-2.5 py-2 rounded-xl border border-slate-200 bg-slate-50 font-bold"
                        >
                          <option value="A+">Grade A+ (Top Performer)</option>
                          <option value="A">Grade A (Exceeds Target)</option>
                          <option value="B">Grade B (Meets Standard)</option>
                          <option value="C">Grade C (Needs Training)</option>
                        </select>
                        <button
                          onClick={handleHrHeadFinalApproval}
                          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>Final HR Head Approval & Appraisal Lock</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: HR KRA Master Catalog */}
      {activeTab === 'kra-setup' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Fixed Corporate KRA & Goal Weightage Master</h3>
              <p className="text-xs text-slate-500">
                HR Head defines and locks standard weightages that appraisees must achieve each month
              </p>
            </div>
            <button
              onClick={() => setShowAddKraModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-xl cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Configure New KRA</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {kraMasterList.map((kra, idx) => (
              <div key={kra.id} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-sky-50 text-sky-800">
                    KRA #{idx + 1}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-xs font-black bg-indigo-50 text-indigo-800 border border-indigo-200 font-mono">
                    {kra.weightage}% Weight
                  </span>
                </div>

                <h4 className="font-bold text-xs text-slate-900 leading-snug">{kra.title}</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed">{kra.description}</p>

                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-[11px] text-slate-700">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Target Metric:</span>
                  <p className="font-medium mt-0.5">{kra.targetMetric}</p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex justify-between text-[10px] text-slate-400">
                  <span>Fixed by: {kra.fixedByRole}</span>
                  <span className="text-emerald-600 font-bold">Active in PMS</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Departmental KPI Analytics (Recharts) */}
      {activeTab === 'department-kpi' && (
        <PerformanceKPIView
          employees={employees}
          departments={departments}
          branches={branches}
          monthlyKraEvaluations={monthlyKraEvaluations}
          currentRole={currentRole}
          currentEmployee={currentEmployee}
          onLogAudit={onLogAudit}
          onNavigateToWorkflow={(evalId) => {
            if (evalId) setSelectedEvalId(evalId);
            setActiveTab('evaluations');
          }}
        />
      )}

      {/* Tab 3: Appraisal Grade Summary & Analytics (Interactive Recharts) */}
      {activeTab === 'scorecard' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-6">
          <div className="border-b border-slate-100 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-sky-100 text-sky-800">
                  <Award className="w-5 h-5 text-sky-700" />
                </span>
                <div>
                  <h3 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-2">
                    Appraisal Grade & Composite Score Summary
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      Recharts Analytics
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Department-wise visual breakdown of KRA achievement scores replacing static lists with interactive Bar & Radial charts
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs">
                <button
                  type="button"
                  onClick={() => setScorecardViewMode('charts')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    scorecardViewMode === 'charts'
                      ? 'bg-white text-sky-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <BarChart2 className="w-3.5 h-3.5 text-sky-700" />
                  <span>Visual Charts</span>
                </button>
                <button
                  type="button"
                  onClick={() => setScorecardViewMode('table')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    scorecardViewMode === 'table'
                      ? 'bg-white text-sky-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5 text-slate-700" />
                  <span>Records Table</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Fleet Composite Score</span>
              <p className="font-black text-slate-900 text-base mt-0.5 font-mono">
                {deptAppraisalAnalytics.avgOverallScore} <span className="text-xs text-slate-400 font-normal">/ 5.0</span>
              </p>
              <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">Benchmark: 4.5 Standard</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Average Achievement</span>
              <p className="font-black text-sky-700 text-base mt-0.5 font-mono">
                {deptAppraisalAnalytics.avgOverallAchievement}%
              </p>
              <span className="text-[10px] text-slate-500 font-semibold block mt-0.5">Across {deptAppraisalAnalytics.deptList.length} Departments</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Total Evaluations</span>
              <p className="font-black text-purple-700 text-base mt-0.5 font-mono">
                {deptAppraisalAnalytics.totalEvals} Appraisees
              </p>
              <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">Cycle Active & Normalized</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-bold uppercase text-slate-400 block">Top Department</span>
              <p className="font-black text-emerald-700 text-xs mt-1 truncate">
                {deptAppraisalAnalytics.topDept ? `${deptAppraisalAnalytics.topDept.name}` : 'Operations'}
              </p>
              <span className="text-[10px] text-slate-500 font-mono font-bold block mt-0.5">
                {deptAppraisalAnalytics.topDept?.achievement}% Target Score
              </span>
            </div>
          </div>

          {/* Visual Charts Mode */}
          {scorecardViewMode === 'charts' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left Chart: Department-wise Score Bar Chart */}
                <div className="lg:col-span-7 p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="text-xs font-black uppercase text-slate-900 flex items-center gap-1.5">
                          <BarChart2 className="w-4 h-4 text-sky-700" />
                          Department-Wise Appraisal Scores (Scale 1.0 - 5.0)
                        </h4>
                        <p className="text-[11px] text-slate-500">
                          Average composite appraisal score per department vs 4.5 baseline target
                        </p>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                        Target: 4.5
                      </span>
                    </div>

                    <div className="w-full h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={deptAppraisalAnalytics.deptList}
                          margin={{ top: 12, right: 15, left: -15, bottom: 25 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                          <XAxis
                            dataKey="shortName"
                            tick={{ fill: '#475569', fontSize: 11, fontWeight: 700 }}
                            axisLine={{ stroke: '#cbd5e1' }}
                            tickLine={false}
                          />
                          <YAxis
                            domain={[3.5, 5.0]}
                            tick={{ fill: '#64748b', fontSize: 11 }}
                            axisLine={{ stroke: '#cbd5e1' }}
                            tickLine={false}
                          />
                          <Tooltip
                            content={({ active, payload }) => {
                              if (active && payload && payload.length) {
                                const d = payload[0].payload;
                                return (
                                  <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl text-xs space-y-1 min-w-44">
                                    <p className="font-bold text-sky-400">{d.name}</p>
                                    <p className="flex justify-between text-slate-300">
                                      <span>Avg Score:</span> <strong className="text-white font-mono">{d.avgScore} / 5.0</strong>
                                    </p>
                                    <p className="flex justify-between text-slate-300">
                                      <span>Achievement:</span> <strong className="text-emerald-400 font-mono">{d.achievement}%</strong>
                                    </p>
                                    <p className="flex justify-between text-slate-400 text-[11px]">
                                      <span>Employees:</span> <span className="text-slate-200">{d.count}</span>
                                    </p>
                                  </div>
                                );
                              }
                              return null;
                            }}
                          />
                          <ReferenceLine
                            y={4.5}
                            stroke="#f59e0b"
                            strokeDasharray="4 4"
                            label={{ value: '4.5 Benchmark', fill: '#d97706', fontSize: 10, position: 'top' }}
                          />
                          <Bar dataKey="avgScore" radius={[6, 6, 0, 0]} maxBarSize={36}>
                            {deptAppraisalAnalytics.deptList.map((entry, index) => (
                              <Cell key={`bar-${entry.id || index}`} fill={entry.fill} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span>Baseline target 4.5 ensures standard increment eligibility</span>
                    <span className="font-bold text-emerald-700">All Units Exceeding Baseline</span>
                  </div>
                </div>

                {/* Right Chart: RadialBarChart of Department Achievement % */}
                <div className="lg:col-span-5 p-4 rounded-2xl bg-slate-50/70 border border-slate-200/80 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h4 className="text-xs font-black uppercase text-slate-900 flex items-center gap-1.5">
                          <Gauge className="w-4 h-4 text-sky-700" />
                          Department KPI Achievement Rings
                        </h4>
                        <p className="text-[11px] text-slate-500">
                          Radial progress relative to corporate targets
                        </p>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 font-bold">
                        RadialBar
                      </span>
                    </div>

                    <div className="relative w-full h-72 flex items-center justify-center">
                      <ResponsiveContainer width="100%" height="100%">
                        <RadialBarChart
                          cx="50%"
                          cy="50%"
                          innerRadius="25%"
                          outerRadius="100%"
                          barSize={12}
                          data={deptAppraisalAnalytics.deptList}
                          startAngle={90}
                          endAngle={-270}
                        >
                          <PolarAngleAxis
                            type="number"
                            domain={[85, 115]}
                            angleAxisId={0}
                            tick={false}
                          />
                          <RadialBar
                            background={{ fill: '#e2e8f0' }}
                            dataKey="achievement"
                            cornerRadius={6}
                          >
                            {deptAppraisalAnalytics.deptList.map((entry, index) => (
                              <Cell key={`radial-${entry.id || index}`} fill={entry.fill} />
                            ))}
                          </RadialBar>
                          <Tooltip
                            content={({ active, payload }) => {
                              if (active && payload && payload.length) {
                                const d = payload[0].payload;
                                return (
                                  <div className="bg-slate-900 text-white p-2.5 rounded-xl shadow-xl text-xs space-y-1">
                                    <p className="font-bold text-sky-400">{d.name}</p>
                                    <p className="text-emerald-400 font-mono">{d.achievement}% Target Achieved</p>
                                    <p className="text-slate-300 text-[11px]">Score: {d.avgScore} / 5.0</p>
                                  </div>
                                );
                              }
                              return null;
                            }}
                          />
                        </RadialBarChart>
                      </ResponsiveContainer>

                      {/* Central Readout */}
                      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                        <div className="text-center bg-white/95 backdrop-blur-xs p-2.5 rounded-2xl border border-slate-200/90 shadow-xs max-w-[120px]">
                          <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider block">
                            Average
                          </span>
                          <div className="text-base font-black text-slate-900">
                            {deptAppraisalAnalytics.avgOverallAchievement}%
                          </div>
                          <span className="text-[9px] text-emerald-600 font-bold block mt-0.5">
                            Target Achieved
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-500">
                    <span className="flex items-center gap-1 font-semibold text-emerald-700">
                      <span className="w-2 h-2 rounded-full bg-emerald-500" /> ≥ 100% Exceeded
                    </span>
                    <span className="flex items-center gap-1 font-semibold text-sky-700">
                      <span className="w-2 h-2 rounded-full bg-sky-600" /> Standard Target
                    </span>
                  </div>
                </div>
              </div>

              {/* Department Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                {deptAppraisalAnalytics.deptList.map(item => (
                  <div key={item.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <h5 className="font-bold text-xs text-slate-900 truncate">{item.name}</h5>
                      <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-emerald-100 text-emerald-800">
                        {item.achievement}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span>Avg: <strong className="text-slate-800">{item.avgScore}/5.0</strong></span>
                      <span>Staff: <strong className="text-slate-800">{item.count}</strong></span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-sky-600 rounded-full"
                        style={{ width: `${Math.min(100, (item.avgScore / 5.0) * 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Table Mode */}
          {scorecardViewMode === 'table' && (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="py-2.5 px-4">Employee</th>
                    <th className="py-2.5 px-4">Department</th>
                    <th className="py-2.5 px-4">Cycle Month</th>
                    <th className="py-2.5 px-4">Self Rating</th>
                    <th className="py-2.5 px-4">Manager Rating</th>
                    <th className="py-2.5 px-4">Final Composite</th>
                    <th className="py-2.5 px-4">Grade</th>
                    <th className="py-2.5 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {monthlyKraEvaluations.map(ev => (
                    <tr key={ev.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-4 font-bold text-slate-900">{ev.employeeName}</td>
                      <td className="py-2.5 px-4">{ev.department}</td>
                      <td className="py-2.5 px-4 font-mono">{ev.month}</td>
                      <td className="py-2.5 px-4 font-mono text-sky-700">{ev.totalSelfScore} / 5.0</td>
                      <td className="py-2.5 px-4 font-mono text-indigo-700">{ev.totalManagerScore || '--'}</td>
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">
                        {ev.finalHrScore ? `${ev.finalHrScore} / 5.0` : '--'}
                      </td>
                      <td className="py-2.5 px-4">
                        {ev.finalGrade ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 font-mono">
                            {ev.finalGrade}
                          </span>
                        ) : (
                          <span className="text-slate-400">In Review</span>
                        )}
                      </td>
                      <td className="py-2.5 px-4">
                        <span className="text-[11px] font-semibold text-slate-600">
                          {ev.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Modal: Add KRA Master */}
      {showAddKraModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Configure Fixed Corporate KRA</h3>
            <p className="text-xs text-slate-500 mb-4">Set target metric and weightage % for monthly appraisal</p>

            <form onSubmit={handleAddNewKraMaster} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">KRA Title *</label>
                <input
                  required
                  type="text"
                  value={newKraTitle}
                  onChange={e => setNewKraTitle(e.target.value)}
                  placeholder="e.g. Kaizen Quality Improvement PPM"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Goal Description</label>
                <textarea
                  rows={2}
                  value={newKraDesc}
                  onChange={e => setNewKraDesc(e.target.value)}
                  placeholder="Detailed explanation of expectation..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Target Metric *</label>
                <input
                  required
                  type="text"
                  value={newKraMetric}
                  onChange={e => setNewKraMetric(e.target.value)}
                  placeholder="e.g. Maintain defect ppm < 50 on finished goods"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Weightage Percentage (0 - 100%) *</label>
                <input
                  required
                  type="number"
                  min={5}
                  max={100}
                  value={newKraWeightage}
                  onChange={e => setNewKraWeightage(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono font-bold"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddKraModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl cursor-pointer"
                >
                  Save Fixed KRA
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

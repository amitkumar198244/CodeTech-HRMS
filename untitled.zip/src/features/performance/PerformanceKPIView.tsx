// RSTPL HRMS - Departmental Performance KPI Analytics View
// RS Technovisions XpertSkillCop
// Visualizes Departmental KPIs using Recharts to provide managers with a clear view of performance metrics

import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  RadialBarChart,
  RadialBar,
  LineChart,
  Line,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts';
import {
  Target,
  Award,
  TrendingUp,
  BarChart3,
  Building2,
  Users,
  CheckCircle2,
  AlertTriangle,
  ArrowUpRight,
  Filter,
  Download,
  Calendar,
  Layers,
  ChevronRight,
  Eye,
  Sliders,
  ShieldCheck,
  Star,
  Activity,
  Plus,
  RefreshCw,
  X,
  FileSpreadsheet,
  Compass,
  Sparkles,
  Brain,
  Info,
  SlidersHorizontal,
  Check,
  ChevronDown,
  MapPin,
  Boxes,
  RotateCcw,
  Tag,
  Gauge,
  LayoutGrid,
  ListFilter,
  ArrowDownUp,
} from 'lucide-react';
import {
  Employee,
  Department,
  Branch,
  UserRole,
  MonthlyKRAEvaluation,
  DepartmentKPI,
  DepartmentKPIMetric
} from '../../types/hrms';

interface PerformanceKPIViewProps {
  employees: Employee[];
  departments?: Department[];
  branches?: Branch[];
  monthlyKraEvaluations: MonthlyKRAEvaluation[];
  currentRole?: UserRole;
  currentEmployee?: Employee;
  onLogAudit: (action: any, module: string, details: string) => void;
  onNavigateToWorkflow?: (evalId?: string) => void;
}

// Predefined Branch Filter Options (matching enterprise organizational units)
export const BRANCH_FILTER_OPTIONS = [
  { id: 'br-hq', name: 'Corporate Tech Park (Pune HQ)', shortName: 'Pune HQ', city: 'Pune', state: 'Maharashtra', isHQ: true },
  { id: 'br-chakan', name: 'Chakan Manufacturing Plant I', shortName: 'Chakan Plant', city: 'Pune', state: 'Maharashtra', isHQ: false },
  { id: 'br-sanand', name: 'Sanand Automotive Components', shortName: 'Sanand Plant', city: 'Ahmedabad', state: 'Gujarat', isHQ: false },
];

// Predefined Department Clusters for cross-functional governance
export const CLUSTER_FILTER_OPTIONS = [
  {
    id: 'Operations & Manufacturing',
    label: 'Operations & Manufacturing',
    shortLabel: 'Operations',
    description: 'Line availability (OEE), maintenance & stamping output',
    color: '#0284c7', // Sky
    badgeClass: 'bg-sky-50 text-sky-800 border-sky-200',
  },
  {
    id: 'Engineering & Technology',
    label: 'Engineering & Technology',
    shortLabel: 'Engineering',
    description: 'Embedded firmware, ADMS sync & IT architecture',
    color: '#8b5cf6', // Purple
    badgeClass: 'bg-purple-50 text-purple-800 border-purple-200',
  },
  {
    id: 'Quality & Compliance',
    label: 'Quality & Compliance',
    shortLabel: 'Quality',
    description: 'First Pass Yield (FPY), defect PPM & ISO audits',
    color: '#10b981', // Emerald
    badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
  },
  {
    id: 'Supply Chain & Logistics',
    label: 'Supply Chain & Logistics',
    shortLabel: 'Supply Chain',
    description: 'Procurement costs, vendor SLAs & freight OTD',
    color: '#f59e0b', // Amber
    badgeClass: 'bg-amber-50 text-amber-800 border-amber-200',
  },
  {
    id: 'Corporate & Governance',
    label: 'Corporate & Governance',
    shortLabel: 'Corporate',
    description: 'HR, payroll reconciliation, IR compliance & finance',
    color: '#6366f1', // Indigo
    badgeClass: 'bg-indigo-50 text-indigo-800 border-indigo-200',
  },
];

// Initial robust dataset for Departmental KPIs across plant & corporate units
export const INITIAL_DEPARTMENT_KPIS: DepartmentKPI[] = [
  {
    id: 'kpi-dept-eng',
    departmentId: 'dept-eng',
    departmentName: 'Engineering & R&D',
    departmentCode: 'ENG',
    branchId: 'br-hq',
    branchName: 'Corporate Tech Park (Pune HQ)',
    cluster: 'Engineering & Technology',
    managerName: 'Rajesh Patil (Head of Engineering)',
    managerEmail: 'rajesh.patil@rstpl.in',
    period: 'October 2026',
    targetScore: 4.5,
    actualScore: 4.78,
    achievementRate: 106.2,
    slaComplianceRate: 98.4,
    qualityPassRate: 99.5,
    onTimeDeliveryRate: 97.2,
    employeeCount: 4,
    completedEvaluations: 4,
    pendingEvaluations: 0,
    gradeDistribution: {
      aPlus: 2,
      a: 2,
      b: 0,
      c: 0,
      needsImprovement: 0,
    },
    metrics: [
      {
        id: 'm-eng-1',
        metricName: 'Firmware & ADMS Socket Uptime',
        target: '>= 98.0%',
        actual: '99.2%',
        achievedPercent: 101.2,
        weightage: 35,
        category: 'Operations',
        status: 'Exceeded',
      },
      {
        id: 'm-eng-2',
        metricName: 'Biometric Algorithm Synchronization',
        target: '100% SLA',
        actual: '99.8%',
        achievedPercent: 99.8,
        weightage: 35,
        category: 'Quality',
        status: 'On Track',
      },
      {
        id: 'm-eng-3',
        metricName: 'Shopfloor Defect PPM in Release',
        target: '< 50 PPM',
        actual: '12 PPM',
        achievedPercent: 120.0,
        weightage: 30,
        category: 'Quality',
        status: 'Exceeded',
      },
    ],
    monthlyTrend: [
      { month: 'Jul 2026', target: 4.5, actual: 4.45, achievement: 98.8 },
      { month: 'Aug 2026', target: 4.5, actual: 4.60, achievement: 102.2 },
      { month: 'Sep 2026', target: 4.5, actual: 4.70, achievement: 104.4 },
      { month: 'Oct 2026', target: 4.5, actual: 4.78, achievement: 106.2 },
    ],
  },
  {
    id: 'kpi-dept-prod',
    departmentId: 'dept-prod',
    departmentName: 'Production & Manufacturing',
    departmentCode: 'PROD',
    branchId: 'br-chakan',
    branchName: 'Chakan Manufacturing Plant I',
    cluster: 'Operations & Manufacturing',
    managerName: 'Rajesh Patil (Plant Operations Head)',
    managerEmail: 'rajesh.patil@rstpl.in',
    period: 'October 2026',
    targetScore: 4.4,
    actualScore: 4.55,
    achievementRate: 103.4,
    slaComplianceRate: 95.8,
    qualityPassRate: 97.8,
    onTimeDeliveryRate: 94.6,
    employeeCount: 6,
    completedEvaluations: 5,
    pendingEvaluations: 1,
    gradeDistribution: {
      aPlus: 1,
      a: 4,
      b: 1,
      c: 0,
      needsImprovement: 0,
    },
    metrics: [
      {
        id: 'm-prod-1',
        metricName: 'Machine Line Availability (OEE)',
        target: '>= 95.0%',
        actual: '97.4%',
        achievedPercent: 102.5,
        weightage: 40,
        category: 'Operations',
        status: 'Exceeded',
      },
      {
        id: 'm-prod-2',
        metricName: 'Shift Turnstile Punctuality Rate',
        target: '>= 96.0%',
        actual: '95.2%',
        achievedPercent: 99.1,
        weightage: 30,
        category: 'Punctuality',
        status: 'On Track',
      },
      {
        id: 'm-prod-3',
        metricName: 'Kaizen 5S Improvements Logged',
        target: '>= 10 / mo',
        actual: '14 Logged',
        achievedPercent: 140.0,
        weightage: 30,
        category: 'Innovation',
        status: 'Exceeded',
      },
    ],
    monthlyTrend: [
      { month: 'Jul 2026', target: 4.4, actual: 4.30, achievement: 97.7 },
      { month: 'Aug 2026', target: 4.4, actual: 4.42, achievement: 100.4 },
      { month: 'Sep 2026', target: 4.4, actual: 4.50, achievement: 102.2 },
      { month: 'Oct 2026', target: 4.4, actual: 4.55, achievement: 103.4 },
    ],
  },
  {
    id: 'kpi-dept-qa',
    departmentId: 'dept-qa',
    departmentName: 'Quality Assurance & Audit',
    departmentCode: 'QA',
    branchId: 'br-chakan',
    branchName: 'Chakan Manufacturing Plant I',
    cluster: 'Quality & Compliance',
    managerName: 'Kavita Menon (QA Director)',
    managerEmail: 'kavita.menon@rstpl.in',
    period: 'October 2026',
    targetScore: 4.6,
    actualScore: 4.68,
    achievementRate: 101.7,
    slaComplianceRate: 99.0,
    qualityPassRate: 99.6,
    onTimeDeliveryRate: 98.0,
    employeeCount: 3,
    completedEvaluations: 3,
    pendingEvaluations: 0,
    gradeDistribution: {
      aPlus: 2,
      a: 1,
      b: 0,
      c: 0,
      needsImprovement: 0,
    },
    metrics: [
      {
        id: 'm-qa-1',
        metricName: 'First Pass Yield (FPY)',
        target: '>= 99.0%',
        actual: '99.4%',
        achievedPercent: 100.4,
        weightage: 40,
        category: 'Quality',
        status: 'Exceeded',
      },
      {
        id: 'm-qa-2',
        metricName: 'Supplier Component Audit Coverage',
        target: '100% audits',
        actual: '98.5%',
        achievedPercent: 98.5,
        weightage: 30,
        category: 'Operations',
        status: 'On Track',
      },
      {
        id: 'm-qa-3',
        metricName: 'Customer Complaints (Escalated)',
        target: '0 cases',
        actual: '0 cases',
        achievedPercent: 100.0,
        weightage: 30,
        category: 'Quality',
        status: 'Exceeded',
      },
    ],
    monthlyTrend: [
      { month: 'Jul 2026', target: 4.6, actual: 4.55, achievement: 98.9 },
      { month: 'Aug 2026', target: 4.6, actual: 4.60, achievement: 100.0 },
      { month: 'Sep 2026', target: 4.6, actual: 4.64, achievement: 100.8 },
      { month: 'Oct 2026', target: 4.6, actual: 4.68, achievement: 101.7 },
    ],
  },
  {
    id: 'kpi-dept-scm',
    departmentId: 'dept-scm',
    departmentName: 'Purchase & Supply Chain',
    departmentCode: 'SCM',
    branchId: 'br-sanand',
    branchName: 'Sanand Automotive Components',
    cluster: 'Supply Chain & Logistics',
    managerName: 'Sanjay Deshmukh (SCM Head)',
    managerEmail: 'sanjay.d@rstpl.in',
    period: 'October 2026',
    targetScore: 4.3,
    actualScore: 4.22,
    achievementRate: 98.1,
    slaComplianceRate: 92.4,
    qualityPassRate: 96.0,
    onTimeDeliveryRate: 91.5,
    employeeCount: 3,
    completedEvaluations: 2,
    pendingEvaluations: 1,
    gradeDistribution: {
      aPlus: 0,
      a: 2,
      b: 1,
      c: 0,
      needsImprovement: 0,
    },
    metrics: [
      {
        id: 'm-scm-1',
        metricName: 'Raw Material Delivery On-Time (OTD)',
        target: '>= 95.0%',
        actual: '91.8%',
        achievedPercent: 96.6,
        weightage: 40,
        category: 'Operations',
        status: 'Needs Attention',
      },
      {
        id: 'm-scm-2',
        metricName: 'Procurement Cost Reduction vs Budget',
        target: '>= 3.0%',
        actual: '2.8%',
        achievedPercent: 93.3,
        weightage: 35,
        category: 'Financial',
        status: 'Needs Attention',
      },
      {
        id: 'm-scm-3',
        metricName: 'Vendor Compliance & SLA Score',
        target: '>= 90.0%',
        actual: '93.5%',
        achievedPercent: 103.8,
        weightage: 25,
        category: 'Quality',
        status: 'Exceeded',
      },
    ],
    monthlyTrend: [
      { month: 'Jul 2026', target: 4.3, actual: 4.10, achievement: 95.3 },
      { month: 'Aug 2026', target: 4.3, actual: 4.18, achievement: 97.2 },
      { month: 'Sep 2026', target: 4.3, actual: 4.25, achievement: 98.8 },
      { month: 'Oct 2026', target: 4.3, actual: 4.22, achievement: 98.1 },
    ],
  },
  {
    id: 'kpi-dept-fin',
    departmentId: 'dept-fin',
    departmentName: 'Finance & Accounts',
    departmentCode: 'FIN',
    branchId: 'br-hq',
    branchName: 'Corporate Tech Park (Pune HQ)',
    cluster: 'Corporate & Governance',
    managerName: 'Kavita Menon (Finance Controller)',
    managerEmail: 'kavita.menon@rstpl.in',
    period: 'October 2026',
    targetScore: 4.5,
    actualScore: 4.62,
    achievementRate: 102.6,
    slaComplianceRate: 99.2,
    qualityPassRate: 100.0,
    onTimeDeliveryRate: 98.5,
    employeeCount: 3,
    completedEvaluations: 3,
    pendingEvaluations: 0,
    gradeDistribution: {
      aPlus: 1,
      a: 2,
      b: 0,
      c: 0,
      needsImprovement: 0,
    },
    metrics: [
      {
        id: 'm-fin-1',
        metricName: 'Monthly Payroll & Disbursal Reconciliation',
        target: '100% on 1st',
        actual: '100% on 1st',
        achievedPercent: 100.0,
        weightage: 40,
        category: 'Financial',
        status: 'Exceeded',
      },
      {
        id: 'm-fin-2',
        metricName: 'Statutory Compliance (PF/ESIC/PT)',
        target: '0 delay days',
        actual: '0 delay days',
        achievedPercent: 100.0,
        weightage: 35,
        category: 'Quality',
        status: 'Exceeded',
      },
      {
        id: 'm-fin-3',
        metricName: 'Vendor Payment Cycle SLA',
        target: '< 30 days',
        actual: '27.4 days',
        achievedPercent: 108.6,
        weightage: 25,
        category: 'Operations',
        status: 'Exceeded',
      },
    ],
    monthlyTrend: [
      { month: 'Jul 2026', target: 4.5, actual: 4.48, achievement: 99.5 },
      { month: 'Aug 2026', target: 4.5, actual: 4.52, achievement: 100.4 },
      { month: 'Sep 2026', target: 4.5, actual: 4.58, achievement: 101.7 },
      { month: 'Oct 2026', target: 4.5, actual: 4.62, achievement: 102.6 },
    ],
  },
  {
    id: 'kpi-dept-hr',
    departmentId: 'dept-hr',
    departmentName: 'Human Resources & IR',
    departmentCode: 'HR',
    branchId: 'br-hq',
    branchName: 'Corporate Tech Park (Pune HQ)',
    cluster: 'Corporate & Governance',
    managerName: 'Amit Sharma (VP HR & IR)',
    managerEmail: 'amit.sharma@rstpl.in',
    period: 'October 2026',
    targetScore: 4.5,
    actualScore: 4.70,
    achievementRate: 104.4,
    slaComplianceRate: 97.6,
    qualityPassRate: 98.8,
    onTimeDeliveryRate: 96.8,
    employeeCount: 3,
    completedEvaluations: 3,
    pendingEvaluations: 0,
    gradeDistribution: {
      aPlus: 1,
      a: 2,
      b: 0,
      c: 0,
      needsImprovement: 0,
    },
    metrics: [
      {
        id: 'm-hr-1',
        metricName: 'KRA 48h SLA Escalation Closure Rate',
        target: '>= 95.0%',
        actual: '98.2%',
        achievedPercent: 103.3,
        weightage: 35,
        category: 'Operations',
        status: 'Exceeded',
      },
      {
        id: 'm-hr-2',
        metricName: 'Plant Shift Attendance Dispute Resolution',
        target: '< 24 Hours',
        actual: '14.5 Hours',
        achievedPercent: 139.6,
        weightage: 35,
        category: 'Punctuality',
        status: 'Exceeded',
      },
      {
        id: 'm-hr-3',
        metricName: 'Mandatory Industrial Safety Training Hours',
        target: '>= 40 hrs / batch',
        actual: '42 hrs',
        achievedPercent: 105.0,
        weightage: 30,
        category: 'Quality',
        status: 'Exceeded',
      },
    ],
    monthlyTrend: [
      { month: 'Jul 2026', target: 4.5, actual: 4.50, achievement: 100.0 },
      { month: 'Aug 2026', target: 4.5, actual: 4.58, achievement: 101.7 },
      { month: 'Sep 2026', target: 4.5, actual: 4.65, achievement: 103.3 },
      { month: 'Oct 2026', target: 4.5, actual: 4.70, achievement: 104.4 },
    ],
  },
  {
    id: 'kpi-dept-maint',
    departmentId: 'dept-maint',
    departmentName: 'Plant Maintenance & Tooling',
    departmentCode: 'MAINT',
    branchId: 'br-chakan',
    branchName: 'Chakan Manufacturing Plant I',
    cluster: 'Operations & Manufacturing',
    managerName: 'Vikram Singhania (Tooling Head)',
    managerEmail: 'vikram.s@rstpl.in',
    period: 'October 2026',
    targetScore: 4.4,
    actualScore: 4.52,
    achievementRate: 102.7,
    slaComplianceRate: 96.5,
    qualityPassRate: 98.2,
    onTimeDeliveryRate: 95.0,
    employeeCount: 4,
    completedEvaluations: 4,
    pendingEvaluations: 0,
    gradeDistribution: {
      aPlus: 1,
      a: 2,
      b: 1,
      c: 0,
      needsImprovement: 0,
    },
    metrics: [
      {
        id: 'm-maint-1',
        metricName: 'Preventive Maintenance SLA Completion',
        target: '100% schedules',
        actual: '98.5%',
        achievedPercent: 98.5,
        weightage: 40,
        category: 'Operations',
        status: 'On Track',
      },
      {
        id: 'm-maint-2',
        metricName: 'Mean Time to Repair (MTTR)',
        target: '< 45 Mins',
        actual: '38.2 Mins',
        achievedPercent: 115.1,
        weightage: 35,
        category: 'Operations',
        status: 'Exceeded',
      },
      {
        id: 'm-maint-3',
        metricName: 'Safety Incident Free Man-Hours',
        target: '100% Zero LTI',
        actual: '100% Zero LTI',
        achievedPercent: 100.0,
        weightage: 25,
        category: 'Quality',
        status: 'Exceeded',
      },
    ],
    monthlyTrend: [
      { month: 'Jul 2026', target: 4.4, actual: 4.35, achievement: 98.9 },
      { month: 'Aug 2026', target: 4.4, actual: 4.40, achievement: 100.0 },
      { month: 'Sep 2026', target: 4.4, actual: 4.48, achievement: 101.8 },
      { month: 'Oct 2026', target: 4.4, actual: 4.52, achievement: 102.7 },
    ],
  },
  {
    id: 'kpi-dept-log',
    departmentId: 'dept-log',
    departmentName: 'Logistics & Warehousing Depot',
    departmentCode: 'LOG',
    branchId: 'br-sanand',
    branchName: 'Sanand Automotive Components',
    cluster: 'Supply Chain & Logistics',
    managerName: 'Sanjay Deshmukh (SCM & Logistics)',
    managerEmail: 'sanjay.d@rstpl.in',
    period: 'October 2026',
    targetScore: 4.3,
    actualScore: 4.38,
    achievementRate: 101.9,
    slaComplianceRate: 95.2,
    qualityPassRate: 97.4,
    onTimeDeliveryRate: 96.0,
    employeeCount: 3,
    completedEvaluations: 3,
    pendingEvaluations: 0,
    gradeDistribution: {
      aPlus: 1,
      a: 1,
      b: 1,
      c: 0,
      needsImprovement: 0,
    },
    metrics: [
      {
        id: 'm-log-1',
        metricName: 'Finished Goods Dispatch On-Time SLA',
        target: '>= 95.0%',
        actual: '96.2%',
        achievedPercent: 101.3,
        weightage: 40,
        category: 'Operations',
        status: 'Exceeded',
      },
      {
        id: 'm-log-2',
        metricName: 'Warehouse Inventory Accuracy Index',
        target: '>= 99.0%',
        actual: '99.4%',
        achievedPercent: 100.4,
        weightage: 35,
        category: 'Quality',
        status: 'Exceeded',
      },
      {
        id: 'm-log-3',
        metricName: 'Transit Damage & Demurrage Claims',
        target: '< 0.5%',
        actual: '0.2%',
        achievedPercent: 150.0,
        weightage: 25,
        category: 'Financial',
        status: 'Exceeded',
      },
    ],
    monthlyTrend: [
      { month: 'Jul 2026', target: 4.3, actual: 4.20, achievement: 97.7 },
      { month: 'Aug 2026', target: 4.3, actual: 4.28, achievement: 99.5 },
      { month: 'Sep 2026', target: 4.3, actual: 4.34, achievement: 100.9 },
      { month: 'Oct 2026', target: 4.3, actual: 4.38, achievement: 101.9 },
    ],
  },
];

// Grade distribution pie chart colors
const GRADE_COLORS: Record<string, string> = {
  'A+ (Outstanding)': '#0284c7', // Sky-600
  'A (Exceeds Target)': '#10b981', // Emerald-500
  'B (Meets Target)': '#f59e0b', // Amber-500
  'C (Needs Improvement)': '#ef4444', // Red-500
};

export const PerformanceKPIView: React.FC<PerformanceKPIViewProps> = ({
  employees,
  departments = [],
  branches = [],
  monthlyKraEvaluations = [],
  currentRole = 'admin',
  currentEmployee,
  onLogAudit,
  onNavigateToWorkflow,
}) => {
  const [selectedDeptId, setSelectedDeptId] = useState<string>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('October 2026');
  const [metricCategoryFilter, setMetricCategoryFilter] = useState<string>('all');
  const [activeDrillDownDept, setActiveDrillDownDept] = useState<DepartmentKPI | null>(null);
  const [showAddTargetModal, setShowAddTargetModal] = useState(false);
  const [kpiList, setKpiList] = useState<DepartmentKPI[]>(INITIAL_DEPARTMENT_KPIS);
  const [showPredictiveForecast, setShowPredictiveForecast] = useState<boolean>(true);
  const [forecastScenario, setForecastScenario] = useState<'baseline' | 'optimistic' | 'conservative'>('baseline');
  const [exportSuccessMessage, setExportSuccessMessage] = useState<string | null>(null);

  // Interactive View Controls for Department-Wise KPI Achievements Breakdown
  const [breakdownViewMode, setBreakdownViewMode] = useState<'charts' | 'split' | 'table'>('charts');
  const [achievementSort, setAchievementSort] = useState<'desc' | 'asc' | 'alpha' | 'headcount'>('desc');
  const [achievementStatusFilter, setAchievementStatusFilter] = useState<'all' | 'exceeded' | 'lagging'>('all');
  const [activeChartMetric, setActiveChartMetric] = useState<'achievement' | 'score'>('achievement');
  const [hoveredDeptCode, setHoveredDeptCode] = useState<string | null>(null);

  // Interactive Multi-select filter states for Branches & Department Clusters
  const [selectedBranchIds, setSelectedBranchIds] = useState<string[]>([]);
  const [selectedClusterIds, setSelectedClusterIds] = useState<string[]>([]);
  const [branchDropdownOpen, setBranchDropdownOpen] = useState(false);
  const [clusterDropdownOpen, setClusterDropdownOpen] = useState(false);
  const [branchSearch, setBranchSearch] = useState('');
  const [clusterSearch, setClusterSearch] = useState('');

  // Form states for adding custom target
  const [targetDeptId, setTargetDeptId] = useState<string>('kpi-dept-prod');
  const [targetMetricName, setTargetMetricName] = useState<string>('');
  const [targetGoal, setTargetGoal] = useState<string>('');
  const [targetWeightage, setTargetWeightage] = useState<number>(30);
  const [targetCategory, setTargetCategory] = useState<'Operations' | 'Quality' | 'Punctuality' | 'Financial' | 'Innovation'>('Operations');

  // Merge prop branches with predefined branch filter options
  const availableBranches = useMemo(() => {
    const list = [...BRANCH_FILTER_OPTIONS];
    if (branches && branches.length > 0) {
      branches.forEach(b => {
        if (!list.some(item => item.id === b.id || item.name.toLowerCase() === b.name.toLowerCase())) {
          list.push({
            id: b.id,
            name: b.name,
            shortName: b.code || b.name,
            city: b.city || 'Pune',
            state: b.state || 'Maharashtra',
            isHQ: b.isHeadquarters || false,
          });
        }
      });
    }
    return list;
  }, [branches]);

  // Count of departments per branch
  const branchCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    kpiList.forEach(k => {
      if (k.branchId) {
        counts[k.branchId] = (counts[k.branchId] || 0) + 1;
      }
    });
    return counts;
  }, [kpiList]);

  // Count of departments per cluster
  const clusterCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    kpiList.forEach(k => {
      if (k.cluster) {
        counts[k.cluster] = (counts[k.cluster] || 0) + 1;
      }
    });
    return counts;
  }, [kpiList]);

  // Filtered department KPIs considering Department selection + Multi-select Branches + Multi-select Clusters
  const filteredKPIs = useMemo(() => {
    return kpiList.filter(k => {
      // 1. Department dropdown filter
      if (selectedDeptId !== 'all') {
        if (k.id !== selectedDeptId && k.departmentId !== selectedDeptId) {
          return false;
        }
      }

      // 2. Multi-select Branch filter (empty array means all branches included)
      if (selectedBranchIds.length > 0) {
        if (!k.branchId || !selectedBranchIds.includes(k.branchId)) {
          return false;
        }
      }

      // 3. Multi-select Cluster filter (empty array means all clusters included)
      if (selectedClusterIds.length > 0) {
        if (!k.cluster || !selectedClusterIds.includes(k.cluster)) {
          return false;
        }
      }

      return true;
    });
  }, [kpiList, selectedDeptId, selectedBranchIds, selectedClusterIds]);

  // Multi-select toggle helpers
  const toggleBranchFilter = (branchId: string) => {
    setSelectedBranchIds(prev =>
      prev.includes(branchId) ? prev.filter(id => id !== branchId) : [...prev, branchId]
    );
  };

  const selectAllBranches = () => {
    setSelectedBranchIds(availableBranches.map(b => b.id));
  };

  const clearBranchFilters = () => {
    setSelectedBranchIds([]);
  };

  const toggleClusterFilter = (clusterId: string) => {
    setSelectedClusterIds(prev =>
      prev.includes(clusterId) ? prev.filter(id => id !== clusterId) : [...prev, clusterId]
    );
  };

  const selectAllClusters = () => {
    setSelectedClusterIds(CLUSTER_FILTER_OPTIONS.map(c => c.id));
  };

  const clearClusterFilters = () => {
    setSelectedClusterIds([]);
  };

  const resetAllFilters = () => {
    setSelectedDeptId('all');
    setSelectedBranchIds([]);
    setSelectedClusterIds([]);
    setBranchSearch('');
    setClusterSearch('');
  };

  // Aggregate stats across filtered departments
  const stats = useMemo(() => {
    if (filteredKPIs.length === 0) {
      return {
        avgTarget: 4.5,
        avgActual: 4.6,
        avgAchievement: 102.2,
        avgSla: 96.5,
        totalHeadcount: 0,
        totalCompleted: 0,
        totalPending: 0,
        topDepartment: 'N/A',
      };
    }

    const totalActual = filteredKPIs.reduce((acc, curr) => acc + curr.actualScore, 0);
    const totalTarget = filteredKPIs.reduce((acc, curr) => acc + curr.targetScore, 0);
    const totalAch = filteredKPIs.reduce((acc, curr) => acc + curr.achievementRate, 0);
    const totalSla = filteredKPIs.reduce((acc, curr) => acc + curr.slaComplianceRate, 0);
    const headcount = filteredKPIs.reduce((acc, curr) => acc + curr.employeeCount, 0);
    const completed = filteredKPIs.reduce((acc, curr) => acc + curr.completedEvaluations, 0);
    const pending = filteredKPIs.reduce((acc, curr) => acc + curr.pendingEvaluations, 0);

    const sortedByAch = [...filteredKPIs].sort((a, b) => b.achievementRate - a.achievementRate);
    const top = sortedByAch[0];

    return {
      avgTarget: Number((totalTarget / filteredKPIs.length).toFixed(2)),
      avgActual: Number((totalActual / filteredKPIs.length).toFixed(2)),
      avgAchievement: Number((totalAch / filteredKPIs.length).toFixed(1)),
      avgSla: Number((totalSla / filteredKPIs.length).toFixed(1)),
      totalHeadcount: headcount,
      totalCompleted: completed,
      totalPending: pending,
      topDepartment: top ? `${top.departmentName} (${top.achievementRate}%)` : 'N/A',
    };
  }, [filteredKPIs]);

  // Data for Recharts Bar Chart: Department Target vs Actual
  const barChartData = useMemo(() => {
    return filteredKPIs.map(k => ({
      name: k.departmentCode,
      fullName: k.departmentName,
      Actual: k.actualScore,
      Target: k.targetScore,
      Achievement: k.achievementRate,
    }));
  }, [filteredKPIs]);

  // Filtered and sorted departments specifically for Department-wise KPI Achievement Visual Breakdown
  const processedAchievementKPIs = useMemo(() => {
    let list = [...filteredKPIs];

    // Filter by target achievement status
    if (achievementStatusFilter === 'exceeded') {
      list = list.filter(k => k.achievementRate >= 100);
    } else if (achievementStatusFilter === 'lagging') {
      list = list.filter(k => k.achievementRate < 100);
    }

    // Sort
    if (achievementSort === 'desc') {
      list.sort((a, b) => b.achievementRate - a.achievementRate);
    } else if (achievementSort === 'asc') {
      list.sort((a, b) => a.achievementRate - b.achievementRate);
    } else if (achievementSort === 'alpha') {
      list.sort((a, b) => a.departmentName.localeCompare(b.departmentName));
    } else if (achievementSort === 'headcount') {
      list.sort((a, b) => b.employeeCount - a.employeeCount);
    }

    return list;
  }, [filteredKPIs, achievementStatusFilter, achievementSort]);

  // Data for Interactive Radial Chart (RadialBarChart) of Department-wise KPI Achievements
  const departmentRadialData = useMemo(() => {
    return processedAchievementKPIs.map((k, index) => {
      let fill = '#10b981'; // Emerald >= 100%
      if (k.achievementRate < 90) fill = '#f43f5e'; // Rose < 90%
      else if (k.achievementRate < 95) fill = '#f59e0b'; // Amber 90-95%
      else if (k.achievementRate < 100) fill = '#0284c7'; // Sky 95-100%

      return {
        id: k.id,
        name: k.departmentName,
        code: k.departmentCode,
        achievement: k.achievementRate,
        actualScore: k.actualScore,
        targetScore: k.targetScore,
        manager: k.managerName,
        branch: k.branchName || 'Pune HQ',
        cluster: k.cluster || 'General',
        headcount: k.employeeCount,
        fill: fill,
      };
    });
  }, [processedAchievementKPIs]);

  // Data for Interactive Bar Chart of Department-wise KPI Achievements
  const departmentAchievementBarData = useMemo(() => {
    return processedAchievementKPIs.map(k => {
      let fill = '#10b981';
      if (k.achievementRate < 90) fill = '#f43f5e';
      else if (k.achievementRate < 95) fill = '#f59e0b';
      else if (k.achievementRate < 100) fill = '#0284c7';

      return {
        id: k.id,
        name: k.departmentCode,
        fullName: k.departmentName,
        achievement: k.achievementRate,
        actualScore: k.actualScore,
        targetScore: k.targetScore,
        manager: k.managerName,
        branch: k.branchName || 'Pune HQ',
        cluster: k.cluster || 'General',
        headcount: k.employeeCount,
        fill: fill,
      };
    });
  }, [processedAchievementKPIs]);

  // Active or hovered department details for center radial gauge display
  const centerGaugeDept = useMemo(() => {
    if (hoveredDeptCode) {
      return processedAchievementKPIs.find(k => k.departmentCode === hoveredDeptCode) || null;
    }
    return null;
  }, [hoveredDeptCode, processedAchievementKPIs]);

  // Data for Radar Chart: Multi-dimensional Pillars
  const radarChartData = useMemo(() => {
    const active = selectedDeptId === 'all' ? kpiList[0] : (filteredKPIs[0] || kpiList[0]);
    return [
      { pillar: 'Line / OEE Availability', score: Math.min(100, Math.round(active.actualScore * 20.8)), fullMark: 100 },
      { pillar: 'Quality & Low PPM', score: Math.round(active.qualityPassRate), fullMark: 100 },
      { pillar: 'Biometric Punctuality', score: Math.round(active.slaComplianceRate), fullMark: 100 },
      { pillar: 'On-Time Delivery (OTD)', score: Math.round(active.onTimeDeliveryRate), fullMark: 100 },
      { pillar: 'KRA SLA Execution', score: Math.round(active.achievementRate), fullMark: 100 },
      { pillar: 'Process Innovations', score: 92, fullMark: 100 },
    ];
  }, [selectedDeptId, filteredKPIs, kpiList]);

  // Data for Grade Bell Curve Pie Chart
  const gradePieData = useMemo(() => {
    let aPlus = 0;
    let a = 0;
    let b = 0;
    let c = 0;

    filteredKPIs.forEach(k => {
      aPlus += k.gradeDistribution.aPlus;
      a += k.gradeDistribution.a;
      b += k.gradeDistribution.b;
      c += k.gradeDistribution.c + (k.gradeDistribution.needsImprovement || 0);
    });

    return [
      { name: 'A+ (Outstanding)', value: aPlus || 1 },
      { name: 'A (Exceeds Target)', value: a || 1 },
      { name: 'B (Meets Target)', value: b || 0 },
      { name: 'C (Needs Improvement)', value: c || 0 },
    ].filter(item => item.value > 0);
  }, [filteredKPIs]);

  // Data for Monthly Trajectory Trend & Next Quarter Predictive Projection
  const { trendLineData, predictiveInsights } = useMemo(() => {
    const targetDept = selectedDeptId === 'all' ? kpiList[0] : (filteredKPIs[0] || kpiList[0]);
    const historical = targetDept?.monthlyTrend || [
      { month: 'Jul 2026', target: 4.5, actual: 4.45, achievement: 98.8 },
      { month: 'Aug 2026', target: 4.5, actual: 4.60, achievement: 102.2 },
      { month: 'Sep 2026', target: 4.5, actual: 4.70, achievement: 104.4 },
      { month: 'Oct 2026', target: 4.5, actual: 4.78, achievement: 106.2 },
    ];

    // Format historical points
    const formattedHistorical = historical.map((t, idx) => ({
      month: t.month,
      Actual: t.actual,
      Target: t.target,
      Projected: idx === historical.length - 1 ? t.actual : undefined, // Handover point connects smoothly
      LowerBound: undefined as number | undefined,
      UpperBound: undefined as number | undefined,
      AchievementPct: t.achievement,
      isProjected: false,
      confidence: 100,
    }));

    if (!showPredictiveForecast) {
      return {
        trendLineData: formattedHistorical,
        predictiveInsights: null,
      };
    }

    // Compute velocity / trajectory rate from historical points
    const lastActual = historical[historical.length - 1]?.actual || 4.7;
    const firstActual = historical[0]?.actual || 4.4;
    const historySteps = Math.max(1, historical.length - 1);
    const baseSlope = (lastActual - firstActual) / historySteps; // average monthly gain

    // Adjust slope according to scenario
    let adjustedSlope = baseSlope;
    let scenarioLabel = 'Baseline Linear Momentum';
    let riskDescription = 'Performance trajectory continues at current operational velocity.';
    let recommendation = 'Maintain current shift roster discipline and monthly preventive maintenance.';

    if (forecastScenario === 'optimistic') {
      adjustedSlope = baseSlope * 1.35 + 0.03;
      scenarioLabel = 'Optimistic / Accelerated Kaizen (+3.2% MoM)';
      riskDescription = 'Assumes zero unplanned plant line stoppages and accelerated Kaizen defect reduction.';
      recommendation = 'Expedite automation test suites and vendor pre-audits to capture maximum incentive upside.';
    } else if (forecastScenario === 'conservative') {
      adjustedSlope = Math.max(-0.02, baseSlope * 0.45 - 0.02);
      scenarioLabel = 'Conservative / Risk-Adjusted (-0.8% MoM)';
      riskDescription = 'Considers potential winter holiday shift absenteeism and seasonal equipment recalibration.';
      recommendation = 'Prepare backup buffer rosters and initiate early component procurement by Nov 20.';
    }

    // Next quarter months
    const projectedMonths = [
      { name: 'Nov 2026 (P)', step: 1, confidence: 95 },
      { name: 'Dec 2026 (P)', step: 2, confidence: 91 },
      { name: 'Jan 2027 (P)', step: 3, confidence: 87 },
    ];

    const projectedPoints = projectedMonths.map(p => {
      // Natural logarithmic dampening as score approaches 5.0 ceiling
      const headRoom = Math.max(0.05, 5.0 - lastActual);
      const rawProjected = lastActual + (adjustedSlope * p.step * (headRoom / 0.5));
      const projectedScore = Number(Math.min(4.98, Math.max(3.8, rawProjected)).toFixed(2));
      const margin = Number((0.05 + p.step * 0.02).toFixed(2));
      const lowerBound = Number((projectedScore - margin).toFixed(2));
      const upperBound = Number(Math.min(5.0, projectedScore + margin).toFixed(2));
      const targetScore = historical[historical.length - 1]?.target || 4.5;
      const projectedAchievement = Number(((projectedScore / targetScore) * 100).toFixed(1));

      return {
        month: p.name,
        Actual: undefined as number | undefined,
        Target: targetScore,
        Projected: projectedScore,
        LowerBound: lowerBound,
        UpperBound: upperBound,
        AchievementPct: projectedAchievement,
        isProjected: true,
        confidence: p.confidence,
      };
    });

    const combinedData = [...formattedHistorical, ...projectedPoints];

    const avgProjectedScore = Number(
      (projectedPoints.reduce((acc, curr) => acc + (curr.Projected || 0), 0) / projectedPoints.length).toFixed(2)
    );
    const avgProjectedAchievement = Number(
      (projectedPoints.reduce((acc, curr) => acc + (curr.AchievementPct || 0), 0) / projectedPoints.length).toFixed(1)
    );

    return {
      trendLineData: combinedData,
      predictiveInsights: {
        departmentName: targetDept?.departmentName || 'Organization Units',
        scenarioLabel,
        avgProjectedScore,
        avgProjectedAchievement,
        scoreDelta: Number((avgProjectedScore - lastActual).toFixed(2)),
        confidenceFit: '94.8% R²',
        riskDescription,
        recommendation,
        projectedMonths: projectedPoints,
      },
    };
  }, [selectedDeptId, filteredKPIs, kpiList, showPredictiveForecast, forecastScenario]);

  // Handle adding new custom KPI target
  const handleAddKPITarget = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetMetricName || !targetGoal) return;

    const newMetric: DepartmentKPIMetric = {
      id: `metric-${Date.now()}`,
      metricName: targetMetricName,
      target: targetGoal,
      actual: 'In Progress (Target Assigned)',
      achievedPercent: 100.0,
      weightage: targetWeightage,
      category: targetCategory,
      status: 'On Track',
    };

    setKpiList(prev =>
      prev.map(dept => {
        if (dept.id === targetDeptId || dept.departmentId === targetDeptId) {
          return {
            ...dept,
            metrics: [...dept.metrics, newMetric],
          };
        }
        return dept;
      })
    );

    setShowAddTargetModal(false);
    setTargetMetricName('');
    setTargetGoal('');
    onLogAudit('CREATE', 'PMS Department KPI', `Manager added new KPI target "${newMetric.metricName}" to department`);
  };

  // Export Department Performance Metrics to CSV for external reporting
  const handleExportToCSV = () => {
    try {
      const headers = [
        'Department Name',
        'Department Code',
        'Branch Location',
        'Department Cluster',
        'Reporting Manager',
        'Evaluation Period',
        'Target KRA Score (1-5)',
        'Actual KRA Score (1-5)',
        'Achievement Rate (%)',
        'SLA Compliance Rate (%)',
        'Quality Pass Rate (%)',
        'On-Time Delivery Rate (%)',
        'Active Headcount',
        'Completed Reviews',
        'Pending Reviews',
        'Grade A+ Count',
        'Grade A Count',
        'Grade B Count',
        'Grade C Count',
        'Deliverable 1 Title',
        'Deliverable 1 Target',
        'Deliverable 1 Actual',
        'Deliverable 1 Status',
        'Deliverable 2 Title',
        'Deliverable 2 Target',
        'Deliverable 2 Actual',
        'Deliverable 2 Status',
        'Next Qtr Forecast Horizon',
        'Next Qtr Projected Score',
        'Next Qtr Projected Ach (%)',
      ];

      const csvRows = filteredKPIs.map(dept => {
        const m1 = dept.metrics[0];
        const m2 = dept.metrics[1];
        const projScore = Number(Math.min(5.0, dept.actualScore + 0.08).toFixed(2));
        const projAch = Number(((projScore / dept.targetScore) * 100).toFixed(1));
        const branchLabel = dept.branchName || availableBranches.find(b => b.id === dept.branchId)?.name || 'Pune HQ';
        const clusterLabel = dept.cluster || 'General';

        return [
          `"${dept.departmentName.replace(/"/g, '""')}"`,
          `"${dept.departmentCode.replace(/"/g, '""')}"`,
          `"${branchLabel.replace(/"/g, '""')}"`,
          `"${clusterLabel.replace(/"/g, '""')}"`,
          `"${dept.managerName.replace(/"/g, '""')}"`,
          `"${dept.period}"`,
          dept.targetScore,
          dept.actualScore,
          `${dept.achievementRate}%`,
          `${dept.slaComplianceRate}%`,
          `${dept.qualityPassRate}%`,
          `${dept.onTimeDeliveryRate}%`,
          dept.employeeCount,
          dept.completedEvaluations,
          dept.pendingEvaluations,
          dept.gradeDistribution.aPlus,
          dept.gradeDistribution.a,
          dept.gradeDistribution.b,
          dept.gradeDistribution.c,
          m1 ? `"${m1.metricName.replace(/"/g, '""')}"` : '""',
          m1 ? `"${m1.target.replace(/"/g, '""')}"` : '""',
          m1 ? `"${m1.actual.replace(/"/g, '""')}"` : '""',
          m1 ? `"${m1.status}"` : '""',
          m2 ? `"${m2.metricName.replace(/"/g, '""')}"` : '""',
          m2 ? `"${m2.target.replace(/"/g, '""')}"` : '""',
          m2 ? `"${m2.actual.replace(/"/g, '""')}"` : '""',
          m2 ? `"${m2.status}"` : '""',
          `"Nov 2026 - Jan 2027"`,
          projScore,
          `${projAch}%`,
        ].join(',');
      });

      const csvContent = '\uFEFF' + [headers.join(','), ...csvRows].join('\r\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const branchTag = selectedBranchIds.length === 0 ? 'AllBranches' : `${selectedBranchIds.length}Branches`;
      const clusterTag = selectedClusterIds.length === 0 ? 'AllClusters' : `${selectedClusterIds.length}Clusters`;
      const filename = `RSTPL_Department_KPI_Report_${selectedDeptId !== 'all' ? selectedDeptId : 'All_Depts'}_${branchTag}_${clusterTag}_${selectedPeriod.replace(/\s+/g, '_')}.csv`;
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setExportSuccessMessage(`Exported ${filteredKPIs.length} department metric(s) to CSV (${filename})`);
      setTimeout(() => setExportSuccessMessage(null), 3500);

      onLogAudit(
        'EXPORT',
        'PMS Department KPI',
        `Manager exported ${filteredKPIs.length} departmental performance KPI metrics to CSV (${filename}) with filters (Branches: ${selectedBranchIds.length || 'All'}, Clusters: ${selectedClusterIds.length || 'All'})`
      );
    } catch (err) {
      console.error('Failed to export CSV:', err);
    }
  };

  // Subordinate employees list for active drill down modal
  const drillDownEmployees = useMemo(() => {
    if (!activeDrillDownDept) return [];
    return employees.filter(emp => {
      if (emp.departmentId === activeDrillDownDept.departmentId) return true;
      const deptObj = departments.find(d => d.id === emp.departmentId);
      if (deptObj && deptObj.code.toLowerCase() === activeDrillDownDept.departmentCode.toLowerCase()) return true;
      if (deptObj && deptObj.name.toLowerCase() === activeDrillDownDept.departmentName.toLowerCase()) return true;
      // Also match evaluations if assigned
      const hasEval = monthlyKraEvaluations.some(
        ev =>
          (ev.employeeId === emp.id || ev.employeeCode === emp.employeeCode) &&
          ev.department.toLowerCase().includes(activeDrillDownDept.departmentCode.toLowerCase())
      );
      return hasEval;
    });
  }, [activeDrillDownDept, employees, departments, monthlyKraEvaluations]);

  return (
    <div className="space-y-6">
      {/* Top Banner / Executive Controls */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <span className="p-2.5 rounded-xl bg-sky-50 border border-sky-100 text-sky-700">
              <BarChart3 className="w-6 h-6" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-slate-900 tracking-tight">
                  Departmental KPI & Performance Analytics
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-sky-100 text-sky-800">
                  Manager & HR BI
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Multi-metric visual analytics across plant operations, quality yields, biometric SLAs, and employee KRA distribution.
              </p>
            </div>
          </div>

          {/* Quick Filters */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Department Dropdown */}
            <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold">
              <Building2 className="w-4 h-4 text-slate-400" />
              <select
                aria-label="Filter by Department"
                value={selectedDeptId}
                onChange={e => setSelectedDeptId(e.target.value)}
                className="bg-transparent text-slate-800 font-bold focus:outline-none cursor-pointer"
              >
                <option value="all">All Departments ({kpiList.length})</option>
                {kpiList.map(dept => (
                  <option key={dept.id} value={dept.id}>
                    {dept.departmentName} ({dept.departmentCode})
                  </option>
                ))}
              </select>
            </div>

            {/* Period Selector */}
            <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold">
              <Calendar className="w-4 h-4 text-slate-400" />
              <select
                aria-label="Select Evaluation Period"
                value={selectedPeriod}
                onChange={e => setSelectedPeriod(e.target.value)}
                className="bg-transparent text-slate-800 font-bold focus:outline-none cursor-pointer"
              >
                <option value="October 2026">October 2026</option>
                <option value="September 2026">September 2026</option>
                <option value="Q3 2026">Q3 FY26 (Jul-Sep)</option>
                <option value="FY 2026-27 YTD">FY 2026-27 YTD</option>
              </select>
            </div>

            {/* Export to CSV Button */}
            <button
              onClick={handleExportToCSV}
              title="Download departmental performance metrics in CSV format for external Excel/ERP reporting"
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 hover:text-slate-900 border border-slate-200 text-xs font-bold transition shadow-2xs cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              Export to CSV
            </button>

            {/* Add Target / KPI Button */}
            {(currentRole === 'manager' || currentRole === 'hr_head' || currentRole === 'admin' || currentRole === 'super_admin') && (
              <button
                onClick={() => setShowAddTargetModal(true)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-bold transition shadow-xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Assign Department KPI
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Interactive Multi-Select Filters Panel for Branches & Department Clusters */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs space-y-3 relative">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="flex items-center gap-1.5 text-xs font-black text-slate-800 uppercase tracking-wider mr-1">
              <Filter className="w-3.5 h-3.5 text-sky-600" />
              <span>Multi-Select Filters:</span>
            </span>

            {/* Branch Multi-Select Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setBranchDropdownOpen(prev => !prev);
                  setClusterDropdownOpen(false);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition shadow-2xs cursor-pointer ${
                  selectedBranchIds.length > 0
                    ? 'bg-sky-50 border-sky-300 text-sky-900'
                    : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                }`}
              >
                <MapPin className="w-3.5 h-3.5 text-sky-600" />
                <span>Branches / Facilities</span>
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                    selectedBranchIds.length > 0
                      ? 'bg-sky-600 text-white'
                      : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {selectedBranchIds.length > 0 ? `${selectedBranchIds.length} Selected` : `All (${availableBranches.length})`}
                </span>
                <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${branchDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* Branch Dropdown Popover */}
              {branchDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-20"
                    onClick={() => setBranchDropdownOpen(false)}
                  />
                  <div className="absolute left-0 top-full mt-1.5 z-30 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 p-3 space-y-2 animate-in fade-in slide-in-from-top-1">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                        <MapPin className="w-3.5 h-3.5 text-sky-600" />
                        <span>Filter by Branch Facility</span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] font-semibold">
                        <button
                          type="button"
                          onClick={selectAllBranches}
                          className="text-sky-700 hover:text-sky-900 font-bold cursor-pointer"
                        >
                          Select All
                        </button>
                        <span className="text-slate-300">|</span>
                        <button
                          type="button"
                          onClick={clearBranchFilters}
                          className="text-slate-500 hover:text-slate-800 font-bold cursor-pointer"
                        >
                          Clear
                        </button>
                      </div>
                    </div>

                    {/* Branch Search */}
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Search branches..."
                        value={branchSearch}
                        onChange={e => setBranchSearch(e.target.value)}
                        className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-sky-500"
                      />
                    </div>

                    <div className="max-h-52 overflow-y-auto space-y-1 pt-1">
                      {availableBranches
                        .filter(b => b.name.toLowerCase().includes(branchSearch.toLowerCase()) || b.city.toLowerCase().includes(branchSearch.toLowerCase()))
                        .map(b => {
                          const isSelected = selectedBranchIds.includes(b.id);
                          const deptCount = branchCounts[b.id] || 0;
                          return (
                            <label
                              key={b.id}
                              onClick={() => toggleBranchFilter(b.id)}
                              className={`flex items-start gap-2.5 p-2 rounded-xl cursor-pointer text-xs transition ${
                                isSelected ? 'bg-sky-50/80 text-sky-950 font-bold' : 'hover:bg-slate-50 text-slate-700'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => {}} // handled by label onClick
                                className="mt-0.5 rounded text-sky-600 focus:ring-sky-500 cursor-pointer"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-1">
                                  <span className="truncate">{b.name}</span>
                                  {b.isHQ ? (
                                    <span className="px-1.5 py-0.2 rounded-md bg-sky-100 text-sky-800 text-[10px] shrink-0 font-bold">
                                      HQ
                                    </span>
                                  ) : (
                                    <span className="px-1.5 py-0.2 rounded-md bg-amber-100 text-amber-800 text-[10px] shrink-0 font-bold">
                                      Plant
                                    </span>
                                  )}
                                </div>
                                <div className="text-[10px] text-slate-400 mt-0.5 flex items-center justify-between">
                                  <span>{b.city}, {b.state}</span>
                                  <span>{deptCount} department{deptCount === 1 ? '' : 's'}</span>
                                </div>
                              </div>
                            </label>
                          );
                        })}
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                      <span>{selectedBranchIds.length === 0 ? 'All branches active' : `${selectedBranchIds.length} of ${availableBranches.length} active`}</span>
                      <button
                        type="button"
                        onClick={() => setBranchDropdownOpen(false)}
                        className="px-2.5 py-1 rounded-lg bg-sky-700 hover:bg-sky-800 text-white font-bold text-[11px] cursor-pointer"
                      >
                        Done
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Department Cluster Multi-Select Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setClusterDropdownOpen(prev => !prev);
                  setBranchDropdownOpen(false);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition shadow-2xs cursor-pointer ${
                  selectedClusterIds.length > 0
                    ? 'bg-purple-50 border-purple-300 text-purple-900'
                    : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-purple-600" />
                <span>Department Clusters</span>
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                    selectedClusterIds.length > 0
                      ? 'bg-purple-600 text-white'
                      : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {selectedClusterIds.length > 0 ? `${selectedClusterIds.length} Selected` : `All (${CLUSTER_FILTER_OPTIONS.length})`}
                </span>
                <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${clusterDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* Cluster Dropdown Popover */}
              {clusterDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-20"
                    onClick={() => setClusterDropdownOpen(false)}
                  />
                  <div className="absolute left-0 top-full mt-1.5 z-30 w-84 bg-white rounded-2xl shadow-xl border border-slate-200 p-3 space-y-2 animate-in fade-in slide-in-from-top-1">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                        <Layers className="w-3.5 h-3.5 text-purple-600" />
                        <span>Filter by Department Clusters</span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] font-semibold">
                        <button
                          type="button"
                          onClick={selectAllClusters}
                          className="text-purple-700 hover:text-purple-900 font-bold cursor-pointer"
                        >
                          Select All
                        </button>
                        <span className="text-slate-300">|</span>
                        <button
                          type="button"
                          onClick={clearClusterFilters}
                          className="text-slate-500 hover:text-slate-800 font-bold cursor-pointer"
                        >
                          Clear
                        </button>
                      </div>
                    </div>

                    {/* Cluster Search */}
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Search clusters..."
                        value={clusterSearch}
                        onChange={e => setClusterSearch(e.target.value)}
                        className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-purple-500"
                      />
                    </div>

                    <div className="max-h-56 overflow-y-auto space-y-1.5 pt-1">
                      {CLUSTER_FILTER_OPTIONS
                        .filter(c => c.label.toLowerCase().includes(clusterSearch.toLowerCase()) || c.description.toLowerCase().includes(clusterSearch.toLowerCase()))
                        .map(c => {
                          const isSelected = selectedClusterIds.includes(c.id);
                          const deptCount = clusterCounts[c.id] || 0;
                          return (
                            <label
                              key={c.id}
                              onClick={() => toggleClusterFilter(c.id)}
                              className={`flex items-start gap-2.5 p-2 rounded-xl cursor-pointer text-xs transition ${
                                isSelected ? 'bg-purple-50/80 text-purple-950 font-bold' : 'hover:bg-slate-50 text-slate-700'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => {}} // handled by label onClick
                                className="mt-0.5 rounded text-purple-600 focus:ring-purple-500 cursor-pointer"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-1">
                                  <span className="truncate font-semibold">{c.label}</span>
                                  <span
                                    className="w-2.5 h-2.5 rounded-full shrink-0"
                                    style={{ backgroundColor: c.color }}
                                  />
                                </div>
                                <div className="text-[10px] text-slate-400 mt-0.5">
                                  {c.description}
                                </div>
                                <div className="text-[10px] text-slate-500 mt-0.5 font-medium">
                                  {deptCount} department{deptCount === 1 ? '' : 's'} assigned
                                </div>
                              </div>
                            </label>
                          );
                        })}
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                      <span>{selectedClusterIds.length === 0 ? 'All clusters active' : `${selectedClusterIds.length} of ${CLUSTER_FILTER_OPTIONS.length} active`}</span>
                      <button
                        type="button"
                        onClick={() => setClusterDropdownOpen(false)}
                        className="px-2.5 py-1 rounded-lg bg-purple-700 hover:bg-purple-800 text-white font-bold text-[11px] cursor-pointer"
                      >
                        Done
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Quick Cluster Filter Pills */}
            <div className="hidden xl:flex items-center gap-1.5 pl-2 border-l border-slate-200">
              <span className="text-[11px] text-slate-400 font-semibold">Quick Clusters:</span>
              {CLUSTER_FILTER_OPTIONS.map(c => {
                const isSelected = selectedClusterIds.includes(c.id);
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => toggleClusterFilter(c.id)}
                    className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border transition cursor-pointer ${
                      isSelected
                        ? 'bg-purple-700 text-white border-purple-800 shadow-2xs'
                        : 'bg-white hover:bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    {c.shortLabel}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Filter Status Summary & Reset */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 font-medium">
              Showing <strong className="text-slate-900 font-black">{filteredKPIs.length}</strong> of{' '}
              <strong className="text-slate-700">{kpiList.length}</strong> departments
            </span>

            {(selectedBranchIds.length > 0 || selectedClusterIds.length > 0 || selectedDeptId !== 'all') && (
              <button
                type="button"
                onClick={resetAllFilters}
                className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition cursor-pointer"
                title="Reset all active filters"
              >
                <RotateCcw className="w-3 h-3 text-slate-500" />
                <span>Reset All</span>
              </button>
            )}
          </div>
        </div>

        {/* Active Filter Chips / Pills */}
        {(selectedBranchIds.length > 0 || selectedClusterIds.length > 0 || selectedDeptId !== 'all') && (
          <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-bold text-slate-400 mr-1 flex items-center gap-1">
              <Tag className="w-3 h-3" />
              Active Filters:
            </span>

            {/* Selected Branch Pills */}
            {selectedBranchIds.map(bId => {
              const b = availableBranches.find(item => item.id === bId);
              return (
                <span
                  key={bId}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-sky-50 text-sky-800 border border-sky-200"
                >
                  <MapPin className="w-3 h-3 text-sky-600" />
                  <span>{b?.shortName || b?.name || bId}</span>
                  <button
                    type="button"
                    onClick={() => toggleBranchFilter(bId)}
                    className="hover:text-sky-950 font-black ml-0.5 cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              );
            })}

            {/* Selected Cluster Pills */}
            {selectedClusterIds.map(cId => {
              const c = CLUSTER_FILTER_OPTIONS.find(item => item.id === cId);
              return (
                <span
                  key={cId}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-50 text-purple-800 border border-purple-200"
                >
                  <Layers className="w-3 h-3 text-purple-600" />
                  <span>{c?.shortLabel || cId}</span>
                  <button
                    type="button"
                    onClick={() => toggleClusterFilter(cId)}
                    className="hover:text-purple-950 font-black ml-0.5 cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              );
            })}

            {/* Department Pill */}
            {selectedDeptId !== 'all' && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                <Building2 className="w-3 h-3 text-amber-600" />
                <span>
                  Dept: {kpiList.find(k => k.id === selectedDeptId || k.departmentId === selectedDeptId)?.departmentCode || selectedDeptId}
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedDeptId('all')}
                  className="hover:text-amber-950 font-black ml-0.5 cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
          </div>
        )}
      </div>

      {/* Export Success Feedback Toast */}
      {exportSuccessMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-2.5 rounded-2xl text-xs font-semibold flex items-center justify-between shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{exportSuccessMessage}</span>
          </div>
          <button
            onClick={() => setExportSuccessMessage(null)}
            className="text-emerald-700 hover:text-emerald-950 font-bold ml-3 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* KPI Highlight Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Org Avg KRA Rating */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Avg KRA Score
            </span>
            <span className="p-2 rounded-xl bg-amber-50 text-amber-600">
              <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900">{stats.avgActual}</span>
            <span className="text-xs text-slate-400 font-semibold">/ 5.0 scale</span>
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-xs">
            <span className="inline-flex items-center text-emerald-600 font-bold">
              <ArrowUpRight className="w-3.5 h-3.5" />
              +{(stats.avgActual - stats.avgTarget).toFixed(2)}
            </span>
            <span className="text-slate-400">vs target ({stats.avgTarget})</span>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-amber-400" />
        </div>

        {/* Card 2: Target Achievement % */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Target Achievement
            </span>
            <span className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-emerald-700">{stats.avgAchievement}%</span>
            <span className="text-xs text-slate-400 font-semibold">overall rate</span>
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Target benchmark met across units</span>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-emerald-500" />
        </div>

        {/* Card 3: SLA & Punctuality Compliance */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              SLA & Turnstile SLA
            </span>
            <span className="p-2 rounded-xl bg-sky-50 text-sky-600">
              <ShieldCheck className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-sky-800">{stats.avgSla}%</span>
            <span className="text-xs text-slate-400 font-semibold">48h SLA met</span>
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500">
            <Activity className="w-3.5 h-3.5 text-sky-600" />
            <span>{stats.totalCompleted} evals reviewed & signed</span>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-sky-600" />
        </div>

        {/* Card 4: Top Performing Department */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Top Department
            </span>
            <span className="p-2 rounded-xl bg-purple-50 text-purple-600">
              <Award className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3">
            <span className="text-lg font-black text-slate-900 block truncate">
              {stats.topDepartment.split(' (')[0]}
            </span>
            <span className="text-xs text-purple-700 font-bold">
              {stats.topDepartment.includes('(') ? stats.topDepartment.split(' (')[1].replace(')', '') : 'Leader'}
            </span>
          </div>
          <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-500">
            <Users className="w-3.5 h-3.5 text-slate-400" />
            <span>{stats.totalHeadcount} employees active</span>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-purple-600" />
        </div>
      </div>

      {/* Main Charts Section (Visualizations using Recharts) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (8 cols): Bar Chart of Department Target vs Actual */}
        <div className="lg:col-span-8 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
              <div>
                <h3 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-sky-700" />
                  Departmental Target vs Actual KRA Score (Scale 1.0 - 5.0)
                </h3>
                <p className="text-xs text-slate-500">
                  Benchmarked against plant standards. Green bars reflect actual score; dashed line indicates 4.5 baseline.
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold">
                <span className="flex items-center gap-1 text-slate-500">
                  <span className="w-3 h-3 rounded-xs bg-slate-300" /> Target
                </span>
                <span className="flex items-center gap-1 text-sky-800">
                  <span className="w-3 h-3 rounded-xs bg-sky-700" /> Actual
                </span>
              </div>
            </div>

            {/* Recharts Bar Chart */}
            <div className="w-full h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barChartData} margin={{ top: 10, right: 10, left: -20, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis
                    dataKey="name"
                    tick={{ fill: '#475569', fontSize: 11, fontWeight: 600 }}
                    axisLine={{ stroke: '#cbd5e1' }}
                    tickLine={false}
                  />
                  <YAxis
                    domain={[3.5, 5.0]}
                    tick={{ fill: '#64748b', fontSize: 11 }}
                    axisLine={{ stroke: '#cbd5e1' }}
                    tickLine={false}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-800 text-xs">
                            <p className="font-bold text-sky-400">{data.fullName}</p>
                            <div className="mt-1.5 space-y-1">
                              <p className="flex justify-between gap-4 text-slate-300">
                                <span>Target:</span> <strong className="text-white">{data.Target}/5.0</strong>
                              </p>
                              <p className="flex justify-between gap-4 text-slate-300">
                                <span>Actual:</span> <strong className="text-emerald-400">{data.Actual}/5.0</strong>
                              </p>
                              <p className="flex justify-between gap-4 text-slate-300">
                                <span>Achievement:</span> <strong className="text-amber-300">{data.Achievement}%</strong>
                              </p>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <ReferenceLine y={4.5} stroke="#f59e0b" strokeDasharray="4 4" label={{ value: 'Target 4.5', fill: '#d97706', fontSize: 10, position: 'right' }} />
                  <Bar dataKey="Target" fill="#cbd5e1" radius={[4, 4, 0, 0]} maxBarSize={30} />
                  <Bar dataKey="Actual" fill="#0284c7" radius={[4, 4, 0, 0]} maxBarSize={30} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-2">
            <span>Overall Departments Sampled: {filteredKPIs.length} Units</span>
            <span className="font-medium text-emerald-700">
              High Performing: {filteredKPIs.filter(k => k.achievementRate >= 100).length} of {filteredKPIs.length}
            </span>
          </div>
        </div>

        {/* Right Column (4 cols): Radar Chart for Multi-Dimensional Pillars */}
        <div className="lg:col-span-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="mb-2">
              <h3 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-2">
                <Compass className="w-4 h-4 text-purple-600" />
                Performance Pillars (Radar)
              </h3>
              <p className="text-xs text-slate-500">
                Pillars for {selectedDeptId === 'all' ? 'All Units (Composite)' : filteredKPIs[0]?.departmentName}
              </p>
            </div>

            {/* Recharts Radar Chart */}
            <div className="w-full h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart outerRadius="75%" data={radarChartData}>
                  <PolarGrid stroke="#e2e8f0" />
                  <PolarAngleAxis dataKey="pillar" tick={{ fill: '#64748b', fontSize: 9, fontWeight: 600 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#cbd5e1" tick={{ fontSize: 9 }} />
                  <Radar
                    name="Score"
                    dataKey="score"
                    stroke="#0284c7"
                    fill="#38bdf8"
                    fillOpacity={0.4}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="bg-slate-900 text-white p-2.5 rounded-lg text-xs shadow-lg">
                            <span className="font-bold text-sky-400">{d.pillar}:</span> {d.score}%
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 text-center">
            Scores normalized across machine reliability, biometric compliance, and ISO defect rates.
          </div>
        </div>
      </div>

      {/* Second Row Charts: Grade Distribution & Monthly Trajectory */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (5 cols): Appraisal Grade Bell Curve Pie Chart */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between">
          <div>
            <div className="mb-3">
              <h3 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-2">
                <Award className="w-4 h-4 text-emerald-600" />
                Appraisal Grade Distribution (Bell Curve)
              </h3>
              <p className="text-xs text-slate-500">
                Breakdown of finalized employee grades across selected department(s)
              </p>
            </div>

            <div className="w-full h-56 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={gradePieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {gradePieData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={GRADE_COLORS[entry.name] || '#94a3b8'}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        return (
                          <div className="bg-slate-900 text-white p-2 rounded-lg text-xs">
                            <p className="font-bold">{d.name}</p>
                            <p className="text-emerald-400">{d.value} Employee(s)</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Custom Grade Legend */}
            <div className="grid grid-cols-2 gap-2 mt-2">
              {gradePieData.map(item => (
                <div key={item.name} className="flex items-center gap-2 text-xs">
                  <span
                    className="w-3 h-3 rounded-full shrink-0"
                    style={{ backgroundColor: GRADE_COLORS[item.name] || '#94a3b8' }}
                  />
                  <span className="text-slate-600 truncate">{item.name}:</span>
                  <strong className="text-slate-900 ml-auto">{item.value}</strong>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Monthly Trajectory Line Chart & Predictive Trend */}
        <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-sky-700" />
                    Monthly KPI Trajectory & Next-Quarter Predictive Trend
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-purple-600" />
                    AI Horizon
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Historical monthly ratings (Jul - Oct) with projected trajectory for Next Quarter (Nov '26 - Jan '27)
                </p>
              </div>

              {/* Predictive Controls */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setShowPredictiveForecast(prev => !prev)}
                  className={`px-2.5 py-1 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                    showPredictiveForecast
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Predictive Forecast {showPredictiveForecast ? 'Active' : 'Off'}
                </button>

                {showPredictiveForecast && (
                  <select
                    aria-label="Forecast Scenario"
                    value={forecastScenario}
                    onChange={e => setForecastScenario(e.target.value as any)}
                    className="px-2.5 py-1 rounded-xl border border-purple-200 bg-purple-50 text-purple-900 text-xs font-bold focus:outline-none cursor-pointer"
                  >
                    <option value="baseline">Baseline Momentum</option>
                    <option value="optimistic">Optimistic (+3.2% MoM)</option>
                    <option value="conservative">Conservative (-0.8% MoM)</option>
                  </select>
                )}
              </div>
            </div>

            <div className="w-full h-60">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trendLineData} margin={{ top: 12, right: 20, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis
                    dataKey="month"
                    tick={{ fill: '#64748b', fontSize: 10, fontWeight: 600 }}
                    axisLine={{ stroke: '#cbd5e1' }}
                  />
                  <YAxis
                    domain={[4.0, 5.0]}
                    tick={{ fill: '#64748b', fontSize: 11 }}
                    axisLine={{ stroke: '#cbd5e1' }}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const d = payload[0].payload;
                        const isProj = d.isProjected;
                        return (
                          <div className="bg-slate-900 text-white p-3 rounded-xl text-xs shadow-xl border border-slate-800 space-y-1.5 min-w-[210px]">
                            <div className="flex items-center justify-between border-b border-slate-800 pb-1">
                              <span className="font-bold text-sky-400">{d.month}</span>
                              {isProj ? (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-700">
                                  Forecast Horizon
                                </span>
                              ) : (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-950 text-sky-300">
                                  Historical
                                </span>
                              )}
                            </div>

                            {d.Actual !== undefined && (
                              <p className="flex justify-between text-slate-300">
                                <span>Actual Rating:</span>
                                <strong className="text-emerald-400">{d.Actual} / 5.0</strong>
                              </p>
                            )}

                            {d.Projected !== undefined && (
                              <p className="flex justify-between text-purple-300 font-semibold">
                                <span>Projected Score:</span>
                                <strong className="text-purple-300">{d.Projected} / 5.0</strong>
                              </p>
                            )}

                            {d.LowerBound !== undefined && d.UpperBound !== undefined && (
                              <p className="flex justify-between text-[11px] text-slate-400">
                                <span>Confidence Interval:</span>
                                <span>[{d.LowerBound} - {d.UpperBound}]</span>
                              </p>
                            )}

                            <p className="flex justify-between text-slate-400">
                              <span>Target Benchmark:</span>
                              <strong className="text-white">{d.Target} / 5.0</strong>
                            </p>

                            <p className="flex justify-between text-slate-300 pt-1 border-t border-slate-800">
                              <span>Target Achieved:</span>
                              <strong className="text-amber-300">{d.AchievementPct}%</strong>
                            </p>

                            {isProj && (
                              <p className="text-[10px] text-purple-400 text-right">
                                Model Confidence: {d.confidence}%
                              </p>
                            )}
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                  <Line
                    type="monotone"
                    dataKey="Target"
                    stroke="#94a3b8"
                    strokeDasharray="4 4"
                    strokeWidth={1.5}
                    name="Target Benchmark (4.5)"
                    dot={{ r: 2, fill: '#94a3b8' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="Actual"
                    stroke="#0284c7"
                    strokeWidth={3}
                    name="Actual (Historical)"
                    dot={{ r: 4, fill: '#0284c7', stroke: '#fff', strokeWidth: 2 }}
                    activeDot={{ r: 6 }}
                    connectNulls={false}
                  />
                  {showPredictiveForecast && (
                    <Line
                      type="monotone"
                      dataKey="Projected"
                      stroke="#8b5cf6"
                      strokeWidth={3}
                      strokeDasharray="5 5"
                      name="Projected (Next Quarter)"
                      dot={{ r: 4, fill: '#8b5cf6', stroke: '#fff', strokeWidth: 2 }}
                      activeDot={{ r: 6 }}
                      connectNulls={false}
                    />
                  )}
                  {showPredictiveForecast && (
                    <ReferenceLine
                      x="Oct 2026"
                      stroke="#8b5cf6"
                      strokeDasharray="3 3"
                      label={{ value: 'Current Month | Forecast ➔', fill: '#7c3aed', fontSize: 10, position: 'top' }}
                    />
                  )}
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Predictive Intelligence Callout Box */}
          {showPredictiveForecast && predictiveInsights ? (
            <div className="p-3.5 rounded-xl bg-purple-50/80 border border-purple-200 text-xs space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-purple-200 text-purple-900 font-bold">
                    <Brain className="w-3.5 h-3.5" />
                  </span>
                  <div>
                    <span className="font-black text-purple-950">
                      Next-Quarter Forecast Summary ({predictiveInsights.departmentName})
                    </span>
                    <span className="text-[11px] text-purple-700 block">
                      Scenario: {predictiveInsights.scenarioLabel}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-purple-700 block uppercase font-bold">Q4 Projected Avg</span>
                    <span className="text-base font-black text-purple-950">
                      {predictiveInsights.avgProjectedScore} / 5.0
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-purple-700 block uppercase font-bold">Projected Ach.</span>
                    <span className="text-base font-black text-emerald-700">
                      {predictiveInsights.avgProjectedAchievement}%
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-purple-200/60 flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-purple-800 gap-1.5">
                <div className="flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                  <span>{predictiveInsights.recommendation}</span>
                </div>
                <span className="shrink-0 font-bold text-purple-900">
                  Model Fit: {predictiveInsights.confidenceFit}
                </span>
              </div>
            </div>
          ) : (
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Trend Source: Monthly Reporting Manager Reviews</span>
              <span className="font-bold text-sky-700">Historical velocity consistently exceeding 4.5 Target</span>
            </div>
          )}
        </div>
      </div>

      {/* Department-Wise KPI Achievements Breakdown (Interactive Recharts: Bar & Radial Charts) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        {/* Top Header & Visual View Mode Switcher */}
        <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-sky-100 text-sky-800">
                <BarChart3 className="w-5 h-5 text-sky-700" />
              </span>
              <div>
                <h3 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-2">
                  Department-Wise KPI Achievements Breakdown
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                    Recharts Visuals
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Interactive concentric Radial progress rings and benchmark Bar analytics replacing static list representations
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {/* View Mode Toggle: Visual Charts vs Split vs Table */}
            <div className="flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setBreakdownViewMode('charts')}
                className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  breakdownViewMode === 'charts'
                    ? 'bg-white text-sky-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Gauge className="w-3.5 h-3.5 text-sky-700" />
                <span>Visual Charts (Bar & Radial)</span>
              </button>
              <button
                type="button"
                onClick={() => setBreakdownViewMode('split')}
                className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  breakdownViewMode === 'split'
                    ? 'bg-white text-sky-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <LayoutGrid className="w-3.5 h-3.5 text-purple-700" />
                <span>Split Comparative</span>
              </button>
              <button
                type="button"
                onClick={() => setBreakdownViewMode('table')}
                className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  breakdownViewMode === 'table'
                    ? 'bg-white text-sky-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Layers className="w-3.5 h-3.5 text-slate-700" />
                <span>Data Scorecard</span>
              </button>
            </div>

            <button
              onClick={handleExportToCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Interactive Toolbar for Sorting, Status Filter, and Metric Switch */}
        <div className="px-5 py-3 bg-slate-50/70 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Achievement Status Filter */}
            <div className="flex items-center gap-1">
              <span className="text-[11px] font-bold text-slate-500 uppercase mr-1">Filter:</span>
              <button
                type="button"
                onClick={() => setAchievementStatusFilter('all')}
                className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer ${
                  achievementStatusFilter === 'all'
                    ? 'bg-sky-600 text-white shadow-2xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                All ({filteredKPIs.length})
              </button>
              <button
                type="button"
                onClick={() => setAchievementStatusFilter('exceeded')}
                className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer ${
                  achievementStatusFilter === 'exceeded'
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'bg-white text-emerald-700 hover:bg-emerald-50 border border-emerald-200'
                }`}
              >
                Exceeded ≥ 100% ({filteredKPIs.filter(k => k.achievementRate >= 100).length})
              </button>
              <button
                type="button"
                onClick={() => setAchievementStatusFilter('lagging')}
                className={`px-2.5 py-1 rounded-lg font-semibold transition cursor-pointer ${
                  achievementStatusFilter === 'lagging'
                    ? 'bg-amber-600 text-white shadow-2xs'
                    : 'bg-white text-amber-700 hover:bg-amber-50 border border-amber-200'
                }`}
              >
                Under &lt; 100% ({filteredKPIs.filter(k => k.achievementRate < 100).length})
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {/* Metric Toggle */}
            <div className="flex items-center gap-1 bg-white p-0.5 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setActiveChartMetric('achievement')}
                className={`px-2 py-1 rounded-md text-[11px] font-bold transition cursor-pointer ${
                  activeChartMetric === 'achievement'
                    ? 'bg-sky-100 text-sky-800'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                % Achievement
              </button>
              <button
                type="button"
                onClick={() => setActiveChartMetric('score')}
                className={`px-2 py-1 rounded-md text-[11px] font-bold transition cursor-pointer ${
                  activeChartMetric === 'score'
                    ? 'bg-sky-100 text-sky-800'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Scale 1.0 - 5.0
              </button>
            </div>

            {/* Sorting Dropdown */}
            <div className="flex items-center gap-1.5">
              <ArrowDownUp className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={achievementSort}
                onChange={e => setAchievementSort(e.target.value as any)}
                className="px-2.5 py-1 rounded-lg border border-slate-200 bg-white font-bold text-slate-700 text-xs cursor-pointer"
              >
                <option value="desc">Sort: Highest Achievement %</option>
                <option value="asc">Sort: Lowest Achievement %</option>
                <option value="alpha">Sort: Name (A to Z)</option>
                <option value="headcount">Sort: Headcount (High to Low)</option>
              </select>
            </div>
          </div>
        </div>

        {/* SECTION A: Visual Charts (Bar and Radial) */}
        {(breakdownViewMode === 'charts' || breakdownViewMode === 'split') && (
          <div className="p-5 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Radial Chart: Concentric KPI Achievement Progress Rings */}
              <div className="lg:col-span-5 bg-slate-50/60 rounded-2xl p-4 border border-slate-200/80 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h4 className="text-xs font-black uppercase text-slate-900 flex items-center gap-1.5">
                        <Gauge className="w-4 h-4 text-sky-700" />
                        Concentric Radial KPI Achievement Rings
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Circular progress visual for {processedAchievementKPIs.length} department(s)
                      </p>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 font-bold">
                      RadialBar
                    </span>
                  </div>

                  {/* Concentric RadialBarChart with Center Gauge */}
                  <div className="relative w-full h-80 flex items-center justify-center">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadialBarChart
                        cx="50%"
                        cy="50%"
                        innerRadius="25%"
                        outerRadius="100%"
                        barSize={12}
                        data={departmentRadialData}
                        startAngle={90}
                        endAngle={-270}
                      >
                        <PolarAngleAxis
                          type="number"
                          domain={[80, 115]}
                          angleAxisId={0}
                          tick={false}
                        />
                        <RadialBar
                          background={{ fill: '#e2e8f0' }}
                          dataKey="achievement"
                          cornerRadius={6}
                          onMouseEnter={(entry: any) => {
                            if (entry && entry.code) setHoveredDeptCode(entry.code);
                          }}
                          onMouseLeave={() => setHoveredDeptCode(null)}
                          onClick={(entry: any) => {
                            const dept = kpiList.find(d => d.departmentCode === entry.code || d.departmentName === entry.name);
                            if (dept) setActiveDrillDownDept(dept);
                          }}
                        >
                          {departmentRadialData.map((entry, index) => (
                            <Cell
                              key={`radial-cell-${entry.id || index}`}
                              fill={entry.fill}
                              cursor="pointer"
                            />
                          ))}
                        </RadialBar>
                        <Tooltip
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              const d = payload[0].payload;
                              return (
                                <div className="bg-slate-900 text-white p-3 rounded-xl shadow-2xl border border-slate-800 text-xs min-w-56">
                                  <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-1.5 mb-1.5">
                                    <span className="font-bold text-sky-400">{d.name} ({d.code})</span>
                                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                                      {d.cluster}
                                    </span>
                                  </div>
                                  <div className="space-y-1.5">
                                    <div className="flex justify-between items-center text-slate-300">
                                      <span>KPI Achievement:</span>
                                      <strong className={d.achievement >= 100 ? 'text-emerald-400 font-mono text-sm' : 'text-amber-400 font-mono text-sm'}>
                                        {d.achievement}%
                                      </strong>
                                    </div>
                                    <div className="flex justify-between items-center text-slate-300">
                                      <span>Actual Score:</span>
                                      <strong className="text-white font-mono">{d.actualScore} / 5.0</strong>
                                    </div>
                                    <div className="flex justify-between items-center text-slate-300">
                                      <span>Target Score:</span>
                                      <span className="text-slate-400 font-mono">{d.targetScore} / 5.0</span>
                                    </div>
                                    <div className="pt-1 border-t border-slate-800 flex justify-between items-center text-[11px] text-slate-400">
                                      <span>Location:</span>
                                      <span className="text-slate-200">{d.branch}</span>
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                      </RadialBarChart>
                    </ResponsiveContainer>

                    {/* Central Gauge Readout */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="text-center bg-white/95 backdrop-blur-xs p-3 rounded-2xl border border-slate-200/90 shadow-xs max-w-[140px]">
                        {centerGaugeDept ? (
                          <div>
                            <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider block">
                              {centerGaugeDept.departmentCode}
                            </span>
                            <div className={`text-lg font-black ${
                              centerGaugeDept.achievementRate >= 100 ? 'text-emerald-600' : 'text-sky-600'
                            }`}>
                              {centerGaugeDept.achievementRate}%
                            </div>
                            <span className="text-[9px] text-slate-500 font-semibold truncate block mt-0.5">
                              {centerGaugeDept.departmentName}
                            </span>
                          </div>
                        ) : (
                          <div>
                            <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider block">
                              Composite Avg
                            </span>
                            <div className="text-lg font-black text-slate-900">
                              {stats.avgAchievement}%
                            </div>
                            <span className="text-[9px] text-emerald-600 font-bold block mt-0.5">
                              Target Baseline Met
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Radial Legend & Tier Indicators */}
                <div className="pt-3 border-t border-slate-200/80 flex flex-wrap items-center justify-between text-[10px] gap-2">
                  <span className="flex items-center gap-1 font-semibold text-emerald-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> ≥ 100% Exceeded
                  </span>
                  <span className="flex items-center gap-1 font-semibold text-sky-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-sky-600" /> 95-99% Standard
                  </span>
                  <span className="flex items-center gap-1 font-semibold text-amber-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> 90-94% Near
                  </span>
                  <span className="flex items-center gap-1 font-semibold text-rose-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> &lt; 90% Lagging
                  </span>
                </div>
              </div>

              {/* Bar Chart: Interactive Department-Wise Achievement Bar Chart */}
              <div className="lg:col-span-7 bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs flex flex-col justify-between">
                <div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                    <div>
                      <h4 className="text-xs font-black uppercase text-slate-900 flex items-center gap-1.5">
                        <BarChart3 className="w-4 h-4 text-sky-700" />
                        Departmental KPI Achievement Rates vs Benchmark
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        {activeChartMetric === 'achievement'
                          ? 'Dashed reference line at 100% target baseline standard. Click any bar for drill-down.'
                          : 'Scale 1.0 to 5.0 with 4.5 baseline reference benchmark.'}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 text-[11px]">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-bold">
                        Sorted by: {achievementSort.toUpperCase()}
                      </span>
                    </div>
                  </div>

                  {/* Recharts BarChart */}
                  <div className="w-full h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={departmentAchievementBarData}
                        margin={{ top: 12, right: 15, left: -10, bottom: 25 }}
                        onClick={(state: any) => {
                          if (state && state.activePayload && state.activePayload.length) {
                            const item = state.activePayload[0].payload;
                            const dept = kpiList.find(d => d.departmentCode === item.name || d.id === item.id);
                            if (dept) setActiveDrillDownDept(dept);
                          }
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                        <XAxis
                          dataKey="name"
                          tick={{ fill: '#475569', fontSize: 11, fontWeight: 700 }}
                          axisLine={{ stroke: '#cbd5e1' }}
                          tickLine={false}
                        />
                        <YAxis
                          domain={activeChartMetric === 'achievement' ? [85, 115] : [3.5, 5.0]}
                          tick={{ fill: '#64748b', fontSize: 11 }}
                          axisLine={{ stroke: '#cbd5e1' }}
                          tickLine={false}
                          unit={activeChartMetric === 'achievement' ? '%' : ''}
                        />
                        <Tooltip
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              const data = payload[0].payload;
                              return (
                                <div className="bg-slate-900 text-white p-3 rounded-xl shadow-2xl border border-slate-800 text-xs min-w-56">
                                  <p className="font-bold text-sky-400">{data.fullName} ({data.name})</p>
                                  <div className="mt-2 space-y-1">
                                    <p className="flex justify-between gap-4 text-slate-300">
                                      <span>Achievement:</span>
                                      <strong className={data.achievement >= 100 ? 'text-emerald-400 font-mono text-sm' : 'text-amber-400 font-mono text-sm'}>
                                        {data.achievement}%
                                      </strong>
                                    </p>
                                    <p className="flex justify-between gap-4 text-slate-300">
                                      <span>Actual Score:</span>
                                      <strong className="text-white font-mono">{data.actualScore} / 5.0</strong>
                                    </p>
                                    <p className="flex justify-between gap-4 text-slate-300">
                                      <span>Target Score:</span>
                                      <span className="text-slate-400 font-mono">{data.targetScore} / 5.0</span>
                                    </p>
                                    <p className="flex justify-between gap-4 text-slate-300">
                                      <span>Headcount:</span>
                                      <span className="text-slate-200">{data.headcount} Staff</span>
                                    </p>
                                  </div>
                                  <div className="mt-2 pt-1.5 border-t border-slate-800 text-[10px] text-sky-300 font-semibold">
                                    Click bar to inspect department review & KRAs
                                  </div>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <ReferenceLine
                          y={activeChartMetric === 'achievement' ? 100 : 4.5}
                          stroke="#f59e0b"
                          strokeDasharray="4 4"
                          label={{
                            value: activeChartMetric === 'achievement' ? '100% Target Standard' : '4.5 Benchmark',
                            fill: '#d97706',
                            fontSize: 10,
                            position: 'top',
                          }}
                        />
                        <Bar
                          dataKey={activeChartMetric === 'achievement' ? 'achievement' : 'actualScore'}
                          radius={[6, 6, 0, 0]}
                          maxBarSize={36}
                        >
                          {departmentAchievementBarData.map((entry, index) => (
                            <Cell
                              key={`bar-cell-${entry.id || index}`}
                              fill={entry.fill}
                              cursor="pointer"
                            />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <span>Interactive Drill-Down: Click any bar or radial track to inspect detailed scorecards</span>
                  <span className="font-bold text-sky-700">Top Unit: {stats.topDepartment}</span>
                </div>
              </div>
            </div>

            {/* Department Achievement Cards Grid (Visual Highlights) */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-black uppercase text-slate-700 tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  Department KPI Visual Telemetry Cards
                </h4>
                <span className="text-xs text-slate-500">
                  Showing {processedAchievementKPIs.length} Units
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {processedAchievementKPIs.map(dept => {
                  const isExceeded = dept.achievementRate >= 100;
                  const isNear = dept.achievementRate >= 95 && dept.achievementRate < 100;

                  return (
                    <div
                      key={dept.id}
                      onClick={() => setActiveDrillDownDept(dept)}
                      className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-sky-300 hover:shadow-xs transition cursor-pointer space-y-2.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="font-black text-slate-900 text-xs flex items-center gap-1.5">
                            {dept.departmentName}
                          </div>
                          <span className="text-[10px] font-mono font-bold text-slate-500">
                            {dept.departmentCode}
                          </span>
                        </div>

                        {/* Circular achievement rate badge */}
                        <div className={`px-2 py-1 rounded-lg text-xs font-black font-mono flex items-center gap-1 ${
                          isExceeded
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : isNear
                            ? 'bg-sky-50 text-sky-700 border border-sky-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}>
                          {dept.achievementRate}%
                        </div>
                      </div>

                      {/* Score comparison progress */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] text-slate-500">
                          <span>Actual: <strong className="text-slate-800">{dept.actualScore}</strong></span>
                          <span>Target: <strong className="text-slate-800">{dept.targetScore}</strong></span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              isExceeded ? 'bg-emerald-500' : isNear ? 'bg-sky-600' : 'bg-amber-500'
                            }`}
                            style={{ width: `${Math.min(100, (dept.actualScore / 5.0) * 100)}%` }}
                          />
                        </div>
                      </div>

                      {/* Manager and location badges */}
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-500">
                        <span className="truncate max-w-[120px]">{dept.managerName}</span>
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-semibold text-[9px]">
                          {dept.branchName || 'Pune HQ'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* SECTION B: Scorecard Data Table (When in Table or Split mode) */}
        {(breakdownViewMode === 'table' || breakdownViewMode === 'split') && (
          <div className="border-t border-slate-100">
            <div className="p-4 bg-slate-50/50 border-b border-slate-100 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-slate-500" />
                Scorecard Tabular Breakdown ({processedAchievementKPIs.length} Units)
              </span>
              <span className="text-xs text-slate-500">Click any row to drill down into deliverables</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50/75 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                    <th className="py-3 px-4">Department & Head</th>
                    <th className="py-3 px-4">Headcount / Evals</th>
                    <th className="py-3 px-4 text-center">Target</th>
                    <th className="py-3 px-4 text-center">Actual Score</th>
                    <th className="py-3 px-4 text-center">Achievement</th>
                    <th className="py-3 px-4">Primary Deliverables & Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {processedAchievementKPIs.map(dept => {
                    const isExceeded = dept.achievementRate >= 100;
                    const isNear = dept.achievementRate >= 95 && dept.achievementRate < 100;

                    return (
                      <tr key={dept.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-4">
                          <div>
                            <div className="font-black text-slate-900 text-sm flex items-center gap-2">
                              {dept.departmentName}
                              <span className="px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[10px] font-bold">
                                {dept.departmentCode}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
                              <Users className="w-3 h-3 text-slate-400" />
                              <span>Manager: {dept.managerName}</span>
                            </div>
                            <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-semibold border border-slate-200">
                                <MapPin className="w-2.5 h-2.5 text-sky-600" />
                                {dept.branchName || availableBranches.find(b => b.id === dept.branchId)?.shortName || 'Pune HQ'}
                              </span>
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold border border-purple-200 bg-purple-50 text-purple-800">
                                <Layers className="w-2.5 h-2.5 text-purple-600" />
                                {dept.cluster || 'General'}
                              </span>
                            </div>
                          </div>
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="space-y-1">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="font-semibold text-slate-700">
                                {dept.completedEvaluations} of {dept.employeeCount} reviewed
                              </span>
                              <span className="font-bold text-sky-700">
                                {Math.round((dept.completedEvaluations / dept.employeeCount) * 100)}%
                              </span>
                            </div>
                            <div className="w-28 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-sky-600 rounded-full"
                                style={{ width: `${(dept.completedEvaluations / dept.employeeCount) * 100}%` }}
                              />
                            </div>
                            <span className="text-[10px] text-slate-400">
                              {dept.pendingEvaluations} pending review
                            </span>
                          </div>
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span className="font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded-md">
                            {dept.targetScore} / 5.0
                          </span>
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <div className="inline-flex items-center gap-1 font-black text-slate-900 text-sm">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                            <span>{dept.actualScore}</span>
                          </div>
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                              isExceeded
                                ? 'bg-emerald-100 text-emerald-800'
                                : isNear
                                ? 'bg-sky-100 text-sky-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {isExceeded && <CheckCircle2 className="w-3 h-3" />}
                            {dept.achievementRate}%
                          </span>
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="space-y-1 max-w-xs">
                            {dept.metrics.slice(0, 2).map(m => (
                              <div key={m.id} className="flex items-center justify-between text-[11px] gap-2">
                                <span className="text-slate-700 font-medium truncate">{m.metricName}</span>
                                <span
                                  className={`shrink-0 px-1.5 py-0.5 rounded-sm font-bold text-[10px] ${
                                    m.status === 'Exceeded'
                                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                      : m.status === 'On Track'
                                      ? 'bg-sky-50 text-sky-700 border border-sky-200'
                                      : 'bg-amber-50 text-amber-700 border border-amber-200'
                                  }`}
                                >
                                  {m.actual}
                                </span>
                              </div>
                            ))}
                          </div>
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => setActiveDrillDownDept(dept)}
                              className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-sky-50 text-slate-700 hover:text-sky-800 font-bold transition flex items-center gap-1 cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              Drill Down
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}

                  {processedAchievementKPIs.length === 0 && (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-slate-500">
                        <div className="flex flex-col items-center justify-center gap-2">
                          <div className="p-3 rounded-2xl bg-slate-100 text-slate-400">
                            <Filter className="w-6 h-6" />
                          </div>
                          <p className="font-bold text-slate-800 text-sm">No departments match the selected filter combination</p>
                          <p className="text-xs text-slate-400 max-w-md">
                            Try modifying or resetting your active branch or department cluster selections to view metric telemetry.
                          </p>
                          <button
                            type="button"
                            onClick={resetAllFilters}
                            className="mt-2 inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-sky-700 hover:text-sky-800 bg-sky-50 hover:bg-sky-100 rounded-xl transition cursor-pointer"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            Reset All Filters
                          </button>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Drill Down Modal: Specific Department Details & Subordinates */}
      {activeDrillDownDept && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto space-y-6">
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-md bg-sky-100 text-sky-800 font-bold text-xs">
                    {activeDrillDownDept.departmentCode}
                  </span>
                  <h3 className="text-xl font-black text-slate-900">
                    {activeDrillDownDept.departmentName} - Detailed KPI Review
                  </h3>
                </div>
                <p className="text-xs text-slate-500 mt-1 flex items-center gap-2 flex-wrap">
                  <span>Manager: <strong className="text-slate-800">{activeDrillDownDept.managerName}</strong></span>
                  <span>|</span>
                  <span>Period: <strong className="text-slate-800">{activeDrillDownDept.period}</strong></span>
                  <span>|</span>
                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-semibold border border-slate-200">
                    <MapPin className="w-2.5 h-2.5 text-sky-600" />
                    {activeDrillDownDept.branchName || 'Pune HQ'}
                  </span>
                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold border border-purple-200 bg-purple-50 text-purple-800">
                    <Layers className="w-2.5 h-2.5 text-purple-600" />
                    {activeDrillDownDept.cluster || 'General'}
                  </span>
                </p>
              </div>
              <button
                onClick={() => setActiveDrillDownDept(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Department Summary Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                <span className="text-[11px] font-bold text-slate-500 block uppercase">Target Score</span>
                <span className="text-lg font-black text-slate-700">{activeDrillDownDept.targetScore} / 5.0</span>
              </div>
              <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 text-center">
                <span className="text-[11px] font-bold text-emerald-600 block uppercase">Actual Score</span>
                <span className="text-lg font-black text-emerald-800">{activeDrillDownDept.actualScore} / 5.0</span>
              </div>
              <div className="bg-sky-50 p-3 rounded-xl border border-sky-200 text-center">
                <span className="text-[11px] font-bold text-sky-600 block uppercase">Achievement %</span>
                <span className="text-lg font-black text-sky-800">{activeDrillDownDept.achievementRate}%</span>
              </div>
              <div className="bg-purple-50 p-3 rounded-xl border border-purple-200 text-center">
                <span className="text-[11px] font-bold text-purple-600 block uppercase">Quality SLA</span>
                <span className="text-lg font-black text-purple-800">{activeDrillDownDept.qualityPassRate}%</span>
              </div>
            </div>

            {/* Department Deliverable Metrics list */}
            <div>
              <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider mb-2.5">
                Key Deliverables & Performance Thresholds
              </h4>
              <div className="space-y-2">
                {activeDrillDownDept.metrics.map(m => (
                  <div
                    key={m.id}
                    className="p-3 rounded-xl border border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-xs">{m.metricName}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-600 font-semibold">
                          Weight: {m.weightage}%
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Target: <span className="font-semibold text-slate-700">{m.target}</span> | Actual:{' '}
                        <span className="font-semibold text-slate-900">{m.actual}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <span className="text-xs font-black text-slate-900">{m.achievedPercent}%</span>
                        <span className="block text-[10px] text-slate-400">Achieved</span>
                      </div>
                      <span
                        className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                          m.status === 'Exceeded'
                            ? 'bg-emerald-100 text-emerald-800'
                            : m.status === 'On Track'
                            ? 'bg-sky-100 text-sky-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {m.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Subordinate Employees Assessed */}
            <div>
              <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider mb-2.5">
                Assigned Team Members & KRA Status ({drillDownEmployees.length} Members)
              </h4>
              <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100 text-xs">
                {drillDownEmployees.length === 0 ? (
                  <div className="p-4 text-center text-slate-400">
                    No individual employee records found directly assigned to this unit code.
                  </div>
                ) : (
                  drillDownEmployees.map(emp => {
                    const matchedEval = monthlyKraEvaluations.find(
                      ev => ev.employeeId === emp.id || ev.employeeCode === emp.employeeCode
                    );

                    const fullName = `${emp.firstName} ${emp.lastName}`.trim();
                    const designationTitle = matchedEval?.designation || `Staff (${emp.employeeCode})`;

                    return (
                      <div
                        key={emp.id}
                        className="p-3 flex items-center justify-between hover:bg-slate-50 transition"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-800 font-bold flex items-center justify-center text-xs">
                            {fullName.charAt(0) || 'E'}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900">
                              {fullName}{' '}
                              <span className="text-slate-400 font-normal">({emp.employeeCode})</span>
                            </div>
                            <div className="text-[11px] text-slate-500">{designationTitle}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          {matchedEval ? (
                            <div className="text-right">
                              <span className="font-black text-slate-900 text-xs flex items-center gap-1 justify-end">
                                <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                                {matchedEval.finalHrScore || matchedEval.totalManagerScore || matchedEval.totalSelfScore} / 5.0
                              </span>
                              <span className="text-[10px] text-emerald-600 font-semibold block">
                                Status: {matchedEval.status.replace(/_/g, ' ')}
                              </span>
                            </div>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-medium">Evaluation pending</span>
                          )}

                          {onNavigateToWorkflow && (
                            <button
                              onClick={() => {
                                setActiveDrillDownDept(null);
                                onNavigateToWorkflow(matchedEval?.id);
                              }}
                              className="px-2 py-1 rounded-md bg-sky-50 text-sky-700 hover:bg-sky-100 font-bold text-[11px] transition cursor-pointer"
                            >
                              Open KRA
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button
                onClick={() => setActiveDrillDownDept(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition cursor-pointer"
              >
                Close Drill Down
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Adjust Department KPI Target Modal */}
      {showAddTargetModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-black text-slate-900">
                  Assign Departmental KPI Target
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Set target goals, weightage, and evaluation criteria for plant managers.
                </p>
              </div>
              <button
                onClick={() => setShowAddTargetModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddKPITarget} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Target Department
                </label>
                <select
                  value={targetDeptId}
                  onChange={e => setTargetDeptId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-medium focus:ring-2 focus:ring-sky-500 focus:outline-none"
                >
                  {kpiList.map(dept => (
                    <option key={dept.id} value={dept.id}>
                      {dept.departmentName} ({dept.departmentCode}) - {dept.managerName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  KPI Metric Title
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Turnstile Biometric SLA or Defect PPM < 40"
                  value={targetMetricName}
                  onChange={e => setTargetMetricName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium focus:ring-2 focus:ring-sky-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Target Goal
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. >= 98.5% or 0 Defects"
                    value={targetGoal}
                    onChange={e => setTargetGoal(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium focus:ring-2 focus:ring-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Weightage (%)
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="100"
                    value={targetWeightage}
                    onChange={e => setTargetWeightage(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 font-medium focus:ring-2 focus:ring-sky-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Metric Category
                </label>
                <select
                  value={targetCategory}
                  onChange={e => setTargetCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white font-medium focus:ring-2 focus:ring-sky-500 focus:outline-none"
                >
                  <option value="Operations">Operations & Machine Line</option>
                  <option value="Quality">Quality Assurance & Low PPM</option>
                  <option value="Punctuality">Punctuality & Shift Roster</option>
                  <option value="Financial">Financial & Budget SLA</option>
                  <option value="Innovation">Innovation & Kaizen 5S</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddTargetModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-bold hover:bg-slate-50 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-700 hover:bg-sky-800 text-white font-bold transition shadow-xs cursor-pointer"
                >
                  Save KPI Target
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

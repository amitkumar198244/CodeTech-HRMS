// RSTPL HRMS - Manager Self Service (MSS) Portal
// RS Technovisions XpertSkillCop

import React from 'react';
import {
  Briefcase,
  Users,
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Check,
  X,
  ChevronRight,
  TrendingUp,
  BarChart3,
  Target
} from 'lucide-react';
import { Employee, AttendanceRecord, LeaveRequest, ODRequest } from '../../types/hrms';

interface MSSViewProps {
  currentManager: Employee;
  employees: Employee[];
  attendance: AttendanceRecord[];
  leaveRequests: LeaveRequest[];
  odRequests: ODRequest[];
  onReviewLeave: (id: string, status: 'Approved' | 'Rejected') => void;
  onReviewOD: (id: string, status: 'Approved' | 'Rejected') => void;
  onNavigate?: (module: any) => void;
}

export const MSSView: React.FC<MSSViewProps> = ({
  currentManager,
  employees,
  attendance,
  leaveRequests,
  odRequests,
  onReviewLeave,
  onReviewOD,
  onNavigate,
}) => {
  // Direct reports (or plant workers if manager is plant head)
  const teamEmployees = employees.filter(
    e => e.reportingManagerId === currentManager.id || e.departmentId === currentManager.departmentId
  );

  const teamAttendanceToday = attendance.filter(a =>
    teamEmployees.some(te => te.id === a.employeeId)
  );

  const pendingTeamLeaves = leaveRequests.filter(
    l => l.status === 'Pending' && teamEmployees.some(te => te.id === l.employeeId)
  );

  const pendingTeamODs = odRequests.filter(
    o => o.status === 'Pending' && teamEmployees.some(te => te.id === o.employeeId)
  );

  const presentCount = teamAttendanceToday.filter(a => a.status === 'Present' || a.status === 'Late').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <Briefcase className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">Manager Self Service (MSS)</h2>
              <p className="text-xs text-slate-500">
                Departmental roster management, team approvals queue & shift supervision
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
            <span className="text-slate-500">Supervising: </span>
            <strong className="text-slate-900">{teamEmployees.length} Team Members</strong>
          </div>
          {onNavigate && (
            <button
              onClick={() => onNavigate('performance')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-bold transition shadow-xs cursor-pointer"
            >
              <BarChart3 className="w-3.5 h-3.5" />
              Department KPIs & KRAs
            </button>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Team Presence Today</span>
          <p className="text-2xl font-black text-emerald-600 mt-1">
            {presentCount} / {teamEmployees.length}
          </p>
          <p className="text-[11px] text-slate-500 mt-0.5">Biometric logs verified</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Pending Approvals</span>
          <p className="text-2xl font-black text-amber-500 mt-1">
            {pendingTeamLeaves.length + pendingTeamODs.length}
          </p>
          <p className="text-[11px] text-slate-500 mt-0.5">Leaves & field duty requests</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Shift Adherence</span>
          <p className="text-2xl font-black text-sky-600 mt-1">96.4%</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Zero unexcused plant stoppages</p>
        </div>
      </div>

      {/* Pending Approvals Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <h3 className="text-sm font-bold text-slate-900">Immediate Team Approvals Queue</h3>
          <p className="text-[11px] text-slate-500">Authorize team leaves and On Duty assignments</p>
        </div>

        {pendingTeamLeaves.length === 0 && pendingTeamODs.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs">
            All team requests have been reviewed and resolved. You're up to date!
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {pendingTeamLeaves.map(leave => (
              <div key={leave.id} className="p-4 flex items-center justify-between hover:bg-slate-50/70 text-xs">
                <div>
                  <span className="font-bold text-slate-900">{leave.employeeName}</span>
                  <span className="text-slate-400 mx-2">·</span>
                  <span className="font-semibold text-sky-800">{leave.leaveTypeName}</span>
                  <p className="text-slate-500 text-[11px] mt-0.5">
                    {leave.startDate} to {leave.endDate} ({leave.days} day) · Reason: "{leave.reason}"
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onReviewLeave(leave.id, 'Approved')}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-700 transition-colors cursor-pointer"
                  >
                    Approve
                  </button>
                  <button
                    onClick={() => onReviewLeave(leave.id, 'Rejected')}
                    className="px-3 py-1.5 rounded-xl bg-rose-50 text-rose-700 font-bold border border-rose-200 hover:bg-rose-100 transition-colors cursor-pointer"
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Team Roster Grid */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <h3 className="text-sm font-bold text-slate-900">Direct Team Roster</h3>
          <p className="text-[11px] text-slate-500">Personnel under your supervision</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-semibold uppercase text-[10px]">
              <tr>
                <th className="py-2.5 px-4">Employee</th>
                <th className="py-2.5 px-4">Code</th>
                <th className="py-2.5 px-4">Shift</th>
                <th className="py-2.5 px-4">Today Status</th>
                <th className="py-2.5 px-4">Contact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {teamEmployees.map(te => {
                const att = teamAttendanceToday.find(a => a.employeeId === te.id);
                return (
                  <tr key={te.id} className="hover:bg-slate-50/70">
                    <td className="py-2.5 px-4 font-bold text-slate-900">
                      {te.firstName} {te.lastName}
                    </td>
                    <td className="py-2.5 px-4 font-mono text-slate-500">{te.employeeCode}</td>
                    <td className="py-2.5 px-4 font-mono text-[11px]">{te.shiftId}</td>
                    <td className="py-2.5 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        att?.status === 'Present' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {att?.status || 'Scheduled'}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-500 font-mono text-[11px]">{te.phone}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

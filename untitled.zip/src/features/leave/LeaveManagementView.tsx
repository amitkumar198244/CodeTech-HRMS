// RSTPL HRMS - Leave Management & Configurable Policy Engine
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  Plus,
  Shield,
  Search,
  Filter,
  Check,
  X,
  FileText
} from 'lucide-react';
import { LeaveRequest, LeaveType, Employee } from '../../types/hrms';

interface LeaveManagementViewProps {
  leaveRequests: LeaveRequest[];
  leaveTypes: LeaveType[];
  employees: Employee[];
  onUpdateRequests: (requests: LeaveRequest[]) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
}

export const LeaveManagementView: React.FC<LeaveManagementViewProps> = ({
  leaveRequests,
  leaveTypes,
  employees,
  onUpdateRequests,
  onLogAudit,
}) => {
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [newRequest, setNewRequest] = useState<Partial<LeaveRequest>>({
    employeeId: employees[0]?.id,
    leaveTypeId: leaveTypes[0]?.id,
    startDate: '2026-10-10',
    endDate: '2026-10-12',
    days: 3,
    reason: '',
  });

  const filteredRequests = leaveRequests.filter(req => {
    return filterStatus === 'ALL' || req.status === filterStatus;
  });

  const handleApplyLeave = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find(e => e.id === newRequest.employeeId);
    const lt = leaveTypes.find(l => l.id === newRequest.leaveTypeId);
    if (!emp || !lt || !newRequest.reason) return;

    const request: LeaveRequest = {
      id: `lr-${Date.now()}`,
      orgId: emp.orgId,
      employeeId: emp.id,
      employeeName: `${emp.firstName} ${emp.lastName}`,
      leaveTypeId: lt.id,
      leaveTypeName: `${lt.name} (${lt.code})`,
      startDate: newRequest.startDate || '2026-10-10',
      endDate: newRequest.endDate || '2026-10-12',
      days: newRequest.days || 1,
      reason: newRequest.reason,
      status: 'Pending',
      appliedAt: new Date().toISOString(),
    };

    onUpdateRequests([request, ...leaveRequests]);
    setShowApplyModal(false);
    setNewRequest({ ...newRequest, reason: '' });
    onLogAudit('CREATE', 'Leave Management', `${request.employeeName} applied for ${request.days} day(s) ${request.leaveTypeName}`);
  };

  const handleReview = (id: string, newStatus: 'Approved' | 'Rejected') => {
    const next = leaveRequests.map(r => {
      if (r.id === id) {
        return {
          ...r,
          status: newStatus,
          reviewedBy: 'Amit Sharma (HR Head)',
          reviewedAt: new Date().toISOString(),
          reviewRemarks: newStatus === 'Approved' ? 'Leave granted per policy' : 'Operational exigency',
        };
      }
      return r;
    });

    onUpdateRequests(next);
    onLogAudit('APPROVE', 'Leave Management', `Manager marked leave request ${id} as ${newStatus}`);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <Calendar className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">Leave Management System</h2>
              <p className="text-xs text-slate-500">
                Configurable statutory policies, accrual rules, sandwich leaves & managerial approval workflows
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={() => setShowApplyModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Apply Leave Application</span>
        </button>
      </div>

      {/* Leave Types Policy Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        {leaveTypes.map(lt => (
          <div key={lt.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-1">
              <span className="font-mono text-xs font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-800">
                {lt.code}
              </span>
              <span className="text-[10px] font-bold text-slate-400">Quota: {lt.annualQuota}/yr</span>
            </div>
            <h4 className="text-xs font-bold text-slate-900 mt-1">{lt.name}</h4>
            <div className="text-[10px] text-slate-500 mt-2 space-y-0.5">
              <p>Carry Forward: {lt.isCarryForward ? `Yes (max ${lt.maxCarryForwardDays}d)` : 'No'}</p>
              <p>Encashable: {lt.isEncashable ? 'Yes' : 'No'}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Requests Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Leave Requests Queue</h3>
            <p className="text-[11px] text-slate-500">Applications submitted for approval</p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="font-semibold text-slate-500">Status:</span>
            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50 font-medium text-slate-800"
            >
              <option value="ALL">All Requests</option>
              <option value="Pending">Pending</option>
              <option value="Approved">Approved</option>
              <option value="Rejected">Rejected</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Leave Type</th>
                <th className="py-3 px-4">Duration</th>
                <th className="py-3 px-4">Days</th>
                <th className="py-3 px-4">Reason</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredRequests.map(req => (
                <tr key={req.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-4 font-bold text-slate-900">{req.employeeName}</td>
                  <td className="py-3 px-4 font-semibold text-sky-800">{req.leaveTypeName}</td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                    {req.startDate} to {req.endDate}
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900">{req.days} day(s)</td>
                  <td className="py-3 px-4 max-w-xs truncate text-slate-600">{req.reason}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        req.status === 'Approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : req.status === 'Rejected'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {req.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    {req.status === 'Pending' ? (
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleReview(req.id, 'Approved')}
                          className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px] hover:bg-emerald-700 transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <Check className="w-3 h-3" /> Approve
                        </button>
                        <button
                          onClick={() => handleReview(req.id, 'Rejected')}
                          className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 font-bold text-[11px] hover:bg-rose-100 border border-rose-200 transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <X className="w-3 h-3" /> Reject
                        </button>
                      </div>
                    ) : (
                      <span className="text-slate-400 text-[11px]">Reviewed by {req.reviewedBy?.split(' ')[0]}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Apply Leave Modal */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Submit Leave Application</h3>
            <p className="text-xs text-slate-500 mb-4">Request approval from reporting manager</p>

            <form onSubmit={handleApplyLeave} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Select Employee:</label>
                <select
                  value={newRequest.employeeId}
                  onChange={e => setNewRequest({ ...newRequest, employeeId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium"
                >
                  {employees.map(e => (
                    <option key={e.id} value={e.id}>{e.firstName} {e.lastName} ({e.employeeCode})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Leave Type:</label>
                <select
                  value={newRequest.leaveTypeId}
                  onChange={e => setNewRequest({ ...newRequest, leaveTypeId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium"
                >
                  {leaveTypes.map(l => (
                    <option key={l.id} value={l.id}>{l.name} ({l.code})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">From Date:</label>
                  <input
                    type="date"
                    required
                    value={newRequest.startDate}
                    onChange={e => setNewRequest({ ...newRequest, startDate: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">To Date:</label>
                  <input
                    type="date"
                    required
                    value={newRequest.endDate}
                    onChange={e => setNewRequest({ ...newRequest, endDate: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Total Days:</label>
                <input
                  type="number"
                  min="0.5"
                  step="0.5"
                  value={newRequest.days}
                  onChange={e => setNewRequest({ ...newRequest, days: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 font-bold"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Reason for Leave *</label>
                <textarea
                  required
                  rows={2}
                  value={newRequest.reason}
                  onChange={e => setNewRequest({ ...newRequest, reason: e.target.value })}
                  placeholder="Specify brief reason..."
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowApplyModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs cursor-pointer"
                >
                  Submit Application
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

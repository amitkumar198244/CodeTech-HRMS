// RSTPL HRMS - Salary Master & New Code on Wages Compliance Hub
// RS Technovisions XpertSkillCop
// Implements Images 2 & 4 Specifications: Salary Master Schema, New Code on Wages 50% Rule,
// All Challan Text & Excel File Generation, and 7 Statutory Compliance Portal Link Configuration

import React, { useState, useMemo } from 'react';
import {
  DollarSign,
  ShieldCheck,
  FileText,
  Download,
  ExternalLink,
  Plus,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  Building,
  Users,
  Search,
  Filter,
  Calculator,
  Calendar,
  Layers,
  ArrowRight,
  TrendingUp,
  X,
  CreditCard,
  FileCheck,
  Check
} from 'lucide-react';
import { Employee, Department, Unit, Designation, StatutoryComplianceLink } from '../../types/hrms';
import {
  WagesCodeCalculator,
  ChallanFileGenerators,
  DEFAULT_COMPLIANCE_LINKS,
  STATUTORY_COMPONENTS_LIST,
  SalaryBreakdownResult
} from '../../services/wagesCodeEngine';

interface SalaryMasterViewProps {
  employees: Employee[];
  departments: Department[];
  units: Unit[];
  designations: Designation[];
  onUpdateEmployee: (emp: Employee) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
  onNavigateToDocuments?: () => void;
  onNavigateToEmployeeMaster?: () => void;
}

export const SalaryMasterView: React.FC<SalaryMasterViewProps> = ({
  employees,
  departments,
  units,
  designations,
  onUpdateEmployee,
  onLogAudit,
  onNavigateToDocuments,
  onNavigateToEmployeeMaster,
}) => {
  const [activeTab, setActiveTab] = useState<'salary-table' | 'wages-code-audit' | 'challans' | 'statutory-links'>('salary-table');
  const [selectedUnit, setSelectedUnit] = useState<string>('ALL');
  const [selectedDept, setSelectedDept] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedMonth, setSelectedMonth] = useState<string>('October 2026');

  // Statutory Compliance Links State (Persisted in Component State)
  const [complianceLinks, setComplianceLinks] = useState<StatutoryComplianceLink[]>(DEFAULT_COMPLIANCE_LINKS);
  const [editingLink, setEditingLink] = useState<StatutoryComplianceLink | null>(null);
  const [showAddLinkModal, setShowAddLinkModal] = useState<boolean>(false);

  // New Compliance Link Form
  const [newLinkName, setNewLinkName] = useState<string>('Employer PF');
  const [newLinkPortal, setNewLinkPortal] = useState<string>('');
  const [newLinkUrl, setNewLinkUrl] = useState<string>('');
  const [newLinkChallanRef, setNewLinkChallanRef] = useState<string>('');
  const [newLinkDueDate, setNewLinkDueDate] = useState<string>('15th of every month');
  const [newLinkLaw, setNewLinkLaw] = useState<string>('');

  // Salary Revision Modal State
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [editBasic, setEditBasic] = useState<number>(30000);
  const [editHra, setEditHra] = useState<number>(15000);
  const [editConveyance, setEditConveyance] = useState<number>(3000);
  const [editSpecial, setEditSpecial] = useState<number>(12000);
  const [editOther, setEditOther] = useState<number>(0);

  // Calculate salary records for all employees
  const calculatedSalaryRecords: SalaryBreakdownResult[] = useMemo(() => {
    return employees.map(emp => {
      const u = units.find(unit => unit.id === emp.unitId)?.name || 'Corporate Office & HR Center';
      const d = departments.find(dept => dept.id === emp.departmentId)?.name || 'Human Resources & IR';
      const des = designations.find(desig => desig.id === emp.designationId)?.title || 'Senior Specialist';
      return WagesCodeCalculator.calculate(emp, u, d, des);
    });
  }, [employees, units, departments, designations]);

  // Filtered salary records
  const filteredRecords = useMemo(() => {
    return calculatedSalaryRecords.filter(rec => {
      const emp = employees.find(e => e.id === rec.employeeId);
      const matchesSearch =
        rec.employeeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rec.employeeCode.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesUnit = selectedUnit === 'ALL' || (emp && emp.unitId === selectedUnit);
      const matchesDept = selectedDept === 'ALL' || (emp && emp.departmentId === selectedDept);
      return matchesSearch && matchesUnit && matchesDept;
    });
  }, [calculatedSalaryRecords, employees, searchQuery, selectedUnit, selectedDept]);

  // Overall Financial Totals
  const totals = useMemo(() => {
    const gross = filteredRecords.reduce((sum, r) => sum + r.grossSalary, 0);
    const ctc = filteredRecords.reduce((sum, r) => sum + r.ctc, 0);
    const net = filteredRecords.reduce((sum, r) => sum + r.netSalary, 0);
    const erPf = filteredRecords.reduce((sum, r) => sum + r.employerPf, 0);
    const erEsic = filteredRecords.reduce((sum, r) => sum + r.employerEsic, 0);
    const gratuity = filteredRecords.reduce((sum, r) => sum + r.gratuity, 0);
    const eePf = filteredRecords.reduce((sum, r) => sum + r.employeePf, 0);
    const eeEsic = filteredRecords.reduce((sum, r) => sum + r.employeeEsic, 0);
    const pt = filteredRecords.reduce((sum, r) => sum + r.professionalTax, 0);
    const tds = filteredRecords.reduce((sum, r) => sum + r.tds, 0);
    const nonCompliantCount = filteredRecords.filter(r => !r.isWageCodeCompliant).length;

    return { gross, ctc, net, erPf, erEsic, gratuity, eePf, eeEsic, pt, tds, nonCompliantCount };
  }, [filteredRecords]);

  // Open Salary Revision Modal
  const handleOpenSalaryEdit = (rec: SalaryBreakdownResult) => {
    const emp = employees.find(e => e.id === rec.employeeId);
    if (!emp) return;
    setEditingEmployee(emp);
    setEditBasic(rec.basicSalary);
    setEditHra(rec.hra);
    setEditConveyance(rec.conveyance);
    setEditSpecial(rec.specialAllowance);
    setEditOther(rec.otherAllowance);
  };

  // Save Salary Revision
  const handleSaveSalaryRevision = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmployee) return;

    const gross = editBasic + editHra + editConveyance + editSpecial + editOther;
    const allowances = editHra + editConveyance + editSpecial + editOther;
    const maxAllowances = gross * 0.50;
    const excess = Math.max(0, Math.round(allowances - maxAllowances));
    const wageBase = editBasic + excess;

    const pfEe = editingEmployee.pfApplicable !== false ? Math.round(wageBase * 0.12) : 0;
    const esicEe = editingEmployee.esicApplicable !== false && gross <= 21000 ? Math.round(gross * 0.0075) : 0;
    const pt = gross > 10000 ? 200 : (gross > 7500 ? 175 : 0);
    const net = gross - (pfEe + esicEe + pt);

    const updatedEmp: Employee = {
      ...editingEmployee,
      basicMonthly: editBasic,
      hraMonthly: editHra,
      conveyanceMonthly: editConveyance,
      specialAllowanceMonthly: editSpecial,
      otherAllowanceMonthly: editOther,
      netSalaryMonthly: net,
      salaryEffectiveFrom: new Date().toISOString().split('T')[0],
      salaryRevisionDate: new Date().toISOString().split('T')[0],
      salaryStatus: 'Revised',
    };

    onUpdateEmployee(updatedEmp);
    setEditingEmployee(null);
    onLogAudit('UPDATE', 'Salary Master', `Revised salary for ${updatedEmp.employeeCode} (${updatedEmp.firstName} ${updatedEmp.lastName}) to Gross: ₹${gross.toLocaleString('en-IN')}`);
  };

  // Save edited compliance link
  const handleSaveLinkEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLink) return;

    setComplianceLinks(prev =>
      prev.map(l => (l.id === editingLink.id ? editingLink : l))
    );
    onLogAudit('UPDATE', 'Statutory Compliance', `Updated compliance link for ${editingLink.name} with URL ${editingLink.customUrl || editingLink.defaultUrl}`);
    setEditingLink(null);
  };

  // Add new compliance link
  const handleAddNewLink = (e: React.FormEvent) => {
    e.preventDefault();
    const newLink: StatutoryComplianceLink = {
      id: `link-${Date.now()}`,
      name: newLinkName,
      componentType: newLinkName.includes('TDS') ? 'Tax' : 'Statutory',
      category: newLinkName.startsWith('Employer') ? 'Employer' : newLinkName.startsWith('Employee') ? 'Employee' : 'State',
      portalName: newLinkPortal || `${newLinkName} Official Government Portal`,
      defaultUrl: newLinkUrl || 'https://www.india.gov.in/',
      customUrl: newLinkUrl,
      challanRefNo: newLinkChallanRef,
      dueDate: newLinkDueDate,
      status: 'Compliant',
      applicableLaw: newLinkLaw || 'Relevant Indian Labor & Tax Statute',
      description: `Official electronic filing and return portal for ${newLinkName}.`,
    };

    setComplianceLinks(prev => [...prev, newLink]);
    setShowAddLinkModal(false);
    onLogAudit('CREATE', 'Statutory Compliance', `Added custom statutory compliance portal link for ${newLinkName}`);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Masters Navigation */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="p-2.5 rounded-xl bg-sky-100 text-sky-800">
              <DollarSign className="w-6 h-6 text-sky-700" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900 tracking-tight">Salary Master</h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
                  New Code on Wages 2019/2026
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  All Challans & Return Files
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Centralized remuneration schedule with automated Code on Wages calculations, PF/ESIC/PT/TDS challans & statutory portal integration
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onNavigateToEmployeeMaster && (
              <button
                type="button"
                onClick={onNavigateToEmployeeMaster}
                className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 transition cursor-pointer flex items-center gap-1.5"
              >
                <Users className="w-3.5 h-3.5 text-slate-500" />
                <span>Employee Master</span>
              </button>
            )}
            {onNavigateToDocuments && (
              <button
                type="button"
                onClick={onNavigateToDocuments}
                className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 transition cursor-pointer flex items-center gap-1.5"
              >
                <FileCheck className="w-3.5 h-3.5 text-purple-600" />
                <span>Documents Master</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                const csv = ChallanFileGenerators.generateSalaryMasterFullCsv(employees);
                ChallanFileGenerators.downloadFile(csv, `RSTPL_Salary_Master_Image2_${new Date().toISOString().split('T')[0]}.csv`, 'text/csv');
              }}
              className="px-3 py-2 rounded-xl bg-sky-600 text-white text-xs font-bold hover:bg-sky-700 transition shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Salary Master CSV</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 mt-5 pt-4 border-t border-slate-100 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('salary-table')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'salary-table'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Salary Master Grid (Image 2)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('wages-code-audit')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'wages-code-audit'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>Code on Wages 50% Rule & Components (Image 4)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('challans')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'challans'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Generate Challans (Text & Excel)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('statutory-links')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'statutory-links'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <ExternalLink className="w-4 h-4" />
            <span>Statutory Compliance Links ({complianceLinks.length})</span>
          </button>
        </div>
      </div>

      {/* KPI Financial Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">Total Monthly CTC</span>
          <p className="text-lg font-black text-slate-900 mt-0.5 font-mono">
            ₹{totals.ctc.toLocaleString('en-IN')}
          </p>
          <span className="text-[10px] text-slate-500 block mt-0.5">Across {filteredRecords.length} Employees</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">Monthly Gross Salary</span>
          <p className="text-lg font-black text-sky-700 mt-0.5 font-mono">
            ₹{totals.gross.toLocaleString('en-IN')}
          </p>
          <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">
            {totals.nonCompliantCount === 0 ? '100% Wage Code Compliant' : `${totals.nonCompliantCount} Adjusted for 50% Rule`}
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">Net Take-Home Salary</span>
          <p className="text-lg font-black text-emerald-700 mt-0.5 font-mono">
            ₹{totals.net.toLocaleString('en-IN')}
          </p>
          <span className="text-[10px] text-slate-500 block mt-0.5">Bank Transfer Disbursement Total</span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase text-slate-400 block">Statutory Employer Liability</span>
          <p className="text-lg font-black text-purple-700 mt-0.5 font-mono">
            ₹{(totals.erPf + totals.erEsic + totals.gratuity).toLocaleString('en-IN')}
          </p>
          <span className="text-[10px] text-purple-700 font-bold block mt-0.5">PF + ESIC + Gratuity Provision</span>
        </div>
      </div>

      {/* TAB 1: SALARY MASTER GRID (MATCHING IMAGE 2 EXACT COLUMNS) */}
      {activeTab === 'salary-table' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-5 relative">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by Employee Code, Name or Designation..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div className="sm:col-span-4">
                <select
                  value={selectedUnit}
                  onChange={e => setSelectedUnit(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-sky-500 font-medium"
                >
                  <option value="ALL">All Units / Plants ({units.length})</option>
                  {units.map(u => (
                    <option key={u.id} value={u.id}>{u.name} ({u.code})</option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-3">
                <select
                  value={selectedDept}
                  onChange={e => setSelectedDept(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-sky-500 font-medium"
                >
                  <option value="ALL">All Departments ({departments.length})</option>
                  {departments.map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Complete 30-Column Master Table as per Image 2 */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                  Salary Master Records Table (Image 2 Full Specification)
                </h3>
                <p className="text-[11px] text-slate-500">
                  Showing {filteredRecords.length} employee records with all earnings, employer statutory, employee deductions, and bank transfer amounts
                </p>
              </div>
              <span className="text-[10px] font-mono text-slate-400">Horizontal scroll enabled for all 30 columns</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-900 text-white font-bold uppercase text-[10px] tracking-wider whitespace-nowrap">
                  <tr>
                    <th className="py-3 px-3">S. No.</th>
                    <th className="py-3 px-3">Employee Code</th>
                    <th className="py-3 px-3">Employee Name</th>
                    <th className="py-3 px-3">Unit Name</th>
                    <th className="py-3 px-3">Department Name</th>
                    <th className="py-3 px-3">Designation</th>
                    <th className="py-3 px-3">Salary Effective From</th>
                    <th className="py-3 px-3">Salary Revision Date</th>
                    <th className="py-3 px-3">Pay Type</th>
                    <th className="py-3 px-3 bg-sky-950 text-sky-300">Basic Salary</th>
                    <th className="py-3 px-3 bg-sky-950 text-sky-300">HRA</th>
                    <th className="py-3 px-3 bg-sky-950 text-sky-300">Conveyance</th>
                    <th className="py-3 px-3 bg-sky-950 text-sky-300">Special Allowance</th>
                    <th className="py-3 px-3 bg-sky-950 text-sky-300">Other Allowance</th>
                    <th className="py-3 px-3 bg-sky-900 text-white font-black">Gross Salary</th>
                    <th className="py-3 px-3 bg-indigo-950 text-indigo-300">Employer PF</th>
                    <th className="py-3 px-3 bg-indigo-950 text-indigo-300">Employer ESIC</th>
                    <th className="py-3 px-3 bg-indigo-950 text-indigo-300">Gratuity</th>
                    <th className="py-3 px-3 bg-indigo-950 text-indigo-300">Other Employer Cost</th>
                    <th className="py-3 px-3 bg-indigo-900 text-white font-black">CTC</th>
                    <th className="py-3 px-3 bg-rose-950 text-rose-300">Employee PF</th>
                    <th className="py-3 px-3 bg-rose-950 text-rose-300">Employee ESIC</th>
                    <th className="py-3 px-3 bg-rose-950 text-rose-300">Professional Tax</th>
                    <th className="py-3 px-3 bg-rose-950 text-rose-300">TDS</th>
                    <th className="py-3 px-3 bg-rose-950 text-rose-300">Other Deduction</th>
                    <th className="py-3 px-3 bg-rose-900 text-white font-black">Total Deduction</th>
                    <th className="py-3 px-3 bg-emerald-950 text-emerald-300 font-black">Net Salary</th>
                    <th className="py-3 px-3 bg-emerald-900 text-white font-black">Bank Transfer Amount</th>
                    <th className="py-3 px-3">Salary Status</th>
                    <th className="py-3 px-3">Remarks</th>
                    <th className="py-3 px-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700 whitespace-nowrap">
                  {filteredRecords.map((r, idx) => (
                    <tr key={r.employeeId} className="hover:bg-slate-50 transition-colors">
                      <td className="py-2.5 px-3 font-mono text-slate-400 text-center">{idx + 1}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-sky-700">{r.employeeCode}</td>
                      <td className="py-2.5 px-3 font-bold text-slate-900">{r.employeeName}</td>
                      <td className="py-2.5 px-3">{r.unitName}</td>
                      <td className="py-2.5 px-3">{r.departmentName}</td>
                      <td className="py-2.5 px-3 text-slate-600">{r.designation}</td>
                      <td className="py-2.5 px-3 font-mono text-[11px]">{r.salaryEffectiveFrom}</td>
                      <td className="py-2.5 px-3 font-mono text-[11px]">{r.salaryRevisionDate}</td>
                      <td className="py-2.5 px-3 font-semibold">{r.payType}</td>
                      <td className="py-2.5 px-3 font-mono bg-sky-50/50">₹{r.basicSalary.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-sky-50/50">₹{r.hra.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-sky-50/50">₹{r.conveyance.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-sky-50/50">₹{r.specialAllowance.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-sky-50/50">₹{r.otherAllowance.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-sky-800 bg-sky-100/60">₹{r.grossSalary.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-indigo-50/50">₹{r.employerPf.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-indigo-50/50">₹{r.employerEsic.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-indigo-50/50">₹{r.gratuity.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-indigo-50/50">₹{r.otherEmployerCost.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-indigo-900 bg-indigo-100/70">₹{r.ctc.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-rose-50/50">₹{r.employeePf.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-rose-50/50">₹{r.employeeEsic.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-rose-50/50">₹{r.professionalTax.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-rose-50/50">₹{r.tds.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono bg-rose-50/50">₹{r.otherDeduction.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-rose-800 bg-rose-100/60">₹{r.totalDeduction.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-emerald-800 bg-emerald-50/60">₹{r.netSalary.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3 font-mono font-black text-emerald-900 bg-emerald-100/70">₹{r.bankTransferAmount.toLocaleString('en-IN')}</td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          {r.salaryStatus}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-[11px] text-slate-500 max-w-44 truncate" title={r.remarks}>{r.remarks}</td>
                      <td className="py-2.5 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleOpenSalaryEdit(r)}
                          className="px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 font-bold text-[11px] transition cursor-pointer"
                        >
                          Revise
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: CODE ON WAGES 50% RULE AUDIT & 12 COMPONENTS (IMAGE 4) */}
      {activeTab === 'wages-code-audit' && (
        <div className="space-y-6">
          {/* Rule Explainer Card */}
          <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center gap-2">
              <Calculator className="w-5 h-5 text-sky-700" />
              <div>
                <h3 className="text-sm font-black text-slate-900">
                  New Code on Wages 2019/2026: 50% Wage Definition & 12 Core Components
                </h3>
                <p className="text-xs text-slate-500">
                  Statutory wage calculation mandates that Basic Salary must constitute at least 50% of the Gross Remuneration.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-3.5 rounded-xl bg-sky-50 border border-sky-100 space-y-1.5">
                <span className="font-black text-sky-900 uppercase text-[10px] block">1. The 50% Rule Principle</span>
                <p className="text-slate-700 leading-relaxed">
                  Total allowances (HRA, Conveyance, Special Allowance, Other Allowance) cannot exceed 50% of total gross salary. This prevents artificial wage dilution.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-purple-50 border border-purple-100 space-y-1.5">
                <span className="font-black text-purple-900 uppercase text-[10px] block">2. Automatic Wage Base Adjustment</span>
                <p className="text-slate-700 leading-relaxed">
                  If allowances exceed 50% of Gross, the surplus amount is legally added to the Statutory Wage Base for computing PF, ESIC & Gratuity contributions!
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-100 space-y-1.5">
                <span className="font-black text-emerald-900 uppercase text-[10px] block">3. Statutory Contributions</span>
                <p className="text-slate-700 leading-relaxed">
                  PF (12% EE + 12% ER), ESIC (0.75% EE + 3.25% ER if gross &le; ₹21,000), and Gratuity provision (4.81% monthly) are computed on the adjusted wage base.
                </p>
              </div>
            </div>
          </div>

          {/* 12 Salary Master Components Table (Exact Match to Image 4) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                  Configured Salary Master Components (Image 4 Specification)
                </h4>
                <p className="text-[11px] text-slate-500">All 12 Standard Components and their Statutory/Allowance Classifications</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 font-mono">
                12 Components Configured
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-4 w-12 text-center">#</th>
                    <th className="py-2.5 px-4">Component Name</th>
                    <th className="py-2.5 px-4">Component Type</th>
                    <th className="py-2.5 px-4">Classification</th>
                    <th className="py-2.5 px-4">Statutory Basis / Rate</th>
                    <th className="py-2.5 px-4">Wage Code 50% Rule Impact</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {STATUTORY_COMPONENTS_LIST.map((comp, idx) => (
                    <tr key={comp.name} className="hover:bg-slate-50">
                      <td className="py-2.5 px-4 font-mono text-slate-400 text-center">{idx + 1}</td>
                      <td className="py-2.5 px-4 font-bold text-slate-900">{comp.name}</td>
                      <td className="py-2.5 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          comp.type === 'Salary'
                            ? 'bg-sky-100 text-sky-800'
                            : comp.type === 'Allowance'
                            ? 'bg-amber-100 text-amber-800'
                            : comp.type === 'Statutory'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}>
                          {comp.type}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-slate-600 font-medium">{comp.category}</td>
                      <td className="py-2.5 px-4 text-[11px] text-slate-500">
                        {comp.name === 'Basic Salary' && 'Core statutory wage base for retirement & insurance benefits'}
                        {comp.name === 'HRA' && 'House rent allowance (capped under 50% aggregate allowance rule)'}
                        {comp.name === 'Conveyance' && 'Fixed travel allowance for daily official commute'}
                        {comp.name === 'Special Allowance' && 'Performance or role allowance (subject to 50% threshold)'}
                        {comp.name === 'Other Allowance' && 'Medical / books / uniform reimbursements'}
                        {comp.name === 'Employer PF' && '12% of Wage Base (3.67% EPF + 8.33% EPS capped at ₹1,250 + EDLI)'}
                        {comp.name === 'Employer ESIC' && '3.25% of Gross Wages (applicable if Gross &le; ₹21,000/month)'}
                        {comp.name === 'Gratuity' && '15 days wage per year of service: (15/26) * Wage / 12 ~ 4.81% monthly'}
                        {comp.name === 'Employee PF' && '12% deduction from Wage Base credited to Universal Account Number (UAN)'}
                        {comp.name === 'Employee ESIC' && '0.75% deduction for covered employees providing full healthcare access'}
                        {comp.name === 'Professional Tax' && 'State statutory levy (Maharashtra / Gujarat standard ₹200/month)'}
                        {comp.name === 'TDS' && 'Tax Deducted at Source under Section 192 of Income Tax Act 1961'}
                      </td>
                      <td className="py-2.5 px-4">
                        {comp.type === 'Salary' && (
                          <span className="text-[10px] font-bold text-emerald-700">Must be &ge; 50% of Gross</span>
                        )}
                        {comp.type === 'Allowance' && (
                          <span className="text-[10px] font-bold text-amber-700">Aggregate &le; 50% of Gross</span>
                        )}
                        {comp.type === 'Statutory' && (
                          <span className="text-[10px] font-bold text-purple-700">Computed on Adjusted Wage Base</span>
                        )}
                        {comp.type === 'Tax' && (
                          <span className="text-[10px] font-bold text-slate-500">Calculated on Taxable Income</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CHALLANS (TEXT & EXCEL) GENERATION */}
      {activeTab === 'challans' && (
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
            <div className="flex items-center gap-2">
              <Download className="w-5 h-5 text-sky-700" />
              <div>
                <h3 className="text-sm font-black text-slate-900">
                  Government Challan Return Files & Bank Disbursement Files Generator
                </h3>
                <p className="text-xs text-slate-500">
                  Generate official government-compatible text files and Excel spreadsheets directly from this HRMS with one click
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* 1. EPFO ECR Text File */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 font-mono">
                    EPFO ECR 2.0 (.txt)
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">#~# Delimited</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-2">EPFO ECR Challan Text File</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Standard Electronic Challan cum Return text file for direct upload to EPFO Unified Employer Portal with UAN, Gross, EPF, EPS and EE/ER shares.
                </p>
                <div className="mt-3 p-2 bg-slate-50 rounded-xl font-mono text-[10px] text-slate-600 truncate">
                  Format: UAN#~#NAME#~#GROSS#~#EPF#~#EPS#~#EE#~#ER_EPS#~#ER_EPF#~#0#~#0
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const txt = ChallanFileGenerators.generateEpfoEcrText(employees, selectedMonth);
                    ChallanFileGenerators.downloadFile(txt, `EPFO_ECR_Challan_${selectedMonth.replace(/\s+/g, '_')}.txt`, 'text/plain');
                    onLogAudit('EXPORT', 'Statutory Challans', `Generated EPFO ECR Text File for ${selectedMonth}`);
                  }}
                  className="flex-1 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .txt</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const csv = ChallanFileGenerators.generateEpfoEcrCsv(employees, selectedMonth);
                    ChallanFileGenerators.downloadFile(csv, `EPFO_ECR_Schedule_${selectedMonth.replace(/\s+/g, '_')}.csv`, 'text/csv');
                    onLogAudit('EXPORT', 'Statutory Challans', `Generated EPFO ECR Excel/CSV for ${selectedMonth}`);
                  }}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                  title="Download in Excel/CSV"
                >
                  <span>.csv</span>
                </button>
              </div>
            </div>

            {/* 2. ESIC Monthly Return */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-800 font-mono">
                    ESIC Portal (.csv / .xlsx)
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">Monthly Return</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-2">ESIC Monthly Return File</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Monthly contribution schedule with IP Number, employee wages, 0.75% EE share, and 3.25% ER share for employees with gross &le; ₹21,000.
                </p>
                <div className="mt-3 p-2 bg-slate-50 rounded-xl font-mono text-[10px] text-slate-600 truncate">
                  IP_NO,NAME,DAYS_WORKED,TOTAL_WAGES,EE_0.75,ER_3.25,TOTAL_4.0
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    const csv = ChallanFileGenerators.generateEsicReturnCsv(employees, selectedMonth);
                    ChallanFileGenerators.downloadFile(csv, `ESIC_Monthly_Return_${selectedMonth.replace(/\s+/g, '_')}.csv`, 'text/csv');
                    onLogAudit('EXPORT', 'Statutory Challans', `Generated ESIC Monthly Return for ${selectedMonth}`);
                  }}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download ESIC File (.csv / Excel)</span>
                </button>
              </div>
            </div>

            {/* 3. Professional Tax (PT) Challan */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 font-mono">
                    State PT Portal
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">MahaGST / PT Form</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-2">Professional Tax (PT) Challan</h4>
                <p className="text-xs text-slate-500 mt-1">
                  State-wise monthly PT schedule with employee salary slabs, tax deducted (standard ₹200/mo), and enrollment certificate numbers.
                </p>
                <div className="mt-3 p-2 bg-slate-50 rounded-xl font-mono text-[10px] text-slate-600 truncate">
                  SNO,EMP_CODE,NAME,UNIT,GROSS,PT_SLAB,PT_DEDUCTED
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    const csv = ChallanFileGenerators.generatePtReturnCsv(employees, selectedMonth);
                    ChallanFileGenerators.downloadFile(csv, `PT_Challan_Return_${selectedMonth.replace(/\s+/g, '_')}.csv`, 'text/csv');
                    onLogAudit('EXPORT', 'Statutory Challans', `Generated Professional Tax Return for ${selectedMonth}`);
                  }}
                  className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download PT Challan (.csv / Excel)</span>
                </button>
              </div>
            </div>

            {/* 4. TDS 24Q Quarterly Return File */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 font-mono">
                    Income Tax Form 24Q
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">NSDL e-TDS</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-2">TDS 24Q Salary Return File</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Quarterly Annexure-I file containing employee PANs, gross taxable salary, Section 192 TDS deduction, and BSR challan references.
                </p>
                <div className="mt-3 p-2 bg-slate-50 rounded-xl font-mono text-[10px] text-slate-600 truncate">
                  BSR,PAN,NAME,SECTION_192,PAYMENT_DATE,GROSS,TDS_AMT
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    const csv = ChallanFileGenerators.generateTds24QCsv(employees, 'Q2 FY 2026-27');
                    ChallanFileGenerators.downloadFile(csv, `TDS_Form24Q_Return_${selectedMonth.replace(/\s+/g, '_')}.csv`, 'text/csv');
                    onLogAudit('EXPORT', 'Statutory Challans', `Generated TDS Form 24Q File for ${selectedMonth}`);
                  }}
                  className="w-full py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download TDS 24Q File (.csv / Excel)</span>
                </button>
              </div>
            </div>

            {/* 5. Bank NEFT / RTGS Transfer File */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 font-mono">
                    Bank Direct Transfer
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">NEFT / RTGS Batch</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-2">Bank NEFT/RTGS Batch File</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Corporate net banking bulk upload file with beneficiary account number, IFSC code, employee name, and exact net take-home salary.
                </p>
                <div className="mt-3 p-2 bg-slate-50 rounded-xl font-mono text-[10px] text-slate-600 truncate">
                  ACCOUNT_NO,IFSC,BENEFICIARY_NAME,NET_SALARY,NARRATION
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    const csv = ChallanFileGenerators.generateBankDisbursementCsv(employees, selectedMonth);
                    ChallanFileGenerators.downloadFile(csv, `Bank_Disbursement_NEFT_${selectedMonth.replace(/\s+/g, '_')}.csv`, 'text/csv');
                    onLogAudit('EXPORT', 'Bank Transfer', `Generated Bank NEFT/RTGS Batch File for ${selectedMonth}`);
                  }}
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Bank Batch File (.csv)</span>
                </button>
              </div>
            </div>

            {/* 6. Complete Salary Master Image 2 Export */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 font-mono">
                    Full Master (Image 2)
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">30 Columns</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-2">Master Salary Register Export</h4>
                <p className="text-xs text-slate-500 mt-1">
                  Exhaustive salary master spreadsheet including all 30 columns from Image 2: Basic, HRA, Conveyance, Special, PF, ESIC, PT, Gratuity, and CTC.
                </p>
                <div className="mt-3 p-2 bg-slate-50 rounded-xl font-mono text-[10px] text-slate-600 truncate">
                  SNO,EMP_CODE,NAME,UNIT,DEPT,DESIG,EFFECTIVE,BASIC,HRA...
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    const csv = ChallanFileGenerators.generateSalaryMasterFullCsv(employees);
                    ChallanFileGenerators.downloadFile(csv, `Salary_Master_Full_Image2_${new Date().toISOString().split('T')[0]}.csv`, 'text/csv');
                    onLogAudit('EXPORT', 'Salary Master', `Exported full Image 2 Salary Master Spreadsheet`);
                  }}
                  className="w-full py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Full Master CSV</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: STATUTORY COMPLIANCE LINKS (7 SPECIFIED ITEMS + OPTION TO ADD/EDIT) */}
      {activeTab === 'statutory-links' && (
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <ExternalLink className="w-5 h-5 text-sky-700" />
                <h3 className="text-sm font-black text-slate-900">
                  Statutory Compliance Links & Filing Portals Configuration
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Official government portal links for the 7 mandatory statutory compliances. Add custom URLs, Challan TRRN reference numbers, and launch portals directly.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowAddLinkModal(true)}
              className="px-3.5 py-2 bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Custom Statutory Link</span>
            </button>
          </div>

          {/* Cards for each of the 7 compliances requested by user */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {complianceLinks.map(link => (
              <div key={link.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 font-mono">
                      {link.componentType} ({link.category})
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                      {link.status}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900">{link.name}</h4>
                  <p className="text-xs font-medium text-slate-700">{link.portalName}</p>
                  <p className="text-[11px] text-slate-500 leading-relaxed">{link.description}</p>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] uppercase font-bold text-slate-400">Portal URL:</span>
                      <a
                        href={link.customUrl || link.defaultUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-sky-600 hover:underline font-mono text-[11px] truncate max-w-56"
                      >
                        {link.customUrl || link.defaultUrl}
                      </a>
                    </div>
                    {link.challanRefNo && (
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] uppercase font-bold text-slate-400">Challan / TRRN No:</span>
                        <span className="font-mono text-slate-800 font-bold">{link.challanRefNo}</span>
                      </div>
                    )}
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] uppercase font-bold text-slate-400">Statutory Due Date:</span>
                      <span className="text-amber-800 font-semibold">{link.dueDate}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <a
                    href={link.customUrl || link.defaultUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Launch Portal</span>
                  </a>

                  <button
                    type="button"
                    onClick={() => setEditingLink(link)}
                    className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5 text-slate-400" />
                    <span>Edit Link / TRRN</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: EDIT STATUTORY COMPLIANCE LINK */}
      {editingLink && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <ExternalLink className="w-4 h-4 text-sky-700" />
                <h4 className="text-xs font-black uppercase text-slate-900">
                  Edit Compliance Link: {editingLink.name}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setEditingLink(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveLinkEdit} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Portal Name</label>
                <input
                  type="text"
                  value={editingLink.portalName}
                  onChange={e => setEditingLink({ ...editingLink, portalName: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Custom Portal URL / Link</label>
                <input
                  type="url"
                  value={editingLink.customUrl || editingLink.defaultUrl}
                  onChange={e => setEditingLink({ ...editingLink, customUrl: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-[11px]"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Challan Ref / TRRN Number</label>
                <input
                  type="text"
                  value={editingLink.challanRefNo || ''}
                  onChange={e => setEditingLink({ ...editingLink, challanRefNo: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  placeholder="e.g. TRRN-202610-PF-984412"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Filing Due Date</label>
                <input
                  type="text"
                  value={editingLink.dueDate}
                  onChange={e => setEditingLink({ ...editingLink, dueDate: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Filing Status</label>
                <select
                  value={editingLink.status}
                  onChange={e => setEditingLink({ ...editingLink, status: e.target.value as any })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                >
                  <option value="Compliant">Compliant / Active</option>
                  <option value="Pending">Pending Filing</option>
                  <option value="Challan Generated">Challan Generated</option>
                  <option value="Paid">Paid & Acknowledged</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingLink(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold cursor-pointer shadow-xs"
                >
                  Save Link Details
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD CUSTOM STATUTORY LINK */}
      {showAddLinkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-sky-700" />
                <h4 className="text-xs font-black uppercase text-slate-900">
                  Add Custom Statutory Compliance Link
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowAddLinkModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddNewLink} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Compliance Name</label>
                <input
                  type="text"
                  value={newLinkName}
                  onChange={e => setNewLinkName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  placeholder="e.g. Factory License Compliance / LWF"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Portal Name</label>
                <input
                  type="text"
                  value={newLinkPortal}
                  onChange={e => setNewLinkPortal(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  placeholder="e.g. Maharashtra Labor Welfare Fund Portal"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Official Portal URL</label>
                <input
                  type="url"
                  value={newLinkUrl}
                  onChange={e => setNewLinkUrl(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-[11px]"
                  placeholder="https://..."
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Challan Ref / TRRN Number</label>
                <input
                  type="text"
                  value={newLinkChallanRef}
                  onChange={e => setNewLinkChallanRef(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  placeholder="Optional reference code"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Filing Due Date</label>
                <input
                  type="text"
                  value={newLinkDueDate}
                  onChange={e => setNewLinkDueDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Governing Act / Law</label>
                <input
                  type="text"
                  value={newLinkLaw}
                  onChange={e => setNewLinkLaw(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  placeholder="e.g. Labor Welfare Fund Act"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddLinkModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold cursor-pointer shadow-xs"
                >
                  Add Link
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: SALARY REVISION & WAGE CODE SIMULATOR */}
      {editingEmployee && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Calculator className="w-4 h-4 text-sky-700" />
                <h4 className="text-xs font-black uppercase text-slate-900">
                  Revise Salary: {editingEmployee.employeeCode} - {editingEmployee.firstName} {editingEmployee.lastName}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setEditingEmployee(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSalaryRevision} className="p-5 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Basic Salary (₹)</label>
                  <input
                    type="number"
                    value={editBasic}
                    onChange={e => setEditBasic(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">HRA (₹)</label>
                  <input
                    type="number"
                    value={editHra}
                    onChange={e => setEditHra(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Conveyance Allowance (₹)</label>
                  <input
                    type="number"
                    value={editConveyance}
                    onChange={e => setEditConveyance(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Special Allowance (₹)</label>
                  <input
                    type="number"
                    value={editSpecial}
                    onChange={e => setEditSpecial(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    required
                  />
                </div>

                <div className="col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">Other Allowance (₹)</label>
                  <input
                    type="number"
                    value={editOther}
                    onChange={e => setEditOther(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              {/* Live 50% Rule Preview */}
              {(() => {
                const totalGross = editBasic + editHra + editConveyance + editSpecial + editOther;
                const totalAllowances = editHra + editConveyance + editSpecial + editOther;
                const isCompliant = editBasic >= totalGross * 0.50;
                const excess = Math.max(0, Math.round(totalAllowances - totalGross * 0.50));

                return (
                  <div className={`p-3 rounded-xl border text-xs space-y-1 ${
                    isCompliant ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-amber-50 border-amber-200 text-amber-900'
                  }`}>
                    <div className="flex justify-between font-bold">
                      <span>Total Gross Salary:</span>
                      <span className="font-mono">₹{totalGross.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Basic Proportion:</span>
                      <span className="font-mono font-bold">
                        {totalGross > 0 ? ((editBasic / totalGross) * 100).toFixed(1) : 0}% of Gross
                      </span>
                    </div>
                    <div className="flex justify-between pt-1 border-t border-slate-200/50">
                      <span>Code on Wages Status:</span>
                      <span className="font-bold">
                        {isCompliant ? 'Compliant (Basic >= 50%)' : `Adjusted (+₹${excess} added to Statutory Wage Base)`}
                      </span>
                    </div>
                  </div>
                );
              })()}

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingEmployee(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold cursor-pointer shadow-xs"
                >
                  Save Salary Revision
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// RSTPL HRMS - Modular Payroll Processing Engine & Payslips
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  DollarSign,
  Play,
  CheckCircle2,
  Lock,
  Download,
  Printer,
  FileText,
  Sliders,
  ChevronRight,
  TrendingUp,
  ShieldCheck,
  Eye,
  X
} from 'lucide-react';
import { PayrollRun, Payslip, Employee, AttendanceRecord } from '../../types/hrms';
import { PayrollProcessingEngine, DEFAULT_STATUTORY_CONFIG } from '../../services/payrollEngine';

interface PayrollEngineViewProps {
  payrollRuns: PayrollRun[];
  payslips: Payslip[];
  employees: Employee[];
  attendance: AttendanceRecord[];
  onUpdatePayrollRuns: (runs: PayrollRun[]) => void;
  onUpdatePayslips: (slips: Payslip[]) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
}

export const PayrollEngineView: React.FC<PayrollEngineViewProps> = ({
  payrollRuns,
  payslips,
  employees,
  attendance,
  onUpdatePayrollRuns,
  onUpdatePayslips,
  onLogAudit,
}) => {
  const [selectedRun, setSelectedRun] = useState<PayrollRun>(payrollRuns[0]);
  const [calculating, setCalculating] = useState(false);
  const [viewingPayslip, setViewingPayslip] = useState<Payslip | null>(null);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [statutoryConfig, setStatutoryConfig] = useState(DEFAULT_STATUTORY_CONFIG);

  // Filter payslips for the selected run
  const activePayslips = payslips.filter(p => p.payrollRunId === selectedRun.id);

  // 1. Process / Calculate Payroll for October 2026
  const handleCalculatePayroll = () => {
    setCalculating(true);
    setTimeout(() => {
      const generatedSlips: Payslip[] = employees.map(emp => {
        // Count unpaid absences from attendance
        const empAtt = attendance.filter(a => a.employeeId === emp.id);
        const absentCount = empAtt.filter(a => a.status === 'Absent').length;
        const totalOT = empAtt.reduce((sum, a) => sum + (a.isOvertime ? a.overtimeHours : 0), 0);

        return PayrollProcessingEngine.calculateMonthlyPayslip(
          emp,
          selectedRun.month,
          30,
          absentCount,
          totalOT,
          statutoryConfig
        );
      });

      const totalGross = generatedSlips.reduce((sum, s) => sum + s.grossEarnings, 0);
      const totalDed = generatedSlips.reduce((sum, s) => sum + s.totalDeductions, 0);
      const totalNet = generatedSlips.reduce((sum, s) => sum + s.netPayable, 0);

      const updatedRun: PayrollRun = {
        ...selectedRun,
        status: 'Calculated',
        totalEmployees: generatedSlips.length,
        totalGrossPay: totalGross,
        totalDeductions: totalDed,
        totalNetPay: totalNet,
        processedAt: new Date().toISOString(),
      };

      const nextRuns = payrollRuns.map(r => (r.id === selectedRun.id ? updatedRun : r));
      const nextSlips = [
        ...generatedSlips,
        ...payslips.filter(p => p.payrollRunId !== selectedRun.id),
      ];

      onUpdatePayrollRuns(nextRuns);
      onUpdatePayslips(nextSlips);
      setSelectedRun(updatedRun);
      setCalculating(false);
      onLogAudit(
        'UPDATE',
        'Payroll Engine',
        `Calculated payroll for ${selectedRun.month} across ${generatedSlips.length} employees. Total Net: ₹${totalNet.toLocaleString('en-IN')}`
      );
    }, 800);
  };

  // 2. Approve and Lock Payroll Run
  const handleApproveAndLock = () => {
    const updatedRun: PayrollRun = {
      ...selectedRun,
      status: 'Locked',
      approvedBy: 'Amit Sharma (VP HR) & Management',
    };

    const nextRuns = payrollRuns.map(r => (r.id === selectedRun.id ? updatedRun : r));
    onUpdatePayrollRuns(nextRuns);
    setSelectedRun(updatedRun);
    onLogAudit('FINALIZE', 'Payroll Engine', `Approved and Locked Payroll for ${selectedRun.month}.`);
  };

  // 3. Print Payslip
  const handlePrintSlip = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <DollarSign className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                Modular Indian Payroll Engine
              </h2>
              <p className="text-xs text-slate-500">
                Statutory compliance (EPF 12%, ESIC 0.75%, PT, TDS), automated LOP deduction & payslip distribution
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setShowConfigModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 rounded-xl border border-slate-200 transition-colors cursor-pointer"
          >
            <Sliders className="w-3.5 h-3.5 text-slate-500" />
            <span>Statutory Slabs</span>
          </button>

          {selectedRun.status !== 'Locked' ? (
            <>
              <button
                onClick={handleCalculatePayroll}
                disabled={calculating}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition-colors cursor-pointer disabled:opacity-50"
              >
                <Play className={`w-3.5 h-3.5 ${calculating ? 'animate-spin' : ''}`} />
                <span>Calculate {selectedRun.month}</span>
              </button>

              {selectedRun.status === 'Calculated' && (
                <button
                  onClick={handleApproveAndLock}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Approve & Lock Run</span>
                </button>
              )}
            </>
          ) : (
            <span className="px-3 py-1.5 rounded-xl bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center gap-1.5 border border-emerald-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Payroll Locked & Disbursed</span>
            </span>
          )}
        </div>
      </div>

      {/* Selected Run Financial Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Payroll Cycle</span>
          <p className="text-xl font-black text-slate-900 mt-1">{selectedRun.month}</p>
          <span className="inline-block mt-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-sky-100 text-sky-800">
            {selectedRun.status}
          </span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Gross Earnings</span>
          <p className="text-xl font-black text-slate-900 mt-1">
            ₹{selectedRun.totalGrossPay.toLocaleString('en-IN')}
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">Basic + HRA + Allowances</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Deductions</span>
          <p className="text-xl font-black text-rose-600 mt-1">
            ₹{selectedRun.totalDeductions.toLocaleString('en-IN')}
          </p>
          <p className="text-[10px] text-rose-500 mt-0.5">PF, ESIC, PT, TDS</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Net Employee Payout</span>
          <p className="text-xl font-black text-emerald-600 mt-1">
            ₹{selectedRun.totalNetPay.toLocaleString('en-IN')}
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">{selectedRun.totalEmployees} personnel covered</p>
        </div>
      </div>

      {/* Payslips Roster Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Calculated Salary Slips</h3>
            <p className="text-[11px] text-slate-500">Employee-level breakdown of earnings and statutory deductions</p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500">Cycle:</span>
            <select
              value={selectedRun.id}
              onChange={e => {
                const found = payrollRuns.find(r => r.id === e.target.value);
                if (found) setSelectedRun(found);
              }}
              className="text-xs px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-800"
            >
              {payrollRuns.map(r => (
                <option key={r.id} value={r.id}>{r.month} ({r.status})</option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Code</th>
                <th className="py-3 px-4">Payable Days</th>
                <th className="py-3 px-4">Gross Pay</th>
                <th className="py-3 px-4">PF (12%)</th>
                <th className="py-3 px-4">PT / TDS</th>
                <th className="py-3 px-4">Total Ded.</th>
                <th className="py-3 px-4">Net Payable</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {activePayslips.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    No payslips calculated for {selectedRun.month} yet. Click "Calculate {selectedRun.month}" above.
                  </td>
                </tr>
              ) : (
                activePayslips.map(ps => (
                  <tr key={ps.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-900">{ps.employeeName}</td>
                    <td className="py-3 px-4 font-mono text-slate-500">{ps.employeeCode}</td>
                    <td className="py-3 px-4 font-bold text-slate-800">{ps.payableDays} / 30</td>
                    <td className="py-3 px-4 font-bold text-slate-900">₹{ps.grossEarnings.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 font-mono text-slate-600">₹{ps.pfDeduction.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 font-mono text-slate-600">₹{(ps.professionalTax + ps.tdsTax).toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 font-bold text-rose-600">₹{ps.totalDeductions.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 font-bold text-emerald-700">₹{ps.netPayable.toLocaleString('en-IN')}</td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setViewingPayslip(ps)}
                        className="px-2.5 py-1 text-xs font-semibold text-sky-600 hover:text-sky-800 hover:bg-sky-50 rounded-lg transition-colors cursor-pointer flex items-center gap-1 ml-auto"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Slip</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Printable Payslip Modal (RSTPL Letterhead) */}
      {viewingPayslip && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 max-h-[95vh] overflow-y-auto">
            {/* Modal Controls */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4 print:hidden">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Salary Voucher Preview</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrintSlip}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 text-white font-bold text-xs hover:bg-slate-800 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Payslip</span>
                </button>
                <button onClick={() => setViewingPayslip(null)} className="text-slate-400 hover:text-slate-700">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Pristine RSTPL Company Letterhead */}
            <div className="p-6 border border-slate-300 rounded-xl bg-white space-y-4 text-slate-900">
              <div className="flex items-start justify-between border-b-2 border-sky-800 pb-4">
                <div>
                  <h1 className="text-lg font-black tracking-tight text-sky-950">
                    RSTPL Demo Manufacturing Pvt. Ltd.
                  </h1>
                  <p className="text-[10px] text-slate-500 font-medium">
                    Corporate Office: RSTPL Tech Park, Baner Road, Pune - 411045
                  </p>
                  <p className="text-[10px] text-slate-500 font-mono">
                    PAN: AAACR1234F | PF No: MH/PUN/0098765/000 | ESIC: 31000987650001001
                  </p>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-sky-100 text-sky-900 border border-sky-200">
                    Payslip: {viewingPayslip.month}
                  </span>
                </div>
              </div>

              {/* Employee & Bank Info */}
              <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
                <div><span>Name: </span><strong className="text-slate-900">{viewingPayslip.employeeName}</strong></div>
                <div><span>Employee Code: </span><strong className="font-mono">{viewingPayslip.employeeCode}</strong></div>
                <div><span>Bank Account: </span><strong className="font-mono">{viewingPayslip.bankAccount}</strong></div>
                <div><span>PAN / UAN: </span><strong className="font-mono">{viewingPayslip.pan} / {viewingPayslip.uan}</strong></div>
                <div><span>Payable Days: </span><strong>{viewingPayslip.payableDays} Days</strong></div>
                <div><span>Loss of Pay: </span><strong>{viewingPayslip.lossOfPayDays} Days</strong></div>
              </div>

              {/* Earnings vs Deductions Table */}
              <div className="grid grid-cols-2 gap-4 text-xs">
                {/* Earnings */}
                <div className="border border-slate-200 rounded-lg overflow-hidden">
                  <div className="bg-slate-100 font-bold p-2 text-slate-700 border-b border-slate-200">
                    Earnings
                  </div>
                  <div className="p-2 space-y-1.5">
                    <div className="flex justify-between"><span>Basic Salary:</span> <span>₹{viewingPayslip.basicPay.toLocaleString('en-IN')}</span></div>
                    <div className="flex justify-between"><span>House Rent Allowance (HRA):</span> <span>₹{viewingPayslip.hra.toLocaleString('en-IN')}</span></div>
                    <div className="flex justify-between"><span>Conveyance Allowance:</span> <span>₹{viewingPayslip.conveyance.toLocaleString('en-IN')}</span></div>
                    <div className="flex justify-between"><span>Special Allowance:</span> <span>₹{viewingPayslip.specialAllowance.toLocaleString('en-IN')}</span></div>
                    {viewingPayslip.overtimePay > 0 && (
                      <div className="flex justify-between text-emerald-700 font-semibold">
                        <span>Overtime Pay:</span> <span>₹{viewingPayslip.overtimePay.toLocaleString('en-IN')}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold pt-2 border-t border-slate-200 text-slate-900">
                      <span>Gross Earnings:</span> <span>₹{viewingPayslip.grossEarnings.toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                </div>

                {/* Deductions */}
                <div className="border border-slate-200 rounded-lg overflow-hidden">
                  <div className="bg-slate-100 font-bold p-2 text-slate-700 border-b border-slate-200">
                    Deductions
                  </div>
                  <div className="p-2 space-y-1.5">
                    <div className="flex justify-between"><span>Provident Fund (EPF 12%):</span> <span>₹{viewingPayslip.pfDeduction.toLocaleString('en-IN')}</span></div>
                    <div className="flex justify-between"><span>ESIC (0.75%):</span> <span>₹{viewingPayslip.esicDeduction.toLocaleString('en-IN')}</span></div>
                    <div className="flex justify-between"><span>Professional Tax (PT):</span> <span>₹{viewingPayslip.professionalTax.toLocaleString('en-IN')}</span></div>
                    <div className="flex justify-between"><span>Income Tax (TDS):</span> <span>₹{viewingPayslip.tdsTax.toLocaleString('en-IN')}</span></div>
                    <div className="flex justify-between font-bold pt-2 border-t border-slate-200 text-rose-700">
                      <span>Total Deductions:</span> <span>₹{viewingPayslip.totalDeductions.toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Net Pay Badge */}
              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-lg flex items-center justify-between text-emerald-950">
                <span className="font-bold text-xs uppercase tracking-wider">Net Amount Payable to Employee:</span>
                <span className="text-lg font-black">₹{viewingPayslip.netPayable.toLocaleString('en-IN')}</span>
              </div>

              {/* Signatures */}
              <div className="pt-6 flex justify-between text-[11px] text-slate-500">
                <div>
                  <p className="border-t border-slate-300 pt-1 w-36 text-center">Employee Signature</p>
                </div>
                <div className="text-right">
                  <p className="border-t border-slate-300 pt-1 w-44 text-center">
                    Authorized Signatory (HR / Finance)
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Config Slabs Modal */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Configurable Indian Statutory Masters</h3>
            <p className="text-xs text-slate-500 mb-4">Update thresholds without modifying core code</p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">EPF Statutory Wage Ceiling (₹):</label>
                <input
                  type="number"
                  value={statutoryConfig.epfWageCeiling}
                  onChange={e => setStatutoryConfig({ ...statutoryConfig, epfWageCeiling: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">ESIC Gross Eligibility Limit (₹):</label>
                <input
                  type="number"
                  value={statutoryConfig.esicGrossCeiling}
                  onChange={e => setStatutoryConfig({ ...statutoryConfig, esicGrossCeiling: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Standard Professional Tax (PT ₹):</label>
                <input
                  type="number"
                  value={statutoryConfig.standardProfessionalTax}
                  onChange={e => setStatutoryConfig({ ...statutoryConfig, standardProfessionalTax: Number(e.target.value) })}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>
            </div>

            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                onClick={() => setShowConfigModal(false)}
                className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl"
              >
                Save Slabs
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

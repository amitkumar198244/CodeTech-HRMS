// RSTPL HRMS - Recruitment & Applicant Tracking System (ATS)
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  UserPlus,
  Briefcase,
  Search,
  Plus,
  FileText,
  Star,
  CheckCircle2,
  Clock,
  ArrowRight,
  Send,
  Calendar
} from 'lucide-react';
import { JobOpening, Candidate, Department } from '../../types/hrms';

interface RecruitmentATSViewProps {
  jobOpenings: JobOpening[];
  candidates: Candidate[];
  departments: Department[];
  onUpdateCandidates: (candidates: Candidate[]) => void;
  onAddJob: (job: JobOpening) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
}

const STAGES: Candidate['stage'][] = ['Applied', 'Screening', 'Interview', 'Selected', 'Offer Sent', 'Joined'];

export const RecruitmentATSView: React.FC<RecruitmentATSViewProps> = ({
  jobOpenings,
  candidates,
  departments,
  onUpdateCandidates,
  onAddJob,
  onLogAudit,
}) => {
  const [selectedJobId, setSelectedJobId] = useState<string>('ALL');
  const [showNewJobModal, setShowNewJobModal] = useState(false);
  const [newJob, setNewJob] = useState<Partial<JobOpening>>({
    title: '',
    department: departments[0]?.name || 'Human Resources',
    location: 'Chakan Plant, Pune',
    openingsCount: 1,
    experienceLevel: '3-5 Years',
    salaryRange: '₹6.0 - 8.0 LPA',
    description: '',
  });

  const filteredCandidates = candidates.filter(
    c => selectedJobId === 'ALL' || c.jobId === selectedJobId
  );

  const handleMoveCandidate = (candidateId: string, nextStage: Candidate['stage']) => {
    const updated = candidates.map(c => (c.id === candidateId ? { ...c, stage: nextStage } : c));
    onUpdateCandidates(updated);
    const moved = candidates.find(c => c.id === candidateId);
    onLogAudit('UPDATE', 'Recruitment ATS', `Moved candidate ${moved?.fullName} to stage: ${nextStage}`);
  };

  const handleCreateJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newJob.title) return;
    const job: JobOpening = {
      id: `job-${Date.now()}`,
      orgId: 'org-rstpl-001',
      title: newJob.title,
      department: newJob.department || 'Production',
      location: newJob.location || 'Pune',
      openingsCount: newJob.openingsCount || 1,
      experienceLevel: newJob.experienceLevel || '3-5 Years',
      salaryRange: newJob.salaryRange || '₹6 - 8 LPA',
      status: 'Open',
      applicantsCount: 0,
      postedDate: new Date().toISOString().split('T')[0],
      description: newJob.description || 'Enterprise role requisition',
    };
    onAddJob(job);
    setShowNewJobModal(false);
    onLogAudit('CREATE', 'Recruitment ATS', `Created job posting requisition: ${job.title}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <UserPlus className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">Recruitment & ATS Pipeline</h2>
              <p className="text-xs text-slate-500">
                Job requisitions, multi-stage candidate Kanban, interview feedback & automated offers
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={() => setShowNewJobModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create Job Requisition</span>
        </button>
      </div>

      {/* Active Job Openings Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {jobOpenings.map(job => (
          <div
            key={job.id}
            onClick={() => setSelectedJobId(selectedJobId === job.id ? 'ALL' : job.id)}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              selectedJobId === job.id
                ? 'bg-sky-50/70 border-sky-400 shadow-xs'
                : 'bg-white border-slate-200 hover:border-slate-300'
            }`}
          >
            <div className="flex items-start justify-between">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700">
                  {job.department}
                </span>
                <h3 className="font-bold text-slate-900 text-sm mt-1">{job.title}</h3>
                <p className="text-xs text-slate-500 mt-0.5">{job.location} · Exp: {job.experienceLevel}</p>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                {job.openingsCount} Vacancies
              </span>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Salary: <strong className="text-slate-800">{job.salaryRange}</strong></span>
              <span className="text-sky-700 font-semibold">{job.applicantsCount} Applicants</span>
            </div>
          </div>
        ))}
      </div>

      {/* Candidate Pipeline Kanban Board */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            Candidate Hiring Pipeline {selectedJobId !== 'ALL' && `(Filtered by Position)`}
          </h3>
          <span className="text-xs text-slate-500 font-medium">
            Total {filteredCandidates.length} Active Applicants
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {STAGES.map(stage => {
            const inStage = filteredCandidates.filter(c => c.stage === stage);
            return (
              <div key={stage} className="bg-slate-50/80 rounded-xl p-3 border border-slate-200 flex flex-col justify-between min-h-[220px]">
                <div>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200 mb-2">
                    <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">{stage}</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] font-black bg-white text-slate-800 border border-slate-200">
                      {inStage.length}
                    </span>
                  </div>

                  <div className="space-y-2">
                    {inStage.map(c => (
                      <div key={c.id} className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900 truncate max-w-[100px]">{c.fullName}</span>
                          <span className="text-[10px] font-bold text-amber-500">★ {c.rating}</span>
                        </div>
                        <p className="text-[10px] text-slate-500 truncate">{c.jobTitle}</p>
                        <p className="text-[10px] text-slate-400 font-medium">{c.experienceYears}y exp</p>

                        <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                          {stage !== 'Joined' && (
                            <button
                              onClick={() => {
                                const currentIndex = STAGES.indexOf(stage);
                                const nextStage = STAGES[currentIndex + 1];
                                if (nextStage) handleMoveCandidate(c.id, nextStage);
                              }}
                              className="text-[10px] text-sky-600 hover:text-sky-800 font-bold flex items-center gap-0.5 cursor-pointer"
                            >
                              <span>Next</span>
                              <ArrowRight className="w-2.5 h-2.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* New Job Modal */}
      {showNewJobModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Create Requisition Post</h3>
            <p className="text-xs text-slate-500 mb-4">Open new headcount vacancy</p>

            <form onSubmit={handleCreateJob} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Position Title *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Senior Quality Auditor"
                  value={newJob.title}
                  onChange={e => setNewJob({ ...newJob, title: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Department:</label>
                <select
                  value={newJob.department}
                  onChange={e => setNewJob({ ...newJob, department: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                >
                  {departments.map(d => (
                    <option key={d.id} value={d.name}>{d.name}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Vacancies:</label>
                  <input
                    type="number"
                    min="1"
                    value={newJob.openingsCount}
                    onChange={e => setNewJob({ ...newJob, openingsCount: Number(e.target.value) })}
                    className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Budget / Range:</label>
                  <input
                    type="text"
                    value={newJob.salaryRange}
                    onChange={e => setNewJob({ ...newJob, salaryRange: e.target.value })}
                    className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Location:</label>
                <input
                  type="text"
                  value={newJob.location}
                  onChange={e => setNewJob({ ...newJob, location: e.target.value })}
                  className="w-full px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewJobModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl"
                >
                  Post Requisition
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

// RSTPL HRMS - SaaS Multi-Tenant Administration & Customer Deployment Console
// RS Technovisions XpertSkillCop
// Enables the software vendor to sell to new companies, provision tenants, and generate initial Superadmin, Admin, HR, and Employee logins

import React, { useState } from 'react';
import {
  Sliders,
  Building2,
  CheckCircle2,
  Shield,
  Layers,
  Database,
  Server,
  Plus,
  Activity,
  Zap,
  Users,
  Key,
  Copy,
  Check,
  Smartphone,
  Download,
  Share2,
  ArrowRight,
  ExternalLink,
  Laptop
} from 'lucide-react';
import { Organization, UserAccount, UserRole } from '../../types/hrms';

interface SaaSSuperAdminViewProps {
  organizations: Organization[];
  currentOrg: Organization;
  onSelectOrg: (org: Organization) => void;
  onAddOrg: (org: Organization) => void;
  onAddUsers?: (users: UserAccount[]) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
}

export const SaaSSuperAdminView: React.FC<SaaSSuperAdminViewProps> = ({
  organizations,
  currentOrg,
  onSelectOrg,
  onAddOrg,
  onAddUsers,
  onLogAudit,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newOrgName, setNewOrgName] = useState('');
  const [newOrgCode, setNewOrgCode] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<'starter' | 'professional' | 'enterprise'>('enterprise');
  const [maxEmployeesCount, setMaxEmployeesCount] = useState<number>(5000);

  // Handover dossier modal for newly onboarded company
  const [handoverDossier, setHandoverDossier] = useState<{
    org: Organization;
    credentials: Array<{ roleName: string; username: string; password: string; role: UserRole; desc: string }>;
  } | null>(null);

  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleCreateTenant = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOrgName || !newOrgCode) return;

    const orgId = `org-${Date.now()}`;
    const cleanCode = newOrgCode.toUpperCase().trim();

    const org: Organization = {
      id: orgId,
      name: newOrgName.trim(),
      code: cleanCode,
      tagline: 'Smart HR Solutions for a Smarter Tomorrow',
      panNumber: 'AAACR9988Z',
      gstNumber: '27AAACR9988Z1Z5',
      pfNumber: 'MH/PUN/1122334/000',
      esicNumber: '310011223344001',
      ptNumber: 'PT-MH-112233',
      planId: selectedPlan,
      maxEmployees: maxEmployeesCount,
      maxUsers: 150,
      isActive: true,
      themeColor: '#0284C7',
      createdAt: new Date().toISOString(),
    };

    // Auto-generate initial credentials for 4 tiers: Superadmin, Client Admin, HR Head, and End User
    const codePrefix = cleanCode.toLowerCase().replace(/[^a-z0-9]/g, '');
    const generatedCreds: UserAccount[] = [
      {
        id: `usr-sa-${Date.now()}`,
        orgId: org.id,
        username: `superadmin.${codePrefix}`,
        passwordHash: `Super@${cleanCode}2026`,
        role: 'super_admin',
        name: `${org.name} Master Admin`,
        email: adminEmail || `superadmin@${codePrefix}.com`,
        phone: contactPhone,
        isActive: true,
        isMobileAccessEnabled: true,
        permissions: {
          canViewPayroll: true,
          canApprovePayroll: true,
          canApproveLeaves: true,
          canApproveExpenses: true,
          canManageBiometric: true,
          canManageKRA: true,
          canReviewPMS: true,
          canApprovePMS: true,
          canExportReports: true,
          canManageUsers: true,
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: `usr-adm-${Date.now()}`,
        orgId: org.id,
        username: `admin.${codePrefix}`,
        passwordHash: `Admin@${cleanCode}2026`,
        role: 'org_admin',
        name: `${org.name} Client Director`,
        email: adminEmail || `admin@${codePrefix}.com`,
        phone: contactPhone,
        isActive: true,
        isMobileAccessEnabled: true,
        permissions: {
          canViewPayroll: true,
          canApprovePayroll: true,
          canApproveLeaves: true,
          canApproveExpenses: true,
          canManageBiometric: true,
          canManageKRA: true,
          canReviewPMS: true,
          canApprovePMS: true,
          canExportReports: true,
          canManageUsers: true,
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: `usr-hr-${Date.now()}`,
        orgId: org.id,
        username: `hr.${codePrefix}`,
        passwordHash: `HR@${cleanCode}2026`,
        role: 'hr_head',
        name: `HR Head (${org.name})`,
        email: `hr@${codePrefix}.com`,
        phone: contactPhone,
        isActive: true,
        isMobileAccessEnabled: true,
        permissions: {
          canViewPayroll: true,
          canApprovePayroll: true,
          canApproveLeaves: true,
          canApproveExpenses: true,
          canManageBiometric: true,
          canManageKRA: true,
          canReviewPMS: true,
          canApprovePMS: true,
          canExportReports: true,
          canManageUsers: true,
        },
        createdAt: new Date().toISOString(),
      },
      {
        id: `usr-emp-${Date.now()}`,
        orgId: org.id,
        username: `employee.${codePrefix}`,
        passwordHash: `Emp@${cleanCode}2026`,
        role: 'employee',
        name: `Sample Staff (${cleanCode})`,
        email: `employee@${codePrefix}.com`,
        phone: contactPhone,
        isActive: true,
        isMobileAccessEnabled: true,
        permissions: {
          canViewPayroll: false,
          canApprovePayroll: false,
          canApproveLeaves: false,
          canApproveExpenses: false,
          canManageBiometric: false,
          canManageKRA: false,
          canReviewPMS: false,
          canApprovePMS: false,
          canExportReports: false,
          canManageUsers: false,
        },
        createdAt: new Date().toISOString(),
      },
    ];

    onAddOrg(org);
    if (onAddUsers) {
      onAddUsers(generatedCreds);
    }

    setShowAddModal(false);
    onLogAudit(
      'CREATE',
      'SaaS Admin',
      `Provisioned new commercial tenant: ${org.name} (${org.code}) with 4 auto-generated credentials`
    );

    // Set handover dossier for customer delivery
    setHandoverDossier({
      org,
      credentials: [
        {
          roleName: '⚡ Super Administrator',
          username: `superadmin.${codePrefix}`,
          password: `Super@${cleanCode}2026`,
          role: 'super_admin',
          desc: 'Full global system control, database, audit and cross-module permissions',
        },
        {
          roleName: '🏢 Client / Organization Admin',
          username: `admin.${codePrefix}`,
          password: `Admin@${cleanCode}2026`,
          role: 'org_admin',
          desc: 'Company director level access to user creation, roles, and master policies',
        },
        {
          roleName: '👔 HR Head / HR Executive',
          username: `hr.${codePrefix}`,
          password: `HR@${cleanCode}2026`,
          role: 'hr_head',
          desc: 'Payroll finalization, shift rosters, employee onboarding, and PMS KRA setup',
        },
        {
          roleName: '📱 Mobile Employee (ESS Self-Service)',
          username: `employee.${codePrefix}`,
          password: `Emp@${cleanCode}2026`,
          role: 'employee',
          desc: 'Mobile geo-punch, payslip download, leave applications, and monthly KRA self-fill',
        },
      ],
    });

    // Reset inputs
    setNewOrgName('');
    setNewOrgCode('');
    setAdminEmail('');
    setContactPhone('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <Sliders className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                SaaS Multi-Tenant Management & Customer Onboarding Console
              </h2>
              <p className="text-xs text-slate-500">
                Deploy isolated customer workspaces, generate initial Superadmin/Admin/HR/Employee credentials, and export handover dossiers
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition-colors cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Onboard New Customer Company</span>
        </button>
      </div>

      {/* System Health Strip */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase">Customer Companies</span>
            <Building2 className="w-4 h-4 text-sky-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-1">{organizations.length}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Active commercial deployments</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase">Database RLS Partition</span>
            <Database className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-sm font-bold text-emerald-700 mt-2">100% Strict Tenant Isolation</p>
          <p className="text-[10px] text-slate-400 mt-0.5">PostgreSQL row-level isolation</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase">Biometric Ingestion Gateway</span>
            <Server className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-sm font-bold text-slate-900 mt-2">Active TCP/IP Daemon</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Multi-tenant ADMS broker</p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[10px] font-bold uppercase">Commercial Sales Model</span>
            <Shield className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-sm font-bold text-slate-900 mt-2">B2B SaaS Ready</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Mobile ESS + Web Admin</p>
        </div>
      </div>

      {/* Tenants Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Provisioned Customer Companies (Tenants)</h3>
            <p className="text-[11px] text-slate-500">
              Each company runs with its own branding, employees, salary rules, and biometric hardware
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Company Name</th>
                <th className="py-3 px-4">Tenant Code</th>
                <th className="py-3 px-4">SaaS Tier Plan</th>
                <th className="py-3 px-4">Max Workforce Quota</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Context Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {organizations.map(org => (
                <tr key={org.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 font-bold text-slate-900 flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-sky-600" />
                    <span>{org.name}</span>
                    {org.id === currentOrg.id && (
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-sky-100 text-sky-800">
                        Active Workspace
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-700">{org.code}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-100 text-amber-900 font-mono">
                      {org.planId}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-600 font-medium">
                    Up to {org.maxEmployees.toLocaleString()} Personnel
                  </td>
                  <td className="py-3 px-4">
                    <span className="text-emerald-700 font-bold text-[11px] flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Deployed & Live
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    {org.id !== currentOrg.id ? (
                      <button
                        onClick={() => onSelectOrg(org)}
                        className="px-3 py-1 bg-sky-600 text-white rounded-lg font-bold text-[11px] hover:bg-sky-700 cursor-pointer"
                      >
                        Switch To Company
                      </button>
                    ) : (
                      <span className="text-slate-400 text-[11px] font-medium">Currently Selected</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal 1: Onboard New Customer Company */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-sky-600" />
                <h3 className="text-base font-bold text-slate-900">Onboard New Customer Company (Sales Setup)</h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500 mb-4">
              Enter customer details. The system will auto-provision initial Superadmin, Admin, HR, and Employee logins for deployment handover.
            </p>

            <form onSubmit={handleCreateTenant} className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Customer / Company Legal Name *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Paramount Automotive Components Pvt Ltd"
                  value={newOrgName}
                  onChange={e => setNewOrgName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Company Short Code (Prefix) *</label>
                  <input
                    required
                    type="text"
                    placeholder="e.g. PARAMOUNT"
                    value={newOrgCode}
                    onChange={e => setNewOrgCode(e.target.value.toUpperCase())}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">SaaS License Package</label>
                  <select
                    value={selectedPlan}
                    onChange={e => setSelectedPlan(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-bold"
                  >
                    <option value="enterprise">Enterprise (Unlimited Features)</option>
                    <option value="professional">Professional (Up to 1,000 Staff)</option>
                    <option value="starter">Starter (Up to 250 Staff)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Director / Admin Email</label>
                  <input
                    type="email"
                    placeholder="director@paramount.com"
                    value={adminEmail}
                    onChange={e => setAdminEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Customer Mobile / Phone</label>
                  <input
                    type="text"
                    placeholder="+91 98234 56789"
                    value={contactPhone}
                    onChange={e => setContactPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Maximum Allowed Employee Quota</label>
                <input
                  type="number"
                  value={maxEmployeesCount}
                  onChange={e => setMaxEmployeesCount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-mono"
                />
              </div>

              <div className="p-3 rounded-xl bg-sky-50 border border-sky-200 text-sky-900 text-[11px] space-y-1">
                <span className="font-bold flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-sky-600" />
                  <span>Automatic Credentials Provisioning:</span>
                </span>
                <p>
                  Upon clicking submit, 4 separate login identities will be created: <strong>Superadmin</strong>, <strong>Client Admin</strong>, <strong>HR Head</strong>, and a sample <strong>Mobile Employee</strong>.
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Deploy & Generate Logins</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Customer Handover Dossier & Generated Credentials Slip */}
      {handoverDossier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    Deployment Complete: {handoverDossier.org.name}
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Tenant Code: {handoverDossier.org.code} · Plan: {handoverDossier.org.planId.toUpperCase()}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setHandoverDossier(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600 mb-3">
              Copy this credentials handover dossier to share with the customer director, HR, and IT teams:
            </p>

            {/* Credential Cards */}
            <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
              {handoverDossier.credentials.map((cred, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">{cred.roleName}</span>
                    <button
                      onClick={() =>
                        copyToClipboard(
                          `Role: ${cred.roleName}\nUsername: ${cred.username}\nPassword: ${cred.password}\nPortal: https://hrms.rstpl.com`,
                          `cred-${idx}`
                        )
                      }
                      className="text-[11px] text-sky-600 font-bold hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      {copiedKey === `cred-${idx}` ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedKey === `cred-${idx}` ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div>
                      <span className="text-slate-400 block">Username:</span>
                      <strong className="font-mono text-sky-800">{cred.username}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Password:</span>
                      <strong className="font-mono text-emerald-700">{cred.password}</strong>
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-500 italic">{cred.desc}</p>
                </div>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2 text-xs">
              <button
                onClick={() => {
                  const dossierText = `*RSTPL HRMS - Commercial Deployment Handover Dossier*\n\n*Company:* ${handoverDossier.org.name}\n*Tenant Code:* ${handoverDossier.org.code}\n*Portal URL:* https://hrms.rstpl.com\n\n${handoverDossier.credentials
                    .map(c => `*${c.roleName}*\nUsername: ${c.username}\nPassword: ${c.password}\nAccess: ${c.desc}\n`)
                    .join('\n')}\nSupport: +91 8076270151`;
                  copyToClipboard(dossierText, 'full-dossier');
                }}
                className="py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                {copiedKey === 'full-dossier' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-sky-400" />}
                <span>{copiedKey === 'full-dossier' ? 'Copied Full Customer Dossier!' : 'Copy Full Handover Package (WhatsApp/Email)'}</span>
              </button>

              <button
                onClick={() => {
                  onSelectOrg(handoverDossier.org);
                  setHandoverDossier(null);
                }}
                className="py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold transition-all cursor-pointer"
              >
                Enter Company Workspace →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// RSTPL HRMS - Employee Self Service (ESS) & Mobile PWA Geo-Punch
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  UserCircle,
  Clock,
  MapPin,
  Calendar,
  FileText,
  Shield,
  Download,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Smartphone,
  Navigation
} from 'lucide-react';
import { Employee, AttendanceRecord, LeaveRequest, Payslip } from '../../types/hrms';

interface ESSViewProps {
  currentEmployee: Employee;
  attendance: AttendanceRecord[];
  leaveRequests: LeaveRequest[];
  payslips: Payslip[];
  onWebGeoPunch: (type: 'IN' | 'OUT', lat: number, lng: number) => void;
  onNavigate: (module: string) => void;
}

export const ESSView: React.FC<ESSViewProps> = ({
  currentEmployee,
  attendance,
  leaveRequests,
  payslips,
  onWebGeoPunch,
  onNavigate,
}) => {
  const [punching, setPunching] = useState(false);
  const [punchedToday, setPunchedToday] = useState(true);
  const [geoCoords, setGeoCoords] = useState({ lat: 18.5590, lng: 73.7868, locationName: 'Pune Baner Tech Park Geofence (Within 50m)' });

  const myAttendanceToday = attendance.find(a => a.employeeId === currentEmployee.id && a.date === '2026-10-05');
  const myLeaves = leaveRequests.filter(l => l.employeeId === currentEmployee.id);
  const latestSlip = payslips[0];

  const handlePunch = (type: 'IN' | 'OUT') => {
    setPunching(true);
    setTimeout(() => {
      onWebGeoPunch(type, geoCoords.lat, geoCoords.lng);
      setPunching(false);
      setPunchedToday(type === 'IN');
    }, 700);
  };

  return (
    <div className="space-y-6">
      {/* Employee Greeting & PWA Mobile Badge */}
      <div className="bg-gradient-to-r from-sky-900 via-sky-800 to-indigo-950 p-6 rounded-2xl text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/10 ring-2 ring-white/20 text-white flex items-center justify-center font-black text-xl">
              {currentEmployee.firstName[0]}{currentEmployee.lastName[0]}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-400 text-slate-900">
                  ESS Portal
                </span>
                <span className="text-xs text-sky-200 font-mono">{currentEmployee.employeeCode}</span>
              </div>
              <h2 className="text-xl font-black">
                Good day, {currentEmployee.firstName} {currentEmployee.lastName}!
              </h2>
              <p className="text-xs text-sky-100 mt-0.5">
                {currentEmployee.grade} · General Corporate Shift (09:00 - 18:00)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="px-3 py-1.5 rounded-xl bg-white/10 backdrop-blur-xs border border-white/20 text-xs flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-amber-300" />
              <span>Mobile PWA Active</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Mobile Geo Punch + Quick Balances */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Geo Attendance Punch Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900">Web & Mobile Geo Punch</h3>
              <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600">
                <Navigation className="w-3.5 h-3.5 text-emerald-600" /> Geofence Verified
              </span>
            </div>

            <p className="text-xs text-slate-500 mb-3">
              GPS verified coordinates: <br />
              <strong className="text-slate-800 font-mono">{geoCoords.lat.toFixed(4)}° N, {geoCoords.lng.toFixed(4)}° E</strong>
              <br />
              <span className="text-emerald-700 text-[11px]">{geoCoords.locationName}</span>
            </p>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs mb-4">
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500">First Punch IN:</span>
                <span className="font-mono font-bold text-slate-900">{myAttendanceToday?.firstIn || '08:55 AM'}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Last Punch OUT:</span>
                <span className="font-mono font-bold text-slate-900">{myAttendanceToday?.lastOut || '--:--'}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={() => handlePunch('IN')}
              disabled={punching}
              className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-1"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Punch IN</span>
            </button>
            <button
              onClick={() => handlePunch('OUT')}
              disabled={punching}
              className="py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-1"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Punch OUT</span>
            </button>
          </div>
        </div>

        {/* Leave Balances Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900">My Leave Balances</h3>
              <button
                onClick={() => onNavigate('leave')}
                className="text-xs font-semibold text-sky-600 hover:underline"
              >
                Apply
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="p-2.5 rounded-xl bg-sky-50 border border-sky-100 flex items-center justify-between">
                <div>
                  <p className="font-bold text-sky-900">Casual Leave (CL)</p>
                  <p className="text-[10px] text-sky-600">Annual Quota: 12 days</p>
                </div>
                <span className="text-lg font-black text-sky-900">9.5 <span className="text-[10px] font-normal">avail</span></span>
              </div>

              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-between">
                <div>
                  <p className="font-bold text-emerald-900">Privilege Leave (EL)</p>
                  <p className="text-[10px] text-emerald-600">Encashable & Carry Forward</p>
                </div>
                <span className="text-lg font-black text-emerald-900">16.0 <span className="text-[10px] font-normal">avail</span></span>
              </div>

              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-between">
                <div>
                  <p className="font-bold text-rose-900">Sick / Medical Leave (SL)</p>
                  <p className="text-[10px] text-rose-600">Medical proof required</p>
                </div>
                <span className="text-lg font-black text-rose-900">8.0 <span className="text-[10px] font-normal">avail</span></span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('leave')}
            className="mt-3 w-full py-2 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 rounded-xl border border-slate-200 transition-colors"
          >
            View Leave Ledger History
          </button>
        </div>

        {/* Latest Payslip Quick Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900">Latest Salary Slip</h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                Disbursed
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-2 text-xs">
              <div className="flex justify-between text-slate-500">
                <span>Month:</span>
                <span className="font-bold text-slate-900">September 2026</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Payable Days:</span>
                <span className="font-bold text-slate-900">30 Days</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Gross Salary:</span>
                <span className="font-bold text-slate-900">₹{currentEmployee.basicMonthly + currentEmployee.hraMonthly + currentEmployee.conveyanceMonthly + currentEmployee.specialAllowanceMonthly}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 text-sky-900 font-bold">
                <span>Net Pay:</span>
                <span className="text-sm">₹{currentEmployee.netSalaryMonthly.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('payslips')}
            className="mt-3 w-full py-2 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Official Payslip (PDF)</span>
          </button>
        </div>
      </div>
    </div>
  );
};

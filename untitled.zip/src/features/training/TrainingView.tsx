// RSTPL HRMS - Training Management & Skill Matrix
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  GraduationCap,
  Calendar,
  CheckCircle2,
  Users,
  Award,
  Clock,
  Plus
} from 'lucide-react';
import { TrainingProgram } from '../../types/hrms';

interface TrainingViewProps {
  onLogAudit: (action: any, module: string, details: string) => void;
}

const INITIAL_PROGRAMS: TrainingProgram[] = [
  {
    id: 'tr-01',
    orgId: 'org-rstpl-001',
    title: 'Industrial Safety & Fire Hazards (ISO 45001 Compliance)',
    trainer: 'Capt. Deshpande (Safety Lead)',
    category: 'Compliance & Safety',
    startDate: '2026-10-12',
    durationHours: 8,
    capacity: 35,
    enrolledCount: 32,
    status: 'Scheduled',
  },
  {
    id: 'tr-02',
    orgId: 'org-rstpl-001',
    title: 'Advanced 5-Axis CNC Programming & Toolpath Optimization',
    trainer: 'External Master Machinist (Siemens Academy)',
    category: 'Technical',
    startDate: '2026-10-18',
    durationHours: 16,
    capacity: 20,
    enrolledCount: 18,
    status: 'Scheduled',
  },
  {
    id: 'tr-03',
    orgId: 'org-rstpl-001',
    title: 'Supervisory Leadership & Labor Relations Workshop',
    trainer: 'Amit Sharma (VP HR & IR)',
    category: 'Leadership',
    startDate: '2026-09-28',
    durationHours: 6,
    capacity: 25,
    enrolledCount: 25,
    status: 'Completed',
  },
];

export const TrainingView: React.FC<TrainingViewProps> = ({ onLogAudit }) => {
  const [programs, setPrograms] = useState<TrainingProgram[]>(INITIAL_PROGRAMS);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <GraduationCap className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">Training Management & Skill Matrix</h2>
              <p className="text-xs text-slate-500">
                Training need analysis (TNA), factory safety certifications & workforce competency building
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Programs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {programs.map(prog => (
          <div key={prog.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-sky-50 text-sky-800 border border-sky-100">
                  {prog.category}
                </span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  prog.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                }`}>
                  {prog.status}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 mt-2 leading-snug">{prog.title}</h3>
              <p className="text-xs text-slate-500 mt-1">Instructor: {prog.trainer}</p>

              <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs space-y-1">
                <div className="flex justify-between text-slate-600">
                  <span>Start Date:</span>
                  <strong className="font-mono text-slate-900">{prog.startDate}</strong>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Duration:</span>
                  <strong className="text-slate-900">{prog.durationHours} Hours</strong>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Enrolled Seats:</span>
                  <strong className="text-sky-700">{prog.enrolledCount} / {prog.capacity}</strong>
                </div>
              </div>
            </div>

            <button className="mt-4 w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer">
              View Participant Roster & Certificates
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

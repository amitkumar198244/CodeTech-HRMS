// RSTPL HRMS - Executive & Operations Dashboard
// RS Technovisions XpertSkillCop

import React, { useState, useMemo } from 'react';
import {
  Users,
  UserCheck,
  UserX,
  Clock,
  Calendar,
  CalendarCheck,
  DollarSign,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  Briefcase,
  Fingerprint,
  ArrowUpRight,
  ArrowUp,
  ArrowDown,
  ShieldCheck,
  Sparkles,
  ChevronRight,
  Wifi,
  Activity,
  CheckCircle2,
  RefreshCw,
  Server,
  Zap,
  Gauge,
  AlertTriangle,
  WifiOff,
  BellRing,
  Sliders,
  Check,
  Play,
  ShieldAlert,
  Cpu,
  MapPin,
  LayoutList,
  List,
  FileDown,
  Radio
} from 'lucide-react';
import { HRMSStoreData } from '../../services/hrmsStorage';
import { UserRole, BiometricDevice, AppNotification } from '../../types/hrms';
import { BiometricLocationMapView } from './BiometricLocationMapView';
import { GeofenceDistributionMapView } from './GeofenceDistributionMapView';
import { BiometricSyncTrendWidget } from './BiometricSyncTrendWidget';
import { HeadcountTrendWidget } from './HeadcountTrendWidget';
import { generateDashboardPdfReport } from '../../services/dashboardPdfGenerator';
import { BrandShowcaseModal, PowerByBadge, RstplLogo, RsTechnoVisionsLogo } from '../../components/branding/BrandLogos';
import { InteractiveHrmsUnitDashboard } from './InteractiveHrmsUnitDashboard';
import { RealtimeAttendanceKpiGrid } from './RealtimeAttendanceKpiGrid';
import { Unit, Branch, Employee, GeoTrackingPunch } from '../../types/hrms';

interface DashboardViewProps {
  storeData: HRMSStoreData;
  currentRole: UserRole;
  geoPunches?: GeoTrackingPunch[];
  onNavigate: (module: string) => void;
  onOpenAI: () => void;
  onUpdateDevices?: (devices: BiometricDevice[]) => void;
  onLogAudit?: (action: any, module: string, details: string) => void;
  onAddNotification?: (notif: AppNotification) => void;
  onAddUnit?: (unit: Unit, branch?: Branch) => void;
  onRoleChange?: (role: UserRole) => void;
  onAddEmployee?: (emp: Employee) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  storeData,
  currentRole,
  geoPunches,
  onNavigate,
  onOpenAI,
  onUpdateDevices,
  onLogAudit,
  onAddNotification,
  onAddUnit,
  onRoleChange,
  onAddEmployee,
}) => {
  const { employees, attendance, leaveRequests, jobOpenings, biometricDevices, payrollRuns } = storeData;

  const [acknowledgedAlertIds, setAcknowledgedAlertIds] = useState<string[]>([]);
  const [showBrandHub, setShowBrandHub] = useState<boolean>(false);

  // Rolling latency samples for calculating average sync latency per device
  const [deviceLatencyHistories, setDeviceLatencyHistories] = useState<Record<string, number[]>>({
    'dev-001': [42, 48, 46],
    'dev-002': [68, 76, 74],
    'dev-003': [142, 160, 152],
    'dev-004': [32, 40, 36],
  });
  const [isPingingAll, setIsPingingAll] = useState<boolean>(false);
  const [pingingDeviceId, setPingingDeviceId] = useState<string | null>(null);
  const [biometricViewMode, setBiometricViewMode] = useState<'list' | 'map'>('map');
  const [focusedMapDeviceId, setFocusedMapDeviceId] = useState<string | null>(null);
  const [isViewTransitioning, setIsViewTransitioning] = useState<boolean>(false);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [pdfDownloadedToast, setPdfDownloadedToast] = useState<string | null>(null);

  // Smooth view switching between List View and Map View
  const handleSwitchView = (mode: 'list' | 'map', deviceId?: string) => {
    if (deviceId) {
      setFocusedMapDeviceId(deviceId);
    }
    if (mode === biometricViewMode) return;
    setIsViewTransitioning(true);
    setBiometricViewMode(mode);
    setTimeout(() => {
      setIsViewTransitioning(false);
    }, 320);
  };

  const totalEmployees = employees.length;
  const activeEmployees = employees.filter(e => e.status === 'Active').length;
  const probationEmployees = employees.filter(e => e.status === 'Probation').length;
  const presentToday = attendance.filter(a => a.status === 'Present' || a.status === 'Late').length;
  const lateToday = attendance.filter(a => a.status === 'Late').length;
  const absentToday = attendance.filter(a => a.status === 'Absent').length;
  const onLeaveToday = attendance.filter(a => a.status === 'On Leave').length;
  const pendingLeaves = leaveRequests.filter(l => l.status === 'Pending').length;
  const approvedLeavesThisMonth = leaveRequests.filter(l => l.status === 'Approved').length;
  const openVacancies = jobOpenings.reduce((sum, j) => sum + (j.status === 'Open' ? j.openingsCount : 0), 0);

  // Current month payroll calculations (Gross Outflow + Employer Statutory Contributions)
  const currentMonthPayroll = payrollRuns[0];
  const totalPayrollExpense = useMemo(() => {
    if (currentMonthPayroll && currentMonthPayroll.totalGrossPay) {
      return currentMonthPayroll.totalGrossPay + (currentMonthPayroll.totalEmployerContributions || Math.round(currentMonthPayroll.totalGrossPay * 0.0825));
    }
    return employees
      .filter(e => e.status === 'Active')
      .reduce((sum, e) => {
        const gross = e.basicMonthly + e.hraMonthly + e.conveyanceMonthly + e.specialAllowanceMonthly;
        const employerContrib = Math.round(e.basicMonthly * 0.12) + Math.round(gross * 0.0325);
        return sum + gross + employerContrib;
      }, 0);
  }, [currentMonthPayroll, employees]);

  const totalNetSalaryDisbursed = useMemo(() => {
    if (currentMonthPayroll && currentMonthPayroll.totalNetPay) {
      return currentMonthPayroll.totalNetPay;
    }
    return employees
      .filter(e => e.status === 'Active')
      .reduce((sum, e) => sum + e.netSalaryMonthly, 0);
  }, [currentMonthPayroll, employees]);

  const getLatency = (d: typeof biometricDevices[0]) => {
    return d.syncLatencyMs ?? (d.vendor === 'eSSL' ? 46 : d.vendor === 'ZKTeco' ? 74 : d.vendor === 'Matrix' ? 152 : 36);
  };

  const getDeviceLatencyHistory = (deviceId: string, defaultLat: number): number[] => {
    return deviceLatencyHistories[deviceId] && deviceLatencyHistories[deviceId].length > 0
      ? deviceLatencyHistories[deviceId]
      : [defaultLat];
  };

  // Calculates the average sync latency for an individual device across recorded samples
  const getDeviceAverageLatency = (device: BiometricDevice): number => {
    const defaultLat = getLatency(device);
    const history = getDeviceLatencyHistory(device.id, defaultLat);
    if (history.length === 0) return defaultLat;
    return Math.round(history.reduce((sum, val) => sum + val, 0) / history.length);
  };

  // Critical alert check: latency > 500ms OR status === 'Offline'
  const criticalDevices = biometricDevices.filter(d => {
    const lat = getLatency(d);
    const avg = getDeviceAverageLatency(d);
    return d.status === 'Offline' || lat > 500 || avg > 500;
  });

  const activeCriticalAlerts = criticalDevices.filter(d => !acknowledgedAlertIds.includes(d.id));

  const handleAcknowledgeAlert = (deviceId: string) => {
    setAcknowledgedAlertIds(prev => [...prev, deviceId]);
    if (onLogAudit) {
      const dev = biometricDevices.find(d => d.id === deviceId);
      onLogAudit('UPDATE', 'Biometric Alert', `HR acknowledged hardware incident for ${dev?.name} (${dev?.ipAddress})`);
    }
  };

  // Test ping for an individual device to re-calculate average sync latency
  const handlePingDevice = (deviceId: string) => {
    if (!onUpdateDevices) return;
    setPingingDeviceId(deviceId);

    setTimeout(() => {
      const dev = biometricDevices.find(d => d.id === deviceId);
      if (!dev) {
        setPingingDeviceId(null);
        return;
      }

      const baseLat = dev.vendor === 'eSSL' ? 46 : dev.vendor === 'ZKTeco' ? 74 : dev.vendor === 'Matrix' ? 152 : 36;
      const jitter = Math.floor(Math.random() * 16) - 8;
      const newLat = Math.max(20, baseLat + jitter);

      const oldHistory = getDeviceLatencyHistory(deviceId, baseLat);
      const updatedHistory = [...oldHistory.slice(-4), newLat];

      setDeviceLatencyHistories(prev => ({
        ...prev,
        [deviceId]: updatedHistory,
      }));

      const updatedDevices = biometricDevices.map(d =>
        d.id === deviceId
          ? {
              ...d,
              syncLatencyMs: newLat,
              status: 'Online' as const,
              lastSyncAt: new Date().toISOString(),
            }
          : d
      );
      onUpdateDevices(updatedDevices);
      setPingingDeviceId(null);

      const avg = Math.round(updatedHistory.reduce((a, b) => a + b, 0) / updatedHistory.length);
      if (onLogAudit) {
        onLogAudit('SYNC', 'Biometric Diagnostic', `Ping probe on ${dev.name}: ${newLat}ms (Avg: ${avg}ms over ${updatedHistory.length} handshakes)`);
      }
    }, 400);
  };

  // Test ping across all devices
  const handlePingAllDevices = () => {
    if (!onUpdateDevices) return;
    setIsPingingAll(true);

    setTimeout(() => {
      const newHistories: Record<string, number[]> = { ...deviceLatencyHistories };
      const updatedDevices = biometricDevices.map(dev => {
        if (dev.status === 'Offline') return dev;
        const baseLat = dev.vendor === 'eSSL' ? 46 : dev.vendor === 'ZKTeco' ? 74 : dev.vendor === 'Matrix' ? 152 : 36;
        const jitter = Math.floor(Math.random() * 14) - 7;
        const newLat = Math.max(20, baseLat + jitter);
        const oldHistory = newHistories[dev.id] || [baseLat];
        newHistories[dev.id] = [...oldHistory.slice(-4), newLat];
        return {
          ...dev,
          syncLatencyMs: newLat,
          lastSyncAt: new Date().toISOString(),
        };
      });

      setDeviceLatencyHistories(newHistories);
      onUpdateDevices(updatedDevices);
      setIsPingingAll(false);

      if (onLogAudit) {
        onLogAudit('SYNC', 'Biometric Telemetry', `Refreshed ping telemetry across all ${biometricDevices.length} terminals`);
      }
    }, 500);
  };

  const handleSimulateLatencySpike = () => {
    if (!onUpdateDevices) return;
    const target = biometricDevices[2] || biometricDevices[0];
    const spikeLat = 640; // > 500ms critical threshold
    const oldHistory = getDeviceLatencyHistory(target.id, 152);
    const updatedHistory = [...oldHistory.slice(-4), spikeLat];

    setDeviceLatencyHistories(prev => ({
      ...prev,
      [target.id]: updatedHistory,
    }));

    const updated = biometricDevices.map(d =>
      d.id === target.id ? { ...d, syncLatencyMs: spikeLat } : d
    );
    onUpdateDevices(updated);
    setAcknowledgedAlertIds(prev => prev.filter(id => id !== target.id));

    if (onAddNotification) {
      onAddNotification({
        id: `notif-spike-${Date.now()}`,
        orgId: target.orgId,
        title: `CRITICAL: High Latency Spike (${spikeLat}ms > 500ms)`,
        message: `${target.name} at ${target.location} sync latency reached ${spikeLat}ms, violating 500ms SLA. Immediate HR attention required.`,
        type: 'biometric',
        read: false,
        timestamp: 'Just now',
      });
    }

    if (onLogAudit) {
      onLogAudit('UPDATE', 'Biometric Alert', `Triggered simulated latency spike (${spikeLat}ms > 500ms) on ${target.name}`);
    }
  };

  const handleSimulateDeviceOffline = () => {
    if (!onUpdateDevices) return;
    const target = biometricDevices[0];
    const updated = biometricDevices.map(d =>
      d.id === target.id ? { ...d, status: 'Offline' as const, syncLatencyMs: 0 } : d
    );
    onUpdateDevices(updated);
    setAcknowledgedAlertIds(prev => prev.filter(id => id !== target.id));

    if (onAddNotification) {
      onAddNotification({
        id: `notif-offline-${Date.now()}`,
        orgId: target.orgId,
        title: `URGENT: Biometric Terminal Offline (${target.name})`,
        message: `${target.name} (${target.ipAddress}) went offline. Shift workers unable to record punch events.`,
        type: 'biometric',
        read: false,
        timestamp: 'Just now',
      });
    }

    if (onLogAudit) {
      onLogAudit('UPDATE', 'Biometric Alert', `Triggered simulated offline state on ${target.name}`);
    }
  };

  const handleRestoreOptimal = () => {
    if (!onUpdateDevices) return;
    const baselineHistories: Record<string, number[]> = {
      'dev-001': [42, 48, 46],
      'dev-002': [68, 76, 74],
      'dev-003': [142, 160, 152],
      'dev-004': [32, 40, 36],
    };
    setDeviceLatencyHistories(baselineHistories);

    const updated = biometricDevices.map((d, idx) => ({
      ...d,
      status: 'Online' as const,
      syncLatencyMs: idx === 0 ? 46 : idx === 1 ? 74 : idx === 2 ? 152 : 36,
    }));
    onUpdateDevices(updated);
    setAcknowledgedAlertIds([]);

    if (onLogAudit) {
      onLogAudit('UPDATE', 'Biometric Alert', 'Restored all biometric devices to optimal SLA compliance (<80ms - 150ms)');
    }
  };

  const {
    onlineBiometrics,
    totalBiometrics,
    totalPunchesSynced,
    latestPayroll,
    averageLatency,
    latencyHealthLabel,
    getDeviceLatencyInfo,
  } = (() => {
  const online = biometricDevices.filter(d => d.status === 'Online').length;
  const total = biometricDevices.length;
  const punches = biometricDevices.reduce((sum, d) => sum + d.totalSyncedPunches, 0);
  const payroll = payrollRuns[0];

  const avg = total > 0 ? Math.round(biometricDevices.reduce((sum, d) => sum + getDeviceAverageLatency(d), 0) / total) : 0;

  const health =
    avg < 80
      ? { text: 'Optimal (<80ms)', color: 'text-emerald-700 bg-emerald-50 border-emerald-200' }
      : avg <= 150
      ? { text: 'Normal (<150ms)', color: 'text-sky-700 bg-sky-50 border-sky-200' }
      : { text: 'High Jitter (>150ms)', color: 'text-amber-700 bg-amber-50 border-amber-200' };

  const getInfo = (d: typeof biometricDevices[0]) => {
    const lat = getLatency(d);
    const avgLat = getDeviceAverageLatency(d);
    const history = getDeviceLatencyHistory(d.id, lat);
    const min = Math.min(...history);
    const max = Math.max(...history);
    const isOffline = d.status === 'Offline';

    if (isOffline) {
      return {
        lat: 0,
        avg: 0,
        min: 0,
        max: 0,
        history,
        label: 'Offline (Heartbeat Lost)',
        color: 'text-slate-800 bg-slate-100 border-slate-300',
        badgeBg: 'bg-slate-900 text-white',
        barColor: 'bg-slate-300',
        percent: 0,
        isCritical: true,
      };
    }
    if (lat > 500 || avgLat > 500) {
      return {
        lat,
        avg: avgLat,
        min,
        max,
        history,
        label: `Critical SLA Breach (${lat}ms > 500ms)`,
        color: 'text-rose-700 bg-rose-50 border-rose-300 animate-pulse',
        badgeBg: 'bg-rose-600 text-white animate-pulse',
        barColor: 'bg-rose-600',
        percent: Math.min(100, Math.round((lat / 500) * 100)),
        isCritical: true,
      };
    }
    if (lat < 80) {
      return {
        lat,
        avg: avgLat,
        min,
        max,
        history,
        label: 'Fast LAN Optimal (<80ms)',
        color: 'text-emerald-700 bg-emerald-50 border-emerald-200',
        badgeBg: 'bg-emerald-100 text-emerald-800 border border-emerald-200',
        barColor: 'bg-emerald-500',
        percent: Math.min(100, Math.round((lat / 500) * 100)),
        isCritical: false,
      };
    }
    if (lat <= 150) {
      return {
        lat,
        avg: avgLat,
        min,
        max,
        history,
        label: 'Normal Target (<150ms)',
        color: 'text-sky-700 bg-sky-50 border-sky-200',
        badgeBg: 'bg-sky-100 text-sky-800 border border-sky-200',
        barColor: 'bg-sky-500',
        percent: Math.min(100, Math.round((lat / 500) * 100)),
        isCritical: false,
      };
    }
    return {
      lat,
      avg: avgLat,
      min,
      max,
      history,
      label: 'Elevated Jitter (150-500ms)',
      color: 'text-amber-700 bg-amber-50 border-amber-200',
      badgeBg: 'bg-amber-100 text-amber-800 border border-amber-200',
      barColor: 'bg-amber-500',
      percent: Math.min(100, Math.round((lat / 500) * 100)),
      isCritical: false,
    };
  };

  return {
    onlineBiometrics: online,
    totalBiometrics: total,
    totalPunchesSynced: punches,
    latestPayroll: payroll,
    averageLatency: avg,
    latencyHealthLabel: health,
    getDeviceLatencyInfo: getInfo,
  };
})();

  const attendanceRate = totalEmployees > 0 ? Math.round((presentToday / totalEmployees) * 100) : 0;

  // Previous month comparative trends (Current Month vs Previous Month - September 2026 baseline)
  const prevMonthActiveEmployees = Math.max(1, activeEmployees - 1);
  const employeeTrendPct = Number((((activeEmployees - prevMonthActiveEmployees) / prevMonthActiveEmployees) * 100).toFixed(1));

  // Pending leaves comparison against previous month backlog (Sept was 4 requests)
  const prevMonthPendingLeaves = 4;
  const leaveBacklogTrendPct = Number((((pendingLeaves - prevMonthPendingLeaves) / prevMonthPendingLeaves) * 100).toFixed(1));

  // Previous month payroll run (September 2026)
  const prevMonthPayroll = payrollRuns.find(p => p.month.toLowerCase().includes('sep') || p.id.includes('sep')) || payrollRuns[1];
  const prevMonthPayrollExpense = useMemo(() => {
    if (prevMonthPayroll && prevMonthPayroll.totalGrossPay) {
      return prevMonthPayroll.totalGrossPay + (prevMonthPayroll.totalEmployerContributions || Math.round(prevMonthPayroll.totalGrossPay * 0.0825));
    }
    return Math.round(totalPayrollExpense * 0.963);
  }, [prevMonthPayroll, totalPayrollExpense]);

  const payrollTrendPct = useMemo(() => {
    if (prevMonthPayrollExpense > 0) {
      return Number((((totalPayrollExpense - prevMonthPayrollExpense) / prevMonthPayrollExpense) * 100).toFixed(1));
    }
    return 3.8;
  }, [totalPayrollExpense, prevMonthPayrollExpense]);

  // Attendance rate comparison against September monthly benchmark (98.2%)
  const prevMonthAttendanceRate = 98.2;
  const attendanceTrendPct = Number((attendanceRate - prevMonthAttendanceRate).toFixed(1));

  // Department counts for bar graph
  const deptCounts = storeData.departments.map(dept => {
    const count = employees.filter(e => e.departmentId === dept.id).length;
    return { name: dept.name, code: dept.code, count };
  });

  // Handler for 'Download PDF Report' button in KPI summary section
  const handleDownloadPdfReport = () => {
    try {
      setIsExportingPdf(true);
      generateDashboardPdfReport({
        organizationName: storeData.currentOrg?.name || 'RSTPL Manufacturing Pvt. Ltd.',
        generatedByRole: currentRole,
        generatedAt: new Date(),
        kpis: {
          activeEmployees,
          totalEmployees,
          employeeTrendPct,
          prevMonthActiveEmployees,
          probationEmployees,
          pendingLeaves,
          approvedLeavesThisMonth,
          leaveBacklogTrendPct,
          prevMonthPendingLeaves,
          totalPayrollExpense,
          totalNetSalaryDisbursed,
          payrollTrendPct,
          prevMonthPayrollExpense,
          payrollMonth: currentMonthPayroll?.month || 'October 2026',
          attendanceRate,
          presentToday,
          absentToday,
          onLeaveToday,
          lateToday,
          attendanceTrendPct,
          prevMonthAttendanceRate,
        },
        biometrics: {
          devices: biometricDevices,
          onlineCount: onlineBiometrics,
          totalCount: biometricDevices.length,
          averageLatency,
          totalPunchesSynced,
          criticalAlertsCount: activeCriticalAlerts.length,
        },
        workforce: {
          departments: deptCounts,
          openVacancies,
        },
      });

      if (onLogAudit) {
        onLogAudit(
          'EXPORT',
          'Dashboard KPI Report',
          `Downloaded official Executive KPI Snapshot PDF for ${currentMonthPayroll?.month || 'October 2026'}`
        );
      }

      setPdfDownloadedToast('Executive KPI snapshot PDF downloaded successfully!');
      setTimeout(() => {
        setPdfDownloadedToast(null);
      }, 4000);
    } catch (err) {
      console.error('Failed to generate dashboard PDF report:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* 🚀 Interactive HRMS Unit Dashboard & Dynamic Operations Hub */}
      <InteractiveHrmsUnitDashboard
        storeData={storeData}
        currentRole={currentRole}
        onNavigate={onNavigate}
        onAddUnit={onAddUnit}
        onRoleChange={onRoleChange}
        onAddEmployee={onAddEmployee}
        onDownloadPdf={handleDownloadPdfReport}
        onLogAudit={onLogAudit}
      />

      {/* Top Banner / Welcome Ribbon with Co-Branded Visuals */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-950 via-sky-950 to-blue-900 p-6 sm:p-7 text-white shadow-xl border border-sky-800/40">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-400 text-slate-950">
                Company: RSTPL
              </span>
              <span className="text-xs text-sky-200 font-bold">Innovate · Integrate · Transform</span>
              <span className="text-slate-500">•</span>
              <span className="inline-flex items-center gap-1 text-xs text-amber-300 font-bold">
                <Zap className="w-3 h-3 fill-amber-400 text-amber-400" />
                <span>Power by RS TechnoVisions XpertSkillCop</span>
              </span>
            </div>
            <h1 className="text-2xl font-black tracking-tight sm:text-3xl text-white">
              Welcome to <span className="text-sky-400">CodeTech HRMS</span>
            </h1>
            <p className="mt-1 text-xs text-sky-100 max-w-xl font-medium">
              Smart HR Solutions for a Brighter Tomorrow. Powered by high-speed biometric telemetry, dynamic payroll compliance, multi-level approvals, and predictive KPI analytics.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => setShowBrandHub(true)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow-md transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>Discover Platform & Solutions</span>
            </button>
            <button
              onClick={onOpenAI}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/20 text-xs font-bold transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
              <span>Ask AI HR Assistant</span>
            </button>
            <button
              onClick={() => onNavigate('biometric')}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-sky-800/80 hover:bg-sky-700 text-white text-xs font-semibold border border-sky-500/30 transition-all cursor-pointer"
            >
              <Fingerprint className="w-4 h-4 text-amber-300" />
              <span>Biometric Hub ({onlineBiometrics}/{biometricDevices.length} Online)</span>
            </button>
            <button
              onClick={() => onNavigate('geofence')}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-indigo-900/90 hover:bg-indigo-800 text-white text-xs font-semibold border border-indigo-400/40 transition-all cursor-pointer shadow-xs"
            >
              <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>AI Geofencing Radar</span>
            </button>
          </div>
        </div>
        {/* Subtle decorative background shapes */}
        <div className="absolute -right-8 -bottom-10 w-64 h-64 rounded-full bg-sky-500/20 blur-3xl pointer-events-none"></div>
      </div>

      {/* 7 Core SaaS Modules Quick-Launch Strip (Matching Image 1) */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-sky-600"></span>
            <span className="text-xs font-black uppercase tracking-wider text-slate-800">
              RSTPL All-in-One HR & Business Solutions
            </span>
          </div>
          <button
            type="button"
            onClick={() => setShowBrandHub(true)}
            className="text-[11px] font-bold text-sky-700 hover:underline cursor-pointer"
          >
            Explore Consulting & Audits ➔
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {/* HRMS */}
          <button
            type="button"
            onClick={() => onNavigate('employees')}
            className="p-2.5 rounded-xl border border-rose-100 bg-rose-50/60 hover:bg-rose-100/70 text-left transition cursor-pointer group"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-rose-600 text-white flex items-center justify-center font-bold text-[10px]">
                <Users className="w-3.5 h-3.5" />
              </div>
              <span className="font-black text-xs text-slate-900 group-hover:text-rose-700">HRMS</span>
            </div>
            <p className="text-[10px] text-rose-800 font-semibold mt-1">Hire · Manage · Retain</p>
          </button>

          {/* Payroll */}
          <button
            type="button"
            onClick={() => onNavigate('payroll')}
            className="p-2.5 rounded-xl border border-emerald-100 bg-emerald-50/60 hover:bg-emerald-100/70 text-left transition cursor-pointer group"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-[10px]">
                <DollarSign className="w-3.5 h-3.5" />
              </div>
              <span className="font-black text-xs text-slate-900 group-hover:text-emerald-700">Payroll</span>
            </div>
            <p className="text-[10px] text-emerald-800 font-semibold mt-1">Simple · Secure</p>
          </button>

          {/* Attendance */}
          <button
            type="button"
            onClick={() => onNavigate('attendance')}
            className="p-2.5 rounded-xl border border-sky-100 bg-sky-50/60 hover:bg-sky-100/70 text-left transition cursor-pointer group"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-sky-600 text-white flex items-center justify-center font-bold text-[10px]">
                <CalendarCheck className="w-3.5 h-3.5" />
              </div>
              <span className="font-black text-xs text-slate-900 group-hover:text-sky-700">Attendance</span>
            </div>
            <p className="text-[10px] text-sky-800 font-semibold mt-1">Track Real-time</p>
          </button>

          {/* Leave */}
          <button
            type="button"
            onClick={() => onNavigate('leave')}
            className="p-2.5 rounded-xl border border-amber-100 bg-amber-50/60 hover:bg-amber-100/70 text-left transition cursor-pointer group"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold text-[10px]">
                <Calendar className="w-3.5 h-3.5" />
              </div>
              <span className="font-black text-xs text-slate-900 group-hover:text-amber-700">Leave</span>
            </div>
            <p className="text-[10px] text-amber-800 font-semibold mt-1">Plan · Apply · Approve</p>
          </button>

          {/* Recruitment */}
          <button
            type="button"
            onClick={() => onNavigate('recruitment')}
            className="p-2.5 rounded-xl border border-purple-100 bg-purple-50/60 hover:bg-purple-100/70 text-left transition cursor-pointer group"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-purple-600 text-white flex items-center justify-center font-bold text-[10px]">
                <UserCheck className="w-3.5 h-3.5" />
              </div>
              <span className="font-black text-xs text-slate-900 group-hover:text-purple-700">Recruitment</span>
            </div>
            <p className="text-[10px] text-purple-800 font-semibold mt-1">Attract · Hire · Grow</p>
          </button>

          {/* Performance */}
          <button
            type="button"
            onClick={() => onNavigate('performance')}
            className="p-2.5 rounded-xl border border-teal-100 bg-teal-50/60 hover:bg-teal-100/70 text-left transition cursor-pointer group"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-[10px]">
                <Activity className="w-3.5 h-3.5" />
              </div>
              <span className="font-black text-xs text-slate-900 group-hover:text-teal-700">Performance</span>
            </div>
            <p className="text-[10px] text-teal-800 font-semibold mt-1">Measure · Develop</p>
          </button>

          {/* Reports & Analytics */}
          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="p-2.5 rounded-xl border border-rose-100 bg-rose-50/60 hover:bg-rose-100/70 text-left transition cursor-pointer group col-span-2 sm:col-span-1"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-rose-700 text-white flex items-center justify-center font-bold text-[10px]">
                <TrendingUp className="w-3.5 h-3.5" />
              </div>
              <span className="font-black text-xs text-slate-900 group-hover:text-rose-800">Reports</span>
            </div>
            <p className="text-[10px] text-rose-800 font-semibold mt-1">Data · Trends · Action</p>
          </button>
        </div>
      </div>

      {/* Visual KPI Summary Header Bar with Download PDF Report */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="p-1.5 rounded-lg bg-sky-50 text-sky-700 border border-sky-100">
              <TrendingUp className="w-4 h-4" />
            </span>
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              Executive Operational KPI Summary
            </h2>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-sky-100 text-sky-800 border border-sky-200">
              {currentMonthPayroll?.month || 'October 2026'} Snapshot
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real-time workforce metrics, monthly expenditure & MoM trajectory compared against previous month baselines.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          {pdfDownloadedToast && (
            <span className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl animate-in fade-in">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>{pdfDownloadedToast}</span>
            </span>
          )}

          <button
            onClick={handleDownloadPdfReport}
            disabled={isExportingPdf}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-xs hover:shadow-md transition-all cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
            title="Download executive PDF snapshot of current dashboard metrics"
          >
            {isExportingPdf ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Generating PDF...</span>
              </>
            ) : (
              <>
                <FileDown className="w-4 h-4 text-sky-400" />
                <span>Download PDF Report</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Visual KPI Summary Cards: Active Employees, Pending Leaves, Monthly Payroll & Attendance */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI Card 1: Active Employees */}
        <div
          onClick={() => onNavigate('employees')}
          className="group bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:shadow-md hover:border-sky-300 transition-all duration-200 cursor-pointer flex flex-col justify-between relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-sky-50 rounded-bl-full pointer-events-none -mr-4 -mt-4 transition-transform group-hover:scale-110" />
          
          <div>
            <div className="flex items-center justify-between mb-3 relative z-10">
              <span className="p-2.5 rounded-xl bg-sky-50 text-sky-700 border border-sky-100 group-hover:bg-sky-600 group-hover:text-white transition-colors">
                <Users className="w-5 h-5" />
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>Active Staff</span>
              </span>
            </div>

            <div className="relative z-10">
              <span className="text-xs font-semibold text-slate-500 block">Total Active Workforce</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight">
                  {activeEmployees}
                </span>
                <span className="text-xs font-semibold text-slate-400 font-mono">
                  / {totalEmployees} Roster
                </span>
              </div>

              {/* Visual MoM Trend Indicator */}
              <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-2xs">
                  <ArrowUp className="w-3 h-3 text-emerald-600 stroke-[2.5]" />
                  <span>+{employeeTrendPct}%</span>
                </span>
                <span className="text-[11px] text-slate-500 font-medium">vs prev month ({prevMonthActiveEmployees} staff)</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 mt-2.5 relative z-10">
              {probationEmployees > 0 ? `${probationEmployees} on probation` : '100% headcount status'} across 3 facility units (HQ, Chakan & Sanand).
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-sky-700 group-hover:text-sky-800 relative z-10">
            <span>Workforce Master</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* KPI Card 2: Pending Leave Requests */}
        <div
          onClick={() => onNavigate('leave')}
          className="group bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:shadow-md hover:border-amber-300 transition-all duration-200 cursor-pointer flex flex-col justify-between relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-50 rounded-bl-full pointer-events-none -mr-4 -mt-4 transition-transform group-hover:scale-110" />

          <div>
            <div className="flex items-center justify-between mb-3 relative z-10">
              <span className="p-2.5 rounded-xl bg-amber-50 text-amber-700 border border-amber-100 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                <Calendar className="w-5 h-5" />
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border flex items-center gap-1 ${
                pendingLeaves > 0
                  ? 'bg-amber-50 text-amber-800 border-amber-200'
                  : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              }`}>
                {pendingLeaves > 0 ? (
                  <>
                    <AlertTriangle className="w-3 h-3 text-amber-600" />
                    <span>Action Needed</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>All Clear</span>
                  </>
                )}
              </span>
            </div>

            <div className="relative z-10">
              <span className="text-xs font-semibold text-slate-500 block">Pending Leave Requests</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight">
                  {pendingLeaves}
                </span>
                <span className="text-xs font-semibold text-slate-400">
                  {pendingLeaves === 1 ? 'Request pending' : 'Requests pending'}
                </span>
              </div>

              {/* Visual MoM Trend Indicator */}
              <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold border shadow-2xs ${
                  leaveBacklogTrendPct <= 0
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-amber-50 text-amber-800 border-amber-200'
                }`}>
                  {leaveBacklogTrendPct <= 0 ? (
                    <ArrowDown className="w-3 h-3 text-emerald-600 stroke-[2.5]" />
                  ) : (
                    <ArrowUp className="w-3 h-3 text-amber-600 stroke-[2.5]" />
                  )}
                  <span>{leaveBacklogTrendPct > 0 ? `+${leaveBacklogTrendPct}%` : `${leaveBacklogTrendPct}%`}</span>
                </span>
                <span className="text-[11px] text-slate-500 font-medium">
                  {leaveBacklogTrendPct <= 0 ? `backlog cleared vs prev mo (${prevMonthPendingLeaves})` : `backlog vs prev mo (${prevMonthPendingLeaves})`}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 mt-2.5 relative z-10">
              {approvedLeavesThisMonth} approved this month. Approvals maintain automated shift roster coverage.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-amber-700 group-hover:text-amber-800 relative z-10">
            <span>Review Leave Desk</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* KPI Card 3: Total Payroll Expenses (Current Month) */}
        <div
          onClick={() => onNavigate('payroll')}
          className="group bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:shadow-md hover:border-emerald-300 transition-all duration-200 cursor-pointer flex flex-col justify-between relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-50 rounded-bl-full pointer-events-none -mr-4 -mt-4 transition-transform group-hover:scale-110" />

          <div>
            <div className="flex items-center justify-between mb-3 relative z-10">
              <span className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-100 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                <DollarSign className="w-5 h-5" />
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                <span>{currentMonthPayroll?.month || 'October 2026'}</span>
              </span>
            </div>

            <div className="relative z-10">
              <span className="text-xs font-semibold text-slate-500 block">Total Payroll Expenses (Current Month)</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight">
                  ₹{totalPayrollExpense.toLocaleString('en-IN')}
                </span>
              </div>

              {/* Visual MoM Trend Indicator */}
              <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-2xs">
                  <ArrowUp className="w-3 h-3 text-emerald-600 stroke-[2.5]" />
                  <span>+{payrollTrendPct}%</span>
                </span>
                <span className="text-[11px] text-slate-500 font-medium">vs prev month (₹{prevMonthPayrollExpense.toLocaleString('en-IN')})</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-500 mt-2.5 relative z-10">
              Net take-home: <strong className="text-slate-800 font-mono">₹{totalNetSalaryDisbursed.toLocaleString('en-IN')}</strong> · PF 12% & ESIC statutory contributions included.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-emerald-700 group-hover:text-emerald-800 relative z-10">
            <span>Manage Payroll Engine</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* KPI Card 4: Today's Shift Attendance Rate */}
        <div
          onClick={() => onNavigate('attendance')}
          className="group bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs hover:shadow-md hover:border-indigo-300 transition-all duration-200 cursor-pointer flex flex-col justify-between relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-50 rounded-bl-full pointer-events-none -mr-4 -mt-4 transition-transform group-hover:scale-110" />

          <div>
            <div className="flex items-center justify-between mb-3 relative z-10">
              <span className="p-2.5 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-100 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                <Clock className="w-5 h-5" />
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-50 text-indigo-800 border border-indigo-200 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-indigo-600" />
                <span>100% Synced</span>
              </span>
            </div>

            <div className="relative z-10">
              <span className="text-xs font-semibold text-slate-500 block">Today's Attendance Rate</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight">
                  {attendanceRate}%
                </span>
                <span className="text-xs font-semibold text-slate-400 font-mono">
                  ({presentToday} Present)
                </span>
              </div>

              {/* Visual MoM Trend Indicator */}
              <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold border shadow-2xs ${
                  attendanceTrendPct >= 0
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : 'bg-rose-50 text-rose-700 border-rose-200'
                }`}>
                  {attendanceTrendPct >= 0 ? (
                    <ArrowUp className="w-3 h-3 text-emerald-600 stroke-[2.5]" />
                  ) : (
                    <ArrowDown className="w-3 h-3 text-rose-600 stroke-[2.5]" />
                  )}
                  <span>{attendanceTrendPct >= 0 ? `+${attendanceTrendPct}%` : `${attendanceTrendPct}%`}</span>
                </span>
                <span className="text-[11px] text-slate-500 font-medium">vs Sept benchmark ({prevMonthAttendanceRate}%)</span>
              </div>
            </div>

            {/* Mini Progress Bar */}
            <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden flex mt-2.5 relative z-10">
              <div
                style={{ width: `${(presentToday / totalEmployees) * 100}%` }}
                className="bg-emerald-500 h-full"
              />
              <div
                style={{ width: `${(onLeaveToday / totalEmployees) * 100}%` }}
                className="bg-sky-400 h-full"
              />
              <div
                style={{ width: `${(absentToday / totalEmployees) * 100}%` }}
                className="bg-rose-500 h-full"
              />
            </div>

            <p className="text-[11px] text-slate-500 mt-2 relative z-10">
              {onLeaveToday} on leave · {lateToday > 0 ? `${lateToday} late marks` : 'Zero late arrivals'}. Live biometric punch ingest.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-indigo-700 group-hover:text-indigo-800 relative z-10">
            <span>View Attendance Register</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>

      {/* HR Department Alert Banner for Biometric Latency (>500ms) or Offline Incidents */}
      {activeCriticalAlerts.length > 0 && (
        <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-4 sm:p-5 shadow-md text-slate-900 space-y-3.5 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start sm:items-center gap-3">
              <div className="relative p-2.5 rounded-xl bg-rose-600 text-white shadow-md shadow-rose-600/30 shrink-0">
                <BellRing className="w-5 h-5 animate-pulse" />
                <span className="absolute -top-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-600"></span>
                </span>
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-rose-200 text-rose-950 border border-rose-300 flex items-center gap-1">
                    <ShieldAlert className="w-3 h-3 text-rose-700" />
                    <span>HR & Operations Immediate Notice</span>
                  </span>
                  <span className="text-xs font-black text-rose-950">
                    Biometric Hardware Latency & Connectivity Incident ({activeCriticalAlerts.length} Machine Alert{activeCriticalAlerts.length > 1 ? 's' : ''})
                  </span>
                </div>
                <p className="text-xs text-rose-800 mt-1">
                  Threshold exceeded: <strong>Sync latency &gt;500ms SLA tolerance or terminal heartbeat disconnected</strong>. Shift attendance punch ingestion is delayed, risking shift turnover bottlenecks and payroll clocking discrepancies.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              <button
                onClick={handleRestoreOptimal}
                className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold border border-rose-200 shadow-2xs transition-colors cursor-pointer"
              >
                Resolve & Reset All
              </button>
              <button
                onClick={() => onNavigate('biometric')}
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer flex items-center gap-1"
              >
                <span>Biometric Studio</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Critical Device Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
            {activeCriticalAlerts.map(dev => {
              const lat = dev.syncLatencyMs ?? 0;
              const avgLat = getDeviceAverageLatency(dev);
              const isOffline = dev.status === 'Offline';
              const isPinging = pingingDeviceId === dev.id;

              return (
                <div key={dev.id} className="bg-white rounded-xl p-3.5 border border-rose-200 shadow-2xs text-xs space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-bold text-slate-900 leading-snug">{dev.name}</h4>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 font-mono text-slate-600 border border-slate-200">
                          {dev.vendor}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                        {dev.ipAddress}:{dev.port} · {dev.location}
                      </p>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold shrink-0 ${
                        isOffline
                          ? 'bg-slate-900 text-white'
                          : 'bg-rose-100 text-rose-900 border border-rose-300 animate-pulse'
                      }`}
                    >
                      {isOffline ? 'DEVICE OFFLINE' : `LATENCY: ${lat}ms (>500ms)`}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-lg bg-rose-50/70 border border-rose-100 text-[11px] text-rose-900 space-y-1">
                    <p className="font-semibold flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                      <span>{isOffline ? 'Terminal Disconnected (Zero Heartbeat):' : 'Severe Sync Packet Latency Violation:'}</span>
                    </p>
                    <p className="text-slate-700">
                      {isOffline
                        ? 'Hardware did not respond to ADMS/TCP polling. Plant supervisors should verify network cable and power supply.'
                        : `Current round-trip sync latency of ${lat}ms (Average: ${avgLat}ms) exceeds the 500ms HR tolerance SLA by ${lat - 500}ms. Punch queuing delayed.`}
                    </p>
                    {!isOffline && (
                      <div className="pt-1 flex items-center gap-3 font-mono text-[10px] text-slate-500">
                        <span>Current: <strong className="text-rose-700 font-bold">{lat}ms</strong></span>
                        <span>·</span>
                        <span>Avg Ping: <strong className="text-slate-800">{avgLat}ms</strong></span>
                        <span>·</span>
                        <span>SLA Ceiling: <strong className="text-slate-800">500ms</strong></span>
                      </div>
                    )}
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] flex-wrap gap-2">
                    <span className="text-slate-400">
                      S/N: <strong className="text-slate-700 font-mono">{dev.serialNumber}</strong>
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handlePingDevice(dev.id)}
                        disabled={isPinging}
                        className="px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 font-semibold text-[11px] border border-sky-200 transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <RefreshCw className={`w-3 h-3 text-sky-600 ${isPinging ? 'animate-spin' : ''}`} />
                        <span>{isPinging ? 'Pinging...' : 'Re-Test Ping'}</span>
                      </button>
                      <button
                        onClick={() => handleAcknowledgeAlert(dev.id)}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-[11px] transition-colors cursor-pointer"
                      >
                        Acknowledge Alert
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Biometric & Connection Sync System Health Indicator */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className={`relative w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${
              activeCriticalAlerts.length > 0
                ? 'bg-rose-50 border-rose-200 text-rose-700'
                : 'bg-emerald-50 border-emerald-200 text-emerald-700'
            }`}>
              <Fingerprint className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  activeCriticalAlerts.length > 0 ? 'bg-rose-400' : 'bg-emerald-400'
                }`}></span>
                <span className={`relative inline-flex rounded-full h-3 w-3 ${
                  activeCriticalAlerts.length > 0 ? 'bg-rose-500' : 'bg-emerald-500'
                }`}></span>
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-black text-slate-900 tracking-tight">System Health Indicator: Biometric IoT Network</span>
                
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border flex items-center gap-1 ${
                  onlineBiometrics === totalBiometrics
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                    : 'bg-amber-100 text-amber-900 border-amber-200'
                }`}>
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  <span>{onlineBiometrics}/{totalBiometrics} Terminals Online</span>
                </span>

                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border flex items-center gap-1 ${latencyHealthLabel.color}`}>
                  <Zap className="w-3 h-3 text-amber-500" />
                  <span>Fleet Avg Latency: {averageLatency}ms</span>
                </span>

                <span className="text-[11px] text-slate-400 hidden sm:inline">·</span>
                <span className="text-[11px] font-medium text-slate-600 flex items-center gap-1">
                  <Wifi className="w-3 h-3 text-emerald-600" />
                  <span>Sync Status: <strong className="text-slate-800">Active TCP 4370 & ADMS Listener</strong></span>
                </span>
              </div>

              <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-2 flex-wrap">
                <span>Total Punches Synchronized: <strong className="text-slate-800 font-mono">{totalPunchesSynced.toLocaleString()}</strong></span>
                <span className="text-slate-300">|</span>
                <span>Connection Health: <strong className="text-slate-700">{latencyHealthLabel.text}</strong></span>
                <span className="text-slate-300">|</span>
                <span>Active Vendors: <strong className="text-slate-700">{Array.from(new Set(biometricDevices.map(d => d.vendor))).join(', ')}</strong></span>
                <span className="text-slate-300">|</span>
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  Real-time Polling Active
                </span>
              </p>
            </div>
          </div>

          {/* Interactive Diagnostic & Simulation Toolbar */}
          <div className="flex items-center gap-2 shrink-0 flex-wrap">
            <button
              onClick={handlePingAllDevices}
              disabled={isPingingAll}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 text-xs font-semibold transition-colors cursor-pointer"
              title="Ping all biometric devices to recalculate average sync latencies"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-slate-600 ${isPingingAll ? 'animate-spin' : ''}`} />
              <span>{isPingingAll ? 'Probing Latency...' : 'Re-Ping Telemetry'}</span>
            </button>

            <button
              onClick={handleSimulateLatencySpike}
              className="px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 text-xs font-semibold transition-colors cursor-pointer"
              title="Simulate high latency spike (>500ms) to test HR alert notification"
            >
              Simulate &gt;500ms Spike
            </button>

            <button
              onClick={handleSimulateDeviceOffline}
              className="px-2.5 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-xs font-semibold transition-colors cursor-pointer"
              title="Simulate device offline state to test HR alert notification"
            >
              Simulate Offline
            </button>

            <button
              onClick={handleRestoreOptimal}
              className="px-2.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-semibold transition-colors cursor-pointer"
              title="Restore all devices to healthy low latency (<80ms) and clear alerts"
            >
              Restore SLA
            </button>

            {/* View Mode Switcher: List vs Map with Smooth CSS Transitions */}
            <div className="relative flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs">
              <div
                className={`absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-lg bg-white shadow-xs border border-slate-200/80 transition-all duration-300 ease-out pointer-events-none ${
                  biometricViewMode === 'list' ? 'left-1' : 'left-[calc(50%+2px)]'
                }`}
              />
              <button
                onClick={() => {
                  handleSwitchView('list');
                  const el = document.getElementById('biometric-telemetry-hub');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`relative z-10 flex items-center gap-1.5 px-3 py-1 rounded-lg font-semibold transition-colors duration-200 cursor-pointer ${
                  biometricViewMode === 'list'
                    ? 'text-slate-900 font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <LayoutList className="w-3.5 h-3.5 text-sky-600" />
                <span>List View</span>
              </button>
              <button
                onClick={() => {
                  handleSwitchView('map');
                  const el = document.getElementById('biometric-telemetry-hub');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`relative z-10 flex items-center gap-1.5 px-3 py-1 rounded-lg font-semibold transition-colors duration-200 cursor-pointer ${
                  biometricViewMode === 'map'
                    ? 'text-slate-900 font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <MapPin className="w-3.5 h-3.5 text-sky-600" />
                <span>Map View</span>
              </button>
            </div>

            <button
              onClick={() => onNavigate('biometric')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-colors cursor-pointer shadow-2xs"
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Hardware Hub</span>
            </button>
          </div>
        </div>
      </div>

      {/* 📊 Interactive Real-Time Attendance Trends & KPI Telemetry Grid (Recharts) */}
      <RealtimeAttendanceKpiGrid
        attendance={attendance}
        employees={employees}
        departments={storeData.departments}
        shifts={storeData.shifts}
        units={storeData.units}
        rawPunches={storeData.rawPunches}
        geoPunches={geoPunches}
        onNavigate={onNavigate}
      />

      {/* Primary KPI Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div
          onClick={() => onNavigate('employees')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-sky-300 hover:shadow-xs transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold">Total Manpower</span>
            <Users className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-2xl font-black text-slate-900">{totalEmployees}</div>
          <div className="text-[10px] text-emerald-600 font-semibold mt-1 flex items-center gap-0.5">
            <span>{activeEmployees} Active on roll</span>
          </div>
        </div>

        <div
          onClick={() => onNavigate('attendance')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-sky-300 hover:shadow-xs transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold">Present Today</span>
            <UserCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-600">{presentToday}</div>
          <div className="text-[10px] text-slate-500 font-medium mt-1">
            {attendanceRate}% workforce presence
          </div>
        </div>

        <div
          onClick={() => onNavigate('attendance')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-sky-300 hover:shadow-xs transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold">Absent / Unplanned</span>
            <UserX className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-black text-rose-600">{absentToday}</div>
          <div className="text-[10px] text-rose-500 font-medium mt-1">
            Requires regularization
          </div>
        </div>

        <div
          onClick={() => onNavigate('attendance')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-sky-300 hover:shadow-xs transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold">Late Coming</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-amber-500">{lateToday}</div>
          <div className="text-[10px] text-slate-500 font-medium mt-1">
            Beyond 15-min grace
          </div>
        </div>

        <div
          onClick={() => onNavigate('leave')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-sky-300 hover:shadow-xs transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold">Pending Leaves</span>
            <Calendar className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-indigo-600">{pendingLeaves}</div>
          <div className="text-[10px] text-slate-500 font-medium mt-1">
            {onLeaveToday} on leave today
          </div>
        </div>

        <div
          onClick={() => onNavigate('recruitment')}
          className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs hover:border-sky-300 hover:shadow-xs transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-semibold">Open Requisitions</span>
            <Briefcase className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-2xl font-black text-sky-600">{openVacancies}</div>
          <div className="text-[10px] text-emerald-600 font-medium mt-1">
            2 active postings
          </div>
        </div>
      </div>

      {/* Biometric Hardware Fleet & Site Diagnostics Hub with Smooth CSS View Transitions */}
      <div id="biometric-telemetry-hub" className="space-y-3.5">
        {/* Hub Header & Smooth Segmented View Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3.5 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="p-1.5 rounded-lg bg-sky-50 text-sky-700 border border-sky-100">
                <Fingerprint className="w-4 h-4" />
              </span>
              <h3 className="text-sm font-bold text-slate-900">
                Biometric Terminal Fleet & Physical Site Telemetry Hub
              </h3>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold border flex items-center gap-1 ${
                onlineBiometrics === totalBiometrics
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : 'bg-amber-50 text-amber-800 border-amber-200'
              }`}>
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                <span>{onlineBiometrics}/{totalBiometrics} Online</span>
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Switch smoothly between comprehensive device diagnostic list and interactive plant location map.
            </p>
          </div>

          {/* Segmented View Switcher with Animated Sliding Background Pill */}
          <div className="relative flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs self-start sm:self-auto">
            {/* Sliding Pill Indicator with CSS Transitions */}
            <div
              className={`absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-lg bg-white shadow-xs border border-slate-200/80 transition-all duration-300 ease-out pointer-events-none ${
                biometricViewMode === 'list' ? 'left-1' : 'left-[calc(50%+2px)]'
              }`}
            />

            <button
              onClick={() => handleSwitchView('list')}
              className={`relative z-10 flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-bold transition-colors duration-200 cursor-pointer ${
                biometricViewMode === 'list'
                  ? 'text-sky-900'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <LayoutList className="w-3.5 h-3.5 text-sky-600" />
              <span>List View</span>
              <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded transition-colors ${
                biometricViewMode === 'list' ? 'bg-sky-100 text-sky-800' : 'bg-slate-200/70 text-slate-600'
              }`}>
                4
              </span>
            </button>

            <button
              onClick={() => handleSwitchView('map')}
              className={`relative z-10 flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-bold transition-colors duration-200 cursor-pointer ${
                biometricViewMode === 'map'
                  ? 'text-sky-900'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <MapPin className="w-3.5 h-3.5 text-sky-600" />
              <span>Map View</span>
              <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded transition-colors ${
                biometricViewMode === 'map' ? 'bg-sky-100 text-sky-800' : 'bg-slate-200/70 text-slate-600'
              }`}>
                Sites
              </span>
            </button>
          </div>
        </div>

        {/* View Mode Animated Content Container with Smooth CSS Transitions */}
        <div
          className={`relative overflow-hidden transition-all duration-300 ease-in-out ${
            isViewTransitioning ? 'opacity-90 scale-[0.998]' : 'opacity-100 scale-100'
          }`}
        >
          {biometricViewMode === 'list' ? (
            <div
              key="biometric-list-view-mode"
              className="smooth-view-enter space-y-4 transition-all duration-300 ease-out"
            >
              {/* Fleet Latency Diagnostics Overview Bar */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-sky-50 text-sky-700 border border-sky-100">
                    <Gauge className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold text-slate-900">Fleet Round-Trip Latency Telemetry</span>
                      <span className={`text-[10px] font-sans px-2 py-0.5 rounded-full border ${latencyHealthLabel.color}`}>
                        {latencyHealthLabel.text}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Average Calculated Sync Latency: <strong className="text-slate-800 font-mono text-xs">{averageLatency}ms</strong> across all active site terminals
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={handlePingAllDevices}
                    disabled={isPingingAll}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 text-slate-600 ${isPingingAll ? 'animate-spin' : ''}`} />
                    <span>{isPingingAll ? 'Pinging All...' : 'Re-Test All Pings'}</span>
                  </button>
                  <button
                    onClick={() => handleSwitchView('map')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-bold transition-colors cursor-pointer"
                  >
                    <MapPin className="w-3.5 h-3.5 text-sky-600" />
                    <span>Switch to Map View</span>
                  </button>
                </div>
              </div>

              {/* Responsive 4-Device Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {biometricDevices.map(dev => {
                  const latInfo = getDeviceLatencyInfo(dev);
                  const isPinging = pingingDeviceId === dev.id;
                  const isOffline = dev.status === 'Offline';

                  return (
                    <div
                      key={dev.id}
                      className={`p-4 rounded-2xl border bg-white shadow-2xs text-xs space-y-3 transition-all duration-200 ${
                        latInfo.isCritical
                          ? 'border-rose-300 ring-2 ring-rose-500/10'
                          : 'border-slate-200 hover:border-sky-300 hover:shadow-xs'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <h4 className="font-bold text-slate-900 text-sm">{dev.name}</h4>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                              {dev.vendor}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                            {dev.ipAddress}:{dev.port} · {dev.location}
                          </p>
                        </div>

                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border flex items-center gap-1 shrink-0 ${latInfo.color}`}
                        >
                          <Zap className="w-2.5 h-2.5" />
                          <span>{isOffline ? 'OFFLINE' : `${latInfo.lat}ms`}</span>
                        </span>
                      </div>

                      {/* Average Latency & Range Diagnostic Box */}
                      <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-2 text-[11px]">
                        <div className="flex items-center justify-between text-slate-600">
                          <span className="flex items-center gap-1">
                            <Activity className="w-3 h-3 text-sky-600" />
                            <span>Calculated Avg Sync Latency:</span>
                          </span>
                          <span className="font-mono font-bold text-slate-900">
                            {isOffline ? 'N/A (Offline)' : `${latInfo.avg}ms`}
                            <span className="text-[10px] font-normal text-slate-400 font-sans ml-1">
                              ({latInfo.history.length} samples)
                            </span>
                          </span>
                        </div>

                        {/* Visual Latency SLA Bar */}
                        <div>
                          <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                            <span>Latency SLA Meter (0 - 500ms)</span>
                            <span className={`font-semibold ${
                              latInfo.lat > 500 ? 'text-rose-700' : 'text-slate-600'
                            }`}>
                              {latInfo.label}
                            </span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                            <div
                              className={`h-1.5 rounded-full transition-all duration-300 ${latInfo.barColor}`}
                              style={{ width: `${isOffline ? 0 : Math.max(8, latInfo.percent)}%` }}
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                          <span>
                            Jitter: Min <strong className="font-mono text-slate-700">{isOffline ? '-' : `${latInfo.min}ms`}</strong> · Max <strong className="font-mono text-slate-700">{isOffline ? '-' : `${latInfo.max}ms`}</strong>
                          </span>
                          <span>{dev.totalSyncedPunches.toLocaleString()} punches synced</span>
                        </div>
                      </div>

                      {/* Card Footer: Placeholder Coordinates, Ping Button, and View on Map */}
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] flex-wrap gap-2">
                        <span className="text-slate-400 font-mono text-[10px]">
                          GPS: {dev.latitude?.toFixed(4)}° N, {dev.longitude?.toFixed(4)}° E
                        </span>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handlePingDevice(dev.id)}
                            disabled={isPinging}
                            className="px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-[11px] font-semibold transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                          >
                            <RefreshCw className={`w-3 h-3 text-sky-600 ${isPinging ? 'animate-spin' : ''}`} />
                            <span>{isPinging ? 'Pinging...' : 'Test Ping'}</span>
                          </button>

                          <button
                            onClick={() => handleSwitchView('map', dev.id)}
                            className="px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-[11px] font-semibold transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                          >
                            <MapPin className="w-3.5 h-3.5 text-sky-600" />
                            <span>View on Map</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div
              key="biometric-map-view-mode"
              className="smooth-view-enter transition-all duration-300 ease-out"
            >
              <BiometricLocationMapView
                devices={biometricDevices}
                onPingDevice={handlePingDevice}
                pingingDeviceId={pingingDeviceId}
                onNavigate={onNavigate}
                onSwitchToListView={() => handleSwitchView('list')}
                selectedDeviceId={focusedMapDeviceId}
                onSelectDeviceId={setFocusedMapDeviceId}
                onFetchConnectivityStatus={handlePingAllDevices}
                isFetchingConnectivity={isPingingAll}
              />
            </div>
          )}
        </div>
      </div>

      {/* Live Workforce Geofence Distribution & Perimeter Radar Map */}
      <GeofenceDistributionMapView
        units={storeData.units}
        employees={employees}
        attendance={attendance}
        onNavigate={onNavigate}
        onAddNotification={onAddNotification}
        onLogAudit={onLogAudit}
      />

      {/* 7-Day Biometric Synchronization Success Rate Trend Chart Widget (Recharts) */}
      <BiometricSyncTrendWidget
        devices={biometricDevices}
        onNavigate={onNavigate}
        onOpenBiometricStudio={() => onNavigate('biometric')}
      />

      {/* 6-Month Workforce Headcount Growth Trend Line Chart (Recharts) */}
      <HeadcountTrendWidget
        employees={employees}
        jobOpenings={jobOpenings}
        onNavigate={onNavigate}
      />

      {/* Main Charts & Telemetry Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Attendance Breakdown Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Today's Attendance Ratio</h3>
                <p className="text-[11px] text-slate-500">Live biometric & shift calculations</p>
              </div>
              <span className="text-xs font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-full border border-sky-100">
                100% Synced
              </span>
            </div>

            {/* Visual Progress Bar representation */}
            <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden flex shadow-inner mb-4">
              <div
                style={{ width: `${(presentToday / totalEmployees) * 100}%` }}
                className="bg-emerald-500 h-full transition-all duration-500"
                title={`Present: ${presentToday}`}
              />
              <div
                style={{ width: `${(onLeaveToday / totalEmployees) * 100}%` }}
                className="bg-sky-400 h-full transition-all duration-500"
                title={`On Leave: ${onLeaveToday}`}
              />
              <div
                style={{ width: `${(absentToday / totalEmployees) * 100}%` }}
                className="bg-rose-500 h-full transition-all duration-500"
                title={`Absent: ${absentToday}`}
              />
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  Present & Working
                </span>
                <span className="font-bold text-slate-900">{presentToday} ({attendanceRate}%)</span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-sky-400"></span>
                  Approved Leave (CL/EL/SL)
                </span>
                <span className="font-bold text-slate-900">{onLeaveToday}</span>
              </div>
              <div className="flex items-center justify-between py-1">
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                  Unplanned Absence
                </span>
                <span className="font-bold text-slate-900">{absentToday}</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('attendance')}
            className="mt-4 w-full py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 border border-slate-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>View Full Attendance Register</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Department Manpower Distribution */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Department Workforce Distribution</h3>
                <p className="text-[11px] text-slate-500">Active personnel across operations</p>
              </div>
              <button
                onClick={() => onNavigate('organization')}
                className="text-xs text-sky-600 hover:underline font-semibold"
              >
                Structure
              </button>
            </div>

            <div className="space-y-2.5">
              {deptCounts.slice(0, 5).map(d => (
                <div key={d.code} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-700 font-medium truncate max-w-[180px]">{d.name}</span>
                    <span className="font-bold text-slate-900">{d.count} staff</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div
                      className="bg-sky-600 h-1.5 rounded-full"
                      style={{ width: `${Math.max(10, (d.count / totalEmployees) * 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigate('employees')}
            className="mt-4 w-full py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 border border-slate-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>Explore Employee Master</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Biometric Integration Status Box & Average Latency Monitoring */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <Fingerprint className="w-4 h-4 text-sky-600" />
                  <span>Biometric Device Telemetry</span>
                </h3>
                <p className="text-[11px] text-slate-500">Device-level average latency calculations & diagnostics</p>
              </div>
              <span className={`flex items-center gap-1 text-[11px] font-bold ${
                onlineBiometrics === totalBiometrics ? 'text-emerald-600' : 'text-amber-600'
              }`}>
                <span className={`w-2 h-2 rounded-full ${
                  onlineBiometrics === totalBiometrics ? 'bg-emerald-500' : 'bg-amber-500'
                } animate-pulse`}></span>
                <span>{onlineBiometrics}/{totalBiometrics} Online</span>
              </span>
            </div>

            {/* Diagnostic Latency Status Bar */}
            <div className="mb-3 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between text-[11px] flex-wrap gap-2">
              <span className="text-slate-600 flex items-center gap-1 font-medium">
                <Gauge className="w-3.5 h-3.5 text-sky-600" />
                <span>Fleet Average Latency:</span>
              </span>
              <div className="flex items-center gap-2 font-mono font-bold">
                <span className="text-slate-900 text-xs">{averageLatency}ms</span>
                <span className={`text-[10px] font-sans px-2 py-0.5 rounded-full border ${latencyHealthLabel.color}`}>
                  {latencyHealthLabel.text}
                </span>
              </div>
            </div>

            {/* Device-by-Device Latency Cards */}
            <div className="space-y-3">
              {biometricDevices.map(dev => {
                const latInfo = getDeviceLatencyInfo(dev);
                const isPinging = pingingDeviceId === dev.id;
                const isOffline = dev.status === 'Offline';

                return (
                  <div
                    key={dev.id}
                    className={`p-3 rounded-xl border text-xs transition-all ${
                      latInfo.isCritical
                        ? 'border-rose-300 bg-rose-50/40'
                        : 'border-slate-200 bg-slate-50/60 hover:border-sky-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-bold text-slate-900 leading-snug">{dev.name}</h4>
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-white border border-slate-200 text-slate-600">
                            {dev.vendor}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                          {dev.ipAddress}:{dev.port} · {dev.location}
                        </p>
                      </div>

                      <div className="text-right shrink-0">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border flex items-center gap-1 ${latInfo.color}`}
                          title={`Current round-trip sync latency`}
                        >
                          <Zap className="w-2.5 h-2.5" />
                          <span>{isOffline ? 'OFFLINE' : `${latInfo.lat}ms`}</span>
                        </span>
                      </div>
                    </div>

                    {/* Calculated Average Sync Latency & Detailed Diagnostics */}
                    <div className="mt-2 pt-2 border-t border-slate-200/60 text-[11px] space-y-1.5">
                      <div className="flex items-center justify-between text-slate-600">
                        <span className="flex items-center gap-1">
                          <Activity className="w-3 h-3 text-sky-600" />
                          <span>Calculated Avg Sync Latency:</span>
                        </span>
                        <span className="font-mono font-bold text-slate-900">
                          {isOffline ? 'N/A (Offline)' : `${latInfo.avg}ms`}
                          <span className="text-[10px] font-normal text-slate-400 font-sans ml-1">
                            ({latInfo.history.length} samples)
                          </span>
                        </span>
                      </div>

                      {/* Visual Latency Gauge Bar vs 500ms SLA */}
                      <div>
                        <div className="flex items-center justify-between text-[10px] text-slate-500 mb-1">
                          <span>Latency SLA Meter (0 - 500ms)</span>
                          <span className={`font-semibold ${
                            latInfo.lat > 500 ? 'text-rose-700' : 'text-slate-600'
                          }`}>
                            {latInfo.label}
                          </span>
                        </div>
                        <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                          <div
                            className={`h-1.5 rounded-full transition-all duration-300 ${latInfo.barColor}`}
                            style={{ width: `${isOffline ? 0 : Math.max(8, latInfo.percent)}%` }}
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5">
                        <span>
                          Min: <strong className="text-slate-600 font-mono">{isOffline ? '-' : `${latInfo.min}ms`}</strong> · Max: <strong className="text-slate-600 font-mono">{isOffline ? '-' : `${latInfo.max}ms`}</strong>
                        </span>
                        <span>{dev.totalSyncedPunches.toLocaleString()} punches synced</span>
                      </div>
                    </div>

                    {/* Individual Device Test Ping Control */}
                    <div className="mt-2 pt-1.5 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 font-mono">
                        SLA Target: &lt;150ms · Max 500ms
                      </span>
                      <button
                        onClick={() => handlePingDevice(dev.id)}
                        disabled={isPinging}
                        className="px-2 py-0.5 rounded-md bg-white hover:bg-slate-100 text-sky-800 border border-slate-200 text-[10px] font-semibold transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                      >
                        <RefreshCw className={`w-2.5 h-2.5 text-sky-600 ${isPinging ? 'animate-spin' : ''}`} />
                        <span>{isPinging ? 'Pinging...' : 'Test Ping'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <button
            onClick={() => onNavigate('biometric')}
            className="mt-4 w-full py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-xs font-bold text-white transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
          >
            <Fingerprint className="w-3.5 h-3.5" />
            <span>Open Biometric Integration Studio</span>
          </button>
        </div>
      </div>

      {/* Financial Payroll & Quick Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Payroll summary card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Payroll & Statutory Summary</h3>
              <p className="text-[11px] text-slate-500">{latestPayroll.month} Execution Status</p>
            </div>
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
              {latestPayroll.status}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-4 my-4">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
              <span className="text-[10px] font-medium text-slate-500 uppercase">Gross Earnings</span>
              <p className="text-sm font-bold text-slate-900 mt-0.5">
                ₹{latestPayroll.totalGrossPay.toLocaleString('en-IN')}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-rose-50/60 border border-rose-100">
              <span className="text-[10px] font-medium text-rose-600 uppercase">Statutory Deductions</span>
              <p className="text-sm font-bold text-rose-700 mt-0.5">
                ₹{latestPayroll.totalDeductions.toLocaleString('en-IN')}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-sky-50 border border-sky-100">
              <span className="text-[10px] font-medium text-sky-700 uppercase">Net Disbursed</span>
              <p className="text-sm font-bold text-sky-900 mt-0.5">
                ₹{latestPayroll.totalNetPay.toLocaleString('en-IN')}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 pt-2">
            <span>Approved by: <strong className="text-slate-800">{latestPayroll.approvedBy || 'Pending'}</strong></span>
            <button
              onClick={() => onNavigate('payroll')}
              className="text-sky-600 hover:underline font-semibold"
            >
              Manage Monthly Runs →
            </button>
          </div>
        </div>

        {/* Quick Enterprise Action Center */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 mb-1">Quick Action Command Hub</h3>
          <p className="text-[11px] text-slate-500 mb-4">Fast shortcuts for enterprise HR workflows</p>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => onNavigate('biometric')}
              className="p-3 text-left rounded-xl border border-slate-200 hover:border-sky-500 hover:bg-sky-50/40 transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2 font-bold text-xs text-slate-900 group-hover:text-sky-700">
                <Fingerprint className="w-4 h-4 text-sky-600" />
                <span>Sync Attendance</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Ingest raw punches from hardware</p>
            </button>

            <button
              onClick={() => onNavigate('finalization')}
              className="p-3 text-left rounded-xl border border-slate-200 hover:border-sky-500 hover:bg-sky-50/40 transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2 font-bold text-xs text-slate-900 group-hover:text-sky-700">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Finalize Attendance</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Audit and lock records for payroll</p>
            </button>

            <button
              onClick={() => onNavigate('letters')}
              className="p-3 text-left rounded-xl border border-slate-200 hover:border-sky-500 hover:bg-sky-50/40 transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2 font-bold text-xs text-slate-900 group-hover:text-sky-700">
                <Briefcase className="w-4 h-4 text-amber-500" />
                <span>HR Letter Generator</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">Appointment & increment letters</p>
            </button>

            <button
              onClick={() => onNavigate('reports')}
              className="p-3 text-left rounded-xl border border-slate-200 hover:border-sky-500 hover:bg-sky-50/40 transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-2 font-bold text-xs text-slate-900 group-hover:text-sky-700">
                <TrendingUp className="w-4 h-4 text-indigo-600" />
                <span>Export Reports</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">PF ECR, registers & CSV files</p>
            </button>
          </div>
        </div>
      </div>

      {/* Brand & Advisory Solutions Showcase Modal */}
      <BrandShowcaseModal
        isOpen={showBrandHub}
        onClose={() => setShowBrandHub(false)}
        onNavigateToModule={mod => {
          onNavigate(mod);
          setShowBrandHub(false);
        }}
      />
    </div>
  );
};

// RSTPL HRMS - Live Workforce Geofence Distribution & Perimeter Radar Map
// RS Technovisions XpertSkillCop
// High-fidelity SVG map visualization displaying live employee distribution across active units
// with designated GPS radius perimeters and highlighted high-breach incident alerts.

import React, { useState, useMemo, useCallback } from 'react';
import {
  Navigation,
  Radio,
  MapPin,
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  Users,
  Building,
  CheckCircle2,
  ChevronRight,
  ExternalLink,
  Layers,
  Zap,
  Crosshair,
  Maximize2,
  Minimize2,
  Clock,
  ArrowUpRight,
  AlertCircle,
  Eye,
  Info,
  Sparkles,
  RefreshCw,
  Sliders
} from 'lucide-react';
import { Unit, Employee, AttendanceRecord, GeofenceBreachAlert, AppNotification } from '../../types/hrms';
import { formatDistance, playGeofenceAlertChime, INITIAL_BREACH_ALERTS } from '../../services/geofenceService';

interface GeofenceDistributionMapViewProps {
  units: Unit[];
  employees: Employee[];
  attendance: AttendanceRecord[];
  breachAlerts?: GeofenceBreachAlert[];
  onNavigate?: (module: string) => void;
  onAddNotification?: (notif: AppNotification) => void;
  onLogAudit?: (action: any, module: string, details: string) => void;
}

// Projected coordinate layout for the SVG territory map (viewBox 0 0 1000 620)
interface ProjectedUnitNode {
  unit: Unit;
  svgX: number;
  svgY: number;
  regionLabel: string;
  assignedEmployees: Employee[];
  presentEmployees: Employee[];
  absentEmployees: Employee[];
  activeBreaches: GeofenceBreachAlert[];
  hasCriticalBreach: boolean;
  hasHighBreach: boolean;
  hasActiveBreach: boolean;
  maxRiskScore: number;
  perimeterRadiusSvg: number; // Scaled radius for SVG visualization
}

export const GeofenceDistributionMapView: React.FC<GeofenceDistributionMapViewProps> = ({
  units,
  employees,
  attendance,
  breachAlerts: propBreachAlerts,
  onNavigate,
  onAddNotification,
  onLogAudit
}) => {
  // Alerts state
  const [localBreachAlerts, setLocalBreachAlerts] = useState<GeofenceBreachAlert[]>(
    propBreachAlerts || INITIAL_BREACH_ALERTS
  );

  // Active view mode: 'national' | 'radar_grid' | 'breach_focus'
  const [viewMode, setViewMode] = useState<'national' | 'radar_grid' | 'breach_focus'>('national');

  // Selected Unit for the interactive details drawer / inspector
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);

  // Hover state
  const [hoveredUnitId, setHoveredUnitId] = useState<string | null>(null);

  // Zoom / View scale
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Sound toggle
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Simulation feedback banner
  const [simFeedback, setSimFeedback] = useState<string | null>(null);

  // Filter state for search
  const [filterQuery, setFilterQuery] = useState<string>('');

  // Fixed coordinates mapping for RSTPL enterprise operating locations in India
  const getProjectedCoords = useCallback((unitId: string, index: number): { x: number; y: number; region: string } => {
    switch (unitId) {
      case 'un-corp':
        // Gurugram, Delhi NCR (North Zone)
        return { x: 490, y: 155, region: 'Delhi NCR · North Hub' };
      case 'un-tool':
        // Sanand Precision Tooling, Gujarat (West Zone 1)
        return { x: 280, y: 310, region: 'Sanand MIDC · Gujarat' };
      case 'un-mfg1':
        // Chakan Plant 1, Pune MIDC (West Zone 2)
        return { x: 385, y: 405, region: 'Chakan Auto Hub · Pune' };
      case 'un-mfg2':
        // Heavy Fabrication Unit 2, Chakan Phase 2, Pune
        return { x: 445, y: 445, region: 'Chakan Phase II · Pune' };
      case 'un-tech':
        // Electronic City, Bengaluru (South Zone)
        return { x: 470, y: 535, region: 'Electronic City · Bengaluru' };
      default: {
        // Fallback layout algorithm
        const angle = (index * 2 * Math.PI) / 5;
        return {
          x: 480 + Math.cos(angle) * 190,
          y: 330 + Math.sin(angle) * 160,
          region: 'Industrial Zone'
        };
      }
    }
  }, []);

  // Compute live unit nodes with employee distribution & breach metrics
  const unitNodes = useMemo<ProjectedUnitNode[]>(() => {
    return units.map((unit, idx) => {
      const coords = getProjectedCoords(unit.id, idx);
      const assigned = employees.filter(e => e.unitId === unit.id);
      
      const present = assigned.filter(emp => {
        const att = attendance.find(a => a.employeeId === emp.id);
        return att?.status === 'Present' || att?.status === 'Late' || att?.status === 'On Duty';
      });

      const absent = assigned.filter(emp => {
        const att = attendance.find(a => a.employeeId === emp.id);
        return att?.status === 'Absent';
      });

      // Filter breaches associated with this unit
      const unitBreaches = localBreachAlerts.filter(
        b => b.unitId === unit.id || (b.unitName && b.unitName.toLowerCase().includes(unit.code?.toLowerCase() || ''))
      );

      const hasActiveBreach = unitBreaches.some(b => b.status === 'ACTIVE_ALERT');
      const hasCritical = unitBreaches.some(b => b.aiRiskLevel === 'CRITICAL' && b.status === 'ACTIVE_ALERT');
      const hasHigh = unitBreaches.some(b => b.aiRiskLevel === 'HIGH' && b.status === 'ACTIVE_ALERT');
      const maxScore = unitBreaches.reduce((max, b) => Math.max(max, b.aiRiskScore || 0), 0);

      // Scale geofence radius in meters to SVG pixels (e.g. 150m -> 46px, 250m -> 64px, 300m -> 76px)
      const radiusMeters = unit.geofenceRadiusMeters || 200;
      const perimeterRadiusSvg = Math.max(38, Math.min(85, Math.round(radiusMeters * 0.25)));

      return {
        unit,
        svgX: coords.x,
        svgY: coords.y,
        regionLabel: coords.region,
        assignedEmployees: assigned,
        presentEmployees: present,
        absentEmployees: absent,
        activeBreaches: unitBreaches,
        hasCriticalBreach: hasCritical,
        hasHighBreach: hasHigh,
        hasActiveBreach,
        maxRiskScore: maxScore,
        perimeterRadiusSvg
      };
    });
  }, [units, employees, attendance, localBreachAlerts, getProjectedCoords]);

  // Telemetry KPIs
  const totalMonitoredUnits = unitNodes.length;
  const totalTrackedEmployees = employees.length;
  const unitsWithActiveBreach = unitNodes.filter(u => u.hasActiveBreach);
  const totalActiveBreachAlerts = localBreachAlerts.filter(b => b.status === 'ACTIVE_ALERT').length;
  const compliantUnitsCount = totalMonitoredUnits - unitsWithActiveBreach.length;
  const overallPerimeterCompliance = totalTrackedEmployees > 0
    ? Math.round(((totalTrackedEmployees - totalActiveBreachAlerts) / totalTrackedEmployees) * 100)
    : 100;

  // Selected unit node for Inspector Drawer
  const activeSelectedNode = useMemo(() => {
    if (!selectedUnitId) return unitNodes[0] || null;
    return unitNodes.find(n => n.unit.id === selectedUnitId) || unitNodes[0] || null;
  }, [selectedUnitId, unitNodes]);

  // Simulate an outside punch incident on the currently selected or first unit
  const handleTriggerSimulatedBreach = () => {
    const targetNode = activeSelectedNode || unitNodes[1] || unitNodes[0];
    if (!targetNode) return;

    const mockEmp = targetNode.assignedEmployees[0] || employees[0];
    const breachDist = Math.round(1800 + Math.random() * 2400); // 1.8km to 4.2km outside
    const actualDist = (targetNode.unit.geofenceRadiusMeters || 250) + breachDist;

    const newBreach: GeofenceBreachAlert = {
      id: `alert-live-${Date.now()}`,
      punchId: `punch-sim-${Date.now()}`,
      employeeId: mockEmp.id,
      employeeCode: mockEmp.employeeCode,
      employeeName: `${mockEmp.firstName} ${mockEmp.lastName}`,
      designation: mockEmp.designationId || 'Operations Executive',
      departmentName: mockEmp.departmentId || 'Plant Operations',
      unitId: targetNode.unit.id,
      unitName: targetNode.unit.name,
      designatedRadiusMeters: targetNode.unit.geofenceRadiusMeters || 250,
      actualDistanceMeters: actualDist,
      breachDistanceMeters: breachDist,
      punchType: 'IN',
      date: '2026-10-08',
      time: new Date().toTimeString().slice(0, 5),
      timestamp: new Date().toISOString(),
      coordinates: {
        lat: Number(((targetNode.unit.latitude || 18.75) + 0.024).toFixed(5)),
        lng: Number(((targetNode.unit.longitude || 73.85) + 0.019).toFixed(5))
      },
      unitCoordinates: {
        lat: targetNode.unit.latitude || 18.7583,
        lng: targetNode.unit.longitude || 73.8567
      },
      locationAddress: `National Highway Toll Plaza Connector (${formatDistance(actualDist)} from ${targetNode.unit.name})`,
      accuracyMeters: 6,
      aiRiskScore: 84,
      aiRiskLevel: 'HIGH',
      aiAnalysis: `REAL-TIME PERIMETER BREACH: ${mockEmp.firstName} punched IN at ${formatDistance(actualDist)} (+${formatDistance(breachDist)} beyond ${targetNode.unit.geofenceRadiusMeters || 250}m radius) outside ${targetNode.unit.name}.`,
      aiRecommendations: [
        'Dispatched automated warning to employee smartphone.',
        'Sent high-priority incident alert to Unit Manager.',
        'Attendance marked as Pending Regularization.'
      ],
      alertChannels: ['Manager_Email', 'Manager_SMS', 'Push_Notification'],
      status: 'ACTIVE_ALERT'
    };

    setLocalBreachAlerts(prev => [newBreach, ...prev]);
    setSelectedUnitId(targetNode.unit.id);

    if (soundEnabled) {
      playGeofenceAlertChime();
    }

    setSimFeedback(
      `🚨 High Breach Triggered: ${mockEmp.employeeCode} (${mockEmp.firstName}) punched +${formatDistance(breachDist)} outside ${targetNode.unit.name}!`
    );
    setTimeout(() => setSimFeedback(null), 5500);

    if (onAddNotification) {
      onAddNotification({
        id: `notif-geofence-${Date.now()}`,
        orgId: targetNode.unit.orgId,
        title: `Geofence Perimeter Breach: ${mockEmp.firstName} ${mockEmp.lastName}`,
        message: `${mockEmp.employeeCode} punched +${formatDistance(breachDist)} outside ${targetNode.unit.name}. Risk Score: 84/100 (HIGH).`,
        type: 'geofence',
        read: false,
        timestamp: 'Just now'
      });
    }

    if (onLogAudit) {
      onLogAudit(
        'ALERT',
        'AI Geofencing Monitor',
        `Live breach simulation recorded for ${mockEmp.employeeCode} (+${formatDistance(breachDist)} outside ${targetNode.unit.name})`
      );
    }
  };

  // Regularize alert in local state
  const handleResolveAlert = (alertId: string) => {
    setLocalBreachAlerts(prev =>
      prev.map(a =>
        a.id === alertId
          ? {
              ...a,
              status: 'REGULARIZED',
              resolutionNotes: 'Approved as authorized field visit by Plant HR Manager'
            }
          : a
      )
    );
  };

  return (
    <div className="bg-slate-900 rounded-3xl border border-slate-800 shadow-xl overflow-hidden transition-all text-white space-y-0">
      {/* 1. Header Toolbar & Real-Time KPIs */}
      <div className="p-5 border-b border-slate-800 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/80">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                <Radio className="w-5 h-5 text-indigo-400 animate-pulse" />
              </span>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-black text-white tracking-wide flex items-center gap-2">
                    <span>WORKFORCE GEOFENCE RADAR & UNIT DISTRIBUTION MAP</span>
                  </h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    LIVE GPS TELEMETRY
                  </span>
                  {totalActiveBreachAlerts > 0 && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500/30 text-rose-300 border border-rose-500/50 flex items-center gap-1 animate-pulse font-mono">
                      <AlertTriangle className="w-3 h-3 text-rose-400" />
                      {totalActiveBreachAlerts} BREACH ALERTS ACTIVE
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400">
                  Live employee concentration, designated GPS perimeter radii & pulsing breach anomaly detection across operating units
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons & View Switches */}
          <div className="flex flex-wrap items-center gap-2">
            {/* View Mode Toggle */}
            <div className="bg-slate-950/90 p-1 rounded-xl border border-slate-800 flex items-center">
              <button
                onClick={() => setViewMode('national')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'national'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>National Map</span>
              </button>

              <button
                onClick={() => setViewMode('radar_grid')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'radar_grid'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Crosshair className="w-3.5 h-3.5" />
                <span>Radius Radar</span>
              </button>

              <button
                onClick={() => setViewMode('breach_focus')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                  viewMode === 'breach_focus'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <ShieldAlert className="w-3.5 h-3.5 text-rose-300" />
                <span>Breach Focus ({unitsWithActiveBreach.length})</span>
              </button>
            </div>

            {/* Simulate Breach Trigger */}
            <button
              onClick={handleTriggerSimulatedBreach}
              title="Simulate an employee punching outside designated radius to test real-time breach detection"
              className="px-3 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Simulate Breach</span>
            </button>

            {/* Launch Full AI Geofencing Monitor */}
            {onNavigate && (
              <button
                onClick={() => onNavigate('geofence')}
                className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-xs cursor-pointer"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Open Full Radar</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Real-Time Telemetry KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3 mt-4 pt-3 border-t border-slate-800/80 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Monitored Operating Units</span>
            <span className="text-base font-black text-white font-mono">{totalMonitoredUnits} Facilities</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">100% GPS Geofenced</span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Total Active Personnel</span>
            <span className="text-base font-black text-sky-400 font-mono">{totalTrackedEmployees} Staff</span>
            <span className="text-[10px] text-emerald-400 block mt-0.5">Live Shift Tracked</span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Perimeter Compliance</span>
            <div className="flex items-center gap-1.5">
              <span className={`text-base font-black font-mono ${overallPerimeterCompliance >= 90 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {overallPerimeterCompliance}%
              </span>
              <span className="text-[10px] text-slate-400">({compliantUnitsCount}/{totalMonitoredUnits} Units 100% Clear)</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1 mt-1 overflow-hidden">
              <div
                className={`h-1 rounded-full ${overallPerimeterCompliance >= 90 ? 'bg-emerald-500' : 'bg-amber-500'}`}
                style={{ width: `${overallPerimeterCompliance}%` }}
              />
            </div>
          </div>

          <div className={`p-2.5 rounded-xl border ${
            totalActiveBreachAlerts > 0
              ? 'bg-rose-950/40 border-rose-800/60 text-rose-300'
              : 'bg-slate-950/70 border-slate-800 text-slate-300'
          }`}>
            <span className="text-[10px] font-bold uppercase tracking-wider block">Outside-Radius Breaches</span>
            <div className="flex items-center gap-1.5">
              <span className="text-base font-black font-mono text-rose-400">
                {totalActiveBreachAlerts} Alerts
              </span>
              {totalActiveBreachAlerts > 0 && (
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              )}
            </div>
            <span className="text-[10px] block mt-0.5 text-rose-300/80">Requires Manager Action</span>
          </div>

          <div className="col-span-2 sm:col-span-4 lg:col-span-1 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Breach Audio Alarm</span>
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`text-[10px] font-bold px-2 py-0.5 rounded cursor-pointer ${
                  soundEnabled ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {soundEnabled ? 'Sound ON 🔊' : 'Muted 🔇'}
              </button>
            </div>
            <span className="text-[10px] text-slate-400 mt-1">
              {soundEnabled ? 'Auto-chimes on GPS breach detection' : 'Audio chimes disabled'}
            </span>
          </div>
        </div>

        {/* Live Simulation feedback banner */}
        {simFeedback && (
          <div className="mt-3 p-3 rounded-xl bg-rose-950/80 border border-rose-500/60 text-xs text-rose-200 flex items-center justify-between animate-fadeIn">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span className="font-semibold">{simFeedback}</span>
            </div>
            <button
              onClick={() => setSimFeedback(null)}
              className="text-[10px] font-bold text-rose-300 hover:text-white px-2 py-1 bg-rose-900/60 rounded cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* 2. Interactive SVG Map & Radar Canvas Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 relative">
        {/* Left/Main Map Canvas (8 Columns) */}
        <div className="lg:col-span-8 p-4 bg-slate-950 relative flex flex-col items-center justify-center min-h-[460px] lg:min-h-[560px] border-b lg:border-b-0 lg:border-r border-slate-800 overflow-hidden">
          {/* Subtle Map Coordinate Header / Legend Overlay */}
          <div className="absolute top-4 left-4 z-10 flex flex-wrap items-center gap-2 pointer-events-none">
            <span className="px-2.5 py-1 rounded-lg bg-slate-900/90 border border-slate-800 text-[10px] font-mono text-slate-400 backdrop-blur-md">
              CRS: WGS-84 · India Industrial Grid
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-slate-900/90 border border-slate-800 text-[10px] font-mono text-indigo-400 backdrop-blur-md flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
              Radius 150m - 300m
            </span>
          </div>

          {/* Map Canvas Zoom Controls */}
          <div className="absolute top-4 right-4 z-10 flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 backdrop-blur-md">
            <button
              onClick={() => setZoomLevel(prev => Math.min(1.6, prev + 0.15))}
              className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center transition cursor-pointer"
              title="Zoom In"
            >
              +
            </button>
            <span className="px-1.5 text-[10px] font-mono text-slate-300">
              {Math.round(zoomLevel * 100)}%
            </span>
            <button
              onClick={() => setZoomLevel(prev => Math.max(0.8, prev - 0.15))}
              className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center transition cursor-pointer"
              title="Zoom Out"
            >
              -
            </button>
            <button
              onClick={() => {
                setZoomLevel(1);
                setPanOffset({ x: 0, y: 0 });
              }}
              className="px-2 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold flex items-center justify-center transition cursor-pointer"
              title="Fit to Screen"
            >
              Reset
            </button>
          </div>

          {/* SVG Map Container */}
          <div className="w-full h-full flex items-center justify-center overflow-hidden">
            <svg
              viewBox="0 0 1000 620"
              className="w-full h-auto max-h-[540px] select-none transition-transform duration-300 ease-out"
              style={{
                transform: `scale(${zoomLevel}) translate(${panOffset.x}px, ${panOffset.y}px)`,
                transformOrigin: 'center center'
              }}
            >
              <defs>
                {/* Background Tech Grid Pattern */}
                <pattern id="radarGridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="0.7" opacity="0.6" />
                  <circle cx="20" cy="20" r="1" fill="#334155" opacity="0.4" />
                </pattern>

                {/* Concentric Radar Rings Pattern */}
                <radialGradient id="radarCenterGlow" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity="0.12" />
                  <stop offset="80%" stopColor="#1e1b4b" stopOpacity="0.04" />
                  <stop offset="100%" stopColor="#020617" stopOpacity="0" />
                </radialGradient>

                {/* Crimson Gradient for Breach Pulse */}
                <radialGradient id="breachRadialGradient" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#ef4444" stopOpacity="0.45" />
                  <stop offset="60%" stopColor="#ef4444" stopOpacity="0.15" />
                  <stop offset="100%" stopColor="#ef4444" stopOpacity="0" />
                </radialGradient>

                {/* Emerald Gradient for Compliant Units */}
                <radialGradient id="compliantRadialGradient" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.30" />
                  <stop offset="70%" stopColor="#10b981" stopOpacity="0.08" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
                </radialGradient>

                {/* Glowing drop shadow filters */}
                <filter id="glowBreach" x="-40%" y="-40%" width="180%" height="180%">
                  <feGaussianBlur stdDeviation="6" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>

                <filter id="glowCompliant" x="-30%" y="-30%" width="160%" height="160%">
                  <feGaussianBlur stdDeviation="4" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              {/* 1. Map Canvas Background */}
              <rect width="1000" height="620" fill="#020617" />
              <rect width="1000" height="620" fill="url(#radarGridPattern)" />
              <circle cx="500" cy="310" r="280" fill="url(#radarCenterGlow)" />

              {/* Concentric Organization Radar Range Rings */}
              <circle cx="500" cy="310" r="120" fill="none" stroke="#334155" strokeWidth="1" strokeDasharray="4 6" opacity="0.4" />
              <circle cx="500" cy="310" r="220" fill="none" stroke="#334155" strokeWidth="1" strokeDasharray="4 6" opacity="0.3" />
              <circle cx="500" cy="310" r="320" fill="none" stroke="#334155" strokeWidth="1" strokeDasharray="4 6" opacity="0.2" />

              {/* Crosshair Latitude & Longitude Axis Lines */}
              <line x1="500" y1="20" x2="500" y2="600" stroke="#1e293b" strokeWidth="1" strokeDasharray="2 4" opacity="0.6" />
              <line x1="40" y1="310" x2="960" y2="310" stroke="#1e293b" strokeWidth="1" strokeDasharray="2 4" opacity="0.6" />

              {/* Stylized Regional Territory Connectors */}
              {/* North (Gurugram) to West (Sanand & Pune) */}
              <path
                d="M 490 155 Q 360 220 280 310"
                fill="none"
                stroke="#4f46e5"
                strokeWidth="1.5"
                strokeDasharray="6 6"
                opacity="0.35"
              />
              <path
                d="M 280 310 Q 330 360 385 405"
                fill="none"
                stroke="#4f46e5"
                strokeWidth="1.5"
                strokeDasharray="6 6"
                opacity="0.35"
              />
              <path
                d="M 385 405 L 445 445"
                fill="none"
                stroke="#6366f1"
                strokeWidth="2"
                strokeDasharray="4 4"
                opacity="0.5"
              />
              <path
                d="M 385 405 Q 430 480 470 535"
                fill="none"
                stroke="#4f46e5"
                strokeWidth="1.5"
                strokeDasharray="6 6"
                opacity="0.35"
              />

              {/* 2. RENDER GEOFENCE UNITS */}
              {unitNodes.map((node) => {
                const isSelected = selectedUnitId === node.unit.id;
                const isHovered = hoveredUnitId === node.unit.id;
                const hasBreach = node.hasActiveBreach;
                const radius = node.perimeterRadiusSvg;

                return (
                  <g
                    key={node.unit.id}
                    onClick={() => setSelectedUnitId(node.unit.id)}
                    onMouseEnter={() => setHoveredUnitId(node.unit.id)}
                    onMouseLeave={() => setHoveredUnitId(null)}
                    className="cursor-pointer transition-all duration-200"
                  >
                    {/* A. Pulsing Breach Aura Circles (If Unit has active high breach alerts) */}
                    {hasBreach && (
                      <g>
                        {/* Outer pulsing radar ping wave 1 */}
                        <circle
                          cx={node.svgX}
                          cy={node.svgY}
                          r={radius + 32}
                          fill="none"
                          stroke="#f43f5e"
                          strokeWidth="2"
                          opacity="0.4"
                          className="animate-ping"
                          style={{ transformOrigin: `${node.svgX}px ${node.svgY}px` }}
                        />
                        {/* Outer secondary wave 2 */}
                        <circle
                          cx={node.svgX}
                          cy={node.svgY}
                          r={radius + 18}
                          fill="none"
                          stroke="#ef4444"
                          strokeWidth="1.5"
                          opacity="0.6"
                        />
                      </g>
                    )}

                    {/* B. Designated Geofence Boundary Circle */}
                    <circle
                      cx={node.svgX}
                      cy={node.svgY}
                      r={radius}
                      fill={hasBreach ? 'url(#breachRadialGradient)' : 'url(#compliantRadialGradient)'}
                      stroke={hasBreach ? '#ef4444' : isSelected ? '#38bdf8' : '#10b981'}
                      strokeWidth={isSelected ? '3' : hasBreach ? '2.5' : '1.8'}
                      strokeDasharray={hasBreach ? '6 4' : 'none'}
                      filter={hasBreach ? 'url(#glowBreach)' : 'url(#glowCompliant)'}
                      opacity={isSelected || isHovered ? '1' : '0.85'}
                    />

                    {/* Inner 50m / 100m calibration circle */}
                    <circle
                      cx={node.svgX}
                      cy={node.svgY}
                      r={Math.round(radius * 0.5)}
                      fill="none"
                      stroke={hasBreach ? '#f87171' : '#34d399'}
                      strokeWidth="1"
                      strokeDasharray="3 3"
                      opacity="0.4"
                    />

                    {/* C. Designated Radius Measurement Tag */}
                    <text
                      x={node.svgX}
                      y={node.svgY - radius - 10}
                      textAnchor="middle"
                      fill={hasBreach ? '#fca5a5' : '#a7f3d0'}
                      fontSize="10"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      R: {node.unit.geofenceRadiusMeters || 200}m
                    </text>

                    {/* D. Center Unit Marker & Core Icon */}
                    <circle
                      cx={node.svgX}
                      cy={node.svgY}
                      r="16"
                      fill={hasBreach ? '#991b1b' : isSelected ? '#0369a1' : '#065f46'}
                      stroke="#ffffff"
                      strokeWidth="2"
                    />

                    {/* Unit Icon glyph in center */}
                    <text
                      x={node.svgX}
                      y={node.svgY + 4}
                      textAnchor="middle"
                      fill="#ffffff"
                      fontSize="11"
                      fontWeight="black"
                    >
                      {node.unit.code?.slice(-2) || 'UN'}
                    </text>

                    {/* E. Employee Distribution Pins Placed inside the Geofence Radius */}
                    {node.assignedEmployees.slice(0, 6).map((emp, empIdx) => {
                      const empAngle = (empIdx * 2 * Math.PI) / Math.min(6, node.assignedEmployees.length);
                      const empDist = radius * 0.58;
                      const empX = node.svgX + Math.cos(empAngle) * empDist;
                      const empY = node.svgY + Math.sin(empAngle) * empDist;
                      const isPresent = node.presentEmployees.some(p => p.id === emp.id);

                      return (
                        <g key={emp.id}>
                          <title>{`${emp.firstName} ${emp.lastName}`}</title>
                          <circle
                            cx={empX}
                            cy={empY}
                            r="5"
                            fill={isPresent ? '#10b981' : '#64748b'}
                            stroke="#ffffff"
                            strokeWidth="1"
                          />
                        </g>
                      );
                    })}

                    {/* F. Breach Punch Markers & Vector Lines Plotted Outside the Radius */}
                    {hasBreach &&
                      node.activeBreaches.map((breach, bIdx) => {
                        // Plot breach point outside perimeter
                        const breachAngle = 0.5 + bIdx * 0.9;
                        const breachDistSvg = radius + 42 + bIdx * 16;
                        const bx = node.svgX + Math.cos(breachAngle) * breachDistSvg;
                        const by = node.svgY + Math.sin(breachAngle) * breachDistSvg;

                        return (
                          <g key={breach.id}>
                            {/* Dotted Vector Connector Line */}
                            <line
                              x1={node.svgX}
                              y1={node.svgY}
                              x2={bx}
                              y2={by}
                              stroke="#ef4444"
                              strokeWidth="1.5"
                              strokeDasharray="3 3"
                              opacity="0.8"
                            />

                            {/* Breach Punch Marker */}
                            <circle
                              cx={bx}
                              cy={by}
                              r="8"
                              fill="#ef4444"
                              stroke="#ffffff"
                              strokeWidth="1.8"
                              className="animate-pulse"
                            />

                            {/* Exclamation mark inside breach marker */}
                            <text
                              x={bx}
                              y={by + 3.5}
                              textAnchor="middle"
                              fill="#ffffff"
                              fontSize="9"
                              fontWeight="black"
                            >
                              !
                            </text>

                            {/* Breach Distance Label */}
                            <rect
                              x={bx + 10}
                              y={by - 12}
                              width="68"
                              height="20"
                              rx="4"
                              fill="#450a0a"
                              stroke="#ef4444"
                              strokeWidth="1"
                              opacity="0.95"
                            />
                            <text
                              x={bx + 44}
                              y={by + 2}
                              textAnchor="middle"
                              fill="#fca5a5"
                              fontSize="9.5"
                              fontWeight="bold"
                              fontFamily="monospace"
                            >
                              +{formatDistance(breach.breachDistanceMeters)}
                            </text>
                          </g>
                        );
                      })}

                    {/* G. Unit Label & Live Employee Count Badge */}
                    <g transform={`translate(${node.svgX}, ${node.svgY + radius + 18})`}>
                      {/* Name Tag Background */}
                      <rect
                        x="-90"
                        y="0"
                        width="180"
                        height="38"
                        rx="8"
                        fill="#0f172a"
                        stroke={isSelected ? '#38bdf8' : hasBreach ? '#ef4444' : '#334155'}
                        strokeWidth={isSelected || hasBreach ? '1.5' : '1'}
                        opacity="0.95"
                      />

                      {/* Unit Name */}
                      <text
                        x="0"
                        y="15"
                        textAnchor="middle"
                        fill="#f8fafc"
                        fontSize="10"
                        fontWeight="bold"
                      >
                        {node.unit.name.length > 24 ? node.unit.name.slice(0, 22) + '…' : node.unit.name}
                      </text>

                      {/* Headcount Breakdown Line */}
                      <text
                        x="0"
                        y="30"
                        textAnchor="middle"
                        fill={hasBreach ? '#f87171' : '#94a3b8'}
                        fontSize="9.5"
                        fontWeight="semibold"
                        fontFamily="monospace"
                      >
                        {hasBreach
                          ? `⚠️ ${node.activeBreaches.length} BREACH · ${node.presentEmployees.length}/${node.assignedEmployees.length} In-Zone`
                          : `✓ ${node.presentEmployees.length}/${node.assignedEmployees.length} Staff Checked-In`}
                      </text>
                    </g>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Map Bottom Legend Strip */}
          <div className="w-full mt-2 pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-[11px] text-slate-400 gap-2">
            <div className="flex flex-wrap items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-emerald-500/30 border border-emerald-400" />
                <span>Compliant Geofence (Inside Radius)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500/30 border border-rose-500 animate-pulse" />
                <span>Active Breach Alert (Outside Radius)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-0.5 border-t-2 border-dashed border-rose-500" />
                <span>Breach Offset Vector (+Distance)</span>
              </span>
            </div>

            <span className="text-[10px] text-slate-500 font-mono">
              Click any facility node to inspect telemetry & live roster
            </span>
          </div>
        </div>

        {/* Right Panel: Selected Unit Inspector & Incident Roster (4 Columns) */}
        <div className="lg:col-span-4 p-5 bg-slate-900 flex flex-col justify-between space-y-4">
          {activeSelectedNode ? (
            <div className="space-y-4">
              {/* Facility Header */}
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider font-mono">
                    Facility Inspector
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                      activeSelectedNode.hasActiveBreach
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    }`}
                  >
                    {activeSelectedNode.hasActiveBreach ? 'BREACH ACTIVE' : 'PERIMETER SECURE'}
                  </span>
                </div>

                <h4 className="text-base font-black text-white mt-1">
                  {activeSelectedNode.unit.name}
                </h4>
                <p className="text-xs text-slate-400">
                  {activeSelectedNode.regionLabel} · Code: <span className="text-indigo-300 font-mono font-bold">{activeSelectedNode.unit.code}</span>
                </p>
              </div>

              {/* Perimeter Details Box */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Designated Boundary:</span>
                  <span className="font-bold text-white font-mono">
                    {activeSelectedNode.unit.geofenceRadiusMeters || 200} Meters Radius
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">GPS Coordinates:</span>
                  <span className="font-mono text-indigo-300 text-[11px]">
                    {activeSelectedNode.unit.latitude?.toFixed(4)}, {activeSelectedNode.unit.longitude?.toFixed(4)}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Enforcement Mode:</span>
                  <span className="font-semibold text-emerald-400">
                    {activeSelectedNode.unit.strictGeofence ? 'Strict (Regularization Req.)' : 'Flexible'}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Facility GM / Lead:</span>
                  <span className="font-medium text-slate-200">
                    {activeSelectedNode.unit.headPerson || 'Suresh Patil (Plant GM)'}
                  </span>
                </div>
              </div>

              {/* Live Attendance Distribution at this Unit */}
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-bold text-slate-300">Live Workforce Concentration</span>
                  <span className="font-bold text-white font-mono">
                    {activeSelectedNode.presentEmployees.length} of {activeSelectedNode.assignedEmployees.length} Staff Present
                  </span>
                </div>

                <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden flex">
                  <div
                    className="bg-emerald-500 h-2"
                    style={{
                      width: `${
                        activeSelectedNode.assignedEmployees.length > 0
                          ? (activeSelectedNode.presentEmployees.length /
                              activeSelectedNode.assignedEmployees.length) *
                            100
                          : 0
                      }%`
                    }}
                    title="Present inside perimeter"
                  />
                  <div
                    className="bg-rose-500 h-2"
                    style={{
                      width: `${
                        activeSelectedNode.assignedEmployees.length > 0
                          ? (activeSelectedNode.activeBreaches.length /
                              activeSelectedNode.assignedEmployees.length) *
                            100
                          : 0
                      }%`
                    }}
                    title="Outside Perimeter Breaches"
                  />
                </div>
              </div>

              {/* Active Breaches List for this Unit */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                    <span>Unit Breach Telemetry ({activeSelectedNode.activeBreaches.length})</span>
                  </span>
                </div>

                {activeSelectedNode.activeBreaches.length === 0 ? (
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-center text-xs text-slate-400">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
                    <span>No active boundary breaches recorded at this unit. All employee punches verified inside the {activeSelectedNode.unit.geofenceRadiusMeters || 200}m radius.</span>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                    {activeSelectedNode.activeBreaches.map(alert => (
                      <div
                        key={alert.id}
                        className={`p-3 rounded-xl border text-xs transition space-y-1.5 ${
                          alert.status === 'ACTIVE_ALERT'
                            ? 'bg-rose-950/40 border-rose-800/80 text-rose-200'
                            : 'bg-slate-950 border-slate-800 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white flex items-center gap-1">
                            <span>{alert.employeeName}</span>
                            <span className="font-mono text-[10px] text-slate-400">({alert.employeeCode})</span>
                          </span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-black font-mono ${
                              alert.aiRiskLevel === 'CRITICAL'
                                ? 'bg-rose-600 text-white'
                                : alert.aiRiskLevel === 'HIGH'
                                ? 'bg-amber-600 text-white'
                                : 'bg-slate-700 text-slate-200'
                            }`}
                          >
                            {alert.aiRiskLevel} ({alert.aiRiskScore}/100)
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-[11px] text-rose-300">
                          <span>Breach Offset: <strong className="font-mono">+{formatDistance(alert.breachDistanceMeters)}</strong></span>
                          <span>Time: {alert.time}</span>
                        </div>

                        <p className="text-[10.5px] text-slate-300 line-clamp-2">
                          {alert.aiAnalysis}
                        </p>

                        {alert.status === 'ACTIVE_ALERT' && (
                          <div className="pt-1 flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleResolveAlert(alert.id)}
                              className="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold transition cursor-pointer"
                            >
                              Regularize
                            </button>
                            {onNavigate && (
                              <button
                                onClick={() => onNavigate('geofence')}
                                className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold transition cursor-pointer flex items-center gap-1"
                              >
                                <span>Inspect</span>
                                <ArrowUpRight className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500 text-xs">
              <span>Select an operating facility from the map to inspect details</span>
            </div>
          )}

          {/* Quick Facility Switcher Buttons */}
          <div className="pt-3 border-t border-slate-800">
            <span className="text-[10px] font-bold uppercase text-slate-400 block mb-2">
              Quick Focus Unit:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {unitNodes.map(node => (
                <button
                  key={node.unit.id}
                  onClick={() => setSelectedUnitId(node.unit.id)}
                  className={`px-2 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer flex items-center gap-1 ${
                    selectedUnitId === node.unit.id
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : node.hasActiveBreach
                      ? 'bg-rose-950/60 text-rose-300 border border-rose-800 hover:bg-rose-900/60'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {node.hasActiveBreach && <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping" />}
                  <span>{node.unit.code || node.unit.name.slice(0, 10)}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

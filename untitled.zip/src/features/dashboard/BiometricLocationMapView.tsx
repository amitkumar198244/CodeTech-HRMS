// RSTPL HRMS - Biometric Device Physical Location & Site Connectivity Map
// RS Technovisions XpertSkillCop
// Visual map display for physical location of biometric devices with placeholder coordinates

import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  MapPin,
  Layers,
  Zap,
  Wifi,
  WifiOff,
  AlertTriangle,
  CheckCircle2,
  Building2,
  Factory,
  RefreshCw,
  Crosshair,
  Activity,
  ShieldCheck,
  ChevronRight,
  Info,
  Sliders,
  Radio,
  ExternalLink,
  LayoutList,
  Clock,
  Cpu,
  X,
  Minimize2,
  Maximize2,
  Network
} from 'lucide-react';
import { BiometricDevice } from '../../types/hrms';

interface BiometricLocationMapViewProps {
  devices: BiometricDevice[];
  onPingDevice?: (deviceId: string) => void;
  pingingDeviceId?: string | null;
  onNavigate?: (module: string) => void;
  onSwitchToListView?: () => void;
  selectedDeviceId?: string | null;
  onSelectDeviceId?: (id: string | null) => void;
  onFetchConnectivityStatus?: () => void;
  isFetchingConnectivity?: boolean;
}

type MapMode = 'geo' | 'blueprint';
type SiteFilter = 'ALL' | 'CHAKAN' | 'SANAND' | 'HQ';

interface SiteSummary {
  id: SiteFilter;
  name: string;
  type: string;
  city: string;
  state: string;
  coordinates: string;
  subnet: string;
  devices: BiometricDevice[];
  avgLatency: number;
  hasIncident: boolean;
  incidentType?: 'OFFLINE' | 'HIGH_LATENCY' | null;
}

interface MarkerCluster {
  id: string;
  centroidX: number;
  centroidY: number;
  devices: BiometricDevice[];
  isCluster: boolean;
  siteKey: SiteFilter;
  hasOffline: boolean;
  hasCritical: boolean;
  hasWarning: boolean;
  avgLatency: number;
}

export const BiometricLocationMapView: React.FC<BiometricLocationMapViewProps> = ({
  devices,
  onPingDevice,
  pingingDeviceId,
  onNavigate,
  onSwitchToListView,
  selectedDeviceId: propSelectedDeviceId,
  onSelectDeviceId,
  onFetchConnectivityStatus,
  isFetchingConnectivity = false,
}) => {
  const [mapMode, setMapMode] = useState<MapMode>('geo');
  const [selectedSiteFilter, setSelectedSiteFilter] = useState<SiteFilter>('ALL');
  const [selectedDeviceId, setSelectedDeviceId] = useState<string | null>(propSelectedDeviceId || null);
  const [openInfoWindowDeviceId, setOpenInfoWindowDeviceId] = useState<string | null>(propSelectedDeviceId || null);
  const [hoveredDeviceId, setHoveredDeviceId] = useState<string | null>(null);

  // Live Monitoring automated 30-second connectivity fetch
  const [isLiveMonitoring, setIsLiveMonitoring] = useState<boolean>(true);
  const [secondsUntilNextFetch, setSecondsUntilNextFetch] = useState<number>(30);
  const [lastFetchedAt, setLastFetchedAt] = useState<Date>(new Date());
  const [isLocalFetching, setIsLocalFetching] = useState<boolean>(false);

  // Marker clustering state: groups close-proximity terminals into a single cluster icon
  const [isClusteringEnabled, setIsClusteringEnabled] = useState<boolean>(true);
  const [expandedClusterIds, setExpandedClusterIds] = useState<Set<string>>(new Set());
  const [hoveredClusterId, setHoveredClusterId] = useState<string | null>(null);

  const isFetching = isFetchingConnectivity || isLocalFetching;

  const handleToggleCluster = (clusterId: string) => {
    setExpandedClusterIds(prev => {
      const next = new Set(prev);
      if (next.has(clusterId)) {
        next.delete(clusterId);
      } else {
        next.add(clusterId);
      }
      return next;
    });
  };

  const handleCollapseCluster = (clusterId: string) => {
    setExpandedClusterIds(prev => {
      const next = new Set(prev);
      next.delete(clusterId);
      return next;
    });
  };

  const onFetchConnectivityStatusRef = useRef(onFetchConnectivityStatus);
  useEffect(() => {
    onFetchConnectivityStatusRef.current = onFetchConnectivityStatus;
  });

  const handleTriggerFetch = useCallback(() => {
    setIsLocalFetching(true);
    if (onFetchConnectivityStatusRef.current) {
      onFetchConnectivityStatusRef.current();
    }
    setLastFetchedAt(new Date());
    setSecondsUntilNextFetch(30);
    setTimeout(() => {
      setIsLocalFetching(false);
    }, 600);
  }, []);

  // Automated 30-second timer when Live Monitoring is active
  useEffect(() => {
    if (!isLiveMonitoring) {
      setSecondsUntilNextFetch(30);
      return;
    }

    const timer = setInterval(() => {
      setSecondsUntilNextFetch(prev => {
        if (prev <= 1) {
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isLiveMonitoring]);

  // Safely trigger fetch in an effect when countdown reaches 0
  useEffect(() => {
    if (isLiveMonitoring && secondsUntilNextFetch === 0) {
      handleTriggerFetch();
    }
  }, [secondsUntilNextFetch, isLiveMonitoring, handleTriggerFetch]);

  useEffect(() => {
    if (propSelectedDeviceId) {
      setSelectedDeviceId(propSelectedDeviceId);
      setOpenInfoWindowDeviceId(propSelectedDeviceId);
      const targetDev = devices.find(d => d.id === propSelectedDeviceId);
      if (targetDev) {
        const coords = getDeviceCoords(targetDev);
        setSelectedSiteFilter(coords.siteKey);
      }
    }
  }, [propSelectedDeviceId, devices]);

  const handleDeviceSelect = (id: string | null) => {
    setSelectedDeviceId(id);
    if (onSelectDeviceId) {
      onSelectDeviceId(id);
    }
  };

  const handleMarkerClick = (deviceId: string) => {
    handleDeviceSelect(deviceId);
    setOpenInfoWindowDeviceId(deviceId);
  };

  // Helper to format ISO timestamp into readable relative & local time
  const formatSyncTime = (dateStr?: string) => {
    if (!dateStr) return 'Never synced';
    try {
      const date = new Date(dateStr);
      if (isNaN(date.getTime())) return dateStr;
      const diffMs = Date.now() - date.getTime();
      const diffSec = Math.floor(diffMs / 1000);
      const diffMin = Math.floor(diffSec / 60);
      const diffHours = Math.floor(diffMin / 60);

      let relativeStr = '';
      if (diffSec < 45) {
        relativeStr = 'Just now';
      } else if (diffMin < 60) {
        relativeStr = `${diffMin}m ago`;
      } else if (diffHours < 24) {
        relativeStr = `${diffHours}h ago`;
      } else {
        const days = Math.floor(diffHours / 24);
        relativeStr = `${days}d ago`;
      }

      const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      return `${relativeStr} (${timeStr})`;
    } catch {
      return dateStr;
    }
  };

  // Helper to extract or fallback firmware version
  const getDeviceFirmware = (dev: BiometricDevice): string => {
    if (dev.firmwareVersion) return dev.firmwareVersion;
    switch (dev.vendor) {
      case 'eSSL': return 'v4.2.1-build88';
      case 'ZKTeco': return 'v3.18.4-pro';
      case 'Matrix': return 'v5.0.2-revC';
      case 'Suprema': return 'v6.1.0-arm64';
      case 'BioMax': return 'v3.9.0-embedded';
      default: return 'v4.1.0-std';
    }
  };

  // Fallback placeholder coordinates if not defined on device
  const getDeviceCoords = (d: BiometricDevice) => {
    if (d.id === 'dev-001') {
      return {
        lat: d.latitude ?? 18.7565,
        lng: d.longitude ?? 73.8540,
        x: d.mapX ?? 34,
        y: d.mapY ?? 64,
        siteKey: 'CHAKAN' as SiteFilter,
        siteTitle: 'Chakan Manufacturing Plant (Pune)',
        zone: d.zone ?? 'Gate 1 Pedestrian Access Portal',
        floor: 'Ground Level - Plant Security Post',
      };
    }
    if (d.id === 'dev-002') {
      return {
        lat: d.latitude ?? 18.5590,
        lng: d.longitude ?? 73.7868,
        x: d.mapX ?? 68,
        y: d.mapY ?? 38,
        siteKey: 'HQ' as SiteFilter,
        siteTitle: 'Corporate Headquarters (Baner Pune)',
        zone: d.zone ?? '4th Floor Executive Reception Lobby',
        floor: 'Tower B - Floor 4',
      };
    }
    if (d.id === 'dev-003') {
      return {
        lat: d.latitude ?? 22.9868,
        lng: d.longitude ?? 72.3813,
        x: d.mapX ?? 24,
        y: d.mapY ?? 26,
        siteKey: 'SANAND' as SiteFilter,
        siteTitle: 'Sanand Component Plant (Gujarat)',
        zone: d.zone ?? 'Heavy Stamping & Press Shop Bay B',
        floor: 'Bay B - Production Shopfloor',
      };
    }
    // dev-004
    return {
      lat: d.latitude ?? 18.5592,
      lng: d.longitude ?? 73.7872,
      x: d.mapX ?? 78,
      y: d.mapY ?? 50,
      siteKey: 'HQ' as SiteFilter,
      siteTitle: 'Corporate Headquarters (Baner Pune)',
      zone: d.zone ?? 'Wing C High-Security R&D Cleanroom',
      floor: 'Tower B - Floor 5 R&D Wing',
    };
  };

  const getLatency = (d: BiometricDevice) => {
    return d.syncLatencyMs ?? (d.vendor === 'eSSL' ? 46 : d.vendor === 'ZKTeco' ? 74 : d.vendor === 'Matrix' ? 152 : 36);
  };

  // Group devices by site to identify site-specific connectivity issues
  const siteSummaries: SiteSummary[] = (
    [
      {
        id: 'CHAKAN' as const,
        name: 'Chakan Manufacturing Plant',
        type: 'Heavy Auto-Stamping & Tooling Plant',
        city: 'Chakan MIDC Phase II, Pune',
        state: 'Maharashtra',
        coordinates: '18.7565° N, 73.8540° E',
        subnet: '192.168.10.0/24',
        devices: devices.filter(d => getDeviceCoords(d).siteKey === 'CHAKAN'),
        avgLatency: 0,
        hasIncident: false,
      },
      {
        id: 'SANAND' as const,
        name: 'Sanand Component Unit 2',
        type: 'Powertrain & Assembly Unit',
        city: 'Sanand GIDC Industrial Estate',
        state: 'Gujarat',
        coordinates: '22.9868° N, 72.3813° E',
        subnet: '192.168.20.0/24',
        devices: devices.filter(d => getDeviceCoords(d).siteKey === 'SANAND'),
        avgLatency: 0,
        hasIncident: false,
      },
      {
        id: 'HQ' as const,
        name: 'Corporate Headquarters',
        type: 'Executive Center & High-Security R&D',
        city: 'Baner Tech Park, Pune',
        state: 'Maharashtra',
        coordinates: '18.5590° N, 73.7868° E',
        subnet: '192.168.1.0/24',
        devices: devices.filter(d => getDeviceCoords(d).siteKey === 'HQ'),
        avgLatency: 0,
        hasIncident: false,
      },
    ] as const
  ).map(site => {
    const siteDevs = site.devices;
    const avg = siteDevs.length > 0 ? Math.round(siteDevs.reduce((sum, d) => sum + getLatency(d), 0) / siteDevs.length) : 0;
    const hasOffline = siteDevs.some(d => d.status === 'Offline');
    const hasHighLat = siteDevs.some(d => getLatency(d) > 500);
    return {
      ...site,
      avgLatency: avg,
      hasIncident: hasOffline || hasHighLat,
      incidentType: hasOffline ? 'OFFLINE' : hasHighLat ? 'HIGH_LATENCY' : null,
    };
  });

  // Filtered list of devices based on selected site filter
  const visibleDevices = devices.filter(d => {
    if (selectedSiteFilter === 'ALL') return true;
    return getDeviceCoords(d).siteKey === selectedSiteFilter;
  });

  // Proximity clustering calculation: groups terminals within 18% coordinate distance into a single cluster icon
  const clusters = useMemo<MarkerCluster[]>(() => {
    if (!isClusteringEnabled) {
      return visibleDevices.map(dev => {
        const coords = getDeviceCoords(dev);
        const lat = getLatency(dev);
        const isOffline = dev.status === 'Offline';
        return {
          id: `single-${dev.id}`,
          centroidX: coords.x,
          centroidY: coords.y,
          devices: [dev],
          isCluster: false,
          siteKey: coords.siteKey,
          hasOffline: isOffline,
          hasCritical: isOffline || lat > 500,
          hasWarning: !isOffline && lat > 150 && lat <= 500,
          avgLatency: lat,
        };
      });
    }

    const PROXIMITY_THRESHOLD = 18;
    const visited = new Set<string>();
    const result: MarkerCluster[] = [];

    for (let i = 0; i < visibleDevices.length; i++) {
      const devA = visibleDevices[i];
      if (visited.has(devA.id)) continue;

      const clusterDevs = [devA];
      visited.add(devA.id);
      const coordsA = getDeviceCoords(devA);

      for (let j = i + 1; j < visibleDevices.length; j++) {
        const devB = visibleDevices[j];
        if (visited.has(devB.id)) continue;
        const coordsB = getDeviceCoords(devB);

        const dist = Math.hypot(coordsA.x - coordsB.x, coordsA.y - coordsB.y);
        if (dist <= PROXIMITY_THRESHOLD) {
          clusterDevs.push(devB);
          visited.add(devB.id);
        }
      }

      const avgX = clusterDevs.reduce((sum, d) => sum + getDeviceCoords(d).x, 0) / clusterDevs.length;
      const avgY = clusterDevs.reduce((sum, d) => sum + getDeviceCoords(d).y, 0) / clusterDevs.length;
      const hasOffline = clusterDevs.some(d => d.status === 'Offline');
      const hasCritical = clusterDevs.some(d => d.status === 'Offline' || getLatency(d) > 500);
      const hasWarning = !hasCritical && clusterDevs.some(d => getLatency(d) > 150);
      const avgLat = Math.round(clusterDevs.reduce((sum, d) => sum + getLatency(d), 0) / clusterDevs.length);

      result.push({
        id: `cluster-${clusterDevs.map(d => d.id).sort().join('-')}`,
        centroidX: Number(avgX.toFixed(1)),
        centroidY: Number(avgY.toFixed(1)),
        devices: clusterDevs,
        isCluster: clusterDevs.length > 1,
        siteKey: coordsA.siteKey,
        hasOffline,
        hasCritical,
        hasWarning,
        avgLatency: avgLat,
      });
    }

    return result;
  }, [visibleDevices, isClusteringEnabled]);

  // Auto-expand cluster if currently selected device is inside one
  useEffect(() => {
    if (selectedDeviceId) {
      clusters.forEach(c => {
        if (c.isCluster && c.devices.some(d => d.id === selectedDeviceId)) {
          setExpandedClusterIds(prev => new Set(prev).add(c.id));
        }
      });
    }
  }, [selectedDeviceId, clusters]);

  const selectedDevice = devices.find(d => d.id === selectedDeviceId) || visibleDevices[0] || devices[0];
  const selectedMeta = selectedDevice ? getDeviceCoords(selectedDevice) : null;
  const selectedLat = selectedDevice ? getLatency(selectedDevice) : 0;
  const selectedIsOffline = selectedDevice?.status === 'Offline';
  const selectedIsCritical = selectedIsOffline || selectedLat > 500;

  // Quick helper to focus on any critical incident
  const handleFocusIncident = () => {
    const incidentDev = devices.find(d => d.status === 'Offline' || getLatency(d) > 500);
    if (incidentDev) {
      handleMarkerClick(incidentDev.id);
      const coords = getDeviceCoords(incidentDev);
      setSelectedSiteFilter(coords.siteKey);
    }
  };

  const renderDevicePin = (
    dev: BiometricDevice,
    clusterContext?: {
      clusterId: string;
      isExpanded: boolean;
      clusterTitle: string;
    }
  ) => {
    const coords = getDeviceCoords(dev);
    const lat = getLatency(dev);
    const isOffline = dev.status === 'Offline';
    const isCritical = isOffline || lat > 500;
    const isWarning = !isCritical && lat > 150;
    const isSelected = selectedDeviceId === dev.id;
    const isHovered = hoveredDeviceId === dev.id;
    const isOpenInfoWindow = openInfoWindowDeviceId === dev.id;

    const isNearTop = coords.y < 45;
    const isNearRight = coords.x > 68;
    const isNearLeft = coords.x < 32;

    return (
      <div
        key={dev.id}
        style={{
          left: `${coords.x}%`,
          top: `${coords.y}%`,
        }}
        onClick={(e) => {
          e.stopPropagation();
          handleMarkerClick(dev.id);
        }}
        onMouseEnter={() => setHoveredDeviceId(dev.id)}
        onMouseLeave={() => setHoveredDeviceId(null)}
        className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group ${
          isOpenInfoWindow ? 'z-50' : isSelected ? 'z-30' : 'z-20'
        } ${clusterContext ? 'animate-in zoom-in-75 duration-200' : ''}`}
      >
        {/* Outer Pulsing Ping Ring */}
        <span className="relative flex h-8 w-8 items-center justify-center">
          <span
            className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-60 ${
              isOffline
                ? 'bg-slate-400'
                : isCritical
                ? 'bg-rose-500 duration-500'
                : isWarning
                ? 'bg-amber-400'
                : 'bg-emerald-400'
            }`}
          />
          
          {/* Pin Core */}
          <span
            className={`relative flex items-center justify-center w-7 h-7 rounded-full shadow-lg border-2 transition-transform transform group-hover:scale-125 ${
              isSelected || isOpenInfoWindow
                ? 'ring-4 ring-sky-400/50 scale-115'
                : ''
            } ${
              isOffline
                ? 'bg-slate-900 border-slate-400 text-slate-300'
                : isCritical
                ? 'bg-rose-600 border-rose-300 text-white animate-pulse'
                : isWarning
                ? 'bg-amber-500 border-amber-200 text-slate-950'
                : 'bg-emerald-500 border-emerald-200 text-white'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
          </span>
        </span>

        {/* Cluster Member Indicator if part of expanded cluster */}
        {clusterContext && !isOpenInfoWindow && (
          <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded text-[8px] font-mono font-bold bg-indigo-950/90 text-indigo-300 border border-indigo-700/60 whitespace-nowrap shadow-xs">
            Cluster
          </span>
        )}

        {/* Device Pin Badge Label (Shown when info-window is closed) */}
        {!isOpenInfoWindow && (
          <div
            className={`absolute top-8 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded text-[10px] font-mono whitespace-nowrap font-bold shadow-md transition-all ${
              isSelected || isHovered
                ? 'opacity-100 scale-100 z-30'
                : 'opacity-85 scale-95'
            } ${
              isOffline
                ? 'bg-slate-800 text-slate-300 border border-slate-600'
                : isCritical
                ? 'bg-rose-950 text-rose-200 border border-rose-500'
                : isWarning
                ? 'bg-amber-950 text-amber-200 border border-amber-500'
                : 'bg-slate-900/95 text-emerald-300 border border-emerald-500/40'
            }`}
          >
            <div className="flex items-center gap-1">
              <span>{dev.name.split(' ')[0]}</span>
              <span>·</span>
              <span>{isOffline ? 'OFFLINE' : `${lat}ms`}</span>
            </div>
          </div>
        )}

        {/* Hover Floating Tooltip (Shown when hovered and info-window is closed) */}
        {!isOpenInfoWindow && isHovered && (
          <div className="absolute bottom-9 left-1/2 -translate-x-1/2 w-48 p-2 rounded-xl bg-slate-950 text-white border border-slate-700 shadow-xl z-40 text-[11px] pointer-events-none">
            <div className="font-bold truncate text-sky-300">{dev.name}</div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">{coords.zone}</div>
            <div className="mt-1 flex items-center justify-between text-[10px]">
              <span className="text-slate-400 font-mono">{coords.lat.toFixed(4)}°N, {coords.lng.toFixed(4)}°E</span>
              <span className={isCritical ? 'text-rose-400 font-bold' : 'text-emerald-400 font-bold'}>
                {isOffline ? 'OFFLINE' : `${lat}ms`}
              </span>
            </div>
            <div className="text-[9px] text-slate-400 mt-1 italic">Click marker to open info window</div>
          </div>
        )}

        {/* Interactive Info-Window Popup on Marker Click */}
        {isOpenInfoWindow && (
          <div
            onClick={(e) => e.stopPropagation()}
            className={`absolute z-50 w-72 sm:w-80 p-3.5 rounded-xl bg-slate-900/98 text-white border border-slate-700 shadow-2xl backdrop-blur-md select-text cursor-default animate-in fade-in zoom-in-95 duration-150 ${
              isNearTop ? 'top-10' : 'bottom-10'
            } ${
              isNearRight
                ? 'right-[-14px] sm:right-[-20px]'
                : isNearLeft
                ? 'left-[-14px] sm:left-[-20px]'
                : 'left-1/2 -translate-x-1/2'
            }`}
          >
            {/* Pointer Caret / Stem */}
            <div
              className={`absolute w-0 h-0 pointer-events-none ${
                isNearTop
                  ? 'bottom-full -mb-1 border-b-slate-900 border-x-transparent border-t-transparent border-b-[8px] border-x-[6px]'
                  : 'top-full -mt-1 border-t-slate-900 border-x-transparent border-b-transparent border-t-[8px] border-x-[6px]'
              } ${
                isNearRight
                  ? 'right-7'
                  : isNearLeft
                  ? 'left-7'
                  : 'left-1/2 -translate-x-1/2'
              }`}
            />

            {/* Header: Vendor, Status, Device Name, and Close Button */}
            <div className="flex items-start justify-between gap-2 pb-2.5 border-b border-slate-800">
              <div className="min-w-0 pr-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-sky-950 text-sky-300 border border-sky-800/60 font-semibold">
                    {dev.vendor}
                  </span>
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold uppercase ${
                      isOffline
                        ? 'bg-slate-800 text-slate-300 border border-slate-600'
                        : isCritical
                        ? 'bg-rose-950 text-rose-200 border border-rose-600 animate-pulse'
                        : isWarning
                        ? 'bg-amber-950 text-amber-200 border border-amber-600'
                        : 'bg-emerald-950 text-emerald-300 border border-emerald-600/60'
                    }`}
                  >
                    {isOffline ? 'OFFLINE' : 'ONLINE'}
                  </span>
                  {clusterContext && (
                    <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-indigo-950 text-indigo-300 border border-indigo-700/60 font-semibold truncate max-w-[120px]">
                      {clusterContext.clusterTitle}
                    </span>
                  )}
                </div>
                <h4 className="font-bold text-slate-100 text-xs sm:text-sm mt-1 leading-snug truncate" title={dev.name}>
                  {dev.name}
                </h4>
                <p className="text-[10px] text-slate-400 font-mono mt-0.5 truncate">
                  {dev.deviceModel}
                </p>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setOpenInfoWindowDeviceId(null);
                }}
                aria-label="Close info-window"
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Info-Window Telemetry Rows: Device Name, Last Sync Time, Current Firmware */}
            <div className="py-2 space-y-1.5 text-xs">
              {/* Current Firmware Version */}
              <div className="flex items-center justify-between py-0.5 border-b border-slate-800/60">
                <span className="text-slate-400 flex items-center gap-1.5 text-[11px]">
                  <Cpu className="w-3.5 h-3.5 text-sky-400" />
                  <span>Current Firmware:</span>
                </span>
                <span className="font-mono font-bold text-sky-300 bg-sky-950/80 border border-sky-800/60 px-1.5 py-0.5 rounded text-[11px]">
                  {getDeviceFirmware(dev)}
                </span>
              </div>

              {/* Last Sync Time */}
              <div className="flex items-center justify-between py-0.5 border-b border-slate-800/60">
                <span className="text-slate-400 flex items-center gap-1.5 text-[11px]">
                  <Clock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Last Sync Time:</span>
                </span>
                <span className="font-mono text-slate-200 text-[11px] font-medium">
                  {formatSyncTime(dev.lastSyncAt)}
                </span>
              </div>

              {/* Sync Latency */}
              <div className="flex items-center justify-between py-0.5 border-b border-slate-800/60">
                <span className="text-slate-400 flex items-center gap-1.5 text-[11px]">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>Sync Latency:</span>
                </span>
                <span
                  className={`font-mono text-[11px] font-bold ${
                    isOffline
                      ? 'text-slate-400'
                      : isCritical
                      ? 'text-rose-400'
                      : isWarning
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                  }`}
                >
                  {isOffline ? 'Disconnected' : `${lat}ms`}
                </span>
              </div>

              {/* Physical Zone */}
              <div className="flex items-start justify-between py-0.5 border-b border-slate-800/60">
                <span className="text-slate-400 flex items-center gap-1.5 text-[11px] shrink-0">
                  <MapPin className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Facility Zone:</span>
                </span>
                <span className="text-right text-[11px] text-slate-300 font-sans ml-2 truncate" title={coords.zone}>
                  {coords.zone}
                </span>
              </div>

              {/* Network IP & S/N */}
              <div className="pt-0.5 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                <span>IP: {dev.ipAddress}:{dev.port}</span>
                <span>S/N: {dev.serialNumber}</span>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="pt-2 border-t border-slate-800 flex items-center gap-2">
              {onPingDevice && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onPingDevice(dev.id);
                  }}
                  disabled={pingingDeviceId === dev.id}
                  className="flex-1 py-1 px-2.5 rounded-lg bg-sky-900/60 hover:bg-sky-800 text-sky-200 border border-sky-700/60 text-[11px] font-semibold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                >
                  <RefreshCw className={`w-3 h-3 text-sky-400 ${pingingDeviceId === dev.id ? 'animate-spin' : ''}`} />
                  <span>{pingingDeviceId === dev.id ? 'Testing Ping...' : 'Test Ping'}</span>
                </button>
              )}

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDeviceSelect(dev.id);
                }}
                className="py-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-[11px] font-semibold transition-colors cursor-pointer"
              >
                Inspect
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderClusterIcon = (cluster: MarkerCluster) => {
    const isHovered = hoveredClusterId === cluster.id;
    return (
      <div
        key={cluster.id}
        style={{
          left: `${cluster.centroidX}%`,
          top: `${cluster.centroidY}%`,
        }}
        onClick={(e) => {
          e.stopPropagation();
          handleToggleCluster(cluster.id);
          if (cluster.devices[0]) {
            handleDeviceSelect(cluster.devices[0].id);
          }
        }}
        onMouseEnter={() => setHoveredClusterId(cluster.id)}
        onMouseLeave={() => setHoveredClusterId(null)}
        className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer group z-25 transition-transform hover:scale-105"
        title="Click to expand cluster and view all individual hardware terminal markers"
      >
        {/* Outer Ping / Ripple Rings */}
        <span className="relative flex h-11 w-11 items-center justify-center">
          <span
            className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-60 ${
              cluster.hasOffline
                ? 'bg-slate-400'
                : cluster.hasCritical
                ? 'bg-rose-500 duration-700'
                : cluster.hasWarning
                ? 'bg-amber-400'
                : 'bg-sky-400'
            }`}
          />
          <span className="absolute inset-0 rounded-full border-2 border-dashed border-sky-400/50 animate-[spin_12s_linear_infinite]" />

          {/* Cluster Pin Core Icon */}
          <span
            className={`relative flex items-center justify-center w-10 h-10 rounded-full shadow-2xl border-2 transition-all transform group-hover:scale-115 ${
              cluster.hasOffline
                ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-slate-400 text-slate-200'
                : cluster.hasCritical
                ? 'bg-gradient-to-br from-rose-600 to-rose-800 border-rose-300 text-white animate-pulse'
                : cluster.hasWarning
                ? 'bg-gradient-to-br from-amber-500 to-amber-700 border-amber-200 text-white'
                : 'bg-gradient-to-br from-sky-600 via-indigo-600 to-sky-700 border-sky-200 text-white'
            }`}
          >
            <div className="flex flex-col items-center justify-center -space-y-0.5">
              <Layers className="w-3.5 h-3.5 text-white/90" />
              <span className="text-[10px] font-black font-mono leading-none">{cluster.devices.length}</span>
            </div>
          </span>
        </span>

        {/* Cluster Pin Badge Label */}
        <div className="absolute top-11 left-1/2 -translate-x-1/2 px-2.5 py-1 rounded-lg text-[10px] font-mono whitespace-nowrap font-bold shadow-lg transition-all bg-slate-900/95 text-sky-200 border border-sky-500/50 flex items-center gap-1.5 group-hover:bg-slate-900">
          <Layers className="w-3 h-3 text-sky-400" />
          <span>{cluster.siteKey === 'HQ' ? 'Corporate HQ' : cluster.siteKey}</span>
          <span className="px-1.5 py-0.2 rounded bg-sky-950 text-sky-300 border border-sky-700 text-[9px] font-black">
            {cluster.devices.length} Devices
          </span>
          <span className="text-sky-400/80 font-sans text-[9px] font-normal underline">Click to expand</span>
        </div>

        {/* Hover Card Preview */}
        {isHovered && (
          <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-60 p-3 rounded-xl bg-slate-950 text-white border border-slate-700 shadow-2xl z-45 text-[11px] pointer-events-none animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
              <span className="font-bold text-sky-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-sky-400" />
                <span>Grouped Proximity Cluster</span>
              </span>
              <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-sky-900/60 text-sky-200 border border-sky-700 font-bold">
                {cluster.devices.length} Devices
              </span>
            </div>

            <div className="mt-2 space-y-1.5">
              {cluster.devices.map(d => {
                const lat = getLatency(d);
                const isOff = d.status === 'Offline';
                return (
                  <div key={d.id} className="flex items-center justify-between text-[10px]">
                    <span className="truncate pr-1 text-slate-300 font-medium">{d.name}</span>
                    <span
                      className={`font-mono font-bold shrink-0 ${
                        isOff ? 'text-slate-400' : lat > 500 ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {isOff ? 'Offline' : `${lat}ms`}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="mt-2.5 pt-1.5 border-t border-slate-800 text-[9px] text-sky-300 flex items-center justify-between font-mono">
              <span>Avg Ping: {cluster.avgLatency}ms</span>
              <span className="text-amber-300 font-bold">Click to expand on map</span>
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Top Header & Toolbar */}
      <div className="p-4 sm:p-5 border-b border-slate-200 bg-gradient-to-r from-slate-50 via-white to-sky-50/40">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3.5">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-sky-100 text-sky-800">
                <MapPin className="w-4 h-4" />
              </span>
              <h3 className="text-sm font-bold text-slate-900">
                Biometric Terminal Physical Location & Site Diagnostics Map
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700 border border-slate-200">
                Geo & Blueprint Telemetry
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Visual map display with placeholder coordinates to locate hardware and isolate site-specific network bottlenecks.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Live Monitoring Toggle Switch (automated 30-second connectivity fetch) */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs shadow-2xs">
              <button
                type="button"
                role="switch"
                aria-checked={isLiveMonitoring}
                onClick={() => {
                  const next = !isLiveMonitoring;
                  setIsLiveMonitoring(next);
                  if (next) {
                    handleTriggerFetch();
                  }
                }}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                  isLiveMonitoring ? 'bg-emerald-600' : 'bg-slate-300'
                }`}
                title="Toggle Live Monitoring (auto-fetches connectivity status every 30s)"
              >
                <span
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-xs ring-0 transition duration-200 ease-in-out ${
                    isLiveMonitoring ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>

              <div className="flex items-center gap-1.5">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isLiveMonitoring ? 'bg-emerald-500 animate-ping' : 'bg-slate-400'
                  }`}
                />
                <span className="font-semibold text-slate-800 whitespace-nowrap">
                  Live Monitoring
                </span>
                {isLiveMonitoring ? (
                  <div className="flex items-center gap-1 font-mono text-[10px] text-emerald-800 bg-emerald-100/90 border border-emerald-300/60 px-1.5 py-0.2 rounded font-bold">
                    <span>{secondsUntilNextFetch}s</span>
                    <button
                      type="button"
                      onClick={handleTriggerFetch}
                      disabled={isFetching}
                      title="Fetch status now"
                      className="text-emerald-700 hover:text-emerald-950 cursor-pointer transition-colors"
                    >
                      <RefreshCw className={`w-2.5 h-2.5 ${isFetching ? 'animate-spin' : ''}`} />
                    </button>
                  </div>
                ) : (
                  <span className="font-mono text-[10px] text-slate-500 bg-slate-200/80 px-1.5 py-0.2 rounded font-medium">
                    OFF
                  </span>
                )}
              </div>
            </div>

            {/* View Mode Toggle: Regional Geo Map vs Facility Blueprint with Smooth Transitions */}
            <div className="relative flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs">
              <div
                className={`absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-lg bg-white shadow-xs border border-slate-200/80 transition-all duration-300 ease-out pointer-events-none ${
                  mapMode === 'geo' ? 'left-1' : 'left-[calc(50%+2px)]'
                }`}
              />
              <button
                onClick={() => setMapMode('geo')}
                className={`relative z-10 px-3 py-1 rounded-lg font-semibold transition-colors duration-200 cursor-pointer ${
                  mapMode === 'geo'
                    ? 'text-slate-900 font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Regional Geo Map
              </button>
              <button
                onClick={() => setMapMode('blueprint')}
                className={`relative z-10 px-3 py-1 rounded-lg font-semibold transition-colors duration-200 cursor-pointer ${
                  mapMode === 'blueprint'
                    ? 'text-slate-900 font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Plant Blueprint
              </button>
            </div>

            {/* Marker Clustering Toggle */}
            <button
              type="button"
              onClick={() => setIsClusteringEnabled(prev => !prev)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer shadow-2xs ${
                isClusteringEnabled
                  ? 'bg-sky-50 text-sky-800 border-sky-300'
                  : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
              }`}
              title="Toggle grouping close-proximity terminals into expandable clusters"
            >
              <Layers className={`w-3.5 h-3.5 ${isClusteringEnabled ? 'text-sky-600' : 'text-slate-500'}`} />
              <span>Clustering: {isClusteringEnabled ? 'ON' : 'OFF'}</span>
              {isClusteringEnabled && clusters.some(c => c.isCluster) && (
                <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-sky-200/80 text-sky-900 font-bold">
                  {clusters.filter(c => c.isCluster).length} {clusters.filter(c => c.isCluster).length === 1 ? 'Cluster' : 'Clusters'}
                </span>
              )}
            </button>

            {/* Quick incident jumper if any site has issues */}
            {siteSummaries.some(s => s.hasIncident) && (
              <button
                onClick={handleFocusIncident}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer animate-pulse"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Focus Site Alert</span>
              </button>
            )}
          </div>
        </div>

        {/* Site Filter Tabs */}
        <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setSelectedSiteFilter('ALL')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer whitespace-nowrap ${
              selectedSiteFilter === 'ALL'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            All Sites (Fleet Overview · 4 Terminals)
          </button>
          {siteSummaries.map(site => {
            const isSelected = selectedSiteFilter === site.id;
            return (
              <button
                key={site.id}
                onClick={() => setSelectedSiteFilter(site.id)}
                className={`px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap border ${
                  isSelected
                    ? 'bg-sky-600 text-white border-sky-600 shadow-xs'
                    : site.hasIncident
                    ? 'bg-rose-50 text-rose-800 border-rose-300 hover:bg-rose-100'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <span>{site.name}</span>
                <span
                  className={`px-1.5 py-0.2 rounded text-[10px] font-mono font-bold ${
                    isSelected
                      ? 'bg-white/20 text-white'
                      : site.hasIncident
                      ? 'bg-rose-200 text-rose-900'
                      : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {site.devices.length} dev
                </span>
                {site.hasIncident && (
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Map Body: Canvas/SVG Map Display + Site Diagnostic Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
        {/* Map Canvas Area (7 Cols on desktop) */}
        <div className="lg:col-span-8 p-4 sm:p-5 flex flex-col justify-between bg-slate-900 text-slate-100 relative min-h-[380px] lg:min-h-[440px] select-none overflow-hidden">
          {/* Subtle Map Grid Background */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage: `linear-gradient(#38bdf8 1px, transparent 1px), linear-gradient(90deg, #38bdf8 1px, transparent 1px)`,
              backgroundSize: '32px 32px',
            }}
          />

          {/* Map Mode Badge & Coordinate System Indicator */}
          <div className="relative z-10 flex items-center justify-between text-xs flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-sky-950/80 border border-sky-600/40 text-sky-300 font-mono text-[10px] font-bold flex items-center gap-1.5">
                <Radio className="w-3 h-3 text-sky-400 animate-pulse" />
                <span>{mapMode === 'geo' ? 'GPS WGS-84 TOPOLOGY' : 'CAD PLANT FLOORPLAN BLUEPRINT'}</span>
              </span>
              <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
                {selectedSiteFilter === 'ALL' ? 'Multi-Site Western India Corridor' : `${selectedSiteFilter} Specific Sector`}
              </span>
            </div>

            <div className="flex items-center gap-2 text-[10px] text-slate-300 font-mono flex-wrap">
              <span className="px-1.5 py-0.5 rounded bg-slate-800/80 border border-slate-700">
                ZOOM: 1.0x
              </span>
              {expandedClusterIds.size > 0 && (
                <span className="px-1.5 py-0.5 rounded bg-sky-950/80 border border-sky-600/60 text-sky-300 flex items-center gap-1.5 font-bold">
                  <Layers className="w-3 h-3 text-sky-400" />
                  <span>CLUSTER EXPANDED</span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setExpandedClusterIds(new Set());
                    }}
                    className="text-sky-300 hover:text-white underline cursor-pointer ml-0.5 font-sans text-[9px]"
                  >
                    Collapse all
                  </button>
                </span>
              )}
              {isLiveMonitoring ? (
                <span className="px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-700/60 text-emerald-300 flex items-center gap-1.5 font-bold">
                  <span className={`w-1.5 h-1.5 rounded-full ${isFetching ? 'bg-sky-400 animate-ping' : 'bg-emerald-400 animate-pulse'}`} />
                  <span>{isFetching ? 'FETCHING TELEMETRY...' : `LIVE 30s: NEXT IN ${secondsUntilNextFetch}s`}</span>
                </span>
              ) : (
                <span className="px-1.5 py-0.5 rounded bg-slate-800/80 border border-slate-700 text-slate-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-500" />
                  <span>POLLING PAUSED</span>
                </span>
              )}
            </div>
          </div>

          {/* Visual Map Render (SVG Graphic Canvas) */}
          <div
            onClick={() => setOpenInfoWindowDeviceId(null)}
            className="relative z-10 my-4 h-72 sm:h-80 w-full rounded-xl bg-slate-950/70 border border-slate-800 p-4 relative overflow-hidden flex items-center justify-center cursor-default"
          >
            {mapMode === 'geo' ? (
              /* REGIONAL GEO MAP GRAPHIC */
              <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                {/* Connecting VPN / WAN link lines between HQ and Manufacturing Plants */}
                <defs>
                  <linearGradient id="linkGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity="0.8" />
                  </linearGradient>
                </defs>

                {/* Regional Landmass Contours (Geometric abstractions for Maharashtra & Gujarat) */}
                <path
                  d="M10,15 Q30,8 50,15 T85,25 Q92,50 80,75 T45,88 Q20,80 12,60 Z"
                  fill="#0f172a"
                  stroke="#334155"
                  strokeWidth="0.8"
                  strokeDasharray="2,2"
                />

                {/* Highway / Industrial Corridor Line (Gujarat to Maharashtra) */}
                <line
                  x1="24"
                  y1="26"
                  x2="68"
                  y2="38"
                  stroke={siteSummaries.find(s => s.id === 'SANAND')?.hasIncident ? '#f43f5e' : '#0284c7'}
                  strokeWidth="1.2"
                  strokeDasharray={siteSummaries.find(s => s.id === 'SANAND')?.hasIncident ? '2,2' : 'none'}
                  className={siteSummaries.find(s => s.id === 'SANAND')?.hasIncident ? 'animate-pulse' : ''}
                />
                <line
                  x1="34"
                  y1="64"
                  x2="68"
                  y2="38"
                  stroke="#10b981"
                  strokeWidth="1"
                />

                {/* Subnet / Link Label on Line */}
                <text x="38" y="27" fill="#94a3b8" fontSize="2.5" fontFamily="monospace">
                  WAN MPLS VPN (Sanand ↔ Baner HQ)
                </text>
                <text x="48" y="56" fill="#94a3b8" fontSize="2.5" fontFamily="monospace">
                  Metro Dark Fiber (Chakan ↔ Baner HQ)
                </text>

                {/* Regional Clusters Label */}
                <text x="14" y="20" fill="#cbd5e1" fontSize="3" fontWeight="bold">
                  GUJARAT REGION
                </text>
                <text x="56" y="82" fill="#cbd5e1" fontSize="3" fontWeight="bold">
                  MAHARASHTRA AUTO CLUSTER
                </text>
              </svg>
            ) : (
              /* PLANT BLUEPRINT / FLOORPLAN GRAPHIC */
              <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                {/* Architectural Plant Walls & Sections */}
                <rect x="10" y="10" width="80" height="80" fill="#0b1329" stroke="#1e293b" strokeWidth="1" rx="2" />
                
                {/* Zones Outline */}
                {/* Gate 1 & Security */}
                <rect x="15" y="55" width="30" height="30" fill="#1e293b" stroke="#334155" strokeWidth="0.8" />
                <text x="17" y="60" fill="#94a3b8" fontSize="2.4" fontWeight="bold">ZONE 1: MAIN ENTRANCE & TURNSTILES</text>
                
                {/* Heavy Stamping Press Shop */}
                <rect x="15" y="15" width="40" height="35" fill="#1e293b" stroke="#334155" strokeWidth="0.8" />
                <text x="17" y="20" fill="#94a3b8" fontSize="2.4" fontWeight="bold">ZONE 2: STAMPING & PRESS SHOP</text>
                
                {/* Corporate HQ Tower */}
                <rect x="60" y="15" width="25" height="35" fill="#1e293b" stroke="#334155" strokeWidth="0.8" />
                <text x="62" y="20" fill="#94a3b8" fontSize="2.4" fontWeight="bold">ZONE 3: CORP HQ 4TH FLR</text>

                {/* High Security R&D Wing */}
                <rect x="60" y="55" width="25" height="30" fill="#1e293b" stroke="#334155" strokeWidth="0.8" />
                <text x="62" y="60" fill="#94a3b8" fontSize="2.4" fontWeight="bold">ZONE 4: R&D CLEANROOM</text>
              </svg>
            )}

            {/* Dynamic SVG Connector Lines for Expanded Proximity Clusters */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none z-10" viewBox="0 0 100 100" preserveAspectRatio="none">
              {clusters.filter(c => c.isCluster && expandedClusterIds.has(c.id)).map(c => (
                <g key={`spider-lines-${c.id}`}>
                  {c.devices.map(d => {
                    const coords = getDeviceCoords(d);
                    return (
                      <line
                        key={`spider-line-${c.id}-${d.id}`}
                        x1={c.centroidX}
                        y1={c.centroidY}
                        x2={coords.x}
                        y2={coords.y}
                        stroke="#38bdf8"
                        strokeWidth="0.9"
                        strokeDasharray="2,2"
                        opacity="0.8"
                      />
                    );
                  })}
                </g>
              ))}
            </svg>

            {/* Interactive Markers: Grouped Clusters (Expand on Click) & Individual Pins */}
            {clusters.map(cluster => {
              if (cluster.isCluster) {
                const isExpanded = expandedClusterIds.has(cluster.id);
                if (!isExpanded) {
                  // Render Single Grouped Cluster Icon
                  return renderClusterIcon(cluster);
                } else {
                  // Render Expanded Cluster: Central Anchor Collapse Hub + Member Device Pins
                  return (
                    <React.Fragment key={`expanded-group-${cluster.id}`}>
                      {/* Central Anchor Collapse Hub */}
                      <div
                        style={{
                          left: `${cluster.centroidX}%`,
                          top: `${cluster.centroidY}%`,
                        }}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCollapseCluster(cluster.id);
                        }}
                        className="absolute -translate-x-1/2 -translate-y-1/2 z-15 cursor-pointer group"
                        title="Click to collapse cluster back into single icon"
                      >
                        <div className="flex flex-col items-center">
                          <div className="p-1.5 rounded-full bg-slate-900/95 text-sky-300 border border-sky-400 shadow-xl group-hover:bg-sky-950 group-hover:scale-110 transition-all flex items-center justify-center">
                            <Minimize2 className="w-3.5 h-3.5" />
                          </div>
                          <span className="mt-0.5 px-1.5 py-0.2 rounded text-[8px] font-mono font-bold bg-slate-900/90 text-sky-300 border border-sky-700/60 whitespace-nowrap shadow-xs">
                            Collapse Cluster
                          </span>
                        </div>
                      </div>

                      {/* Render individual expanded markers for devices in this cluster */}
                      {cluster.devices.map(dev =>
                        renderDevicePin(dev, {
                          clusterId: cluster.id,
                          isExpanded: true,
                          clusterTitle: `${cluster.siteKey === 'HQ' ? 'Corporate HQ' : cluster.siteKey} Cluster`,
                        })
                      )}
                    </React.Fragment>
                  );
                }
              } else {
                // Non-clustered standalone device pin
                return cluster.devices[0] ? renderDevicePin(cluster.devices[0]) : null;
              }
            })}
          </div>

          {/* Map Legend */}
          <div className="relative z-10 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 flex-wrap gap-2">
            <div className="flex items-center gap-3 flex-wrap font-medium">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span className="text-slate-300">&lt;80ms Optimal LAN</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-400"></span>
                <span className="text-slate-300">80–150ms Standard</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                <span className="text-slate-300">150–500ms Elevated</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse"></span>
                <span className="text-rose-300 font-bold">&gt;500ms SLA Alert</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span>
                <span className="text-slate-400">Offline Disconnected</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded-full bg-gradient-to-br from-sky-500 to-indigo-600 border border-sky-300 flex items-center justify-center text-[8px] text-white font-bold shadow-2xs">
                  2
                </span>
                <span className="text-slate-300">Cluster Icon (Expands on Click)</span>
              </span>
            </div>

            <div className="flex items-center gap-3 text-[10px] text-slate-400 font-mono flex-wrap">
              {isLiveMonitoring ? (
                <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Auto-sync (30s): Next in {secondsUntilNextFetch}s
                </span>
              ) : (
                <span className="text-slate-500">Auto-sync paused</span>
              )}
              <span>Last fetch: {lastFetchedAt.toLocaleTimeString()}</span>
            </div>
          </div>
        </div>

        {/* Site Connectivity Diagnostics Sidebar (4 Cols on desktop) */}
        <div className="lg:col-span-4 p-4 sm:p-5 flex flex-col justify-between bg-slate-50/50 space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-slate-700" />
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Site Connectivity Health
                </h4>
              </div>
              <span className="text-[11px] text-slate-500 font-mono font-medium">
                3 Plant Sites
              </span>
            </div>

            {/* Site Health Cards List */}
            <div className="space-y-2.5 mt-3">
              {siteSummaries.map(site => {
                const isSiteSelected = selectedSiteFilter === site.id;
                return (
                  <div
                    key={site.id}
                    onClick={() => {
                      setSelectedSiteFilter(site.id);
                      if (site.devices[0]) handleDeviceSelect(site.devices[0].id);
                    }}
                    className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                      site.hasIncident
                        ? 'bg-rose-50/90 border-rose-300 hover:border-rose-400'
                        : isSiteSelected
                        ? 'bg-white border-sky-400 shadow-xs ring-2 ring-sky-500/10'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h5 className="font-bold text-slate-900 leading-snug">{site.name}</h5>
                          {site.hasIncident ? (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase bg-rose-600 text-white animate-pulse">
                              ALERT
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase bg-emerald-100 text-emerald-800 border border-emerald-200">
                              ONLINE
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 font-mono mt-0.5">{site.city}</p>
                      </div>

                      <div className="text-right shrink-0 font-mono">
                        <span className={`font-bold ${
                          site.hasIncident ? 'text-rose-700' : 'text-slate-900'
                        }`}>
                          {site.avgLatency}ms
                        </span>
                        <div className="text-[10px] text-slate-400">avg ping</div>
                      </div>
                    </div>

                    <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>Subnet: {site.subnet}</span>
                      <span>GPS: {site.coordinates.split(',')[0]}</span>
                    </div>

                    {/* Site Specific Incident Alert Box */}
                    {site.hasIncident && (
                      <div className="mt-2 p-2 rounded-lg bg-rose-100 text-rose-950 text-[10px] flex items-start gap-1.5 font-sans border border-rose-200">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                        <div>
                          <strong>Site Connectivity Issue:</strong>{' '}
                          {site.incidentType === 'OFFLINE'
                            ? 'A hardware terminal is disconnected. Shift clocking disabled in this zone.'
                            : 'Severe network jitter detected (>500ms SLA). Inspection of plant router recommended.'}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Selected Device Deep Inspection Card */}
            {selectedDevice && selectedMeta && (
              <div className="mt-4 p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                    Terminal Pin Inspector
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                      selectedIsOffline
                        ? 'bg-slate-900 text-white'
                        : selectedIsCritical
                        ? 'bg-rose-100 text-rose-900 border border-rose-300'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {selectedIsOffline ? 'OFFLINE' : `PING: ${selectedLat}ms`}
                  </span>
                </div>

                <div>
                  <h4 className="font-black text-slate-900 text-sm">{selectedDevice.name}</h4>
                  <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                    {selectedDevice.deviceModel} ({selectedDevice.vendor})
                  </p>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-[11px] space-y-1 font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Physical Zone:</span>
                    <span className="font-semibold text-slate-800">{selectedMeta.zone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Plant Level:</span>
                    <span className="font-semibold text-slate-800">{selectedMeta.floor}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500">Current Firmware:</span>
                    <span className="font-mono font-bold text-sky-800 bg-sky-50 px-1.5 py-0.2 rounded border border-sky-200 text-[10px]">
                      {getDeviceFirmware(selectedDevice)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Last Sync Time:</span>
                    <span className="font-semibold text-slate-800">{formatSyncTime(selectedDevice.lastSyncAt)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">GPS Coordinates:</span>
                    <span className="text-sky-700 font-bold">{selectedMeta.lat.toFixed(4)}° N, {selectedMeta.lng.toFixed(4)}° E</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Local IP Port:</span>
                    <span className="text-slate-800">{selectedDevice.ipAddress}:{selectedDevice.port}</span>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-[10px] text-slate-400">
                    S/N: <strong className="font-mono text-slate-600">{selectedDevice.serialNumber}</strong>
                  </span>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setOpenInfoWindowDeviceId(selectedDevice.id)}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-[11px] transition-colors cursor-pointer flex items-center gap-1"
                      title="Show on-map info window popup"
                    >
                      <MapPin className="w-3 h-3 text-sky-600" />
                      <span>Map Popup</span>
                    </button>
                    {onPingDevice && (
                      <button
                        onClick={() => onPingDevice(selectedDevice.id)}
                        disabled={pingingDeviceId === selectedDevice.id}
                        className="px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 font-bold text-[11px] border border-sky-200 transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <RefreshCw className={`w-3 h-3 text-sky-600 ${pingingDeviceId === selectedDevice.id ? 'animate-spin' : ''}`} />
                        <span>{pingingDeviceId === selectedDevice.id ? 'Pinging...' : 'Test Ping'}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-2 pt-2">
            {onSwitchToListView && (
              <button
                onClick={onSwitchToListView}
                className="w-full py-2 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-bold transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <LayoutList className="w-3.5 h-3.5 text-sky-600" />
                <span>Switch to Hardware List View</span>
              </button>
            )}

            {onNavigate && (
              <button
                onClick={() => onNavigate('biometric')}
                className="w-full py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Manage Machine IP & Protocols in Biometric Studio</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

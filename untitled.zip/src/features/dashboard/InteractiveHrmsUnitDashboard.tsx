// RSTPL HRMS - Dynamic Interactive HRMS Dashboard & Unit Location Hub
// RS Technovisions XpertSkillCop
// Implements prompt specification:
// - Dynamic Unit Name selector [ Select Unit ▼ ] with real-time KPI re-computation
// - Add Unit with Location (Name, Code, Type, City, State, Address, Pincode, Capacity, Unit Head, Coordinates)
// - Financial Year: 2026–27, Date: 08-Oct-2026, Role: 👤 Admin / HR ▼
// - 6 Animated KPIs: Total Employees 1,248, Present 1,156, On Leave 52, Absent 40, New Joining 18, Birthday Today 06
// - Attendance Visualization: Present 92.6%, Leave 4.2%, Absent 3.2%
// - Department-Wise Breakdown: Administration (185), Finance (142), HR (96), Operations (425), Technical (280), Others (120)
// - Interactive Quick Actions: + Add Employee | Apply Leave | Approve Leave | Mark Attendance | Generate Report
// - Interactive Module Navigation Panels: Employee, Attendance, Leave, Payroll, Reports, Administration
// - Fully interactive modals for all actions with live state updates & instant feedback

import React, { useState, useMemo, useEffect } from 'react';
import {
  Users,
  UserCheck,
  Calendar,
  Clock,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  Building,
  Building2,
  MapPin,
  Plus,
  Cake,
  UserPlus,
  FileText,
  CheckSquare,
  ShieldCheck,
  ChevronRight,
  ChevronDown,
  Layers,
  BarChart3,
  ExternalLink,
  Search,
  Check,
  X,
  Compass,
  ArrowRight,
  FolderTree,
  FileCheck,
  Receipt,
  GraduationCap,
  Sparkles,
  HelpCircle,
  FileDown,
  Fingerprint,
  Mail,
  Phone,
  Send,
  Eye,
  Award,
  Activity,
  Radio,
  Zap,
  Target,
  Smartphone,
  Shield,
  RefreshCw
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { HRMSStoreData } from '../../services/hrmsStorage';
import { UserRole, Unit, Branch, Employee, LeaveRequest } from '../../types/hrms';

interface InteractiveHrmsUnitDashboardProps {
  storeData: HRMSStoreData;
  currentRole: UserRole;
  onNavigate: (module: string) => void;
  onAddUnit?: (unit: Unit, branch?: Branch) => void;
  onRoleChange?: (role: UserRole) => void;
  onAddEmployee?: (emp: Employee) => void;
  onDownloadPdf?: () => void;
  onLogAudit?: (action: any, module: string, details: string) => void;
}

export const InteractiveHrmsUnitDashboard: React.FC<InteractiveHrmsUnitDashboardProps> = ({
  storeData,
  currentRole,
  onNavigate,
  onAddUnit,
  onRoleChange,
  onAddEmployee,
  onDownloadPdf,
  onLogAudit,
}) => {
  const { units, branches, departments, designations, employees, attendance, leaveRequests } = storeData;

  // Selected Unit State: 'ALL' or unit ID
  const [selectedUnitId, setSelectedUnitId] = useState<string>('ALL');
  const [selectedFY, setSelectedFY] = useState<string>('2026–27');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Live Digital Clock State
  const [currentTimeStr, setCurrentTimeStr] = useState<string>('10:45:00 AM');
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTimeStr(now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Modal Visibility States
  const [showAddUnitModal, setShowAddUnitModal] = useState<boolean>(false);
  const [showAddEmployeeModal, setShowAddEmployeeModal] = useState<boolean>(false);
  const [showApplyLeaveModal, setShowApplyLeaveModal] = useState<boolean>(false);
  const [showApproveLeaveModal, setShowApproveLeaveModal] = useState<boolean>(false);
  const [punchTimeframe, setPunchTimeframe] = useState<'all' | 'peak' | 'egress'>('all');
  const [showMarkAttendanceModal, setShowMarkAttendanceModal] = useState<boolean>(false);
  const [showReportModal, setShowReportModal] = useState<boolean>(false);
  const [showBirthdaysModal, setShowBirthdaysModal] = useState<boolean>(false);
  const [showNewJoineesModal, setShowNewJoineesModal] = useState<boolean>(false);

  // Add Unit Form State
  const [unitName, setUnitName] = useState<string>('');
  const [unitCode, setUnitCode] = useState<string>('');
  const [unitType, setUnitType] = useState<Unit['type']>('Manufacturing Plant');
  const [branchName, setBranchName] = useState<string>('');
  const [city, setCity] = useState<string>('');
  const [state, setState] = useState<string>('Maharashtra');
  const [address, setAddress] = useState<string>('');
  const [pincode, setPincode] = useState<string>('410501');
  const [capacity, setCapacity] = useState<number>(500);
  const [headPerson, setHeadPerson] = useState<string>('');
  const [phone, setPhone] = useState<string>('+91 20 4567890');
  const [email, setEmail] = useState<string>('');
  const [geoCoords, setGeoCoords] = useState<string>('18.7583° N, 73.8567° E');

  // Quick Add Employee Form State
  const [empFirstName, setEmpFirstName] = useState<string>('');
  const [empLastName, setEmpLastName] = useState<string>('');
  const [empCodeInput, setEmpCodeInput] = useState<string>(`EMP-${Math.floor(1000 + Math.random() * 9000)}`);
  const [empDeptId, setEmpDeptId] = useState<string>(departments[0]?.id || 'dept-prod');
  const [empUnitId, setEmpUnitId] = useState<string>(units[0]?.id || 'un-mfg1');
  const [empDesig, setEmpDesig] = useState<string>('Operations Specialist');
  const [empGrossSalary, setEmpGrossSalary] = useState<number>(45000);
  const [empEmail, setEmpEmail] = useState<string>('');
  const [empPhone, setEmpPhone] = useState<string>('+91 98765 43210');

  // Quick Apply Leave Form State
  const [leaveEmpId, setLeaveEmpId] = useState<string>(employees[0]?.id || '');
  const [leaveType, setLeaveType] = useState<'Casual' | 'Sick' | 'Earned' | 'Maternity'>('Casual');
  const [leaveStartDate, setLeaveStartDate] = useState<string>('2026-10-12');
  const [leaveEndDate, setLeaveEndDate] = useState<string>('2026-10-14');
  const [leaveReason, setLeaveReason] = useState<string>('Family function & personal travel');

  // Quick Attendance Punch State
  const [punchEmpId, setPunchEmpId] = useState<string>(employees[0]?.id || '');
  const [punchType, setPunchType] = useState<'IN' | 'OUT'>('IN');
  const [punchUnitId, setPunchUnitId] = useState<string>(units[0]?.id || 'un-mfg1');
  const [punchRemarks, setPunchRemarks] = useState<string>('Biometric verified on-site');

  // Quick Report Generator State
  const [reportType, setReportType] = useState<'unit_wise' | 'dept_wise' | 'attendance' | 'payroll' | 'leave'>('unit_wise');
  const [reportFormat, setReportFormat] = useState<'csv' | 'excel' | 'pdf'>('csv');

  // Active Pending Leaves Local State (so approve/reject updates live)
  const [localPendingLeaves, setLocalPendingLeaves] = useState<Array<{
    id: string;
    employeeName: string;
    employeeCode: string;
    department: string;
    leaveType: string;
    startDate: string;
    endDate: string;
    days: number;
    reason: string;
    status: 'Pending' | 'Approved' | 'Rejected';
  }>>([
    {
      id: 'leave-001',
      employeeName: 'Pooja Verma',
      employeeCode: 'EMP-004',
      department: 'Purchase & SCM',
      leaveType: 'Earned Leave',
      startDate: '2026-10-15',
      endDate: '2026-10-18',
      days: 4,
      reason: 'Diwali vacation advance travel',
      status: 'Pending',
    },
    {
      id: 'leave-002',
      employeeName: 'Rahul Deshmukh',
      employeeCode: 'EMP-005',
      department: 'Production & Manufacturing',
      leaveType: 'Casual Leave',
      startDate: '2026-10-09',
      endDate: '2026-10-09',
      days: 1,
      reason: 'Urgent home maintenance',
      status: 'Pending',
    },
    {
      id: 'leave-003',
      employeeName: 'Sunita Patil',
      employeeCode: 'EMP-007',
      department: 'Quality Assurance',
      leaveType: 'Sick Leave',
      startDate: '2026-10-08',
      endDate: '2026-10-09',
      days: 2,
      reason: 'Medical consultation & viral recovery',
      status: 'Pending',
    },
  ]);

  // Birthday Celebrants (06 today)
  const birthdaysToday = [
    { name: 'Vikramaditya Roy', code: 'EMP-001', dept: 'Human Resources', unit: 'Corporate Office', designation: 'VP & Head HR', avatar: 'VR' },
    { name: 'Priya Sharma', code: 'EMP-002', dept: 'Production & Manufacturing', unit: 'Chakan Unit 1', designation: 'Operations Lead', avatar: 'PS' },
    { name: 'Rohit Verma', code: 'EMP-006', dept: 'Technical & Engineering', unit: 'Machining & Tooling', designation: 'Senior CNC Engineer', avatar: 'RV' },
    { name: 'Ananya Joshi', code: 'EMP-008', dept: 'Finance & Accounts', unit: 'Corporate Office', designation: 'Accounts Manager', avatar: 'AJ' },
    { name: 'Amit Kumar', code: 'EMP-012', dept: 'Operations & Stamping', unit: 'Sanand Unit 2', designation: 'Plant Supervisor', avatar: 'AK' },
    { name: 'Sneha Patel', code: 'EMP-015', dept: 'Administration', unit: 'Chakan Unit 1', designation: 'Admin Executive', avatar: 'SP' },
  ];

  // New Joinees (18 this month)
  const newJoinees = [
    { name: 'Arjun Nair', code: 'EMP-1021', dept: 'Technical', unit: 'Chakan Unit 1', date: '2026-10-01', desig: 'Mechatronics Engineer' },
    { name: 'Kavita Sundaram', code: 'EMP-1022', dept: 'Human Resources', unit: 'Corporate Office', date: '2026-10-01', desig: 'Talent Acquisition' },
    { name: 'Manish Tiwari', code: 'EMP-1023', dept: 'Operations', unit: 'Sanand Unit 2', date: '2026-10-02', desig: 'Production Engineer' },
    { name: 'Deepika Rao', code: 'EMP-1024', dept: 'Finance', unit: 'Corporate Office', date: '2026-10-03', desig: 'Taxation Analyst' },
    { name: 'Siddharth Sen', code: 'EMP-1025', dept: 'Administration', unit: 'Chakan Unit 1', date: '2026-10-03', desig: 'Facility Supervisor' },
    { name: 'Ritu Ganguly', code: 'EMP-1026', dept: 'Technical', unit: 'Tooling Unit', date: '2026-10-04', desig: 'CAD/CAM Designer' },
    { name: 'Nikhil Chauhan', code: 'EMP-1027', dept: 'Operations', unit: 'Chakan Unit 1', date: '2026-10-05', desig: 'Assembly Specialist' },
    { name: 'Bhavna Kulkarni', code: 'EMP-1028', dept: 'Others', unit: 'Sanand Unit 2', date: '2026-10-05', desig: 'Stores Officer' },
    { name: 'Gaurav Mehra', code: 'EMP-1029', dept: 'Technical', unit: 'Tooling Unit', date: '2026-10-06', desig: 'Quality Inspector' },
    { name: 'Pooja Hegde', code: 'EMP-1030', dept: 'Operations', unit: 'Sanand Unit 2', date: '2026-10-06', desig: 'Stamping Operator' },
    { name: 'Alok Mishra', code: 'EMP-1031', dept: 'Administration', unit: 'Corporate Office', date: '2026-10-07', desig: 'Security Head' },
    { name: 'Megha Das', code: 'EMP-1032', dept: 'Finance', unit: 'Corporate Office', date: '2026-10-07', desig: 'Billing Officer' },
  ];

  // Currently selected unit object and branch object
  const selectedUnit = useMemo(() => {
    return units.find(u => u.id === selectedUnitId);
  }, [units, selectedUnitId]);

  const selectedBranch = useMemo(() => {
    if (!selectedUnit) return null;
    return branches.find(b => b.id === selectedUnit.branchId);
  }, [branches, selectedUnit]);

  // Unit-Aware KPI & Attendance Data Computation
  const unitMetrics = useMemo(() => {
    // If 'ALL' is selected, present the full enterprise benchmark scale requested:
    // Total Employees: 1,248 | Present: 1,156 (92.6%) | On Leave: 52 (4.2%) | Absent: 40 (3.2%)
    // New Joining: 18 | Birthday Today: 06
    // Department breakdown: Administration (185), Finance (142), HR (96), Operations (425), Technical (280), Others (120)
    if (selectedUnitId === 'ALL') {
      const total = 1248;
      const present = 1156;
      const onLeave = 52;
      const absent = 40;
      const newJoining = 18;
      const birthday = 6;

      const presentPct = 92.6;
      const leavePct = 4.2;
      const absentPct = 3.2;

      const depts = [
        { name: 'Administration', count: 185, color: '#059669' },
        { name: 'Finance', count: 142, color: '#d97706' },
        { name: 'HR', count: 96, color: '#9333ea' },
        { name: 'Operations', count: 425, color: '#0284c7' },
        { name: 'Technical', count: 280, color: '#4f46e5' },
        { name: 'Others', count: 120, color: '#64748b' },
      ];

      return {
        unitNameDisplay: 'All Units (Whole Enterprise)',
        locationDisplay: 'Multi-Location: Gurugram HQ, Chakan MIDC, Bhosari & Sanand GIDC Plants',
        unitTypeDisplay: 'Enterprise Multi-Plant Network',
        totalEmployees: total,
        presentToday: present,
        onLeave: onLeave,
        absent: absent,
        newJoining: newJoining,
        birthdayToday: birthday,
        presentPct,
        leavePct,
        absentPct,
        departmentBreakdown: depts,
      };
    }

    // Specific unit selected: compute dynamic numbers based on unit profile
    if (selectedUnitId === 'un-mfg1') {
      // Chakan Plant Assembly
      return {
        unitNameDisplay: 'Manufacturing Unit 1 (Assembly)',
        locationDisplay: 'Plot 42, Chakan Industrial Phase II, Pune - 410501, Maharashtra',
        unitTypeDisplay: 'Heavy Manufacturing Plant',
        totalEmployees: 425,
        presentToday: 395,
        onLeave: 18,
        absent: 12,
        newJoining: 6,
        birthdayToday: 2,
        presentPct: 92.9,
        leavePct: 4.2,
        absentPct: 2.9,
        departmentBreakdown: [
          { name: 'Operations', count: 290, color: '#0284c7' },
          { name: 'Technical', count: 75, color: '#4f46e5' },
          { name: 'Administration', count: 35, color: '#059669' },
          { name: 'Others', count: 25, color: '#64748b' },
        ],
      };
    }

    if (selectedUnitId === 'un-corp') {
      // Corporate HQ
      return {
        unitNameDisplay: 'Corporate Office & HR Center',
        locationDisplay: 'DLF Cyber City, Tower 10, Sector 24, Gurugram - 122002, Haryana',
        unitTypeDisplay: 'Corporate Headquarters',
        totalEmployees: 281,
        presentToday: 262,
        onLeave: 12,
        absent: 7,
        newJoining: 5,
        birthdayToday: 2,
        presentPct: 93.2,
        leavePct: 4.3,
        absentPct: 2.5,
        departmentBreakdown: [
          { name: 'Administration', count: 85, color: '#059669' },
          { name: 'Finance', count: 72, color: '#d97706' },
          { name: 'HR', count: 68, color: '#9333ea' },
          { name: 'Technical', count: 36, color: '#4f46e5' },
          { name: 'Others', count: 20, color: '#64748b' },
        ],
      };
    }

    if (selectedUnitId === 'un-tool') {
      // Tooling Unit
      return {
        unitNameDisplay: 'Machining & Tooling Unit',
        locationDisplay: 'MIDC Bhosari Industrial Area, Sector 7, Pune - 411026, Maharashtra',
        unitTypeDisplay: 'Precision Tooling Plant',
        totalEmployees: 280,
        presentToday: 258,
        onLeave: 13,
        absent: 9,
        newJoining: 4,
        birthdayToday: 1,
        presentPct: 92.1,
        leavePct: 4.6,
        absentPct: 3.3,
        departmentBreakdown: [
          { name: 'Technical', count: 155, color: '#4f46e5' },
          { name: 'Operations', count: 75, color: '#0284c7' },
          { name: 'Administration', count: 28, color: '#059669' },
          { name: 'Others', count: 22, color: '#64748b' },
        ],
      };
    }

    if (selectedUnitId === 'un-mfg2') {
      // Sanand Plant
      return {
        unitNameDisplay: 'Assembly & Stamping Unit 2',
        locationDisplay: 'GIDC Sector 12, Sanand Industrial Area, Ahmedabad - 382170, Gujarat',
        unitTypeDisplay: 'Automotive Stamping Plant',
        totalEmployees: 262,
        presentToday: 241,
        onLeave: 9,
        absent: 12,
        newJoining: 3,
        birthdayToday: 1,
        presentPct: 92.0,
        leavePct: 3.4,
        absentPct: 4.6,
        departmentBreakdown: [
          { name: 'Operations', count: 160, color: '#0284c7' },
          { name: 'Technical', count: 50, color: '#4f46e5' },
          { name: 'Administration', count: 27, color: '#059669' },
          { name: 'Others', count: 25, color: '#64748b' },
        ],
      };
    }

    // Dynamic user-added unit
    const u = selectedUnit;
    const b = selectedBranch;
    const baseCount = u?.capacity ? Math.round(u.capacity * 0.7) : 180;
    const pres = Math.round(baseCount * 0.925);
    const lv = Math.round(baseCount * 0.042);
    const ab = baseCount - pres - lv;

    return {
      unitNameDisplay: u ? `${u.name} (${u.code})` : 'Operating Unit',
      locationDisplay: u?.location || (b ? `${b.address}, ${b.city} - ${b.state}` : `${city || 'Operating Plant'}, ${state}`),
      unitTypeDisplay: u?.type || 'Operating Facility',
      totalEmployees: baseCount,
      presentToday: pres,
      onLeave: lv,
      absent: Math.max(1, ab),
      newJoining: 2,
      birthdayToday: 1,
      presentPct: 92.5,
      leavePct: 4.2,
      absentPct: 3.3,
      departmentBreakdown: [
        { name: 'Operations', count: Math.round(baseCount * 0.55), color: '#0284c7' },
        { name: 'Technical', count: Math.round(baseCount * 0.22), color: '#4f46e5' },
        { name: 'Administration', count: Math.round(baseCount * 0.13), color: '#059669' },
        { name: 'Others', count: Math.round(baseCount * 0.10), color: '#64748b' },
      ],
    };
  }, [selectedUnitId, selectedUnit, selectedBranch, city, state]);

  // Handle Save New Unit with Location
  const handleSaveNewUnit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!unitName.trim() || !unitCode.trim()) return;

    const unitId = `un-${unitCode.toLowerCase().replace(/[^a-z0-9]/g, '')}-${Date.now().toString().slice(-4)}`;
    const branchId = `br-${Date.now().toString().slice(-4)}`;

    const newBranch: Branch = {
      id: branchId,
      orgId: storeData.currentOrg.id,
      name: branchName.trim() || `${unitName} Location Hub`,
      code: `BR-${unitCode.toUpperCase()}`,
      city: city.trim() || 'Pune',
      state: state.trim() || 'Maharashtra',
      address: address.trim() || `Plot 10, Industrial Area, ${city || 'Pune'} - ${pincode}`,
      isHeadquarters: false,
    };

    const newUnit: Unit = {
      id: unitId,
      orgId: storeData.currentOrg.id,
      branchId: branchId,
      name: unitName.trim(),
      code: unitCode.trim().toUpperCase(),
      type: unitType,
      location: `${address || 'Industrial Area'}, ${city || 'Pune'}, ${state} - ${pincode}`,
      city: city.trim() || 'Pune',
      state: state.trim() || 'Maharashtra',
      address: address.trim(),
      pincode: pincode.trim(),
      capacity: Number(capacity) || 500,
      headPerson: headPerson.trim() || 'Unit General Manager',
      phone: phone.trim(),
      email: email.trim(),
    };

    if (onAddUnit) {
      onAddUnit(newUnit, newBranch);
    }

    if (onLogAudit) {
      onLogAudit('CREATE', 'Organization Master', `Created operating unit ${newUnit.name} (${newUnit.code}) located at ${newBranch.city}, ${newBranch.state}`);
    }

    // Auto-select newly added unit
    setSelectedUnitId(newUnit.id);
    setShowAddUnitModal(false);

    // Reset Form
    setUnitName('');
    setUnitCode('');
    setBranchName('');
    setCity('');
    setAddress('');
    setHeadPerson('');
    setEmail('');

    setToastMessage(`Operating Unit "${newUnit.name}" added successfully with location! Dashboard filtered to this unit.`);
    setTimeout(() => setToastMessage(null), 4500);
  };

  // Handle Quick Add Employee
  const handleSaveQuickEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!empFirstName.trim() || !empLastName.trim()) return;

    const newEmp: Employee = {
      id: `emp-${Date.now()}`,
      orgId: storeData.currentOrg.id,
      branchId: units.find(u => u.id === empUnitId)?.branchId || 'br-chakan',
      unitId: empUnitId,
      departmentId: empDeptId,
      designationId: designations[0]?.id || 'desig-001',
      employeeCode: empCodeInput.trim(),
      firstName: empFirstName.trim(),
      lastName: empLastName.trim(),
      email: empEmail.trim() || `${empFirstName.toLowerCase()}.${empLastName.toLowerCase()}@rstpl-tech.com`,
      phone: empPhone.trim(),
      dob: '1995-05-15',
      dateOfJoining: '2026-10-08',
      gender: 'Male',
      bloodGroup: 'O+',
      maritalStatus: 'Single',
      address: 'Plot 14, Sector 5, Pune - 410501',
      emergencyContact: {
        name: 'Suresh Kumar',
        relationship: 'Father',
        phone: '+91 98765 00000',
      },
      employmentType: 'Full-Time',
      status: 'Active',
      shiftId: 'shift-gen',
      grade: 'L3',
      pan: 'ABCDE1234F',
      aadhaarMasked: 'XXXX-XXXX-8921',
      uan: '100987654321',
      bankName: 'HDFC Bank Ltd.',
      bankAccountNumber: '50100456789012',
      ifscCode: 'HDFC0001234',
      ctcAnnual: empGrossSalary * 12,
      basicMonthly: Math.round(empGrossSalary * 0.5),
      hraMonthly: Math.round(empGrossSalary * 0.25),
      conveyanceMonthly: 1600,
      specialAllowanceMonthly: Math.max(0, empGrossSalary - (Math.round(empGrossSalary * 0.5) + Math.round(empGrossSalary * 0.25) + 1600)),
      pfApplicable: true,
      esicApplicable: empGrossSalary <= 21000,
      tdsMonthly: Math.round(empGrossSalary * 0.05),
      employerPfMonthly: Math.round(empGrossSalary * 0.5 * 0.12),
      employerEsicMonthly: empGrossSalary <= 21000 ? Math.round(empGrossSalary * 0.0325) : 0,
      pfEmployeeMonthly: Math.round(empGrossSalary * 0.5 * 0.12),
      esicEmployeeMonthly: empGrossSalary <= 21000 ? Math.round(empGrossSalary * 0.0075) : 0,
      professionalTaxMonthly: 200,
      netSalaryMonthly: Math.round(empGrossSalary * 0.85),
    };

    if (onAddEmployee) {
      onAddEmployee(newEmp);
    }

    if (onLogAudit) {
      onLogAudit('CREATE', 'Employee Master', `Quick onboarded employee ${newEmp.firstName} ${newEmp.lastName} (${newEmp.employeeCode})`);
    }

    setShowAddEmployeeModal(false);
    setEmpFirstName('');
    setEmpLastName('');
    setEmpCodeInput(`EMP-${Math.floor(1000 + Math.random() * 9000)}`);

    setToastMessage(`Employee ${newEmp.firstName} ${newEmp.lastName} (${newEmp.employeeCode}) created successfully!`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Handle Apply Leave
  const handleSaveApplyLeave = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find(e => e.id === leaveEmpId) || employees[0];
    const newReq = {
      id: `leave-${Date.now()}`,
      employeeName: `${emp.firstName} ${emp.lastName}`,
      employeeCode: emp.employeeCode,
      department: departments.find(d => d.id === emp.departmentId)?.name || 'Operations',
      leaveType: `${leaveType} Leave`,
      startDate: leaveStartDate,
      endDate: leaveEndDate,
      days: 3,
      reason: leaveReason,
      status: 'Pending' as const,
    };

    setLocalPendingLeaves(prev => [newReq, ...prev]);

    if (onLogAudit) {
      onLogAudit('CREATE', 'Leave Management', `Submitted ${leaveType} Leave request for ${emp.employeeCode}`);
    }

    setShowApplyLeaveModal(false);
    setToastMessage(`Leave application submitted for ${emp.firstName} ${emp.lastName}! Pending manager approval.`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Handle Mark Attendance
  const handleSavePunch = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find(e => e.id === punchEmpId) || employees[0];
    const targetUnit = units.find(u => u.id === punchUnitId) || units[0];

    if (onLogAudit) {
      onLogAudit('SYNC', 'Daily Attendance', `Recorded ${punchType} punch for ${emp.employeeCode} at ${targetUnit.name} terminal`);
    }

    setShowMarkAttendanceModal(false);
    setToastMessage(`Attendance ${punchType} captured successfully for ${emp.firstName} ${emp.lastName} at ${currentTimeStr}!`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Handle Generate Report Download
  const handleExportQuickReport = () => {
    const reportHeaders = ['S.No', 'Employee Code', 'Employee Name', 'Unit', 'Department', 'Designation', 'Status', 'Attendance Ratio'];
    const rows = employees.map((emp, idx) => {
      const u = units.find(unit => unit.id === emp.unitId);
      const d = departments.find(dept => dept.id === emp.departmentId);
      return [
        idx + 1,
        emp.employeeCode,
        `"${emp.firstName} ${emp.lastName}"`,
        `"${u?.name || unitMetrics.unitNameDisplay}"`,
        `"${d?.name || 'Operations'}"`,
        `"${emp.designationId || 'Specialist'}"`,
        emp.status,
        '96.5%',
      ].join(',');
    });

    const csvContent = [reportHeaders.join(','), ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RSTPL_${reportType.toUpperCase()}_Report_${selectedUnitId}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    if (onLogAudit) {
      onLogAudit('EXPORT', 'Reports Module', `Generated and downloaded ${reportType} report for ${unitMetrics.unitNameDisplay}`);
    }

    setShowReportModal(false);
    setToastMessage(`Report "${reportType.toUpperCase()}" generated & downloaded successfully!`);
    setTimeout(() => setToastMessage(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="p-4 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center justify-between shadow-lg animate-in fade-in transition-all">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            <span>{toastMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setToastMessage(null)}
            className="p-1 hover:bg-white/20 rounded cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* TOP HEADER CONTROLS: UNIT SELECTOR, FINANCIAL YEAR, DATE & ADMIN ROLE */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="p-2 rounded-xl bg-sky-100 text-sky-800 border border-sky-200">
                <Building2 className="w-5 h-5 text-sky-700" />
              </span>
              <div>
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-slate-900 text-white">
                    CodeTech HRMS
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-sky-100 text-sky-900 border border-sky-200">
                    RSTPL
                  </span>
                  <span className="text-[10px] text-amber-600 font-bold hidden sm:inline">
                    ⚡ Power by RS TechnoVisions XpertSkillCop
                  </span>
                </div>
                <h1 className="text-base font-black text-slate-900 tracking-tight flex items-center gap-2 flex-wrap">
                  Smart HR Solutions for a Brighter Tomorrow
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                    Live Operations
                  </span>
                </h1>
                <p className="text-xs text-slate-500 font-medium">
                  RSTPL: Innovate · Integrate · Transform | Dynamic multi-unit workforce analytics, animated KPIs & geofence perimeter telemetry
                </p>
              </div>
            </div>
          </div>

          {/* Interactive Unit Selector & Header Metadata Controls */}
          <div className="flex flex-wrap items-center gap-2.5 text-xs">
            {/* Unit Name Selector with Add Unit Action */}
            <div className="flex items-center gap-1.5 bg-slate-50 p-1.5 rounded-xl border border-slate-200 shadow-2xs">
              <span className="font-bold text-slate-700 whitespace-nowrap pl-1 text-[11px]">Unit Name:</span>
              <select
                value={selectedUnitId}
                onChange={e => setSelectedUnitId(e.target.value)}
                className="bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-bold text-sky-950 focus:outline-hidden focus:ring-2 focus:ring-sky-500 shadow-2xs cursor-pointer max-w-xs truncate"
                title="Filter entire dashboard by operating unit or select Whole Organization"
              >
                <option value="ALL">🏢 [ All Units - Whole Enterprise ]</option>
                {units.map(u => (
                  <option key={u.id} value={u.id}>
                    📍 {u.name} ({u.code})
                  </option>
                ))}
              </select>

              {/* Add Unit Button */}
              <button
                type="button"
                onClick={() => setShowAddUnitModal(true)}
                className="px-2.5 py-1 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold transition shadow-xs flex items-center gap-1 cursor-pointer whitespace-nowrap"
                title="Add new manufacturing plant or operating unit with physical location"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add Unit</span>
              </button>
            </div>

            {/* Financial Year Selector */}
            <div className="flex items-center gap-1 bg-slate-50 p-1.5 rounded-xl border border-slate-200 shadow-2xs">
              <Calendar className="w-3.5 h-3.5 text-slate-500 ml-1" />
              <span className="font-bold text-slate-600 text-[11px]">FY:</span>
              <select
                value={selectedFY}
                onChange={e => setSelectedFY(e.target.value)}
                className="bg-white border border-slate-300 rounded-lg px-2 py-0.5 text-xs font-bold text-slate-800 cursor-pointer focus:outline-hidden"
              >
                <option value="2026–27">2026–27</option>
                <option value="2025–26">2025–26</option>
                <option value="2024–25">2024–25</option>
              </select>
            </div>

            {/* Live Date & Digital Clock Pill */}
            <div className="px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 font-mono font-bold text-slate-800 flex items-center gap-1.5 shadow-2xs">
              <Clock className="w-3.5 h-3.5 text-sky-700" />
              <span>08-Oct-2026</span>
              <span className="text-[10px] text-slate-400">|</span>
              <span className="text-sky-800 text-[11px]">{currentTimeStr}</span>
            </div>

            {/* Admin / HR Role Indicator & Switcher */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 text-white font-bold shadow-2xs">
              <span className="text-[11px] whitespace-nowrap">👤 Admin / HR</span>
              {onRoleChange && (
                <select
                  value={currentRole}
                  onChange={e => onRoleChange(e.target.value as any)}
                  className="bg-slate-800 text-white text-[11px] font-semibold rounded px-1.5 py-0.5 border border-slate-700 cursor-pointer ml-1"
                >
                  <option value="hr_head">Admin / HR</option>
                  <option value="super_admin">Super Admin</option>
                  <option value="manager">Manager</option>
                  <option value="employee">Employee</option>
                </select>
              )}
            </div>
          </div>
        </div>

        {/* Selected Unit Physical Location Ribbon */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="p-1 rounded-md bg-amber-50 text-amber-700 border border-amber-200">
              <MapPin className="w-3.5 h-3.5" />
            </span>
            <span className="font-bold text-slate-900">{unitMetrics.unitNameDisplay}:</span>
            <span className="text-slate-600 font-medium">{unitMetrics.locationDisplay}</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700 font-mono">
              {unitMetrics.unitTypeDisplay}
            </span>
            {selectedUnitId !== 'ALL' && (
              <button
                type="button"
                onClick={() => setSelectedUnitId('ALL')}
                className="text-[11px] font-bold text-sky-700 hover:underline cursor-pointer"
              >
                Reset to All Units ✕
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 📊 MAIN DASHBOARD: 6 ANIMATED KPI MODULE CARDS (Module Display) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-sky-700" />
            <h2 className="text-xs font-black uppercase text-slate-900 tracking-wider">
              📊 Main Dashboard – Module Display ({unitMetrics.unitNameDisplay})
            </h2>
          </div>
          <span className="text-[11px] text-slate-400">Click any card to open full details or action drawer</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* KPI 1: 👥 Total Employees */}
          <div
            onClick={() => onNavigate('employees')}
            className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:shadow-md hover:border-sky-300 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="p-2 rounded-xl bg-sky-50 text-sky-700 group-hover:bg-sky-600 group-hover:text-white transition-colors">
                  <Users className="w-4 h-4" />
                </span>
                <span className="text-[10px] font-bold text-slate-400 font-mono">Module</span>
              </div>
              <span className="text-[11px] font-bold text-slate-500 block">👥 Total Employees</span>
              <p className="text-2xl font-black text-slate-900 mt-1 font-mono tracking-tight">
                {unitMetrics.totalEmployees.toLocaleString()}
              </p>
            </div>
            <span className="text-[10px] text-sky-700 font-bold block mt-2 group-hover:underline">
              Employee Master ➔
            </span>
          </div>

          {/* KPI 2: 🟢 Present Today */}
          <div
            onClick={() => onNavigate('attendance')}
            className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:shadow-md hover:border-emerald-300 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="p-2 rounded-xl bg-emerald-50 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                  <UserCheck className="w-4 h-4" />
                </span>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800 font-mono">
                  {unitMetrics.presentPct}%
                </span>
              </div>
              <span className="text-[11px] font-bold text-slate-500 block">🟢 Present Today</span>
              <p className="text-2xl font-black text-emerald-700 mt-1 font-mono tracking-tight">
                {unitMetrics.presentToday.toLocaleString()}
              </p>
            </div>
            <span className="text-[10px] text-emerald-700 font-bold block mt-2 group-hover:underline">
              Daily Attendance ➔
            </span>
          </div>

          {/* KPI 3: 🔴 On Leave */}
          <div
            onClick={() => setShowApproveLeaveModal(true)}
            className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:shadow-md hover:border-rose-300 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="p-2 rounded-xl bg-rose-50 text-rose-700 group-hover:bg-rose-600 group-hover:text-white transition-colors">
                  <Calendar className="w-4 h-4" />
                </span>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-100 text-rose-800 font-mono">
                  {unitMetrics.leavePct}%
                </span>
              </div>
              <span className="text-[11px] font-bold text-slate-500 block">🔴 On Leave</span>
              <p className="text-2xl font-black text-rose-700 mt-1 font-mono tracking-tight">
                {unitMetrics.onLeave}
              </p>
            </div>
            <span className="text-[10px] text-rose-700 font-bold block mt-2 group-hover:underline">
              Review Approvals ➔
            </span>
          </div>

          {/* KPI 4: 🟠 Absent */}
          <div
            onClick={() => onNavigate('attendance')}
            className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:shadow-md hover:border-amber-300 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="p-2 rounded-xl bg-amber-50 text-amber-700 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                  <Clock className="w-4 h-4" />
                </span>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-100 text-amber-800 font-mono">
                  {unitMetrics.absentPct}%
                </span>
              </div>
              <span className="text-[11px] font-bold text-slate-500 block">🟠 Absent</span>
              <p className="text-2xl font-black text-amber-700 mt-1 font-mono tracking-tight">
                {unitMetrics.absent}
              </p>
            </div>
            <span className="text-[10px] text-amber-700 font-bold block mt-2 group-hover:underline">
              Late/Absent Report ➔
            </span>
          </div>

          {/* KPI 5: 🆕 New Joining */}
          <div
            onClick={() => setShowNewJoineesModal(true)}
            className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:shadow-md hover:border-purple-300 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="p-2 rounded-xl bg-purple-50 text-purple-700 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                  <UserPlus className="w-4 h-4" />
                </span>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-purple-100 text-purple-800">
                  Oct 2026
                </span>
              </div>
              <span className="text-[11px] font-bold text-slate-500 block">🆕 New Joining</span>
              <p className="text-2xl font-black text-purple-800 mt-1 font-mono tracking-tight">
                {unitMetrics.newJoining}
              </p>
            </div>
            <span className="text-[10px] text-purple-700 font-bold block mt-2 group-hover:underline">
              View Joinees ➔
            </span>
          </div>

          {/* KPI 6: 🎂 Birthday Today */}
          <div
            onClick={() => setShowBirthdaysModal(true)}
            className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:shadow-md hover:border-pink-300 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="p-2 rounded-xl bg-pink-50 text-pink-700 group-hover:bg-pink-600 group-hover:text-white transition-colors">
                  <Cake className="w-4 h-4" />
                </span>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-pink-100 text-pink-800">
                  08-Oct
                </span>
              </div>
              <span className="text-[11px] font-bold text-slate-500 block">🎂 Birthday Today</span>
              <p className="text-2xl font-black text-pink-700 mt-1 font-mono tracking-tight">
                0{unitMetrics.birthdayToday}
              </p>
            </div>
            <span className="text-[10px] text-pink-700 font-bold block mt-2 group-hover:underline">
              Send Wishes 🎉 ➔
            </span>
          </div>
        </div>
      </div>

      {/* QUICK ACTIONS BAR */}
      <div className="bg-slate-900 text-white p-4 rounded-2xl shadow-md border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-black uppercase tracking-wider text-slate-200">
            Quick Actions
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <button
            type="button"
            onClick={() => setShowAddEmployeeModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Add Employee</span>
          </button>

          <button
            type="button"
            onClick={() => setShowApplyLeaveModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 font-bold transition cursor-pointer flex items-center gap-1.5"
          >
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span>Apply Leave</span>
          </button>

          <button
            type="button"
            onClick={() => setShowApproveLeaveModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 font-bold transition cursor-pointer flex items-center gap-1.5"
          >
            <CheckSquare className="w-3.5 h-3.5 text-emerald-400" />
            <span>Approve Leave ({localPendingLeaves.filter(l => l.status === 'Pending').length})</span>
          </button>

          <button
            type="button"
            onClick={() => setShowMarkAttendanceModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 font-bold transition cursor-pointer flex items-center gap-1.5"
          >
            <Clock className="w-3.5 h-3.5 text-sky-400" />
            <span>Mark Attendance</span>
          </button>

          <button
            type="button"
            onClick={() => setShowReportModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 font-bold transition flex items-center gap-1.5 cursor-pointer"
          >
            <FileDown className="w-3.5 h-3.5 text-purple-400" />
            <span>Generate Report</span>
          </button>

          <button
            type="button"
            onClick={() => setShowAddUnitModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black transition flex items-center gap-1.5 cursor-pointer shadow-xs ml-auto md:ml-0"
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>+ Add Unit with Location</span>
          </button>
        </div>
      </div>

      {/* ATTENDANCE VISUALIZATION BAR & DEPARTMENT-WISE EMPLOYEES BREAKDOWN */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Attendance Visualization Progress Bar (5 Columns) */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
                  <CheckSquare className="w-4 h-4" />
                </span>
                <h3 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                  Attendance Visualization
                </h3>
              </div>
              <span className="text-[10px] font-mono font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-700">
                {unitMetrics.totalEmployees} Employees
              </span>
            </div>

            {/* Attendance Text Diagram & Graphic Bars (Matching prompt specification) */}
            <div className="space-y-4 mt-4 text-xs font-mono">
              {/* Present: 92.6% */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    <span>Present</span>
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[11px]">████████████████████</span>
                    <strong className="text-emerald-700 font-bold">{unitMetrics.presentPct}%</strong>
                  </div>
                </div>
                <div className="w-full h-3.5 bg-slate-100 rounded-full overflow-hidden shadow-inner">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500 shadow-xs"
                    style={{ width: `${unitMetrics.presentPct}%` }}
                  />
                </div>
                <span className="text-[10px] text-slate-500 block mt-1 font-sans">
                  {unitMetrics.presentToday.toLocaleString()} employees active on shift today
                </span>
              </div>

              {/* Leave: 4.2% */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                    <span>Leave</span>
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[11px]">█</span>
                    <strong className="text-rose-700 font-bold">{unitMetrics.leavePct}%</strong>
                  </div>
                </div>
                <div className="w-full h-3.5 bg-slate-100 rounded-full overflow-hidden shadow-inner">
                  <div
                    className="h-full bg-gradient-to-r from-rose-500 to-pink-500 rounded-full transition-all duration-500 shadow-xs"
                    style={{ width: `${Math.max(4, unitMetrics.leavePct * 2)}%` }}
                  />
                </div>
                <span className="text-[10px] text-slate-500 block mt-1 font-sans">
                  {unitMetrics.onLeave} employees on approved leave today
                </span>
              </div>

              {/* Absent: 3.2% */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    <span>Absent</span>
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[11px]">██</span>
                    <strong className="text-amber-700 font-bold">{unitMetrics.absentPct}%</strong>
                  </div>
                </div>
                <div className="w-full h-3.5 bg-slate-100 rounded-full overflow-hidden shadow-inner">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all duration-500 shadow-xs"
                    style={{ width: `${Math.max(3, unitMetrics.absentPct * 2)}%` }}
                  />
                </div>
                <span className="text-[10px] text-slate-500 block mt-1 font-sans">
                  {unitMetrics.absent} employees unexcused / biometric missed
                </span>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>Corporate Compliance SLA</span>
            <span className="font-bold text-emerald-700 flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              <span>Optimal Performance (Above 90% Benchmark)</span>
            </span>
          </div>
        </div>

        {/* Right: Department-Wise Employees Breakdown Table (7 Columns) */}
        <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-sky-50 text-sky-700">
                <Layers className="w-4 h-4" />
              </span>
              <div>
                <h3 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                  Department-Wise Employees Breakdown
                </h3>
                <p className="text-[11px] text-slate-500">Functional workforce allocation in {unitMetrics.unitNameDisplay}</p>
              </div>
            </div>
            <span className="text-[10px] font-mono font-bold bg-sky-50 text-sky-800 px-2 py-0.5 rounded border border-sky-200">
              Total {unitMetrics.totalEmployees.toLocaleString()} Personnel
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-100">
                <tr>
                  <th className="py-2.5 px-3">Department</th>
                  <th className="py-2.5 px-3 text-right">Employees</th>
                  <th className="py-2.5 px-3 text-right">Share %</th>
                  <th className="py-2.5 px-3 min-w-36">Visual Breakdown</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {unitMetrics.departmentBreakdown.map((dept, idx) => {
                  const sharePct = ((dept.count / unitMetrics.totalEmployees) * 100).toFixed(1);
                  return (
                    <tr
                      key={idx}
                      onClick={() => onNavigate('employees')}
                      className="hover:bg-slate-50 transition-colors cursor-pointer group"
                      title={`Click to filter Employee Master by ${dept.name}`}
                    >
                      <td className="py-2 px-3 font-bold text-slate-900 flex items-center gap-2 group-hover:text-sky-700">
                        <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: dept.color }} />
                        <span>{dept.name}</span>
                      </td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-slate-800">
                        {dept.count.toLocaleString()}
                      </td>
                      <td className="py-2 px-3 text-right font-mono text-slate-500 font-semibold">
                        {sharePct}%
                      </td>
                      <td className="py-2 px-3">
                        <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-300"
                            style={{
                              width: `${sharePct}%`,
                              backgroundColor: dept.color,
                            }}
                          />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 📊 DYNAMIC WORKFORCE TELEMETRY & GRAPHICAL OPERATIONS SUITE */}
      <div className="space-y-6">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-slate-900 via-sky-950 to-indigo-950 p-5 rounded-3xl text-white shadow-xl border border-sky-800/40">
          <div className="flex items-center gap-3">
            <span className="p-2.5 rounded-2xl bg-sky-500/20 text-sky-300 border border-sky-400/30">
              <Activity className="w-5 h-5 text-sky-400 animate-pulse" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black uppercase tracking-wider text-white">
                  Dynamic Workforce Telemetry & Graphic Analytics Suite
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Live Stream
                </span>
              </div>
              <p className="text-xs text-sky-200/80 mt-0.5">
                Real-time punch velocity curve, presence distribution radar & department-wise graphical density
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-sky-300 font-mono">Unit: {unitMetrics.unitNameDisplay}</span>
            <button
              onClick={() => onNavigate('attendance')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-all shadow-sm cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Live Telemetry</span>
            </button>
          </div>
        </div>

        {/* Dynamic Graphic Charts Row 1: Punch Velocity & Attendance Donut */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Graphic Card 1: 24h Real-Time Punch Velocity & Shift Ingest Dynamics */}
          <div className="lg:col-span-7 bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4 flex flex-col justify-between">
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
                    <TrendingUp className="w-4 h-4 text-sky-700" />
                  </span>
                  <div>
                    <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                      Biometric & Mobile GEO Punch Velocity Curve
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      Real-time ingress & egress punch frequency across 24h shifts
                    </p>
                  </div>
                </div>

                {/* Timeframe Filter Buttons */}
                <div className="flex items-center rounded-xl bg-slate-100 p-0.5 border border-slate-200 self-start sm:self-auto text-[10px] font-bold">
                  <button
                    onClick={() => setPunchTimeframe('all')}
                    className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                      punchTimeframe === 'all' ? 'bg-white text-sky-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    24h Full Cycle
                  </button>
                  <button
                    onClick={() => setPunchTimeframe('peak')}
                    className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                      punchTimeframe === 'peak' ? 'bg-white text-sky-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Morning Rush (06–11h)
                  </button>
                  <button
                    onClick={() => setPunchTimeframe('egress')}
                    className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                      punchTimeframe === 'egress' ? 'bg-white text-sky-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Egress (14–22h)
                  </button>
                </div>
              </div>

              {/* Live Area Chart */}
              <div className="h-64 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={(() => {
                      const base = [
                        { time: '06:00', inPunches: 145, outPunches: 18, geoPunches: 12 },
                        { time: '07:30', inPunches: 260, outPunches: 22, geoPunches: 28 },
                        { time: '08:30', inPunches: 510, outPunches: 12, geoPunches: 54 },
                        { time: '09:00', inPunches: 620, outPunches: 10, geoPunches: 85 },
                        { time: '10:00', inPunches: 180, outPunches: 25, geoPunches: 42 },
                        { time: '12:30', inPunches: 45, outPunches: 75, geoPunches: 30 },
                        { time: '14:30', inPunches: 290, outPunches: 275, geoPunches: 38 },
                        { time: '17:00', inPunches: 35, outPunches: 320, geoPunches: 44 },
                        { time: '18:15', inPunches: 20, outPunches: 530, geoPunches: 32 },
                        { time: '22:00', inPunches: 195, outPunches: 250, geoPunches: 18 },
                      ];
                      if (punchTimeframe === 'peak') return base.slice(0, 5);
                      if (punchTimeframe === 'egress') return base.slice(5);
                      return base;
                    })()}
                    margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorInPunches" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0} />
                      </linearGradient>
                      <linearGradient id="colorOutPunches" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                      </linearGradient>
                      <linearGradient id="colorGeoPunches" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={{ stroke: '#cbd5e1' }} />
                    <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={{ stroke: '#cbd5e1' }} />
                    <Tooltip
                      content={({ active, payload, label }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="bg-slate-900 text-white p-3 rounded-2xl shadow-xl text-xs space-y-1.5 border border-slate-700">
                              <div className="font-bold text-sky-300 font-mono">Time: {label}</div>
                              <div className="flex items-center justify-between gap-4">
                                <span className="text-sky-400">IN Punches:</span>
                                <span className="font-bold">{payload[0]?.value}</span>
                              </div>
                              <div className="flex items-center justify-between gap-4">
                                <span className="text-amber-400">OUT Punches:</span>
                                <span className="font-bold">{payload[1]?.value}</span>
                              </div>
                              <div className="flex items-center justify-between gap-4">
                                <span className="text-emerald-400">GEO Mobile:</span>
                                <span className="font-bold">{payload[2]?.value}</span>
                              </div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Area type="monotone" dataKey="inPunches" stroke="#0284c7" strokeWidth={2.5} fillOpacity={1} fill="url(#colorInPunches)" name="IN Punches" />
                    <Area type="monotone" dataKey="outPunches" stroke="#f59e0b" strokeWidth={2} fillOpacity={1} fill="url(#colorOutPunches)" name="OUT Punches" />
                    <Area type="monotone" dataKey="geoPunches" stroke="#10b981" strokeWidth={1.5} fillOpacity={1} fill="url(#colorGeoPunches)" name="GEO Mobile" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Live Telemetry Chips */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-100 text-[11px]">
              <div className="p-2.5 rounded-xl bg-sky-50 border border-sky-100">
                <span className="text-slate-500 block text-[10px]">Peak Ingress Velocity</span>
                <strong className="text-sky-800 text-sm font-mono">620 / hr</strong>
                <span className="text-[9px] text-slate-400 block">@ 09:00 AM General Shift</span>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100">
                <span className="text-slate-500 block text-[10px]">Biometric IoT Terminal</span>
                <strong className="text-emerald-800 text-sm font-mono">85.4%</strong>
                <span className="text-[9px] text-slate-400 block">TCP/IP Hardware Share</span>
              </div>
              <div className="p-2.5 rounded-xl bg-indigo-50 border border-indigo-100">
                <span className="text-slate-500 block text-[10px]">Remote Mobile GEO</span>
                <strong className="text-indigo-800 text-sm font-mono">14.6%</strong>
                <span className="text-[9px] text-slate-400 block">GPS Field Workers</span>
              </div>
              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-100">
                <span className="text-slate-500 block text-[10px]">Average Ping Latency</span>
                <strong className="text-amber-800 text-sm font-mono">24 ms</strong>
                <span className="text-[9px] text-slate-400 block">All 4 Terminals Active</span>
              </div>
            </div>
          </div>

          {/* Graphic Card 2: Attendance Presence Composition Donut Visualizer */}
          <div className="lg:col-span-5 bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
                    <CheckSquare className="w-4 h-4 text-emerald-700" />
                  </span>
                  <div>
                    <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                      Workforce Presence Composition
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      Real-time presence vs. absence breakdown
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">
                  {unitMetrics.presentPct}% Present
                </span>
              </div>

              {/* Donut Chart with Center KPI */}
              <div className="relative h-60 w-full flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Present On-Time', value: unitMetrics.presentToday, color: '#10b981' },
                        { name: 'Approved Leave', value: unitMetrics.onLeave, color: '#f59e0b' },
                        { name: 'Absent / Unpunched', value: unitMetrics.absent, color: '#ef4444' },
                        { name: 'Remote Field (GEO)', value: 24, color: '#0284c7' },
                      ]}
                      innerRadius={65}
                      outerRadius={92}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {[
                        { color: '#10b981' },
                        { color: '#f59e0b' },
                        { color: '#ef4444' },
                        { color: '#0284c7' },
                      ].map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0];
                          return (
                            <div className="bg-slate-900 text-white p-2.5 rounded-xl text-xs shadow-xl border border-slate-700">
                              <span className="font-bold">{data.name}: </span>
                              <span className="font-mono text-emerald-300 font-bold">{data.value} Personnel</span>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>

                {/* Center Label */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-2xl font-black text-slate-900 tracking-tight">
                    {unitMetrics.presentPct}%
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600">
                    Present Today
                  </span>
                </div>
              </div>
            </div>

            {/* Legend Chips with Counts */}
            <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
              <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-50/70 border border-emerald-100">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="font-bold text-slate-800">Present On-Time</span>
                </div>
                <div className="font-mono font-bold text-emerald-700">
                  {unitMetrics.presentToday} <span className="text-[10px] text-slate-400">({unitMetrics.presentPct}%)</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-2 rounded-xl bg-amber-50/70 border border-amber-100">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <span className="font-bold text-slate-800">Approved Leave (CL/SL/EL)</span>
                </div>
                <div className="font-mono font-bold text-amber-700">
                  {unitMetrics.onLeave} <span className="text-[10px] text-slate-400">({unitMetrics.leavePct}%)</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-2 rounded-xl bg-rose-50/70 border border-rose-100">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <span className="font-bold text-slate-800">Absent / Missing In-Punch</span>
                </div>
                <div className="font-mono font-bold text-rose-700">
                  {unitMetrics.absent} <span className="text-[10px] text-slate-400">({unitMetrics.absentPct}%)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Graphic Charts Row 2: Department Density Bar Chart & Multi-Unit Radar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Department Density Graphical Bar Chart */}
          <div className="lg:col-span-7 bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-purple-100 text-purple-800">
                  <BarChart3 className="w-4 h-4 text-purple-700" />
                </span>
                <div>
                  <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                    Department Workforce Density & Presence Volume
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Comparative personnel strength across company divisions
                  </p>
                </div>
              </div>

              <button
                onClick={() => onNavigate('organization')}
                className="text-xs text-sky-700 font-bold hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Org Chart</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Department Bar Chart */}
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={unitMetrics.departmentBreakdown.map(d => ({
                    name: d.name,
                    Total: d.count,
                    Present: Math.round(d.count * (unitMetrics.presentPct / 100)),
                    color: d.color,
                  }))}
                  margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={{ stroke: '#cbd5e1' }} />
                  <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={{ stroke: '#cbd5e1' }} />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-slate-900 text-white p-3 rounded-2xl shadow-xl text-xs space-y-1 border border-slate-700">
                            <div className="font-bold text-sky-300">{label} Department</div>
                            <div className="flex items-center justify-between gap-4">
                              <span className="text-slate-300">Total Enrolled:</span>
                              <span className="font-bold font-mono">{payload[0]?.value}</span>
                            </div>
                            <div className="flex items-center justify-between gap-4">
                              <span className="text-emerald-400">Present Today:</span>
                              <span className="font-bold font-mono">{payload[1]?.value}</span>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="Total" fill="#0284c7" radius={[6, 6, 0, 0]} name="Total Enrolled" />
                  <Bar dataKey="Present" fill="#10b981" radius={[6, 6, 0, 0]} name="Present Today" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs text-slate-500">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1.5 font-semibold text-sky-700">
                  <span className="w-3 h-3 rounded bg-sky-600 inline-block" /> Total Headcount
                </span>
                <span className="flex items-center gap-1.5 font-semibold text-emerald-700">
                  <span className="w-3 h-3 rounded bg-emerald-500 inline-block" /> Present Staff
                </span>
              </div>
              <div className="text-[11px] text-slate-400">
                Highest density: <strong>Operations (425 personnel)</strong>
              </div>
            </div>
          </div>

          {/* Operating Unit Telemetry & Location Health Cards */}
          <div className="lg:col-span-5 bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
                    <Building className="w-4 h-4 text-sky-700" />
                  </span>
                  <div>
                    <h4 className="text-xs font-black uppercase text-slate-900 tracking-wider">
                      Operating Units & Plant Telemetry
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      Geographic distribution & active facility presence
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setShowAddUnitModal(true)}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 text-[11px] font-bold border border-sky-200 transition cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                  <span>+ Add Unit</span>
                </button>
              </div>

              {/* Units List Cards */}
              <div className="space-y-2.5 pt-1">
                {storeData.units.map((u) => {
                  const unitCap = u.capacity || 500;
                  const unitStaff = Math.round(unitMetrics.totalEmployees * (u.type === 'Corporate' ? 0.25 : u.type === 'Manufacturing Plant' ? 0.35 : 0.20));
                  const capPct = Math.min(100, Math.round((unitStaff / unitCap) * 100));

                  return (
                    <div
                      key={u.id}
                      onClick={() => setSelectedUnitId(u.id)}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer ${
                        selectedUnitId === u.id
                          ? 'border-sky-500 bg-sky-50/60 shadow-xs'
                          : 'border-slate-200 hover:border-slate-300 bg-slate-50/40 hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                          <span className="font-bold text-slate-900 text-xs">{u.name}</span>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase bg-slate-200 text-slate-700 font-mono">
                          {u.code}
                        </span>
                      </div>

                      <div className="text-[11px] text-slate-500 truncate mb-2">
                        {u.location || `${u.city}, ${u.state}`}
                      </div>

                      {/* Capacity Progress Bar */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] text-slate-500">
                          <span>Staff: <strong className="text-slate-800">{unitStaff}</strong> / {unitCap}</span>
                          <span className="font-bold text-emerald-700">92.6% Present</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-sky-500 to-emerald-500 rounded-full"
                            style={{ width: `${capPct}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>All 4 facilities synchronized with IoT telemetry</span>
              <button
                onClick={() => setSelectedUnitId('ALL')}
                className="text-sky-700 font-bold hover:underline cursor-pointer"
              >
                View Whole Enterprise →
              </button>
            </div>
          </div>
        </div>

        {/* 🚀 DYNAMIC EXECUTIVE WORKFLOW COMMAND MATRIX (Replaces the static ASCII tree lists with high-tech tiles) */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-slate-900 text-white">
                <Compass className="w-4 h-4 text-sky-400" />
              </span>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-slate-900">
                  Interactive Executive Command Hubs & Workflows
                </h3>
                <p className="text-xs text-slate-500">
                  One-click operational triggers, modal launchers, and domain gateways
                </p>
              </div>
            </div>
            <span className="text-[11px] text-slate-400">6 Connected Enterprise Modules</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Command Tile 1: 👥 Workforce & Lifecycle Studio */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4 hover:border-sky-400 transition-all group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="p-2 rounded-2xl bg-sky-100 text-sky-800 group-hover:bg-sky-600 group-hover:text-white transition-colors">
                      <Users className="w-5 h-5 text-sky-700 group-hover:text-white" />
                    </span>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                        Workforce & Lifecycle
                      </h4>
                      <p className="text-[10px] text-slate-400">Directory, Dossiers & Joinees</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-sky-100 text-sky-800 font-mono">
                    {unitMetrics.totalEmployees} Active
                  </span>
                </div>

                {/* Action Buttons Grid */}
                <div className="space-y-2 pt-3 text-xs">
                  <button
                    onClick={() => onNavigate('employees')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-sky-50 hover:text-sky-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-sky-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-sky-600" />
                      <span>Employee Master Register</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  <button
                    onClick={() => setShowAddEmployeeModal(true)}
                    className="w-full text-left p-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold flex items-center justify-between transition shadow-xs cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <UserPlus className="w-4 h-4" />
                      <span>+ Onboard New Employee (Modal)</span>
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setShowNewJoineesModal(true)}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 font-semibold flex items-center justify-between transition border border-slate-100 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      <span>Recent Joinees (+{unitMetrics.newJoining})</span>
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-100 text-amber-800 font-mono">New</span>
                  </button>

                  <button
                    onClick={() => setShowBirthdaysModal(true)}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 font-semibold flex items-center justify-between transition border border-slate-100 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Cake className="w-4 h-4 text-rose-500" />
                      <span>Today's Birthdays (0{unitMetrics.birthdayToday})</span>
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-rose-100 text-rose-800 font-mono">Today</span>
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Relieving & Clearance Workflows</span>
                <button onClick={() => onNavigate('exit')} className="text-sky-700 font-bold hover:underline cursor-pointer">
                  Exit Portal →
                </button>
              </div>
            </div>

            {/* Command Tile 2: 🕒 Time, Biometric & Roster Hub */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4 hover:border-emerald-400 transition-all group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="p-2 rounded-2xl bg-emerald-100 text-emerald-800 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                      <Clock className="w-5 h-5 text-emerald-700 group-hover:text-white" />
                    </span>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                        Time & Attendance Hub
                      </h4>
                      <p className="text-[10px] text-slate-400">Biometric, Rosters & GEO</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 font-mono">
                    92.6% Present
                  </span>
                </div>

                <div className="space-y-2 pt-3 text-xs">
                  <button
                    onClick={() => onNavigate('attendance')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50 hover:text-emerald-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-emerald-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-emerald-600" />
                      <span>Daily Attendance Register</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  <button
                    onClick={() => onNavigate('shifts')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50 hover:text-emerald-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-emerald-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Layers className="w-4 h-4 text-sky-600" />
                      <span>Shifts & Rosters Matrix</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  <button
                    onClick={() => onNavigate('biometric')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50 hover:text-emerald-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-emerald-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Fingerprint className="w-4 h-4 text-indigo-600" />
                      <span>Biometric Integration Studio</span>
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800 font-mono">Live</span>
                  </button>

                  <button
                    onClick={() => onNavigate('geofence')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-indigo-50 hover:text-indigo-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-indigo-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Radio className="w-4 h-4 text-emerald-500 animate-pulse" />
                      <span>AI Geofencing Monitor</span>
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-indigo-100 text-indigo-800 font-mono">Radar</span>
                  </button>

                  <button
                    onClick={() => setShowMarkAttendanceModal(true)}
                    className="w-full text-left p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center justify-between transition shadow-xs cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Check className="w-4 h-4" />
                      <span>Mark Attendance (Punch Simulator)</span>
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Audit Lock & Finalization</span>
                <button onClick={() => onNavigate('finalization')} className="text-emerald-700 font-bold hover:underline cursor-pointer">
                  Lock Register →
                </button>
              </div>
            </div>

            {/* Command Tile 3: 🌴 Leave & Absence Command Hub */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4 hover:border-amber-400 transition-all group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="p-2 rounded-2xl bg-amber-100 text-amber-800 group-hover:bg-amber-500 group-hover:text-white transition-colors">
                      <Calendar className="w-5 h-5 text-amber-700 group-hover:text-white" />
                    </span>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                        Leave Management Hub
                      </h4>
                      <p className="text-[10px] text-slate-400">Applications, Quotas & Approvals</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-800 font-mono">
                    3 Pending
                  </span>
                </div>

                <div className="space-y-2 pt-3 text-xs">
                  <button
                    onClick={() => setShowApplyLeaveModal(true)}
                    className="w-full text-left p-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold flex items-center justify-between transition shadow-xs cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Plus className="w-4 h-4" />
                      <span>Apply Leave Application (Modal)</span>
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setShowApproveLeaveModal(true)}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-amber-50 hover:text-amber-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-amber-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <CheckSquare className="w-4 h-4 text-amber-600" />
                      <span>Review Pending Approvals</span>
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-200 text-amber-900 font-mono">3 Actions</span>
                  </button>

                  <button
                    onClick={() => onNavigate('leave')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 font-semibold flex items-center justify-between transition border border-slate-100 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Layers className="w-4 h-4 text-slate-600" />
                      <span>Leave Master & Annual Quotas</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  <button
                    onClick={() => onNavigate('leave')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 font-semibold flex items-center justify-between transition border border-slate-100 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-slate-600" />
                      <span>Employee Leave Balance Ledger</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>On-Duty & Gate Pass System</span>
                <button onClick={() => onNavigate('od_gatepass')} className="text-amber-700 font-bold hover:underline cursor-pointer">
                  OD Gateway →
                </button>
              </div>
            </div>

            {/* Command Tile 4: 💰 Wage Code & Payroll Engine */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4 hover:border-purple-400 transition-all group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="p-2 rounded-2xl bg-purple-100 text-purple-800 group-hover:bg-purple-600 group-hover:text-white transition-colors">
                      <DollarSign className="w-5 h-5 text-purple-700 group-hover:text-white" />
                    </span>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                        Payroll & Wage Code 2026
                      </h4>
                      <p className="text-[10px] text-slate-400">Statutory, Deductions & Payslips</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-100 text-purple-800 font-mono">
                    Wage Code 50%
                  </span>
                </div>

                <div className="space-y-2 pt-3 text-xs">
                  <button
                    onClick={() => onNavigate('salary_master')}
                    className="w-full text-left p-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold flex items-center justify-between transition shadow-xs cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Award className="w-4 h-4" />
                      <span>Salary Master (Code on Wages)</span>
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onNavigate('payroll')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-purple-50 hover:text-purple-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-purple-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-purple-600" />
                      <span>Monthly Payroll Run Engine</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  <button
                    onClick={() => onNavigate('payslips')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-purple-50 hover:text-purple-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-purple-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-purple-600" />
                      <span>Salary Slip Archive & ESS</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  <button
                    onClick={() => onNavigate('salary_master')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-purple-50 hover:text-purple-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-purple-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>Statutory Challans (PF/ESIC/PT)</span>
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800 font-mono">100% OK</span>
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Monthly Disbursement CTC Volume</span>
                <strong className="text-purple-700 font-mono">₹1.84 Cr / mo</strong>
              </div>
            </div>

            {/* Command Tile 5: 📊 Executive Analytics & Intelligence */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4 hover:border-rose-400 transition-all group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="p-2 rounded-2xl bg-rose-100 text-rose-800 group-hover:bg-rose-600 group-hover:text-white transition-colors">
                      <BarChart3 className="w-5 h-5 text-rose-700 group-hover:text-white" />
                    </span>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                        Reports & Intelligence
                      </h4>
                      <p className="text-[10px] text-slate-400">PDF, Excel & Audit Exports</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-800 font-mono">
                    Instant PDF
                  </span>
                </div>

                <div className="space-y-2 pt-3 text-xs">
                  <button
                    onClick={() => {
                      if (onDownloadPdf) onDownloadPdf();
                      else setShowReportModal(true);
                    }}
                    className="w-full text-left p-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold flex items-center justify-between transition shadow-xs cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <FileDown className="w-4 h-4" />
                      <span>Generate Executive PDF Report</span>
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onNavigate('reports')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-rose-50 hover:text-rose-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-rose-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-rose-600" />
                      <span>Department-Wise Headcount Report</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  <button
                    onClick={() => onNavigate('reports')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-rose-50 hover:text-rose-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-rose-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-rose-600" />
                      <span>Attendance & Late Coming Report</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  <button
                    onClick={() => onNavigate('audit')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-rose-50 hover:text-rose-900 font-semibold flex items-center justify-between transition border border-slate-100 hover:border-rose-200 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-slate-600" />
                      <span>Compliance & Audit Trail Logs</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Multi-Format Export</span>
                <span className="text-slate-700 font-semibold">CSV · XLS · PDF · JSON</span>
              </div>
            </div>

            {/* Command Tile 6: ⚙️ Enterprise Governance & Infrastructure */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs space-y-4 hover:border-slate-400 transition-all group flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <span className="p-2 rounded-2xl bg-slate-100 text-slate-800 group-hover:bg-slate-900 group-hover:text-white transition-colors">
                      <ShieldCheck className="w-5 h-5 text-slate-700 group-hover:text-white" />
                    </span>
                    <div>
                      <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                        Enterprise Governance
                      </h4>
                      <p className="text-[10px] text-slate-400">Org Chart, Docs & Units</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-slate-200 text-slate-800 font-mono">
                    {storeData.units.length} Units Active
                  </span>
                </div>

                <div className="space-y-2 pt-3 text-xs">
                  <button
                    onClick={() => setShowAddUnitModal(true)}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold flex items-center justify-between transition shadow-xs cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-sky-400" />
                      <span>+ Add Operating Unit with Location</span>
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onNavigate('organization')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 font-semibold flex items-center justify-between transition border border-slate-100 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Layers className="w-4 h-4 text-slate-600" />
                      <span>Org Master & Hierarchy Chart</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  <button
                    onClick={() => onNavigate('documents_master')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 font-semibold flex items-center justify-between transition border border-slate-100 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <FileCheck className="w-4 h-4 text-sky-600" />
                      <span>Documents Master (10 Slots Engine)</span>
                    </span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-sky-100 text-sky-800 font-mono">10 Slots</span>
                  </button>

                  <button
                    onClick={() => onNavigate('users_roles')}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 font-semibold flex items-center justify-between transition border border-slate-100 cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-indigo-600" />
                      <span>Users, RBAC & Security Rights</span>
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span>Multi-Tenant SaaS Version</span>
                <span className="text-slate-800 font-bold font-mono">v3.2 Production</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL 1: ADD OPERATING UNIT WITH LOCATION */}
      {showAddUnitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in flex flex-col max-h-[92vh]">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-sky-50">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-sky-200 text-sky-900">
                  <Building2 className="w-5 h-5 text-sky-800" />
                </span>
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase">
                    Add Operating Unit With Location
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    Add new manufacturing plant, corporate center or branch with location coordinates
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddUnitModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveNewUnit} className="p-5 space-y-4 text-xs overflow-y-auto flex-1">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Unit Name *</label>
                  <input
                    type="text"
                    required
                    value={unitName}
                    onChange={e => setUnitName(e.target.value)}
                    placeholder="e.g. Manesar Automotive Plant 3"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Unit Code *</label>
                  <input
                    type="text"
                    required
                    value={unitCode}
                    onChange={e => setUnitCode(e.target.value)}
                    placeholder="e.g. UN-MSR3"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono uppercase"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Unit Facility Type *</label>
                  <select
                    value={unitType}
                    onChange={e => setUnitType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  >
                    <option value="Manufacturing Plant">Manufacturing Plant</option>
                    <option value="Corporate">Corporate Office</option>
                    <option value="Warehouse">Warehouse / Logistics</option>
                    <option value="R&D Center">R&D Center</option>
                    <option value="Branch Office">Branch Office</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Branch / Location Hub Name</label>
                  <input
                    type="text"
                    value={branchName}
                    onChange={e => setBranchName(e.target.value)}
                    placeholder="e.g. Manesar Industrial Division"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Physical Location Address *</label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  placeholder="e.g. Plot 88, Sector 8, IMT Manesar"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">City *</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    placeholder="e.g. Gurugram"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">State *</label>
                  <input
                    type="text"
                    required
                    value={state}
                    onChange={e => setState(e.target.value)}
                    placeholder="e.g. Haryana"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Pincode *</label>
                  <input
                    type="text"
                    required
                    value={pincode}
                    onChange={e => setPincode(e.target.value)}
                    placeholder="e.g. 122051"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Target Capacity (Seats)</label>
                  <input
                    type="number"
                    value={capacity}
                    onChange={e => setCapacity(Number(e.target.value))}
                    placeholder="500"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Unit Head Person</label>
                  <input
                    type="text"
                    value={headPerson}
                    onChange={e => setHeadPerson(e.target.value)}
                    placeholder="e.g. Alok Sharma (GM)"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Geo-Coordinates / GPS Location</label>
                <input
                  type="text"
                  value={geoCoords}
                  onChange={e => setGeoCoords(e.target.value)}
                  placeholder="e.g. 28.3642° N, 76.9324° E"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-[11px]"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddUnitModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Save & Add Operating Unit</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: QUICK ADD EMPLOYEE */}
      {showAddEmployeeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in flex flex-col max-h-[92vh]">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-sky-50">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-sky-200 text-sky-900">
                  <UserPlus className="w-5 h-5 text-sky-800" />
                </span>
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase">
                    + Quick Add Employee
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    Fast workforce onboarding with unit & department assignment
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddEmployeeModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickEmployee} className="p-5 space-y-4 text-xs overflow-y-auto flex-1">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">First Name *</label>
                  <input
                    type="text"
                    required
                    value={empFirstName}
                    onChange={e => setEmpFirstName(e.target.value)}
                    placeholder="e.g. Ramesh"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={empLastName}
                    onChange={e => setEmpLastName(e.target.value)}
                    placeholder="e.g. Kumar"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Employee Code *</label>
                  <input
                    type="text"
                    required
                    value={empCodeInput}
                    onChange={e => setEmpCodeInput(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Designation Title</label>
                  <input
                    type="text"
                    value={empDesig}
                    onChange={e => setEmpDesig(e.target.value)}
                    placeholder="e.g. Operations Lead"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Assigned Unit / Plant *</label>
                  <select
                    value={empUnitId}
                    onChange={e => setEmpUnitId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  >
                    {units.map(u => (
                      <option key={u.id} value={u.id}>{u.name} ({u.code})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Department *</label>
                  <select
                    value={empDeptId}
                    onChange={e => setEmpDeptId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  >
                    {departments.map(d => (
                      <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Gross Salary (Monthly ₹)</label>
                  <input
                    type="number"
                    value={empGrossSalary}
                    onChange={e => setEmpGrossSalary(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Phone Number</label>
                  <input
                    type="text"
                    value={empPhone}
                    onChange={e => setEmpPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddEmployeeModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Onboard & Save Employee</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: APPLY LEAVE */}
      {showApplyLeaveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in flex flex-col">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-amber-50">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-amber-200 text-amber-900">
                  <Calendar className="w-5 h-5 text-amber-800" />
                </span>
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase">
                    Apply Leave Application
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    Fast leave submission for manager & HR approval
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowApplyLeaveModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveApplyLeave} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Select Employee *</label>
                <select
                  value={leaveEmpId}
                  onChange={e => setLeaveEmpId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.firstName} {emp.lastName} ({emp.employeeCode})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Leave Type *</label>
                <select
                  value={leaveType}
                  onChange={e => setLeaveType(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  <option value="Casual">Casual Leave (CL)</option>
                  <option value="Sick">Sick Leave (SL)</option>
                  <option value="Earned">Earned / Privilege Leave (EL/PL)</option>
                  <option value="Maternity">Maternity / Special Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Start Date *</label>
                  <input
                    type="date"
                    required
                    value={leaveStartDate}
                    onChange={e => setLeaveStartDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">End Date *</label>
                  <input
                    type="date"
                    required
                    value={leaveEndDate}
                    onChange={e => setLeaveEndDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Reason for Leave *</label>
                <textarea
                  required
                  rows={3}
                  value={leaveReason}
                  onChange={e => setLeaveReason(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  placeholder="State the purpose of absence..."
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowApplyLeaveModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Leave Request</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: APPROVE LEAVE DRAWER */}
      {showApproveLeaveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in flex flex-col max-h-[85vh]">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-emerald-50">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-emerald-200 text-emerald-900">
                  <CheckSquare className="w-5 h-5 text-emerald-800" />
                </span>
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase">
                    Pending Leave Approvals Hub
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    Review and grant first/second level supervisor approvals
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowApproveLeaveModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3 overflow-y-auto flex-1 text-xs">
              {localPendingLeaves.map(item => (
                <div key={item.id} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <strong className="text-slate-900 font-bold">{item.employeeName}</strong>
                      <span className="font-mono text-[10px] text-sky-700 font-bold ml-2">{item.employeeCode}</span>
                      <span className="text-[10px] text-slate-500 block">{item.department}</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      item.status === 'Approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.status === 'Rejected'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}>
                      {item.status}
                    </span>
                  </div>

                  <div className="bg-white p-2.5 rounded-lg border border-slate-200 flex justify-between items-center text-[11px]">
                    <div>
                      <span className="font-bold text-slate-700">{item.leaveType}</span> ({item.days} Days)
                      <p className="text-slate-500 font-mono text-[10px] mt-0.5">{item.startDate} to {item.endDate}</p>
                    </div>
                    <span className="text-slate-600 italic">"{item.reason}"</span>
                  </div>

                  {item.status === 'Pending' && (
                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setLocalPendingLeaves(prev => prev.map(p => p.id === item.id ? { ...p, status: 'Rejected' } : p));
                          setToastMessage(`Leave request rejected for ${item.employeeName}.`);
                        }}
                        className="px-3 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold cursor-pointer"
                      >
                        Reject
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setLocalPendingLeaves(prev => prev.map(p => p.id === item.id ? { ...p, status: 'Approved' } : p));
                          setToastMessage(`Leave approved for ${item.employeeName}! Notification dispatched.`);
                        }}
                        className="px-4 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold cursor-pointer shadow-xs"
                      >
                        Approve Leave
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="p-3 border-t border-slate-100 bg-white flex justify-end">
              <button
                type="button"
                onClick={() => setShowApproveLeaveModal(false)}
                className="px-4 py-1.5 rounded-xl border border-slate-200 font-bold text-slate-700 text-xs hover:bg-slate-50 cursor-pointer"
              >
                Close Drawer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 5: MARK ATTENDANCE */}
      {showMarkAttendanceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in flex flex-col">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-sky-50">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-sky-200 text-sky-900">
                  <Fingerprint className="w-5 h-5 text-sky-800" />
                </span>
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase">
                    Mark Daily Attendance Punch
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    Live Web/Geo biometric verification and timestamping
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowMarkAttendanceModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSavePunch} className="p-5 space-y-4 text-xs">
              <div className="p-3 bg-slate-900 text-white rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 font-mono block">System Timestamp</span>
                  <strong className="text-sm font-mono text-emerald-400">08-Oct-2026 · {currentTimeStr}</strong>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">Geo GPS Status</span>
                  <span className="text-emerald-400 text-[10px] font-bold">✓ Geo-Fenced Valid</span>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Select Employee *</label>
                <select
                  value={punchEmpId}
                  onChange={e => setPunchEmpId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                >
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.firstName} {emp.lastName} ({emp.employeeCode})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Punch Type *</label>
                  <select
                    value={punchType}
                    onChange={e => setPunchType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  >
                    <option value="IN">🟢 Clock IN (Shift Entry)</option>
                    <option value="OUT">🔴 Clock OUT (Shift Exit)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Terminal Unit *</label>
                  <select
                    value={punchUnitId}
                    onChange={e => setPunchUnitId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  >
                    {units.map(u => (
                      <option key={u.id} value={u.id}>{u.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Punch Verification Notes</label>
                <input
                  type="text"
                  value={punchRemarks}
                  onChange={e => setPunchRemarks(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  placeholder="e.g. Regular shift punch"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowMarkAttendanceModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Confirm & Record Punch</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 6: GENERATE REPORT */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in flex flex-col">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-purple-50">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-purple-200 text-purple-900">
                  <FileDown className="w-5 h-5 text-purple-800" />
                </span>
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase">
                    HRMS Instant Report Generator
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    Export unit-wise reports, statutory challans & registers
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">1. Operating Unit Scope</label>
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 font-bold text-slate-800">
                  📍 {unitMetrics.unitNameDisplay}
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">2. Select Report Type</label>
                <select
                  value={reportType}
                  onChange={e => setReportType(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                >
                  <option value="unit_wise">Unit-Wise Attendance & Headcount Report</option>
                  <option value="dept_wise">Department-Wise Employee Master Register</option>
                  <option value="attendance">Daily & Monthly Attendance Summary</option>
                  <option value="payroll">Monthly Salary Disbursement Register</option>
                  <option value="leave">Leave Balance & Encashment Report</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">3. Export File Format</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setReportFormat('csv')}
                    className={`p-2 rounded-xl border text-center font-bold transition cursor-pointer ${
                      reportFormat === 'csv'
                        ? 'bg-purple-100 border-purple-500 text-purple-900 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    CSV Text
                  </button>
                  <button
                    type="button"
                    onClick={() => setReportFormat('excel')}
                    className={`p-2 rounded-xl border text-center font-bold transition cursor-pointer ${
                      reportFormat === 'excel'
                        ? 'bg-purple-100 border-purple-500 text-purple-900 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    MS Excel (.xlsx)
                  </button>
                  <button
                    type="button"
                    onClick={() => setReportFormat('pdf')}
                    className={`p-2 rounded-xl border text-center font-bold transition cursor-pointer ${
                      reportFormat === 'pdf'
                        ? 'bg-purple-100 border-purple-500 text-purple-900 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    Executive PDF
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleExportQuickReport}
                  className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <FileDown className="w-4 h-4" />
                  <span>Download Report Now</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 7: BIRTHDAYS TODAY CELEBRATION */}
      {showBirthdaysModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in flex flex-col">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-pink-50">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-pink-200 text-pink-900">
                  <Cake className="w-5 h-5 text-pink-700" />
                </span>
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase">
                    🎂 Today's Birthdays (08-Oct-2026)
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    6 team members celebrating birthdays across RSTPL units today!
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowBirthdaysModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3 overflow-y-auto max-h-96 text-xs">
              {birthdaysToday.map((b, i) => (
                <div key={i} className="p-3 rounded-xl border border-pink-100 bg-pink-50/40 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-pink-200 text-pink-800 font-bold flex items-center justify-center text-xs">
                      {b.avatar}
                    </div>
                    <div>
                      <strong className="text-slate-900 block font-bold">{b.name}</strong>
                      <span className="text-[10px] text-slate-500">{b.designation} · {b.dept} ({b.unit})</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setToastMessage(`Personalized birthday wish sent to ${b.name} via email & ESS! 🎉`);
                      setTimeout(() => setToastMessage(null), 3500);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-pink-600 hover:bg-pink-700 text-white font-bold text-[11px] transition cursor-pointer flex items-center gap-1 shadow-xs"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Wish Happy Birthday</span>
                  </button>
                </div>
              ))}
            </div>

            <div className="p-3 border-t border-slate-100 bg-white flex justify-end">
              <button
                type="button"
                onClick={() => setShowBirthdaysModal(false)}
                className="px-4 py-1.5 rounded-xl border border-slate-200 font-bold text-slate-700 text-xs hover:bg-slate-50 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 8: NEW JOINEES LIST */}
      {showNewJoineesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in flex flex-col max-h-[85vh]">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-purple-50">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-purple-200 text-purple-900">
                  <UserPlus className="w-5 h-5 text-purple-800" />
                </span>
                <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase">
                    🆕 New Joinings This Month (18 Hires)
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    October 2026 onboarding register across operating units
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowNewJoineesModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-2 overflow-y-auto flex-1 text-xs">
              <table className="w-full text-left border-collapse">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] border-b border-slate-100">
                  <tr>
                    <th className="py-2 px-3">Employee</th>
                    <th className="py-2 px-3">Designation</th>
                    <th className="py-2 px-3">Unit</th>
                    <th className="py-2 px-3">DOJ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {newJoinees.map((j, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-2 px-3">
                        <strong className="text-slate-900 block">{j.name}</strong>
                        <span className="font-mono text-[10px] text-sky-700">{j.code}</span>
                      </td>
                      <td className="py-2 px-3 text-slate-600">{j.desig}</td>
                      <td className="py-2 px-3 text-slate-600">{j.unit}</td>
                      <td className="py-2 px-3 font-mono text-slate-500">{j.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-3 border-t border-slate-100 bg-white flex justify-end">
              <button
                type="button"
                onClick={() => setShowNewJoineesModal(false)}
                className="px-4 py-1.5 rounded-xl border border-slate-200 font-bold text-slate-700 text-xs hover:bg-slate-50 cursor-pointer"
              >
                Close Register
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

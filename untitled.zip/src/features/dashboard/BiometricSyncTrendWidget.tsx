// RSTPL HRMS - 7-Day Biometric Synchronization Success Rate Trend Widget
// RS Technovisions XpertSkillCop
// Built with Recharts for network telemetry and hardware sync diagnostics

import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from 'recharts';
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Wifi,
  Radio,
  Server,
  Zap,
  ShieldCheck,
  ChevronRight,
  Info,
  Calendar,
  Layers
} from 'lucide-react';
import { BiometricDevice } from '../../types/hrms';

interface BiometricSyncTrendWidgetProps {
  devices?: BiometricDevice[];
  onNavigate?: (module: string) => void;
  onOpenBiometricStudio?: () => void;
}

interface DailySyncData {
  dayLabel: string;
  fullDate: string;
  successRate: number;
  totalPunches: number;
  syncedPunches: number;
  droppedPackets: number;
  avgLatencyMs: number;
  incidentCount: number;
  siteIssues?: string;
}

interface ChartErrorBoundaryProps {
  children: React.ReactNode;
  fallback: React.ReactNode;
}

interface ChartErrorBoundaryState {
  hasError: boolean;
}

class ChartErrorBoundary extends React.Component<ChartErrorBoundaryProps, ChartErrorBoundaryState> {
  constructor(props: ChartErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    console.warn('Recharts render issue caught by boundary, showing responsive SVG fallback:', error);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

const SvgTrendChartFallback: React.FC<{
  trendData: DailySyncData[];
  chartMetric: 'rate' | 'volume';
}> = ({ trendData, chartMetric }) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  const padding = { top: 20, right: 20, bottom: 30, left: 45 };
  const width = 600;
  const height = 240;
  const innerWidth = width - padding.left - padding.right;
  const innerHeight = height - padding.top - padding.bottom;

  const minVal = chartMetric === 'rate' ? 96 : 0;
  const maxVal = chartMetric === 'rate' ? 100 : Math.max(...trendData.map(d => d.totalPunches)) * 1.05;

  const getY = (val: number) => {
    return padding.top + innerHeight - ((val - minVal) / (maxVal - minVal)) * innerHeight;
  };

  const getX = (index: number) => {
    return padding.left + (index / (trendData.length - 1)) * innerWidth;
  };

  const points = trendData.map((d, i) => ({
    x: getX(i),
    y: getY(chartMetric === 'rate' ? d.successRate : d.syncedPunches),
    data: d,
  }));

  const pathD = points.reduce((acc, p, i) => {
    return i === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`;
  }, '');

  const areaD = `${pathD} L ${points[points.length - 1].x} ${padding.top + innerHeight} L ${points[0].x} ${padding.top + innerHeight} Z`;

  const slaY = getY(99.0);

  return (
    <div className="relative w-full h-full flex items-center justify-center select-none">
      <svg className="w-full h-full" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
        <defs>
          <linearGradient id="svgRateGradFallback" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={chartMetric === 'rate' ? '#0284c7' : '#10b981'} stopOpacity="0.4" />
            <stop offset="95%" stopColor={chartMetric === 'rate' ? '#0284c7' : '#10b981'} stopOpacity="0.02" />
          </linearGradient>
        </defs>

        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((pct, i) => {
          const y = padding.top + pct * innerHeight;
          const val = Math.round(maxVal - pct * (maxVal - minVal));
          return (
            <g key={i}>
              <line x1={padding.left} y1={y} x2={width - padding.right} y2={y} stroke="#e2e8f0" strokeDasharray="3 3" />
              <text x={padding.left - 6} y={y + 3} fill="#94a3b8" fontSize="10" textAnchor="end" fontFamily="monospace">
                {val}{chartMetric === 'rate' ? '%' : ''}
              </text>
            </g>
          );
        })}

        {/* 99% SLA Target Line */}
        {chartMetric === 'rate' && (
          <g>
            <line x1={padding.left} y1={slaY} x2={width - padding.right} y2={slaY} stroke="#f43f5e" strokeWidth="1.5" strokeDasharray="4 4" />
            <text x={width - padding.right - 4} y={slaY - 4} fill="#f43f5e" fontSize="9" fontWeight="bold" textAnchor="end">
              SLA Target (99.0%)
            </text>
          </g>
        )}

        {/* Area polygon */}
        <path d={areaD} fill="url(#svgRateGradFallback)" />

        {/* Area line */}
        <path d={pathD} fill="none" stroke={chartMetric === 'rate' ? '#0284c7' : '#10b981'} strokeWidth="2.5" />

        {/* Data points */}
        {points.map((p, i) => (
          <circle
            key={i}
            cx={p.x}
            cy={p.y}
            r={hoveredIdx === i ? 6 : 4}
            fill="#ffffff"
            stroke={chartMetric === 'rate' ? '#0284c7' : '#10b981'}
            strokeWidth="2.5"
            className="cursor-pointer transition-all"
            onMouseEnter={() => setHoveredIdx(i)}
            onMouseLeave={() => setHoveredIdx(null)}
          />
        ))}

        {/* X Axis labels */}
        {trendData.map((d, i) => (
          <text
            key={i}
            x={getX(i)}
            y={height - 8}
            fill="#94a3b8"
            fontSize="10"
            textAnchor="middle"
            fontFamily="sans-serif"
          >
            {d.dayLabel}
          </text>
        ))}
      </svg>

      {/* Hover tooltip */}
      {hoveredIdx !== null && (
        <div
          className="absolute z-30 p-2.5 rounded-xl bg-slate-900 text-white border border-slate-700 shadow-xl text-xs pointer-events-none"
          style={{
            left: `${Math.min(75, Math.max(10, (points[hoveredIdx].x / width) * 100))}%`,
            top: '20px',
          }}
        >
          <div className="font-bold text-sky-300 pb-1 border-b border-slate-800">
            {trendData[hoveredIdx].fullDate}
          </div>
          <div className="mt-1 space-y-0.5 font-mono text-[11px]">
            <div>Success Rate: <strong className="text-emerald-300">{trendData[hoveredIdx].successRate}%</strong></div>
            <div>Punches: {trendData[hoveredIdx].syncedPunches} / {trendData[hoveredIdx].totalPunches}</div>
            <div>Avg Latency: {trendData[hoveredIdx].avgLatencyMs}ms</div>
          </div>
        </div>
      )}
    </div>
  );
};

export const BiometricSyncTrendWidget: React.FC<BiometricSyncTrendWidgetProps> = ({
  devices = [],
  onNavigate,
  onOpenBiometricStudio,
}) => {
  const [selectedSiteFilter, setSelectedSiteFilter] = useState<'ALL' | 'CHAKAN' | 'SANAND' | 'HQ'>('ALL');
  const [chartMetric, setChartMetric] = useState<'rate' | 'volume'>('rate');

  // Baseline 7-Day Synchronization Telemetry Data ending today (Oct 06, 2026)
  const base7DayData: DailySyncData[] = useMemo(() => [
    {
      dayLabel: 'Sep 30',
      fullDate: 'Tuesday, Sep 30, 2026',
      successRate: 99.8,
      totalPunches: 4850,
      syncedPunches: 4840,
      droppedPackets: 10,
      avgLatencyMs: 44,
      incidentCount: 0,
      siteIssues: 'Optimal connectivity across all 4 production terminals',
    },
    {
      dayLabel: 'Oct 01',
      fullDate: 'Wednesday, Oct 01, 2026',
      successRate: 99.6,
      totalPunches: 5120,
      syncedPunches: 5100,
      droppedPackets: 20,
      avgLatencyMs: 48,
      incidentCount: 0,
      siteIssues: 'Normal month-opening shift traffic; zero packet loss',
    },
    {
      dayLabel: 'Oct 02',
      fullDate: 'Thursday, Oct 02, 2026',
      successRate: 98.7,
      totalPunches: 4720,
      syncedPunches: 4658,
      droppedPackets: 62,
      avgLatencyMs: 98,
      incidentCount: 1,
      siteIssues: 'Sanand MIDC WAN fiber maintenance caused intermittent 80ms jitter',
    },
    {
      dayLabel: 'Oct 03',
      fullDate: 'Friday, Oct 03, 2026',
      successRate: 99.9,
      totalPunches: 4980,
      syncedPunches: 4975,
      droppedPackets: 5,
      avgLatencyMs: 42,
      incidentCount: 0,
      siteIssues: 'Optimal LAN throughput; 100% attendance synchronization',
    },
    {
      dayLabel: 'Oct 04',
      fullDate: 'Saturday, Oct 04, 2026',
      successRate: 99.5,
      totalPunches: 3840,
      syncedPunches: 3821,
      droppedPackets: 19,
      avgLatencyMs: 50,
      incidentCount: 0,
      siteIssues: 'Weekend maintenance shift clocked seamlessly',
    },
    {
      dayLabel: 'Oct 05',
      fullDate: 'Sunday, Oct 05, 2026',
      successRate: 98.2,
      totalPunches: 2650,
      syncedPunches: 2602,
      droppedPackets: 48,
      avgLatencyMs: 142,
      incidentCount: 1,
      siteIssues: 'Sanand terminal router auto-reboot triggered brief packet queuing',
    },
    {
      dayLabel: 'Oct 06 (Today)',
      fullDate: 'Monday, Oct 06, 2026 (Live)',
      successRate: 99.7,
      totalPunches: 4920,
      syncedPunches: 4905,
      droppedPackets: 15,
      avgLatencyMs: 46,
      incidentCount: 0,
      siteIssues: 'Live polling nominal; ADMS Webhook handshake latency 46ms',
    },
  ], []);

  // Filter or adjust trend data based on site selection
  const trendData = useMemo(() => {
    if (selectedSiteFilter === 'ALL') return base7DayData;
    if (selectedSiteFilter === 'SANAND') {
      return base7DayData.map(d => ({
        ...d,
        successRate: Math.max(96.5, Number((d.successRate - (d.dayLabel.includes('02') || d.dayLabel.includes('05') ? 1.8 : 0.4)).toFixed(1))),
        totalPunches: Math.round(d.totalPunches * 0.28),
        syncedPunches: Math.round(d.syncedPunches * 0.278),
        droppedPackets: Math.round(d.droppedPackets * 0.65),
        avgLatencyMs: d.avgLatencyMs + 40,
      }));
    }
    if (selectedSiteFilter === 'CHAKAN') {
      return base7DayData.map(d => ({
        ...d,
        successRate: Math.min(100, Number((d.successRate + 0.2).toFixed(1))),
        totalPunches: Math.round(d.totalPunches * 0.45),
        syncedPunches: Math.round(d.syncedPunches * 0.45),
        droppedPackets: Math.max(2, Math.round(d.droppedPackets * 0.2)),
        avgLatencyMs: Math.max(28, d.avgLatencyMs - 12),
      }));
    }
    // HQ
    return base7DayData.map(d => ({
      ...d,
      successRate: Math.min(100, Number((d.successRate + 0.3).toFixed(1))),
      totalPunches: Math.round(d.totalPunches * 0.27),
      syncedPunches: Math.round(d.syncedPunches * 0.27),
      droppedPackets: Math.max(1, Math.round(d.droppedPackets * 0.15)),
      avgLatencyMs: 32,
    }));
  }, [base7DayData, selectedSiteFilter]);

  // Aggregate stats across 7-day period
  const totalPeriodPunches = useMemo(() => trendData.reduce((acc, d) => acc + d.totalPunches, 0), [trendData]);
  const totalPeriodSynced = useMemo(() => trendData.reduce((acc, d) => acc + d.syncedPunches, 0), [trendData]);
  const totalPeriodDropped = useMemo(() => trendData.reduce((acc, d) => acc + d.droppedPackets, 0), [trendData]);
  const avgPeriodSuccessRate = useMemo(() => {
    const sum = trendData.reduce((acc, d) => acc + d.successRate, 0);
    return Number((sum / trendData.length).toFixed(1));
  }, [trendData]);
  const avgPeriodLatency = useMemo(() => {
    const sum = trendData.reduce((acc, d) => acc + d.avgLatencyMs, 0);
    return Math.round(sum / trendData.length);
  }, [trendData]);

  // SLA status evaluation (Target is 99.0%)
  const isSlaCompliant = avgPeriodSuccessRate >= 99.0;
  const lowestDay = useMemo(() => {
    return [...trendData].sort((a, b) => a.successRate - b.successRate)[0];
  }, [trendData]);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
      {/* Widget Header & Diagnostic Controls */}
      <div className="p-4 sm:p-5 border-b border-slate-200 bg-gradient-to-r from-slate-50 via-white to-sky-50/30">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3.5">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="p-1.5 rounded-lg bg-sky-100 text-sky-800">
                <Activity className="w-4 h-4" />
              </span>
              <h3 className="text-sm font-bold text-slate-900">
                Biometric Synchronization Success Rate
              </h3>
              <span className="text-xs font-semibold text-slate-500">
                (7-Day Fleet Trend)
              </span>

              <span
                className={`px-2 py-0.5 rounded text-[10px] font-bold border flex items-center gap-1 ${
                  isSlaCompliant
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                    : 'bg-amber-50 text-amber-800 border-amber-200'
                }`}
              >
                {isSlaCompliant ? (
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                ) : (
                  <AlertTriangle className="w-3 h-3 text-amber-600" />
                )}
                <span>{isSlaCompliant ? 'SLA Met (≥99.0%)' : 'SLA Warning (<99.0%)'}</span>
              </span>
            </div>

            <p className="text-xs text-slate-500 mt-1">
              Automated audit of biometric network packet ingestions, ADMS webhook deliveries, and handshake packet drops.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Metric Mode Toggle */}
            <div className="flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs">
              <button
                onClick={() => setChartMetric('rate')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                  chartMetric === 'rate'
                    ? 'bg-white text-slate-900 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Success Rate (%)
              </button>
              <button
                onClick={() => setChartMetric('volume')}
                className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                  chartMetric === 'volume'
                    ? 'bg-white text-slate-900 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Packet Volume & Drops
              </button>
            </div>

            {/* Site Scope Filter */}
            <select
              value={selectedSiteFilter}
              onChange={(e) => setSelectedSiteFilter(e.target.value as any)}
              className="px-2.5 py-1.5 rounded-xl bg-white border border-slate-200 text-xs font-semibold text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 cursor-pointer"
            >
              <option value="ALL">All Plant Sites (Fleet)</option>
              <option value="CHAKAN">Chakan Plant (Pune)</option>
              <option value="SANAND">Sanand Unit (Gujarat)</option>
              <option value="HQ">Corporate HQ (Baner)</option>
            </select>
          </div>
        </div>

        {/* 4 Summary Stat Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-4 pt-3 border-t border-slate-100 text-xs">
          {/* Stat 1: 7-Day Average Success Rate */}
          <div className="p-3 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
            <span className="text-[11px] text-slate-500 font-medium">7-Day Avg Success Rate</span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className={`text-xl font-black ${avgPeriodSuccessRate >= 99 ? 'text-emerald-600' : 'text-amber-600'}`}>
                {avgPeriodSuccessRate}%
              </span>
              <span className="text-[10px] font-mono text-slate-400">Target 99.0%</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              <span>{avgPeriodSuccessRate >= 99 ? '+0.2% vs prev week' : '-0.8% below tolerance'}</span>
            </div>
          </div>

          {/* Stat 2: Total Synced Punches */}
          <div className="p-3 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
            <span className="text-[11px] text-slate-500 font-medium">Total Ingested Punches</span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-xl font-black text-slate-900 font-mono">
                {totalPeriodSynced.toLocaleString()}
              </span>
              <span className="text-[10px] text-slate-400">/ {totalPeriodPunches.toLocaleString()}</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              <span>Full attendance reconciliation</span>
            </div>
          </div>

          {/* Stat 3: Packet Drops / Jitter Retries */}
          <div className="p-3 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
            <span className="text-[11px] text-slate-500 font-medium">Retried / Dropped Packets</span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className={`text-xl font-black font-mono ${totalPeriodDropped > 150 ? 'text-amber-600' : 'text-slate-800'}`}>
                {totalPeriodDropped}
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                ({((totalPeriodDropped / totalPeriodPunches) * 100).toFixed(2)}%)
              </span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1">
              <span>Auto-retried by ADMS buffer queue</span>
            </div>
          </div>

          {/* Stat 4: Handshake Latency Average */}
          <div className="p-3 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
            <span className="text-[11px] text-slate-500 font-medium">Avg Handshake Latency</span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-xl font-black text-sky-700 font-mono">
                {avgPeriodLatency}ms
              </span>
              <span className="text-[10px] text-slate-400 font-mono">SLA &lt;150ms</span>
            </div>
            <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-500" />
              <span>Optimal WAN round-trip health</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recharts Area Chart Canvas */}
      <div className="p-4 sm:p-5">
        <div className="h-64 sm:h-72 w-full">
          <ChartErrorBoundary fallback={<SvgTrendChartFallback trendData={trendData} chartMetric={chartMetric} />}>
            <ResponsiveContainer width="100%" height="100%">
              {chartMetric === 'rate' ? (
              <AreaChart
                data={trendData}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="successRateGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#0284c7" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#0284c7" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis
                  dataKey="dayLabel"
                  tickLine={false}
                  stroke="#94a3b8"
                  fontSize={11}
                  fontWeight={500}
                />
                <YAxis
                  domain={[96, 100]}
                  ticks={[96, 97, 98, 99, 100]}
                  tickLine={false}
                  stroke="#94a3b8"
                  fontSize={11}
                  unit="%"
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload as DailySyncData;
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-xl border border-slate-700 shadow-xl text-xs space-y-1.5 min-w-[220px]">
                          <div className="font-bold text-sky-300 border-b border-slate-800 pb-1 flex items-center justify-between">
                            <span>{data.fullDate}</span>
                            <span className={`font-mono text-[11px] px-1.5 py-0.2 rounded font-bold ${
                              data.successRate >= 99 ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'
                            }`}>
                              {data.successRate}%
                            </span>
                          </div>
                          <div className="space-y-1 font-mono text-[11px] text-slate-300 pt-0.5">
                            <div className="flex justify-between">
                              <span className="text-slate-400">Total Punches:</span>
                              <span className="font-bold text-slate-100">{data.totalPunches.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Synced:</span>
                              <span className="text-emerald-400">{data.syncedPunches.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Packet Drops:</span>
                              <span className={data.droppedPackets > 30 ? 'text-rose-400 font-bold' : 'text-slate-300'}>
                                {data.droppedPackets}
                              </span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-400">Avg Latency:</span>
                              <span className="text-sky-300">{data.avgLatencyMs}ms</span>
                            </div>
                          </div>
                          {data.siteIssues && (
                            <div className="mt-1.5 pt-1.5 border-t border-slate-800 text-[10px] text-slate-400 font-sans">
                              {data.siteIssues}
                            </div>
                          )}
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                {/* 99% SLA Target Reference Line */}
                <ReferenceLine
                  y={99.0}
                  stroke="#f43f5e"
                  strokeDasharray="4 4"
                  strokeWidth={1.5}
                  label={{
                    value: 'SLA Target (99.0%)',
                    position: 'insideTopRight',
                    fill: '#f43f5e',
                    fontSize: 10,
                    fontWeight: 700,
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="successRate"
                  name="Sync Success Rate"
                  stroke="#0284c7"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#successRateGradient)"
                  activeDot={{ r: 6, stroke: '#0284c7', strokeWidth: 2, fill: '#fff' }}
                />
              </AreaChart>
            ) : (
              <AreaChart
                data={trendData}
                margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="volumeGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="dayLabel" tickLine={false} stroke="#94a3b8" fontSize={11} />
                <YAxis tickLine={false} stroke="#94a3b8" fontSize={11} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload as DailySyncData;
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-xl border border-slate-700 shadow-xl text-xs space-y-1">
                          <div className="font-bold text-sky-300 border-b border-slate-800 pb-1">
                            {data.fullDate}
                          </div>
                          <div className="flex justify-between font-mono text-[11px] gap-4">
                            <span className="text-slate-400">Volume:</span>
                            <span className="text-emerald-400 font-bold">{data.syncedPunches} punches</span>
                          </div>
                          <div className="flex justify-between font-mono text-[11px] gap-4">
                            <span className="text-slate-400">Dropped:</span>
                            <span className="text-rose-400 font-bold">{data.droppedPackets} packets</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="syncedPunches"
                  name="Ingested Punches"
                  stroke="#10b981"
                  strokeWidth={2}
                  fill="url(#volumeGradient)"
                />
              </AreaChart>
            )}
            </ResponsiveContainer>
          </ChartErrorBoundary>
        </div>

        {/* Network Diagnostics Insight Box */}
        <div className="mt-4 p-3.5 rounded-xl bg-slate-50 border border-slate-200/90 text-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <span className="p-1 rounded-lg bg-sky-100 text-sky-800 shrink-0 mt-0.5">
              <Info className="w-3.5 h-3.5" />
            </span>
            <div>
              <h5 className="font-bold text-slate-900">
                Network Performance Insight & Incident Correlation
              </h5>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Lowest sync success dip occurred on <strong className="text-slate-800">{lowestDay.fullDate}</strong> at{' '}
                <strong className="text-amber-700">{lowestDay.successRate}%</strong> ({lowestDay.droppedPackets} retried packets).{' '}
                {lowestDay.siteIssues}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {onOpenBiometricStudio && (
              <button
                onClick={onOpenBiometricStudio}
                className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 text-xs font-semibold transition-colors flex items-center gap-1 cursor-pointer shadow-2xs"
              >
                <span>Device Audit Logs</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}

            {onNavigate && (
              <button
                onClick={() => onNavigate('biometric')}
                className="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer shadow-xs"
              >
                <span>Biometric Studio</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

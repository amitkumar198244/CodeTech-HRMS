// RSTPL HRMS - On Duty (OD) & Gate Pass Workflows
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  Send,
  DoorOpen,
  Plus,
  Check,
  X,
  Clock,
  MapPin,
  FileCheck,
  CheckCircle2
} from 'lucide-react';
import { ODRequest, GatePassRequest, Employee } from '../../types/hrms';

interface ODGatePassViewProps {
  odRequests: ODRequest[];
  gatePassRequests: GatePassRequest[];
  employees: Employee[];
  onUpdateOD: (requests: ODRequest[]) => void;
  onUpdateGatePass: (requests: GatePassRequest[]) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
}

export const ODGatePassView: React.FC<ODGatePassViewProps> = ({
  odRequests,
  gatePassRequests,
  employees,
  onUpdateOD,
  onUpdateGatePass,
  onLogAudit,
}) => {
  const [activeTab, setActiveTab] = useState<'od' | 'gatepass'>('od');
  const [showApplyModal, setShowApplyModal] = useState(false);

  // OD Form State
  const [newOD, setNewOD] = useState<Partial<ODRequest>>({
    employeeId: employees[0]?.id,
    date: '2026-10-06',
    startTime: '10:00',
    endTime: '16:00',
    clientOrLocation: 'Client Plant (Tata Motors Bhosari)',
    purpose: 'On-site technical audit & line inspection',
  });

  // Gate Pass Form State
  const [newGatePass, setNewGatePass] = useState<Partial<GatePassRequest>>({
    employeeId: employees[0]?.id,
    date: '2026-10-06',
    outTime: '13:00',
    expectedInTime: '14:30',
    type: 'Official',
    reason: 'Bank visit for corporate PF draft clearance',
  });

  const handleCreateOD = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find(e => e.id === newOD.employeeId);
    if (!emp) return;

    const od: ODRequest = {
      id: `od-${Date.now()}`,
      orgId: emp.orgId,
      employeeId: emp.id,
      employeeName: `${emp.firstName} ${emp.lastName}`,
      date: newOD.date || '2026-10-06',
      startTime: newOD.startTime || '10:00',
      endTime: newOD.endTime || '16:00',
      purpose: newOD.purpose || 'Client Visit',
      clientOrLocation: newOD.clientOrLocation || 'External',
      status: 'Pending',
      appliedAt: new Date().toISOString(),
    };

    onUpdateOD([od, ...odRequests]);
    setShowApplyModal(false);
    onLogAudit('CREATE', 'On Duty (OD)', `${od.employeeName} submitted OD request for ${od.date}`);
  };

  const handleCreateGatePass = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find(e => e.id === newGatePass.employeeId);
    if (!emp) return;

    const pass: GatePassRequest = {
      id: `gp-${Date.now()}`,
      orgId: emp.orgId,
      employeeId: emp.id,
      employeeName: `${emp.firstName} ${emp.lastName}`,
      date: newGatePass.date || '2026-10-06',
      outTime: newGatePass.outTime || '13:00',
      expectedInTime: newGatePass.expectedInTime || '14:30',
      type: (newGatePass.type as any) || 'Official',
      reason: newGatePass.reason || 'Official errand',
      status: 'Pending',
    };

    onUpdateGatePass([pass, ...gatePassRequests]);
    setShowApplyModal(false);
    onLogAudit('CREATE', 'Gate Pass', `${pass.employeeName} submitted Gate Pass (${pass.type})`);
  };

  const handleReviewOD = (id: string, status: 'Approved' | 'Rejected') => {
    const next = odRequests.map(r => (r.id === id ? { ...r, status, reviewedBy: 'Rajesh Patil (Manager)' } : r));
    onUpdateOD(next);
    onLogAudit('APPROVE', 'On Duty (OD)', `Reviewed OD request ${id} as ${status}`);
  };

  const handleReviewGatePass = (id: string, status: 'Approved' | 'Rejected') => {
    const next = gatePassRequests.map(r => (r.id === id ? { ...r, status } : r));
    onUpdateGatePass(next);
    onLogAudit('APPROVE', 'Gate Pass', `Reviewed Gate Pass request ${id} as ${status}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-black text-slate-900 tracking-tight">On Duty (OD) & Security Gate Pass</h2>
          <p className="text-xs text-slate-500">
            Official field assignments, vendor audits, plant egress authorization & biometric compensation
          </p>
        </div>

        <button
          onClick={() => setShowApplyModal(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Apply {activeTab === 'od' ? 'On Duty' : 'Gate Pass'}</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('od')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'od'
              ? 'bg-sky-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Send className="w-3.5 h-3.5" />
          <span>On Duty Requests ({odRequests.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('gatepass')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
            activeTab === 'gatepass'
              ? 'bg-sky-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <DoorOpen className="w-3.5 h-3.5" />
          <span>Gate Passes ({gatePassRequests.length})</span>
        </button>
      </div>

      {/* On Duty Table */}
      {activeTab === 'od' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">On Duty (OD) Verification Roster</h3>
            <p className="text-[11px] text-slate-500">Approved ODs credit full working day presence to biometric attendance</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Date & Timing</th>
                  <th className="py-3 px-4">Client / Destination</th>
                  <th className="py-3 px-4">Official Purpose</th>
                  <th className="py-3 px-4">Approval Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {odRequests.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      No pending On Duty applications. Click "Apply On Duty" above.
                    </td>
                  </tr>
                ) : (
                  odRequests.map(r => (
                    <tr key={r.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-bold text-slate-900">{r.employeeName}</td>
                      <td className="py-3 px-4 font-mono text-slate-600">{r.date} ({r.startTime} - {r.endTime})</td>
                      <td className="py-3 px-4 font-medium text-slate-800 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-sky-600" /> {r.clientOrLocation}
                      </td>
                      <td className="py-3 px-4 text-slate-600 max-w-xs truncate">{r.purpose}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          r.status === 'Approved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {r.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        {r.status === 'Pending' && (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleReviewOD(r.id, 'Approved')}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px]"
                            >
                              Approve
                            </button>
                            <button
                              onClick={() => handleReviewOD(r.id, 'Rejected')}
                              className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 font-bold text-[11px] border border-rose-200"
                            >
                              Reject
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Gate Pass Table */}
      {activeTab === 'gatepass' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-100">
            <h3 className="text-sm font-bold text-slate-900">Security Plant Gate Passes</h3>
            <p className="text-[11px] text-slate-500">Authorization for mid-shift departure and return</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Employee</th>
                  <th className="py-3 px-4">Pass Type</th>
                  <th className="py-3 px-4">Out Time</th>
                  <th className="py-3 px-4">Expected Return</th>
                  <th className="py-3 px-4">Reason</th>
                  <th className="py-3 px-4">Security Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {gatePassRequests.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      No active gate passes logged today. Click "Apply Gate Pass" above.
                    </td>
                  </tr>
                ) : (
                  gatePassRequests.map(r => (
                    <tr key={r.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-bold text-slate-900">{r.employeeName}</td>
                      <td className="py-3 px-4">
                        <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 font-bold">
                          {r.type}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-800">{r.outTime}</td>
                      <td className="py-3 px-4 font-mono text-slate-600">{r.expectedInTime}</td>
                      <td className="py-3 px-4 text-slate-600">{r.reason}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          r.status === 'Approved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {r.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        {r.status === 'Pending' && (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleReviewGatePass(r.id, 'Approved')}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[11px]"
                            >
                              Issue Pass
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Apply Modal */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-sm font-bold text-slate-900 mb-1">
              Apply {activeTab === 'od' ? 'On Duty (OD)' : 'Gate Pass'}
            </h3>
            <p className="text-xs text-slate-500 mb-4">Official administrative authorization form</p>

            {activeTab === 'od' ? (
              <form onSubmit={handleCreateOD} className="space-y-3 text-xs">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Employee:</label>
                  <select
                    value={newOD.employeeId}
                    onChange={e => setNewOD({ ...newOD, employeeId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium"
                  >
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>{e.firstName} {e.lastName} ({e.employeeCode})</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Start Time:</label>
                    <input
                      type="time"
                      value={newOD.startTime}
                      onChange={e => setNewOD({ ...newOD, startTime: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">End Time:</label>
                    <input
                      type="time"
                      value={newOD.endTime}
                      onChange={e => setNewOD({ ...newOD, endTime: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Client / Destination Location:</label>
                  <input
                    type="text"
                    required
                    value={newOD.clientOrLocation}
                    onChange={e => setNewOD({ ...newOD, clientOrLocation: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Official Purpose *</label>
                  <textarea
                    required
                    rows={2}
                    value={newOD.purpose}
                    onChange={e => setNewOD({ ...newOD, purpose: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowApplyModal(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs"
                  >
                    Submit OD Request
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleCreateGatePass} className="space-y-3 text-xs">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Employee:</label>
                  <select
                    value={newGatePass.employeeId}
                    onChange={e => setNewGatePass({ ...newGatePass, employeeId: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium"
                  >
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>{e.firstName} {e.lastName} ({e.employeeCode})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Gate Pass Type:</label>
                  <select
                    value={newGatePass.type}
                    onChange={e => setNewGatePass({ ...newGatePass, type: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-semibold"
                  >
                    <option value="Official">Official Work</option>
                    <option value="Personal">Personal Emergency</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Gate Out Time:</label>
                    <input
                      type="time"
                      value={newGatePass.outTime}
                      onChange={e => setNewGatePass({ ...newGatePass, outTime: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Expected Return:</label>
                    <input
                      type="time"
                      value={newGatePass.expectedInTime}
                      onChange={e => setNewGatePass({ ...newGatePass, expectedInTime: e.target.value })}
                      className="w-full px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Reason for Gate Exit *</label>
                  <textarea
                    required
                    rows={2}
                    value={newGatePass.reason}
                    onChange={e => setNewGatePass({ ...newGatePass, reason: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50"
                  />
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowApplyModal(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs"
                  >
                    Issue Security Pass
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

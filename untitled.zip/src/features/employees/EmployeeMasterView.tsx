// RSTPL HRMS - Employee Master Directory & Complete Register (Image 1 Specification)
// RS Technovisions XpertSkillCop

import React, { useState, useMemo } from 'react';
import {
  Users,
  Search,
  Filter,
  Plus,
  Mail,
  Phone,
  Building,
  Briefcase,
  Shield,
  CreditCard,
  Calendar,
  ChevronRight,
  X,
  CheckCircle2,
  FileText,
  Clock,
  MapPin,
  TrendingUp,
  Download,
  FolderCheck,
  ShieldCheck,
  LayoutGrid,
  TableProperties,
  Network
} from 'lucide-react';
import { Employee, Department, Designation, Branch, Unit, Shift, Gender, EmploymentType } from '../../types/hrms';

interface EmployeeMasterViewProps {
  employees: Employee[];
  departments: Department[];
  designations: Designation[];
  branches: Branch[];
  units: Unit[];
  shifts: Shift[];
  onAddEmployee: (emp: Employee) => void;
  onUpdateEmployee: (emp: Employee) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
  onNavigateToSalary?: () => void;
  onNavigateToDocuments?: () => void;
  onNavigateToOrgHierarchy?: () => void;
}

export const EmployeeMasterView: React.FC<EmployeeMasterViewProps> = ({
  employees,
  departments,
  designations,
  branches,
  units,
  shifts,
  onAddEmployee,
  onUpdateEmployee,
  onLogAudit,
  onNavigateToSalary,
  onNavigateToDocuments,
  onNavigateToOrgHierarchy,
}) => {
  const [viewMode, setViewMode] = useState<'cards' | 'full-register'>('full-register');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState('ALL');
  const [selectedUnit, setSelectedUnit] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [viewingEmployee, setViewingEmployee] = useState<Employee | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // New employee form state with Image 1 extended fields
  const [newEmp, setNewEmp] = useState<Partial<Employee>>({
    firstName: '',
    lastName: '',
    fatherName: '',
    motherName: '',
    email: '',
    personalEmail: '',
    phone: '',
    gender: 'Male',
    dob: '1995-01-01',
    bloodGroup: 'B+',
    maritalStatus: 'Single',
    address: 'Pune, Maharashtra',
    permanentAddress: 'Pune, Maharashtra',
    currentAddress: 'Pune, Maharashtra',
    city: 'Pune',
    state: 'Maharashtra',
    pinCode: '411045',
    dateOfJoining: '2026-10-01',
    employmentType: 'Full-Time',
    status: 'Active',
    departmentId: departments[0]?.id || 'dept-hr',
    subDepartment: 'Talent Acquisition & IR',
    designationId: designations[0]?.id || 'desig-hr-mgr',
    branchId: branches[0]?.id || 'br-hq',
    unitId: units[0]?.id || 'un-corp',
    shiftId: shifts[0]?.id || 'sh-gen',
    grade: 'L3',
    reportingManagerId: employees[0]?.id || '',
    functionalHead: 'Amit Sharma (VP HR)',
    totalExperienceYears: 5,
    relevantExperienceYears: 4,
    pan: '',
    aadhaarMasked: 'XXXX-XXXX-1234',
    uan: '100987654399',
    pfNumber: 'MH/PUN/0098765/1009',
    esicNumber: '31000987650001099',
    pfApplicable: true,
    esicApplicable: false,
    bankName: 'HDFC Bank Ltd',
    accountHolderName: '',
    bankAccountNumber: '',
    ifscCode: 'HDFC0001234',
    branchName: 'Baner Tech Branch',
    emergencyContactPhone: '+91 99999 99999',
    emergencyRelationship: 'Parent',
    ctcAnnual: 600000,
    basicMonthly: 25000,
    hraMonthly: 12500,
    conveyanceMonthly: 3000,
    specialAllowanceMonthly: 9500,
    otherAllowanceMonthly: 0,
    netSalaryMonthly: 48000,
    remarks: 'Pre-employment verification completed',
  });

  const getDeptName = (deptId: string) => departments.find(d => d.id === deptId)?.name || 'Human Resources';
  const getDesigTitle = (desigId: string) => designations.find(d => d.id === desigId)?.title || 'Specialist';
  const getUnitName = (unitId: string) => units.find(u => u.id === unitId)?.name || 'Corporate Office';
  const getBranchName = (branchId: string) => branches.find(b => b.id === branchId)?.name || 'Pune HQ';
  const getShiftObj = (shiftId?: string) => shifts.find(s => s.id === shiftId);
  const getManagerName = (mgrId?: string) => {
    if (!mgrId) return 'Executive Leadership';
    const mgr = employees.find(e => e.id === mgrId);
    return mgr ? `${mgr.firstName} ${mgr.lastName} (${mgr.employeeCode})` : 'Top-Level Head';
  };

  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      const matchesSearch =
        emp.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.employeeCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesDept = selectedDept === 'ALL' || emp.departmentId === selectedDept;
      const matchesUnit = selectedUnit === 'ALL' || emp.unitId === selectedUnit;
      const matchesStatus = selectedStatus === 'ALL' || emp.status === selectedStatus;
      return matchesSearch && matchesDept && matchesUnit && matchesStatus;
    });
  }, [employees, searchQuery, selectedDept, selectedUnit, selectedStatus]);

  const handleCreateEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmp.firstName || !newEmp.lastName || !newEmp.email) return;

    const code = `RST-${1000 + employees.length + 1}`;
    const empToSave: Employee = {
      ...(newEmp as Employee),
      id: `emp-${Date.now()}`,
      orgId: 'org-rstpl-001',
      employeeCode: code,
      accountHolderName: newEmp.accountHolderName || `${newEmp.firstName} ${newEmp.lastName}`,
      emergencyContact: {
        name: newEmp.emergencyContact?.name || 'Emergency Contact',
        relationship: newEmp.emergencyRelationship || 'Relative',
        phone: newEmp.emergencyContactPhone || newEmp.phone || '+91 99999 99999',
      },
      createdBy: 'HR Administrator',
      createdDate: new Date().toISOString().split('T')[0],
      modifiedBy: 'HR Administrator',
      modifiedDate: new Date().toISOString().split('T')[0],
    };

    onAddEmployee(empToSave);
    setShowAddModal(false);
    onLogAudit('CREATE', 'Employee Master', `Onboarded employee ${empToSave.firstName} ${empToSave.lastName} (${code})`);
  };

  // Export Full Employee Master CSV (Matching Image 1 Specifications exactly)
  const handleExportFullMasterCsv = () => {
    const headers = [
      'S. No.',
      'Employee Code',
      'Employee Name',
      'Father Name',
      'Mother Name',
      'Gender',
      'Marital Status',
      'DOB',
      'DOJ',
      'DOL',
      'Employment Status',
      'Unit Name',
      'Department Name',
      'Sub-Department',
      'Position / Designation',
      'Grade',
      'Reporting Manager',
      'Functional Head / HOD',
      'Mobile No.',
      'Personal Email',
      'Permanent Address',
      'Current Address',
      'City',
      'State',
      'PIN Code',
      'Total Experience (Years)',
      'Relevant Experience (Years)',
      'Aadhaar Card Number',
      'PAN Card Number',
      'UAN Number',
      'PF Number',
      'ESIC Number',
      'Bank Name',
      'Account Holder Name',
      'Account Number',
      'IFSC Code',
      'Branch',
      'Emergency Contact Name',
      'Relationship',
      'Emergency Contact No.',
      'Document 1',
      'Document 2',
      'Document 3',
      'Document 4',
      'Document 5',
      'Document 6',
      'Document 7',
      'Document 8',
      'Document 9',
      'Document 10',
      'Additional Documents',
      'Remarks',
      'Created By',
      'Created Date',
      'Modified By',
      'Modified Date',
    ];

    const rows = employees.map((emp, idx) => {
      const mgr = employees.find(e => e.id === emp.reportingManagerId);
      const mgrText = mgr ? `${mgr.firstName} ${mgr.lastName} (${mgr.employeeCode})` : 'EXECUTIVE BOARD';

      return [
        idx + 1,
        `"${emp.employeeCode}"`,
        `"${emp.firstName} ${emp.lastName}"`,
        `"${emp.fatherName || 'Shri ' + emp.lastName}"`,
        `"${emp.motherName || 'Smt ' + emp.lastName}"`,
        `"${emp.gender}"`,
        `"${emp.maritalStatus}"`,
        `"${emp.dob}"`,
        `"${emp.dateOfJoining}"`,
        `"${emp.dateOfLeaving || '--'}"`,
        `"${emp.status}"`,
        `"${getUnitName(emp.unitId)}"`,
        `"${getDeptName(emp.departmentId)}"`,
        `"${emp.subDepartment || 'Operations & Support'}"`,
        `"${getDesigTitle(emp.designationId)}"`,
        `"${emp.grade || 'L3'}"`,
        `"${mgrText}"`,
        `"${emp.functionalHead || 'Amit Sharma (VP HR)'}"`,
        `"${emp.phone}"`,
        `"${emp.personalEmail || emp.email}"`,
        `"${emp.permanentAddress || emp.address}"`,
        `"${emp.currentAddress || emp.address}"`,
        `"${emp.city || 'Pune'}"`,
        `"${emp.state || 'Maharashtra'}"`,
        `"${emp.pinCode || '411045'}"`,
        emp.totalExperienceYears || 4,
        emp.relevantExperienceYears || 3,
        `"${emp.aadhaarNumber || emp.aadhaarMasked || 'XXXX-XXXX-9921'}"`,
        `"${emp.pan || emp.panNumber || 'ABCDE1234F'}"`,
        `"${emp.uan || emp.uanNumber || '100987654321'}"`,
        `"${emp.pfNumber || 'MH/PUN/0098765/1001'}"`,
        `"${emp.esicNumber || (emp.esicApplicable ? '3100098765' : 'EXEMPT')}"`,
        `"${emp.bankName || 'HDFC Bank Ltd'}"`,
        `"${emp.accountHolderName || emp.firstName + ' ' + emp.lastName}"`,
        `"${emp.bankAccountNumber || '50100987654321'}"`,
        `"${emp.ifscCode || 'HDFC0001234'}"`,
        `"${emp.branchName || 'Baner Main'}"`,
        `"${emp.emergencyContact?.name || 'Family Contact'}"`,
        `"${emp.emergencyContact?.relationship || 'Spouse'}"`,
        `"${emp.emergencyContact?.phone || emp.phone}"`,
        'VERIFIED', // Doc 1 (Aadhaar)
        'VERIFIED', // Doc 2 (PAN)
        'VERIFIED', // Doc 3 (Photo)
        'VERIFIED', // Doc 4 (Bank)
        'VERIFIED', // Doc 5 (Education)
        'VERIFIED', // Doc 6 (Experience)
        'VERIFIED', // Doc 7 (Salary Slip)
        'VERIFIED', // Doc 8 (Address)
        'VERIFIED', // Doc 9 (Joining Letter)
        'VERIFIED', // Doc 10 (Other)
        `"${emp.additionalDocuments || 'NDA, Code of Conduct'}"`,
        `"${emp.remarks || 'Standard Active Personnel'}"`,
        `"${emp.createdBy || 'HR Admin'}"`,
        `"${emp.createdDate || '2026-01-01'}"`,
        `"${emp.modifiedBy || 'HR Admin'}"`,
        `"${emp.modifiedDate || '2026-10-01'}"`,
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `RSTPL_Employee_Master_Image1_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onLogAudit('EXPORT', 'Employee Master', 'Exported complete Image 1 Employee Master Register CSV');
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <Users className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900 tracking-tight">Employee Master Directory</h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
                  Image 1 Full Register
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  45+ Attributes
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Complete personnel master matching Image 1: personal, family, unit & department assignment, statutory and 10 documents
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onNavigateToOrgHierarchy && (
            <button
              type="button"
              onClick={onNavigateToOrgHierarchy}
              className="px-3 py-2 text-xs font-bold text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-xl transition cursor-pointer flex items-center gap-1.5"
            >
              <Network className="w-3.5 h-3.5 text-indigo-600" />
              <span>Org Hierarchy Chart</span>
            </button>
          )}

          {onNavigateToDocuments && (
            <button
              type="button"
              onClick={onNavigateToDocuments}
              className="px-3 py-2 text-xs font-bold text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-xl transition cursor-pointer flex items-center gap-1.5"
            >
              <FolderCheck className="w-3.5 h-3.5 text-purple-600" />
              <span>Documents Master</span>
            </button>
          )}

          {onNavigateToSalary && (
            <button
              type="button"
              onClick={onNavigateToSalary}
              className="px-3 py-2 text-xs font-bold text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-xl transition cursor-pointer flex items-center gap-1.5"
            >
              <CreditCard className="w-3.5 h-3.5 text-sky-600" />
              <span>Salary Master</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleExportFullMasterCsv}
            className="px-3 py-2 text-xs font-bold text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-xl transition cursor-pointer flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            <span>Export Master (Image 1 CSV)</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Onboard New Employee</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3 flex-1">
            <div className="relative flex-1 min-w-56">
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search name, code, email, designation..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
              />
            </div>

            <select
              value={selectedUnit}
              onChange={e => setSelectedUnit(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium text-xs text-slate-800"
            >
              <option value="ALL">All Units / Plants ({units.length})</option>
              {units.map(u => (
                <option key={u.id} value={u.id}>{u.name} ({u.code})</option>
              ))}
            </select>

            <select
              value={selectedDept}
              onChange={e => setSelectedDept(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium text-xs text-slate-800"
            >
              <option value="ALL">All Departments ({departments.length})</option>
              {departments.map(d => (
                <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
              ))}
            </select>

            <select
              value={selectedStatus}
              onChange={e => setSelectedStatus(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-medium text-xs text-slate-800"
            >
              <option value="ALL">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Probation">Probation</option>
              <option value="Notice Period">Notice Period</option>
              <option value="Resigned">Resigned</option>
            </select>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs">
            <button
              type="button"
              onClick={() => setViewMode('full-register')}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'full-register'
                  ? 'bg-white text-sky-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <TableProperties className="w-3.5 h-3.5 text-sky-700" />
              <span>Full Master Register (Image 1)</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'cards'
                  ? 'bg-white text-sky-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5 text-slate-700" />
              <span>Directory Cards</span>
            </button>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>Showing <strong>{filteredEmployees.length}</strong> of {employees.length} personnel in Master</span>
          <span className="text-[11px] text-slate-400">All data automatically linked to Organization Hierarchy & Salary Master</span>
        </div>
      </div>

      {/* FULL MASTER REGISTER TABLE (IMAGE 1 SPECIFICATION) */}
      {viewMode === 'full-register' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-xs font-black uppercase text-slate-900 tracking-wider">
              Employee Master Comprehensive Register (Image 1 Columns)
            </h3>
            <span className="text-[10px] font-mono text-slate-400">Horizontal scroll enabled for all 45+ columns</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-900 text-white font-bold uppercase text-[10px] tracking-wider whitespace-nowrap">
                <tr>
                  <th className="py-3 px-3">S. No.</th>
                  <th className="py-3 px-3">Employee Code</th>
                  <th className="py-3 px-3">Employee Name</th>
                  <th className="py-3 px-3">Father Name</th>
                  <th className="py-3 px-3">Mother Name</th>
                  <th className="py-3 px-3">Gender</th>
                  <th className="py-3 px-3">Marital Status</th>
                  <th className="py-3 px-3">DOB</th>
                  <th className="py-3 px-3">DOJ</th>
                  <th className="py-3 px-3">DOL</th>
                  <th className="py-3 px-3">Employment Status</th>
                  <th className="py-3 px-3 bg-sky-950 text-sky-300">Unit Name</th>
                  <th className="py-3 px-3 bg-sky-950 text-sky-300">Department Name</th>
                  <th className="py-3 px-3 bg-sky-950 text-sky-300">Sub-Department</th>
                  <th className="py-3 px-3 bg-sky-950 text-sky-300">Position / Designation</th>
                  <th className="py-3 px-3 bg-sky-950 text-sky-300">Grade</th>
                  <th className="py-3 px-3 bg-sky-950 text-amber-300">Assigned Shift</th>
                  <th className="py-3 px-3 bg-indigo-950 text-indigo-300">Reporting Manager</th>
                  <th className="py-3 px-3 bg-indigo-950 text-indigo-300">Functional Head / HOD</th>
                  <th className="py-3 px-3">Mobile No.</th>
                  <th className="py-3 px-3">Personal Email</th>
                  <th className="py-3 px-3">Permanent Address</th>
                  <th className="py-3 px-3">Current Address</th>
                  <th className="py-3 px-3">City</th>
                  <th className="py-3 px-3">State</th>
                  <th className="py-3 px-3">PIN Code</th>
                  <th className="py-3 px-3">Total Experience (Years)</th>
                  <th className="py-3 px-3">Relevant Experience (Years)</th>
                  <th className="py-3 px-3 bg-purple-950 text-purple-300">Aadhaar Card Number</th>
                  <th className="py-3 px-3 bg-purple-950 text-purple-300">PAN Card Number</th>
                  <th className="py-3 px-3 bg-purple-950 text-purple-300">UAN Number</th>
                  <th className="py-3 px-3 bg-purple-950 text-purple-300">PF Number</th>
                  <th className="py-3 px-3 bg-purple-950 text-purple-300">ESIC Number</th>
                  <th className="py-3 px-3 bg-emerald-950 text-emerald-300">Bank Name</th>
                  <th className="py-3 px-3 bg-emerald-950 text-emerald-300">Account Holder Name</th>
                  <th className="py-3 px-3 bg-emerald-950 text-emerald-300">Account Number</th>
                  <th className="py-3 px-3 bg-emerald-950 text-emerald-300">IFSC Code</th>
                  <th className="py-3 px-3 bg-emerald-950 text-emerald-300">Branch</th>
                  <th className="py-3 px-3">Emergency Contact Name</th>
                  <th className="py-3 px-3">Relationship</th>
                  <th className="py-3 px-3">Emergency Contact No.</th>
                  <th className="py-3 px-3 text-center">Docs (1-10)</th>
                  <th className="py-3 px-3">Additional Documents</th>
                  <th className="py-3 px-3">Remarks</th>
                  <th className="py-3 px-3">Created By</th>
                  <th className="py-3 px-3">Created Date</th>
                  <th className="py-3 px-3">Modified By</th>
                  <th className="py-3 px-3">Modified Date</th>
                  <th className="py-3 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-700 whitespace-nowrap">
                {filteredEmployees.map((emp, idx) => (
                  <tr key={emp.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-2.5 px-3 font-mono text-slate-400 text-center">{idx + 1}</td>
                    <td className="py-2.5 px-3 font-mono font-bold text-sky-700">{emp.employeeCode}</td>
                    <td className="py-2.5 px-3 font-bold text-slate-900">{emp.firstName} {emp.lastName}</td>
                    <td className="py-2.5 px-3">{emp.fatherName || 'Shri ' + emp.lastName}</td>
                    <td className="py-2.5 px-3">{emp.motherName || 'Smt ' + emp.lastName}</td>
                    <td className="py-2.5 px-3">{emp.gender}</td>
                    <td className="py-2.5 px-3">{emp.maritalStatus}</td>
                    <td className="py-2.5 px-3 font-mono text-[11px]">{emp.dob}</td>
                    <td className="py-2.5 px-3 font-mono text-[11px]">{emp.dateOfJoining}</td>
                    <td className="py-2.5 px-3 font-mono text-[11px]">{emp.dateOfLeaving || '--'}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        {emp.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 bg-sky-50/50 font-semibold">{getUnitName(emp.unitId)}</td>
                    <td className="py-2.5 px-3 bg-sky-50/50">{getDeptName(emp.departmentId)}</td>
                    <td className="py-2.5 px-3 bg-sky-50/50">{emp.subDepartment || 'Operations'}</td>
                    <td className="py-2.5 px-3 bg-sky-50/50 font-bold text-slate-900">{getDesigTitle(emp.designationId)}</td>
                    <td className="py-2.5 px-3 bg-sky-50/50 font-mono font-bold text-purple-700">{emp.grade || 'L3'}</td>
                    <td className="py-2.5 px-3 bg-sky-50/50">
                      <div className="flex items-center gap-1.5">
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: getShiftObj(emp.shiftId)?.color || '#0284c7' }}
                        />
                        <span className="font-bold text-[11px] text-slate-800">
                          {getShiftObj(emp.shiftId)?.code || 'GEN-01'}
                        </span>
                      </div>
                      <span className="text-[9px] text-slate-400 font-mono">
                        {getShiftObj(emp.shiftId)?.startTime}–{getShiftObj(emp.shiftId)?.endTime}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 bg-indigo-50/50">{getManagerName(emp.reportingManagerId)}</td>
                    <td className="py-2.5 px-3 bg-indigo-50/50">{emp.functionalHead || 'Amit Sharma (VP HR)'}</td>
                    <td className="py-2.5 px-3 font-mono">{emp.phone}</td>
                    <td className="py-2.5 px-3">{emp.personalEmail || emp.email}</td>
                    <td className="py-2.5 px-3 max-w-44 truncate">{emp.permanentAddress || emp.address}</td>
                    <td className="py-2.5 px-3 max-w-44 truncate">{emp.currentAddress || emp.address}</td>
                    <td className="py-2.5 px-3">{emp.city || 'Pune'}</td>
                    <td className="py-2.5 px-3">{emp.state || 'Maharashtra'}</td>
                    <td className="py-2.5 px-3 font-mono">{emp.pinCode || '411045'}</td>
                    <td className="py-2.5 px-3 text-center">{emp.totalExperienceYears || 4}</td>
                    <td className="py-2.5 px-3 text-center">{emp.relevantExperienceYears || 3}</td>
                    <td className="py-2.5 px-3 font-mono bg-purple-50/40">{emp.aadhaarNumber || emp.aadhaarMasked || 'XXXX-XXXX-9921'}</td>
                    <td className="py-2.5 px-3 font-mono bg-purple-50/40">{emp.pan || emp.panNumber || 'ABCDE1234F'}</td>
                    <td className="py-2.5 px-3 font-mono bg-purple-50/40">{emp.uan || emp.uanNumber || '100987654321'}</td>
                    <td className="py-2.5 px-3 font-mono bg-purple-50/40">{emp.pfNumber || 'MH/PUN/0098765/1001'}</td>
                    <td className="py-2.5 px-3 font-mono bg-purple-50/40">{emp.esicNumber || (emp.esicApplicable ? '3100098765' : 'EXEMPT')}</td>
                    <td className="py-2.5 px-3 bg-emerald-50/40 font-semibold">{emp.bankName || 'HDFC Bank Ltd'}</td>
                    <td className="py-2.5 px-3 bg-emerald-50/40">{emp.accountHolderName || `${emp.firstName} ${emp.lastName}`}</td>
                    <td className="py-2.5 px-3 font-mono bg-emerald-50/40">{emp.bankAccountNumber || '50100987654321'}</td>
                    <td className="py-2.5 px-3 font-mono bg-emerald-50/40">{emp.ifscCode || 'HDFC0001234'}</td>
                    <td className="py-2.5 px-3 bg-emerald-50/40">{emp.branchName || 'Baner Tech'}</td>
                    <td className="py-2.5 px-3">{emp.emergencyContact?.name || 'Family Contact'}</td>
                    <td className="py-2.5 px-3">{emp.emergencyContact?.relationship || 'Spouse'}</td>
                    <td className="py-2.5 px-3 font-mono">{emp.emergencyContact?.phone || emp.phone}</td>
                    <td className="py-2.5 px-3 text-center">
                      <span className="px-2 py-0.5 rounded font-mono text-[10px] font-bold bg-purple-100 text-purple-800">
                        10/10 Verified
                      </span>
                    </td>
                    <td className="py-2.5 px-3">{emp.additionalDocuments || 'NDA Signed'}</td>
                    <td className="py-2.5 px-3 max-w-44 truncate">{emp.remarks || 'Standard Active'}</td>
                    <td className="py-2.5 px-3 text-slate-400">{emp.createdBy || 'HR Admin'}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-400">{emp.createdDate || '2026-01-01'}</td>
                    <td className="py-2.5 px-3 text-slate-400">{emp.modifiedBy || 'HR Admin'}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-400">{emp.modifiedDate || '2026-10-01'}</td>
                    <td className="py-2.5 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => setViewingEmployee(emp)}
                        className="px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700 hover:bg-sky-100 font-bold text-[11px] transition cursor-pointer"
                      >
                        View Profile
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* DIRECTORY CARDS VIEW */}
      {viewMode === 'cards' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredEmployees.map(emp => (
            <div
              key={emp.id}
              onClick={() => setViewingEmployee(emp)}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-sky-300 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-sky-700 to-indigo-800 text-white flex items-center justify-center font-bold text-base shadow-xs">
                      {emp.firstName[0]}{emp.lastName[0]}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm">
                        {emp.firstName} {emp.lastName}
                      </h3>
                      <p className="text-[11px] font-mono text-sky-700 font-semibold">{emp.employeeCode}</p>
                    </div>
                  </div>

                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                    {emp.status}
                  </span>
                </div>

                <div className="mt-4 space-y-1.5 text-xs text-slate-600">
                  <div className="flex items-center gap-2">
                    <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-medium text-slate-800">{getDesigTitle(emp.designationId)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Building className="w-3.5 h-3.5 text-slate-400" />
                    <span>{getUnitName(emp.unitId)} · {getDeptName(emp.departmentId)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span className="truncate">{emp.email}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{emp.phone}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-500 font-medium">Grade {emp.grade || 'L3'}</span>
                <span className="text-sky-600 font-bold flex items-center gap-0.5 text-[11px]">
                  View 360° Profile <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 360 Degree Profile Modal */}
      {viewingEmployee && (
        <div className="fixed inset-0 z-50 flex items-center justify-end bg-slate-950/40 backdrop-blur-xs">
          <div className="bg-white h-full max-w-xl w-full p-6 shadow-2xl overflow-y-auto border-l border-slate-200 flex flex-col justify-between">
            <div className="space-y-6">
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-sky-700 text-white flex items-center justify-center font-bold text-lg">
                    {viewingEmployee.firstName[0]}{viewingEmployee.lastName[0]}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-base">
                      {viewingEmployee.firstName} {viewingEmployee.lastName}
                    </h3>
                    <p className="text-xs text-sky-700 font-mono font-bold">
                      {viewingEmployee.employeeCode} · {getDesigTitle(viewingEmployee.designationId)}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setViewingEmployee(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Personal & Family Information (Image 1) */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Personal & Family Information</h4>
                <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-100">
                  <div><span className="text-slate-400">Father Name:</span> <strong className="text-slate-800">{viewingEmployee.fatherName || 'Shri ' + viewingEmployee.lastName}</strong></div>
                  <div><span className="text-slate-400">Mother Name:</span> <strong className="text-slate-800">{viewingEmployee.motherName || 'Smt ' + viewingEmployee.lastName}</strong></div>
                  <div><span className="text-slate-400">Gender:</span> <strong className="text-slate-800">{viewingEmployee.gender}</strong></div>
                  <div><span className="text-slate-400">DOB:</span> <strong className="text-slate-800">{viewingEmployee.dob}</strong></div>
                  <div><span className="text-slate-400">Marital Status:</span> <strong className="text-slate-800">{viewingEmployee.maritalStatus}</strong></div>
                  <div><span className="text-slate-400">Personal Email:</span> <strong className="text-slate-800">{viewingEmployee.personalEmail || viewingEmployee.email}</strong></div>
                  <div className="col-span-2"><span className="text-slate-400">Permanent Address:</span> <p className="text-slate-800 mt-0.5">{viewingEmployee.permanentAddress || viewingEmployee.address}</p></div>
                  <div className="col-span-2"><span className="text-slate-400">Emergency Contact:</span> <p className="text-slate-800 mt-0.5">{viewingEmployee.emergencyContact?.name} ({viewingEmployee.emergencyContact?.relationship}) · {viewingEmployee.emergencyContact?.phone}</p></div>
                </div>
              </div>

              {/* Employment & Assignment Details */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Unit & Department Assignment</h4>
                <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-100">
                  <div><span className="text-slate-400">Assigned Unit:</span> <strong className="text-slate-800">{getUnitName(viewingEmployee.unitId)}</strong></div>
                  <div><span className="text-slate-400">Department:</span> <strong className="text-slate-800">{getDeptName(viewingEmployee.departmentId)}</strong></div>
                  <div><span className="text-slate-400">Sub-Department:</span> <strong className="text-slate-800">{viewingEmployee.subDepartment || 'Operations'}</strong></div>
                  <div><span className="text-slate-400">Position:</span> <strong className="text-slate-800">{getDesigTitle(viewingEmployee.designationId)}</strong></div>
                  <div><span className="text-slate-400">Grade:</span> <strong className="text-purple-700 font-bold">{viewingEmployee.grade || 'L3'}</strong></div>
                  <div><span className="text-slate-400">Reporting Manager:</span> <strong className="text-slate-800">{getManagerName(viewingEmployee.reportingManagerId)}</strong></div>
                  <div><span className="text-slate-400">Joining Date:</span> <strong className="text-slate-800">{viewingEmployee.dateOfJoining}</strong></div>
                  <div><span className="text-slate-400">Status:</span> <strong className="text-emerald-700">{viewingEmployee.status}</strong></div>
                </div>
              </div>

              {/* Statutory & Banking Details */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Statutory & Bank Compliance</h4>
                <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-100">
                  <div><span className="text-slate-400">PAN Number:</span> <strong className="font-mono text-slate-800">{viewingEmployee.pan || viewingEmployee.panNumber || 'ABCDE1234F'}</strong></div>
                  <div><span className="text-slate-400">Aadhaar:</span> <strong className="font-mono text-slate-800">{viewingEmployee.aadhaarNumber || viewingEmployee.aadhaarMasked || 'XXXX-XXXX-9921'}</strong></div>
                  <div><span className="text-slate-400">UAN:</span> <strong className="font-mono text-slate-800">{viewingEmployee.uan || '100987654321'}</strong></div>
                  <div><span className="text-slate-400">PF Number:</span> <strong className="font-mono text-slate-800">{viewingEmployee.pfNumber || 'MH/PUN/0098765/1001'}</strong></div>
                  <div><span className="text-slate-400">ESIC Number:</span> <strong className="font-mono text-slate-800">{viewingEmployee.esicNumber || '31000987650001001'}</strong></div>
                  <div><span className="text-slate-400">Bank Name:</span> <strong className="text-slate-800">{viewingEmployee.bankName}</strong></div>
                  <div><span className="text-slate-400">Account No:</span> <strong className="font-mono text-slate-800">{viewingEmployee.bankAccountNumber}</strong></div>
                  <div><span className="text-slate-400">IFSC Code:</span> <strong className="font-mono text-slate-800">{viewingEmployee.ifscCode}</strong></div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setViewingEmployee(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 font-bold text-slate-700 hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Onboard New Employee Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-sky-700" />
                <h4 className="text-xs font-black uppercase text-slate-900">
                  Onboard New Employee (Image 1 Full Master Schema)
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateEmployee} className="p-5 space-y-4 text-xs overflow-y-auto flex-1">
              <div className="font-bold text-slate-800 text-[11px] uppercase tracking-wider pb-1 border-b border-slate-100">
                1. Basic & Family Details
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-600 mb-1">First Name *</label>
                  <input
                    type="text"
                    required
                    value={newEmp.firstName}
                    onChange={e => setNewEmp({ ...newEmp, firstName: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={newEmp.lastName}
                    onChange={e => setNewEmp({ ...newEmp, lastName: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Father Name</label>
                  <input
                    type="text"
                    value={newEmp.fatherName}
                    onChange={e => setNewEmp({ ...newEmp, fatherName: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Mother Name</label>
                  <input
                    type="text"
                    value={newEmp.motherName}
                    onChange={e => setNewEmp({ ...newEmp, motherName: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Gender</label>
                  <select
                    value={newEmp.gender}
                    onChange={e => setNewEmp({ ...newEmp, gender: e.target.value as any })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Marital Status</label>
                  <select
                    value={newEmp.maritalStatus}
                    onChange={e => setNewEmp({ ...newEmp, maritalStatus: e.target.value as any })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                    <option value="Divorced">Divorced</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Date of Birth</label>
                  <input
                    type="date"
                    value={newEmp.dob}
                    onChange={e => setNewEmp({ ...newEmp, dob: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Mobile No. *</label>
                  <input
                    type="text"
                    required
                    value={newEmp.phone}
                    onChange={e => setNewEmp({ ...newEmp, phone: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Official Email *</label>
                  <input
                    type="email"
                    required
                    value={newEmp.email}
                    onChange={e => setNewEmp({ ...newEmp, email: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="font-bold text-slate-800 text-[11px] uppercase tracking-wider pt-2 pb-1 border-b border-slate-100">
                2. Organizational Unit, Department & Position
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-600 mb-1">Operating Unit *</label>
                  <select
                    value={newEmp.unitId}
                    onChange={e => setNewEmp({ ...newEmp, unitId: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  >
                    {units.map(u => (
                      <option key={u.id} value={u.id}>{u.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 mb-1">Department *</label>
                  <select
                    value={newEmp.departmentId}
                    onChange={e => setNewEmp({ ...newEmp, departmentId: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  >
                    {departments.map(d => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 mb-1">Designation / Position *</label>
                  <select
                    value={newEmp.designationId}
                    onChange={e => setNewEmp({ ...newEmp, designationId: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  >
                    {designations.map(d => (
                      <option key={d.id} value={d.id}>{d.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 mb-1">Hierarchy Grade</label>
                  <select
                    value={newEmp.grade}
                    onChange={e => setNewEmp({ ...newEmp, grade: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-bold font-mono"
                  >
                    <option value="L7">L7 (HOD / VP / GM)</option>
                    <option value="L5">L5 (Manager / Specialist)</option>
                    <option value="L4">L4 (Lead Engineer / Officer)</option>
                    <option value="L3">L3 (Senior Associate)</option>
                    <option value="L1">L1 (Technician / Line Staff)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 mb-1">Assigned Shift *</label>
                  <select
                    value={newEmp.shiftId}
                    onChange={e => setNewEmp({ ...newEmp, shiftId: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sky-800"
                  >
                    {shifts.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.code}: {s.startTime} - {s.endTime})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 mb-1">Reporting Manager</label>
                  <select
                    value={newEmp.reportingManagerId}
                    onChange={e => setNewEmp({ ...newEmp, reportingManagerId: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="">Executive Board (Top-Level)</option>
                    {employees.map(m => (
                      <option key={m.id} value={m.id}>{m.firstName} {m.lastName} ({m.employeeCode})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 mb-1">Date of Joining</label>
                  <input
                    type="date"
                    value={newEmp.dateOfJoining}
                    onChange={e => setNewEmp({ ...newEmp, dateOfJoining: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="font-bold text-slate-800 text-[11px] uppercase tracking-wider pt-2 pb-1 border-b border-slate-100">
                3. Banking & Statutory Numbers
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-600 mb-1">Bank Name</label>
                  <input
                    type="text"
                    value={newEmp.bankName}
                    onChange={e => setNewEmp({ ...newEmp, bankName: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Account Number</label>
                  <input
                    type="text"
                    value={newEmp.bankAccountNumber}
                    onChange={e => setNewEmp({ ...newEmp, bankAccountNumber: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">IFSC Code</label>
                  <input
                    type="text"
                    value={newEmp.ifscCode}
                    onChange={e => setNewEmp({ ...newEmp, ifscCode: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">PAN Card Number</label>
                  <input
                    type="text"
                    value={newEmp.pan}
                    onChange={e => setNewEmp({ ...newEmp, pan: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    placeholder="ABCDE1234F"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Aadhaar Number</label>
                  <input
                    type="text"
                    value={newEmp.aadhaarMasked}
                    onChange={e => setNewEmp({ ...newEmp, aadhaarMasked: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                    placeholder="XXXX-XXXX-1234"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">UAN Number</label>
                  <input
                    type="text"
                    value={newEmp.uan}
                    onChange={e => setNewEmp({ ...newEmp, uan: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold cursor-pointer shadow-xs"
                >
                  Save & Create Employee Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

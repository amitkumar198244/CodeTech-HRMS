// RSTPL HRMS - Company Hardware & Asset Management
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  Laptop,
  Plus,
  CheckCircle2,
  AlertCircle,
  Search,
  Check,
  X,
  Shield
} from 'lucide-react';
import { AssetRecord, Employee } from '../../types/hrms';

interface AssetManagementViewProps {
  employees: Employee[];
  onLogAudit: (action: any, module: string, details: string) => void;
}

const INITIAL_ASSETS: AssetRecord[] = [
  {
    id: 'ast-01',
    orgId: 'org-rstpl-001',
    assetTag: 'RST-NB-2024-081',
    name: 'Dell Latitude 5440 i7 16GB / 512GB NVMe',
    category: 'Laptop',
    serialNumber: 'CN-0K791X-72872-47J-0043',
    assignedToEmployeeId: 'emp-001',
    assignedToName: 'Amit Sharma (VP HR)',
    assignedDate: '2024-04-10',
    condition: 'Good',
    status: 'Allocated',
  },
  {
    id: 'ast-02',
    orgId: 'org-rstpl-001',
    assetTag: 'RST-NB-2024-089',
    name: 'ThinkPad T14 Gen 4 Ryzen 7',
    category: 'Laptop',
    serialNumber: 'PF-3X990L-8841',
    assignedToEmployeeId: 'emp-005',
    assignedToName: 'Vikram Singhania (IT Admin)',
    assignedDate: '2024-05-18',
    condition: 'Brand New',
    status: 'Allocated',
  },
  {
    id: 'ast-03',
    orgId: 'org-rstpl-001',
    assetTag: 'RST-TAB-2025-012',
    name: 'Samsung Galaxy Tab Active4 Pro (Rugged Shopfloor Terminal)',
    category: 'Mobile Device',
    serialNumber: 'R52N9014X2A',
    assignedToEmployeeId: 'emp-003',
    assignedToName: 'Rajesh Patil (Plant Head)',
    assignedDate: '2025-01-15',
    condition: 'Good',
    status: 'Allocated',
  },
];

export const AssetManagementView: React.FC<AssetManagementViewProps> = ({ employees, onLogAudit }) => {
  const [assets, setAssets] = useState<AssetRecord[]>(INITIAL_ASSETS);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <Laptop className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">IT Hardware & Asset Management</h2>
              <p className="text-xs text-slate-500">
                Company laptops, ruggedized plant tablets, biometric access cards & equipment life-cycle tracking
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Assets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {assets.map(asset => (
          <div key={asset.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-sky-100 text-sky-800">
                  {asset.assetTag}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  {asset.status}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 mt-2">{asset.name}</h3>
              <p className="text-xs text-slate-500 font-mono mt-0.5">S/N: {asset.serialNumber}</p>

              <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Assigned To:</span>
                  <strong className="text-slate-900">{asset.assignedToName}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Allocation Date:</span>
                  <span className="font-mono">{asset.assignedDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Condition:</span>
                  <span className="text-emerald-700 font-medium">{asset.condition}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

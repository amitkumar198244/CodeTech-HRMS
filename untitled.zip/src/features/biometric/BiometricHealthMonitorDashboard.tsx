// RSTPL HRMS - Biometric Health Monitor Dashboard
// RS Technovisions XpertSkillCop
// Real-time daily punch frequency trends and device connectivity heartbeat monitoring

import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts';
import {
  Activity,
  HeartPulse,
  Radio,
  Wifi,
  WifiOff,
  Zap,
  Clock,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Server,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  Cpu,
  ShieldCheck,
  ShieldAlert,
  Gauge,
  Sliders,
  Play,
  RotateCcw,
  Sparkles,
  Info
} from 'lucide-react';
import { BiometricDevice, RawPunch, Employee } from '../../types/hrms';

interface BiometricHealthMonitorDashboardProps {
  devices: BiometricDevice[];
  rawPunches: RawPunch[];
  employees: Employee[];
  onUpdateDevices: (devices: BiometricDevice[]) => void;
  onUpdateRawPunches?: (punches: RawPunch[]) => void;
  onLogAudit?: (action: any, module: string, details: string) => void;
  onNavigate?: (module: string) => void;
}

// Error Boundary for Recharts resilience
interface ChartErrorBoundaryProps {
  children: React.ReactNode;
  fallback: React.ReactNode;
}

interface ChartErrorBoundaryState {
  hasError: boolean;
}

class ChartErrorBoundary extends React.Component<ChartErrorBoundaryProps, ChartErrorBoundaryState> {
  constructor(props: ChartErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    console.warn('Recharts render issue caught by boundary in BiometricHealthMonitor:', error);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

// SVG Fallback for Punch Frequency Trends
const SvgPunchFrequencyFallback: React.FC<{
  data: { timeLabel: string; total: number; inPunches: number; outPunches: number }[];
}> = ({ data }) => {
  const width = 640;
  const height = 240;
  const padding = { top: 20, right: 20, bottom: 35, left: 35 };
  const innerW = width - padding.left - padding.right;
  const innerH = height - padding.top - padding.bottom;

  const maxVal = Math.max(...data.map(d => d.total), 10);
  const barWidth = Math.max(8, innerW / (data.length * 1.5));

  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-2 bg-slate-50/50 rounded-xl">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full max-h-64">
        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((ratio, idx) => {
          const y = padding.top + innerH * ratio;
          return (
            <line
              key={idx}
              x1={padding.left}
              y1={y}
              x2={width - padding.right}
              y2={y}
              stroke="#e2e8f0"
              strokeDasharray="3 3"
            />
          );
        })}

        {/* Bars */}
        {data.map((d, i) => {
          const x = padding.left + (i / data.length) * innerW + (innerW / data.length - barWidth) / 2;
          const h = (d.total / maxVal) * innerH;
          const y = padding.top + innerH - h;
          const inH = (d.inPunches / maxVal) * innerH;
          const inY = padding.top + innerH - inH;

          return (
            <g key={i} className="group cursor-pointer">
              {/* Total Bar */}
              <rect
                x={x}
                y={y}
                width={barWidth}
                height={Math.max(2, h)}
                rx={3}
                fill="#0284c7"
                opacity={0.8}
              />
              {/* IN Component Bar */}
              <rect
                x={x}
                y={inY}
                width={barWidth}
                height={Math.max(2, inH)}
                rx={3}
                fill="#10b981"
              />
              <text
                x={x + barWidth / 2}
                y={height - 12}
                textAnchor="middle"
                fontSize={9}
                fill="#64748b"
                fontWeight="500"
              >
                {d.timeLabel}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
};

// SVG Fallback for Heartbeat Latency
const SvgHeartbeatFallback: React.FC<{
  data: { cycleLabel: string; [key: string]: number | string }[];
  deviceIds: string[];
}> = ({ data, deviceIds }) => {
  const width = 640;
  const height = 240;
  const padding = { top: 20, right: 20, bottom: 35, left: 40 };
  const innerW = width - padding.left - padding.right;
  const innerH = height - padding.top - padding.bottom;
  const maxLat = 250;

  const colors = ['#10b981', '#0284c7', '#f59e0b', '#8b5cf6'];

  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-2 bg-slate-50/50 rounded-xl">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full max-h-64">
        {/* SLA reference line 150ms */}
        <line
          x1={padding.left}
          y1={padding.top + innerH * (1 - 150 / maxLat)}
          x2={width - padding.right}
          y2={padding.top + innerH * (1 - 150 / maxLat)}
          stroke="#0284c7"
          strokeDasharray="4 4"
          strokeWidth={1.5}
        />
        <text
          x={width - padding.right}
          y={padding.top + innerH * (1 - 150 / maxLat) - 4}
          textAnchor="end"
          fontSize={8}
          fill="#0284c7"
          fontWeight="bold"
        >
          SLA 150ms
        </text>

        {/* Lines for each device */}
        {deviceIds.map((devId, dIdx) => {
          const points = data
            .map((d, i) => {
              const x = padding.left + (i / Math.max(1, data.length - 1)) * innerW;
              const val = typeof d[devId] === 'number' ? (d[devId] as number) : 45;
              const y = padding.top + innerH * (1 - Math.min(maxLat, val) / maxLat);
              return `${x},${y}`;
            })
            .join(' ');

          return (
            <polyline
              key={devId}
              points={points}
              fill="none"
              stroke={colors[dIdx % colors.length]}
              strokeWidth={2}
            />
          );
        })}
      </svg>
    </div>
  );
};

export const BiometricHealthMonitorDashboard: React.FC<BiometricHealthMonitorDashboardProps> = ({
  devices,
  rawPunches,
  employees,
  onUpdateDevices,
  onUpdateRawPunches,
  onLogAudit,
  onNavigate,
}) => {
  // Navigation / Filter States
  const [frequencyViewMode, setFrequencyViewMode] = useState<'hourly' | 'daily'>('hourly');
  const [heartbeatViewFilter, setHeartbeatViewFilter] = useState<'all' | string>('all');
  const [isAutoProbing, setIsAutoProbing] = useState<boolean>(true);
  const [probeCountdown, setProbeCountdown] = useState<number>(15);
  const [isProbingFleet, setIsProbingFleet] = useState<boolean>(false);
  const [probingDeviceId, setProbingDeviceId] = useState<string | null>(null);
  const [lastProbeTimestamp, setLastProbeTimestamp] = useState<Date>(new Date());
  const [auditMessage, setAuditMessage] = useState<string | null>(null);

  // Rolling latency timeline data points (last 10 heartbeat handshake cycles)
  const [heartbeatTimeline, setHeartbeatTimeline] = useState<Array<{
    cycleLabel: string;
    timestamp: string;
    'dev-001': number;
    'dev-002': number;
    'dev-003': number;
    'dev-004': number;
    fleetAvg: number;
  }>>([
    { cycleLabel: '10m ago', timestamp: '10:45', 'dev-001': 42, 'dev-002': 68, 'dev-003': 142, 'dev-004': 32, fleetAvg: 71 },
    { cycleLabel: '9m ago',  timestamp: '10:46', 'dev-001': 45, 'dev-002': 72, 'dev-003': 148, 'dev-004': 34, fleetAvg: 75 },
    { cycleLabel: '8m ago',  timestamp: '10:47', 'dev-001': 44, 'dev-002': 70, 'dev-003': 155, 'dev-004': 30, fleetAvg: 75 },
    { cycleLabel: '7m ago',  timestamp: '10:48', 'dev-001': 46, 'dev-002': 75, 'dev-003': 150, 'dev-004': 35, fleetAvg: 76 },
    { cycleLabel: '6m ago',  timestamp: '10:49', 'dev-001': 43, 'dev-002': 71, 'dev-003': 145, 'dev-004': 33, fleetAvg: 73 },
    { cycleLabel: '5m ago',  timestamp: '10:50', 'dev-001': 48, 'dev-002': 78, 'dev-003': 160, 'dev-004': 38, fleetAvg: 81 },
    { cycleLabel: '4m ago',  timestamp: '10:51', 'dev-001': 46, 'dev-002': 74, 'dev-003': 152, 'dev-004': 36, fleetAvg: 77 },
    { cycleLabel: '3m ago',  timestamp: '10:52', 'dev-001': 45, 'dev-002': 76, 'dev-003': 154, 'dev-004': 35, fleetAvg: 78 },
    { cycleLabel: '2m ago',  timestamp: '10:53', 'dev-001': 47, 'dev-002': 73, 'dev-003': 149, 'dev-004': 37, fleetAvg: 76 },
    { cycleLabel: 'Just now',timestamp: '10:54', 'dev-001': 46, 'dev-002': 74, 'dev-003': 152, 'dev-004': 36, fleetAvg: 77 },
  ]);

  // Automated 15-second probe countdown timer
  useEffect(() => {
    if (!isAutoProbing) return;

    const interval = setInterval(() => {
      setProbeCountdown(prev => {
        if (prev <= 1) {
          triggerFleetHeartbeatProbe(true);
          return 15;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isAutoProbing, devices]);

  // Trigger fleet heartbeat probe
  const triggerFleetHeartbeatProbe = (isAutomated = false) => {
    setIsProbingFleet(true);

    setTimeout(() => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      // Calculate jitter for each device
      const updatedDevices = devices.map(dev => {
        if (dev.status === 'Offline') return dev;
        const base = dev.vendor === 'eSSL' ? 46 : dev.vendor === 'ZKTeco' ? 74 : dev.vendor === 'Matrix' ? 152 : 36;
        const jitter = Math.floor(Math.random() * 14) - 7;
        const newLat = Math.max(22, base + jitter);
        return {
          ...dev,
          syncLatencyMs: newLat,
          lastSyncAt: now.toISOString(),
          status: 'Online' as const,
        };
      });

      onUpdateDevices(updatedDevices);

      // Append new heartbeat data point
      const dev1Lat = updatedDevices.find(d => d.id === 'dev-001')?.syncLatencyMs ?? 46;
      const dev2Lat = updatedDevices.find(d => d.id === 'dev-002')?.syncLatencyMs ?? 74;
      const dev3Lat = updatedDevices.find(d => d.id === 'dev-003')?.syncLatencyMs ?? 152;
      const dev4Lat = updatedDevices.find(d => d.id === 'dev-004')?.syncLatencyMs ?? 36;
      const avg = Math.round((dev1Lat + dev2Lat + dev3Lat + dev4Lat) / 4);

      setHeartbeatTimeline(prev => [
        ...prev.slice(-9),
        {
          cycleLabel: 'Just now',
          timestamp: timeStr,
          'dev-001': dev1Lat,
          'dev-002': dev2Lat,
          'dev-003': dev3Lat,
          'dev-004': dev4Lat,
          fleetAvg: avg,
        },
      ]);

      setLastProbeTimestamp(now);
      setIsProbingFleet(false);

      if (!isAutomated) {
        setAuditMessage('Fleet heartbeat probe complete. All 4 terminals acknowledged heartbeat.');
        setTimeout(() => setAuditMessage(null), 3500);
        if (onLogAudit) {
          onLogAudit('SYNC', 'Biometric Health Monitor', `Admin executed manual fleet heartbeat probe across ${devices.length} terminals`);
        }
      }
    }, 450);
  };

  // Test individual terminal heartbeat probe
  const handleProbeSingleDevice = (deviceId: string) => {
    setProbingDeviceId(deviceId);

    setTimeout(() => {
      const dev = devices.find(d => d.id === deviceId);
      if (!dev) {
        setProbingDeviceId(null);
        return;
      }

      const base = dev.vendor === 'eSSL' ? 46 : dev.vendor === 'ZKTeco' ? 74 : dev.vendor === 'Matrix' ? 152 : 36;
      const jitter = Math.floor(Math.random() * 12) - 6;
      const newLat = Math.max(20, base + jitter);

      const updated = devices.map(d =>
        d.id === deviceId
          ? { ...d, syncLatencyMs: newLat, lastSyncAt: new Date().toISOString(), status: 'Online' as const }
          : d
      );
      onUpdateDevices(updated);
      setProbingDeviceId(null);

      setAuditMessage(`Probe on ${dev.name}: ${newLat}ms handshake verified`);
      setTimeout(() => setAuditMessage(null), 3000);

      if (onLogAudit) {
        onLogAudit('SYNC', 'Biometric Health Monitor', `Single terminal diagnostic probe on ${dev.name} (${dev.ipAddress}): ${newLat}ms`);
      }
    }, 380);
  };

  // Diagnostic Test: Simulate Latency Spike (>500ms SLA alert)
  const handleSimulateLatencySpike = () => {
    const spikeLat = 620;
    const target = devices.find(d => d.id === 'dev-003') || devices[0];
    const updated = devices.map(d =>
      d.id === target.id ? { ...d, syncLatencyMs: spikeLat } : d
    );
    onUpdateDevices(updated);

    setHeartbeatTimeline(prev => [
      ...prev.slice(-9),
      {
        cycleLabel: 'Spike Alert',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        'dev-001': 48,
        'dev-002': 75,
        'dev-003': spikeLat,
        'dev-004': 38,
        fleetAvg: Math.round((48 + 75 + spikeLat + 38) / 4),
      },
    ]);

    setAuditMessage(`Simulated latency incident on ${target.name}: ${spikeLat}ms (>500ms SLA breach)`);
    setTimeout(() => setAuditMessage(null), 4000);

    if (onLogAudit) {
      onLogAudit('ALERT', 'Biometric Health Monitor', `Admin simulated latency anomaly: ${spikeLat}ms on ${target.name}`);
    }
  };

  // Diagnostic Test: Restore Normal Fleet Baselines
  const handleRestoreOptimalBaselines = () => {
    const updated = devices.map((d, i) => ({
      ...d,
      status: 'Online' as const,
      syncLatencyMs: i === 0 ? 46 : i === 1 ? 74 : i === 2 ? 152 : 36,
      lastSyncAt: new Date().toISOString(),
    }));
    onUpdateDevices(updated);

    setHeartbeatTimeline(prev => [
      ...prev.slice(-9),
      {
        cycleLabel: 'Restored',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        'dev-001': 46,
        'dev-002': 74,
        'dev-003': 152,
        'dev-004': 36,
        fleetAvg: 77,
      },
    ]);

    setAuditMessage('Fleet restored to optimal hardware latency baselines (<80ms - 150ms).');
    setTimeout(() => setAuditMessage(null), 3500);

    if (onLogAudit) {
      onLogAudit('UPDATE', 'Biometric Health Monitor', 'Admin restored optimal baseline latency telemetry across all terminals');
    }
  };

  // --- Real-time Daily & Hourly Punch Frequency Trends Calculation ---
  const hourlyPunchFrequencyData = useMemo(() => {
    // Standard factory shift schedule intervals (24-hour timeline)
    const hours = [
      { hour: '06:00', label: '06:00 AM', shift: 'Shift 1 Start', baseIn: 32, baseOut: 4 },
      { hour: '08:00', label: '08:00 AM', shift: 'Gen Shift Peak', baseIn: 58, baseOut: 2 },
      { hour: '10:00', label: '10:00 AM', shift: 'Morning Floor', baseIn: 12, baseOut: 8 },
      { hour: '12:00', label: '12:00 PM', shift: 'Lunch Outflow', baseIn: 6, baseOut: 48 },
      { hour: '13:00', label: '01:00 PM', shift: 'Lunch Inflow', baseIn: 46, baseOut: 5 },
      { hour: '15:00', label: '03:00 PM', shift: 'Afternoon Ops', baseIn: 10, baseOut: 11 },
      { hour: '17:00', label: '05:00 PM', shift: 'Gen Shift Exit', baseIn: 3, baseOut: 62 },
      { hour: '19:00', label: '07:00 PM', shift: 'Shift 2 Turnover', baseIn: 24, baseOut: 28 },
      { hour: '21:00', label: '09:00 PM', shift: 'Night Shift In', baseIn: 18, baseOut: 7 },
      { hour: '23:00', label: '11:00 PM', shift: 'Late Patrol', baseIn: 5, baseOut: 4 },
    ];

    // Compute extra dynamic punches from rawPunches buffer if present
    const hourlyPunchesCount: Record<string, { in: number; out: number }> = {};
    rawPunches.forEach(p => {
      try {
        const d = new Date(p.punchTime);
        const h = d.getHours();
        // Bucket into nearest interval
        let bucket = '08:00';
        if (h <= 6) bucket = '06:00';
        else if (h <= 8) bucket = '08:00';
        else if (h <= 10) bucket = '10:00';
        else if (h <= 12) bucket = '12:00';
        else if (h <= 13) bucket = '13:00';
        else if (h <= 15) bucket = '15:00';
        else if (h <= 17) bucket = '17:00';
        else if (h <= 19) bucket = '19:00';
        else if (h <= 21) bucket = '21:00';
        else bucket = '23:00';

        if (!hourlyPunchesCount[bucket]) hourlyPunchesCount[bucket] = { in: 0, out: 0 };
        if (p.punchType === 'IN') hourlyPunchesCount[bucket].in += 1;
        else hourlyPunchesCount[bucket].out += 1;
      } catch {
        // fallback
      }
    });

    return hours.map(h => {
      const extraIn = hourlyPunchesCount[h.hour]?.in || 0;
      const extraOut = hourlyPunchesCount[h.hour]?.out || 0;
      const inPunches = h.baseIn + extraIn;
      const outPunches = h.baseOut + extraOut;
      const total = inPunches + outPunches;
      return {
        timeLabel: h.label,
        hour: h.hour,
        shiftName: h.shift,
        inPunches,
        outPunches,
        total,
        velocityPerMinute: Number((total / 60).toFixed(1)),
      };
    });
  }, [rawPunches]);

  // 7-Day Punch Volume Progression
  const dailyPunchTrendData = useMemo(() => {
    return [
      { day: 'Mon', fullDate: 'Sep 29', totalPunches: 248, inPunches: 126, outPunches: 122, successRatePct: 99.8, peakHour: '08:00 AM' },
      { day: 'Tue', fullDate: 'Sep 30', totalPunches: 262, inPunches: 134, outPunches: 128, successRatePct: 100.0, peakHour: '08:00 AM' },
      { day: 'Wed', fullDate: 'Oct 01', totalPunches: 274, inPunches: 140, outPunches: 134, successRatePct: 99.6, peakHour: '08:15 AM' },
      { day: 'Thu', fullDate: 'Oct 02', totalPunches: 180, inPunches: 92,  outPunches: 88,  successRatePct: 100.0, peakHour: '09:00 AM' },
      { day: 'Fri', fullDate: 'Oct 03', totalPunches: 268, inPunches: 136, outPunches: 132, successRatePct: 99.7, peakHour: '08:00 AM' },
      { day: 'Sat', fullDate: 'Oct 04', totalPunches: 215, inPunches: 110, outPunches: 105, successRatePct: 100.0, peakHour: '08:30 AM' },
      { day: 'Today', fullDate: 'Oct 05', totalPunches: hourlyPunchFrequencyData.reduce((s, h) => s + h.total, 0), inPunches: hourlyPunchFrequencyData.reduce((s, h) => s + h.inPunches, 0), outPunches: hourlyPunchFrequencyData.reduce((s, h) => s + h.outPunches, 0), successRatePct: 99.9, peakHour: '08:00 AM (58 punches)' },
    ];
  }, [hourlyPunchFrequencyData]);

  // Metrics summary
  const totalTodayPunches = useMemo(() => {
    return hourlyPunchFrequencyData.reduce((sum, h) => sum + h.total, 0);
  }, [hourlyPunchFrequencyData]);

  const totalInPunches = useMemo(() => {
    return hourlyPunchFrequencyData.reduce((sum, h) => sum + h.inPunches, 0);
  }, [hourlyPunchFrequencyData]);

  const totalOutPunches = useMemo(() => {
    return hourlyPunchFrequencyData.reduce((sum, h) => sum + h.outPunches, 0);
  }, [hourlyPunchFrequencyData]);

  const peakHourlyBucket = useMemo(() => {
    return [...hourlyPunchFrequencyData].sort((a, b) => b.total - a.total)[0] || hourlyPunchFrequencyData[0];
  }, [hourlyPunchFrequencyData]);

  const onlineTerminalsCount = devices.filter(d => d.status === 'Online').length;
  const averageLatency = useMemo(() => {
    if (devices.length === 0) return 0;
    const sum = devices.reduce((s, d) => s + (d.syncLatencyMs ?? 46), 0);
    return Math.round(sum / devices.length);
  }, [devices]);

  const criticalTerminals = devices.filter(d => (d.syncLatencyMs ?? 0) > 500 || d.status === 'Offline');

  // Device color map for Recharts
  const deviceColorMap: Record<string, { color: string; name: string; vendor: string }> = {
    'dev-001': { color: '#10b981', name: 'Main Gate In/Out', vendor: 'eSSL' },
    'dev-002': { color: '#0284c7', name: 'Shop Floor A Turnstile', vendor: 'ZKTeco' },
    'dev-003': { color: '#f59e0b', name: 'Assembly Line B Stamping', vendor: 'Matrix' },
    'dev-004': { color: '#8b5cf6', name: 'Warehouse Gate 2', vendor: 'Suprema' },
  };

  return (
    <div className="space-y-6">
      {/* 1. Header Banner & Real-time Heartbeat Pulse Control */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-indigo-950 rounded-2xl p-5 sm:p-6 text-white shadow-md border border-sky-900/50 relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>Live Heartbeat Monitor</span>
              </span>
              <span className="text-xs text-sky-200 font-mono">
                Fleet Status: {onlineTerminalsCount}/{devices.length} Terminals Connected
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-xs text-sky-300">
                Avg Latency: <strong className="font-mono text-white">{averageLatency}ms</strong>
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
              <HeartPulse className="w-6 h-6 text-rose-400 animate-pulse" />
              <span>Biometric Health & Heartbeat Diagnostic Monitor</span>
            </h2>
            <p className="text-xs text-sky-100 max-w-2xl mt-1 leading-relaxed">
              Real-time hardware socket connectivity telemetry, TCP/IP ADMS pulse monitoring, and shift punch ingest frequency analytics across all manufacturing plant terminals.
            </p>
          </div>

          {/* Action Hub / Probing Controls */}
          <div className="flex flex-wrap items-center gap-2.5 self-start lg:self-auto">
            {/* Auto-probe toggle with live countdown */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-slate-300">
              <Radio className={`w-3.5 h-3.5 ${isAutoProbing ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
              <span>
                {isAutoProbing ? `Auto-probe in ${probeCountdown}s` : 'Auto-probe paused'}
              </span>
              <button
                onClick={() => setIsAutoProbing(!isAutoProbing)}
                className="ml-1 text-[10px] font-bold text-sky-400 hover:text-sky-300 underline cursor-pointer"
              >
                {isAutoProbing ? 'Pause' : 'Resume'}
              </button>
            </div>

            {/* Manual probe button */}
            <button
              onClick={() => triggerFleetHeartbeatProbe(false)}
              disabled={isProbingFleet}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow-md transition-all cursor-pointer disabled:opacity-50"
              title="Broadcast TCP/IP ping handshake to all connected biometric terminals"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isProbingFleet ? 'animate-spin' : ''}`} />
              <span>{isProbingFleet ? 'Probing Fleet...' : 'Poll All Heartbeats'}</span>
            </button>

            {/* Test Simulation Dropdown / Actions */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleSimulateLatencySpike}
                className="px-2.5 py-2 rounded-xl bg-slate-800 hover:bg-rose-950/80 hover:text-rose-200 text-slate-300 text-[11px] font-semibold border border-slate-700 transition-colors cursor-pointer"
                title="Simulate network jitter >500ms on Assembly Line Matrix machine"
              >
                Test Spike
              </button>
              <button
                onClick={handleRestoreOptimalBaselines}
                className="px-2.5 py-2 rounded-xl bg-slate-800 hover:bg-emerald-950/80 hover:text-emerald-200 text-slate-300 text-[11px] font-semibold border border-slate-700 transition-colors cursor-pointer"
                title="Restore normal ping latency baselines"
              >
                Reset SLA
              </button>
            </div>
          </div>
        </div>

        {/* Audit / Status toast notification */}
        {auditMessage && (
          <div className="mt-3.5 pt-3 border-t border-sky-800/60 flex items-center gap-2 text-xs text-sky-200 animate-in fade-in slide-in-from-top-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="font-medium">{auditMessage}</span>
          </div>
        )}
      </div>

      {/* 2. Critical Alert Banner if Any Terminal Breaches SLA (>500ms or Offline) */}
      {criticalTerminals.length > 0 && (
        <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-4 text-slate-900 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-pulse">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-rose-600 text-white shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded bg-rose-200 text-rose-950">
                  Critical SLA Threshold Breach
                </span>
                <span className="text-xs font-bold text-rose-900">
                  {criticalTerminals.length} Terminal{criticalTerminals.length > 1 ? 's' : ''} Exceeding 500ms Tolerance
                </span>
              </div>
              <p className="text-xs text-rose-800 mt-0.5">
                {criticalTerminals.map(d => `${d.name} (${d.syncLatencyMs}ms)`).join(', ')}. Raw punch socket ingestion delayed. Shift turnovers risk clocking backlogs.
              </p>
            </div>
          </div>
          <button
            onClick={handleRestoreOptimalBaselines}
            className="px-3.5 py-1.5 rounded-xl bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold shadow-xs transition-colors shrink-0 cursor-pointer"
          >
            Resolve & Restore Baseline
          </button>
        </div>
      )}

      {/* 3. Four Core Real-time Biometric Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Today's Ingestion Volume */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="p-2.5 rounded-xl bg-sky-50 text-sky-700 border border-sky-100">
              <Activity className="w-5 h-5" />
            </span>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>Live Ingestion</span>
            </span>
          </div>

          <div>
            <span className="text-xs font-semibold text-slate-500 block">Today's Ingested Punches</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight">
                {totalTodayPunches}
              </span>
              <span className="text-xs font-bold text-emerald-600 font-mono">
                ({totalInPunches} IN / {totalOutPunches} OUT)
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              Peak flow: <strong className="text-slate-800">{peakHourlyBucket.timeLabel}</strong> ({peakHourlyBucket.total} punches/hr · {peakHourlyBucket.velocityPerMinute}/min).
            </p>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] font-medium text-slate-400">
            <span>Buffer Integrity: 100%</span>
            <span className="text-sky-600 font-bold">Raw Buffer Sync</span>
          </div>
        </div>

        {/* Metric 2: Terminal Heartbeat Availability */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-100">
              <Server className="w-5 h-5" />
            </span>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              <span>100% Up</span>
            </span>
          </div>

          <div>
            <span className="text-xs font-semibold text-slate-500 block">Terminal Fleet Availability</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight">
                {onlineTerminalsCount} / {devices.length}
              </span>
              <span className="text-xs font-bold text-slate-400 font-mono">
                Terminals
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              All 4 factory gates online. Handshake protocol: TCP/IP ADMS & Push SDK. Zero dead sockets.
            </p>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] font-medium text-slate-400">
            <span>Last Handshake: {lastProbeTimestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
            <span className="text-emerald-600 font-bold">100% Socket Uptime</span>
          </div>
        </div>

        {/* Metric 3: Fleet Round-Trip Latency vs SLA */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="p-2.5 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-100">
              <Gauge className="w-5 h-5" />
            </span>
            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
              averageLatency < 80
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : averageLatency <= 150
                ? 'bg-sky-50 text-sky-700 border-sky-200'
                : 'bg-amber-50 text-amber-700 border-amber-200'
            }`}>
              {averageLatency < 80 ? 'Optimal (<80ms)' : averageLatency <= 150 ? 'Normal (<150ms)' : 'Jitter Warning'}
            </span>
          </div>

          <div>
            <span className="text-xs font-semibold text-slate-500 block">Fleet Round-Trip Latency</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight">
                {averageLatency}ms
              </span>
              <span className="text-xs font-semibold text-slate-400 font-mono">
                avg ping
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              LAN response ceiling SLA is 150ms. Current fleet packet turnaround is comfortably within compliance.
            </p>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] font-medium text-slate-400">
            <span>Critical ceiling: 500ms</span>
            <span className="text-indigo-600 font-bold">Optimal Ping</span>
          </div>
        </div>

        {/* Metric 4: Packet Integrity & Zero Drop Rate */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="p-2.5 rounded-xl bg-amber-50 text-amber-700 border border-amber-100">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              99.9% Integrity
            </span>
          </div>

          <div>
            <span className="text-xs font-semibold text-slate-500 block">Packet Delivery & Zero Drop</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-black text-slate-900 font-mono tracking-tight">
                0
              </span>
              <span className="text-xs font-bold text-emerald-600">
                Dropped Packets
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              CRC-32 checksums verified on all raw biometric payloads. No ghost punches or duplicate sequences detected.
            </p>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] font-medium text-slate-400">
            <span>Duplicate filter: Active</span>
            <span className="text-emerald-600 font-bold">100% Ingest Rate</span>
          </div>
        </div>
      </div>

      {/* 4. Real-time Daily Punch Frequency Trends (Recharts) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="p-1.5 rounded-lg bg-sky-50 text-sky-700 border border-sky-100">
                <TrendingUp className="w-4 h-4" />
              </span>
              <h3 className="text-sm font-bold text-slate-900">
                Real-Time Punch Frequency & Workforce Flow Trends (Recharts)
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200 font-mono">
                {totalTodayPunches} Punches Recorded
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Live hourly velocity and shift turnover distribution to detect bottleneck delays at turnstiles.
            </p>
          </div>

          {/* Toggle between Hourly Velocity and 7-Day Trend */}
          <div className="flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs self-start sm:self-auto">
            <button
              onClick={() => setFrequencyViewMode('hourly')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                frequencyViewMode === 'hourly'
                  ? 'bg-white text-sky-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Hourly Velocity (Today)
            </button>
            <button
              onClick={() => setFrequencyViewMode('daily')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                frequencyViewMode === 'daily'
                  ? 'bg-white text-sky-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              7-Day Volume Trajectory
            </button>
          </div>
        </div>

        {/* Recharts Canvas */}
        <div className="h-72 sm:h-80 w-full min-w-0">
          <ChartErrorBoundary
            fallback={
              <SvgPunchFrequencyFallback
                data={hourlyPunchFrequencyData.map(d => ({
                  timeLabel: d.hour,
                  total: d.total,
                  inPunches: d.inPunches,
                  outPunches: d.outPunches,
                }))}
              />
            }
          >
            <ResponsiveContainer width="100%" height="100%">
              {frequencyViewMode === 'hourly' ? (
                <BarChart
                  data={hourlyPunchFrequencyData}
                  margin={{ top: 15, right: 20, left: -10, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis
                    dataKey="timeLabel"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    axisLine={{ stroke: '#cbd5e1' }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    axisLine={{ stroke: '#cbd5e1' }}
                    tickLine={false}
                    label={{
                      value: 'Punches / Hr',
                      angle: -90,
                      position: 'insideLeft',
                      offset: 15,
                      style: { fontSize: 10, fill: '#94a3b8' },
                    }}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload || !payload.length) return null;
                      const d = payload[0].payload as typeof hourlyPunchFrequencyData[0];
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-700 text-xs space-y-1.5 min-w-[200px]">
                          <div className="flex items-center justify-between border-b border-slate-700 pb-1">
                            <span className="font-bold text-sky-300">{d.timeLabel}</span>
                            <span className="text-[10px] text-slate-300 bg-slate-800 px-1.5 py-0.5 rounded font-mono">
                              {d.shiftName}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-300">Total Punches:</span>
                            <strong className="text-white font-mono">{d.total}</strong>
                          </div>
                          <div className="flex justify-between text-emerald-400">
                            <span>IN Punches:</span>
                            <strong className="font-mono">{d.inPunches}</strong>
                          </div>
                          <div className="flex justify-between text-sky-400">
                            <span>OUT Punches:</span>
                            <strong className="font-mono">{d.outPunches}</strong>
                          </div>
                          <div className="pt-1 border-t border-slate-800 text-[10px] text-slate-400 flex justify-between">
                            <span>Velocity:</span>
                            <span className="font-mono">{d.velocityPerMinute} punches/min</span>
                          </div>
                        </div>
                      );
                    }}
                  />
                  <Legend
                    verticalAlign="top"
                    align="right"
                    wrapperStyle={{ paddingBottom: '10px', fontSize: '11px' }}
                  />
                  <ReferenceLine
                    y={50}
                    stroke="#f59e0b"
                    strokeDasharray="4 4"
                    label={{
                      value: 'High Peak Threshold (50/hr)',
                      position: 'top',
                      fill: '#d97706',
                      fontSize: 10,
                      fontWeight: 600,
                    }}
                  />
                  <Bar dataKey="inPunches" name="IN Punches (Entry)" fill="#10b981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="outPunches" name="OUT Punches (Exit)" fill="#0284c7" radius={[4, 4, 0, 0]} />
                </BarChart>
              ) : (
                <AreaChart
                  data={dailyPunchTrendData}
                  margin={{ top: 15, right: 20, left: -10, bottom: 20 }}
                >
                  <defs>
                    <linearGradient id="colorTotalPunches" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis
                    dataKey="day"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    axisLine={{ stroke: '#cbd5e1' }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    axisLine={{ stroke: '#cbd5e1' }}
                    tickLine={false}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload || !payload.length) return null;
                      const d = payload[0].payload as typeof dailyPunchTrendData[0];
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-700 text-xs space-y-1 min-w-[190px]">
                          <div className="flex justify-between border-b border-slate-700 pb-1 font-bold text-sky-300">
                            <span>{d.day} ({d.fullDate})</span>
                            <span className="font-mono text-emerald-400">{d.successRatePct}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-300">Total Volume:</span>
                            <strong className="font-mono">{d.totalPunches}</strong>
                          </div>
                          <div className="flex justify-between text-slate-300 text-[11px]">
                            <span>IN / OUT Split:</span>
                            <span className="font-mono">{d.inPunches} / {d.outPunches}</span>
                          </div>
                          <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
                            Peak: {d.peakHour}
                          </div>
                        </div>
                      );
                    }}
                  />
                  <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: '10px', fontSize: '11px' }} />
                  <Area
                    type="monotone"
                    dataKey="totalPunches"
                    name="Daily Total Punches"
                    stroke="#0284c7"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#colorTotalPunches)"
                  />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </ChartErrorBoundary>
        </div>

        {/* Shift insights footer */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
            <span className="text-slate-400 text-[10px] uppercase font-bold block">Morning Shift (08:00 AM)</span>
            <p className="font-bold text-slate-800 mt-0.5">Heavy Influx Peak</p>
            <p className="text-[11px] text-slate-500 mt-1">98% of general shift staff ingress within 25 minutes.</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
            <span className="text-slate-400 text-[10px] uppercase font-bold block">Lunch Interval (12:00 - 13:00)</span>
            <p className="font-bold text-slate-800 mt-0.5">Bimodal Turnover</p>
            <p className="text-[11px] text-slate-500 mt-1">Smooth gate egress with zero turnstile deadlock.</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/60">
            <span className="text-slate-400 text-[10px] uppercase font-bold block">Evening Outflow (17:00 PM)</span>
            <p className="font-bold text-slate-800 mt-0.5">Shift 1 Exit Surge</p>
            <p className="text-[11px] text-slate-500 mt-1">Matrix and eSSL biometric terminals synced in &lt;50ms.</p>
          </div>
        </div>
      </div>

      {/* 5. Device Connectivity Heartbeat Status (Recharts) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-100">
                <HeartPulse className="w-4 h-4" />
              </span>
              <h3 className="text-sm font-bold text-slate-900">
                Device Connectivity Heartbeat Latency Timeline (Recharts)
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 font-mono">
                SLA Compliance: &lt;150ms
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Continuous TCP/IP round-trip latency handshakes over the last 10 pulse cycles.
            </p>
          </div>

          {/* Device Isolator Filter */}
          <div className="flex items-center gap-1.5 flex-wrap self-start sm:self-auto">
            <span className="text-xs font-semibold text-slate-400 mr-1">Filter:</span>
            <button
              onClick={() => setHeartbeatViewFilter('all')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                heartbeatViewFilter === 'all'
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Terminals
            </button>
            {devices.map(dev => (
              <button
                key={dev.id}
                onClick={() => setHeartbeatViewFilter(dev.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  heartbeatViewFilter === dev.id
                    ? 'bg-sky-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {dev.vendor} ({dev.id})
              </button>
            ))}
          </div>
        </div>

        {/* Recharts LineChart Canvas */}
        <div className="h-72 sm:h-80 w-full min-w-0">
          <ChartErrorBoundary
            fallback={
              <SvgHeartbeatFallback
                data={heartbeatTimeline}
                deviceIds={['dev-001', 'dev-002', 'dev-003', 'dev-004']}
              />
            }
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={heartbeatTimeline}
                margin={{ top: 15, right: 20, left: -10, bottom: 20 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis
                  dataKey="cycleLabel"
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tickLine={false}
                  domain={[0, 300]}
                  label={{
                    value: 'Latency (ms)',
                    angle: -90,
                    position: 'insideLeft',
                    offset: 15,
                    style: { fontSize: 10, fill: '#94a3b8' },
                  }}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (!active || !payload || !payload.length) return null;
                    const d = payload[0].payload as typeof heartbeatTimeline[0];
                    return (
                      <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-700 text-xs space-y-1.5 min-w-[210px]">
                        <div className="flex items-center justify-between border-b border-slate-700 pb-1">
                          <span className="font-bold text-sky-300">{d.cycleLabel}</span>
                          <span className="text-[10px] text-slate-400 font-mono">{d.timestamp}</span>
                        </div>
                        <div className="flex justify-between text-slate-300">
                          <span>Fleet Average:</span>
                          <strong className="font-mono text-white">{d.fleetAvg}ms</strong>
                        </div>
                        {devices.map(dev => {
                          const val = d[dev.id as keyof typeof d];
                          const color = deviceColorMap[dev.id]?.color || '#94a3b8';
                          return (
                            <div key={dev.id} className="flex justify-between" style={{ color }}>
                              <span>{dev.name.split(' ')[0]} ({dev.vendor}):</span>
                              <strong className="font-mono">{val}ms</strong>
                            </div>
                          );
                        })}
                      </div>
                    );
                  }}
                />
                <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: '10px', fontSize: '11px' }} />

                {/* Normal SLA Reference Line (150ms) */}
                <ReferenceLine
                  y={150}
                  stroke="#0284c7"
                  strokeDasharray="4 4"
                  strokeWidth={1.5}
                  label={{
                    value: 'SLA Normal Target (150ms)',
                    position: 'insideTopRight',
                    fill: '#0284c7',
                    fontSize: 10,
                    fontWeight: 'bold',
                  }}
                />

                {/* Critical SLA Reference Line (500ms threshold) */}
                <ReferenceLine
                  y={500}
                  stroke="#e11d48"
                  strokeDasharray="3 3"
                  label={{
                    value: 'Critical Ceiling (500ms)',
                    position: 'insideTopRight',
                    fill: '#e11d48',
                    fontSize: 10,
                    fontWeight: 'bold',
                  }}
                />

                {/* Individual Device Latency Lines */}
                {(heartbeatViewFilter === 'all' || heartbeatViewFilter === 'dev-001') && (
                  <Line
                    type="monotone"
                    dataKey="dev-001"
                    name="dev-001 (eSSL Main Gate)"
                    stroke="#10b981"
                    strokeWidth={2.5}
                    dot={{ r: 3 }}
                    activeDot={{ r: 5 }}
                  />
                )}
                {(heartbeatViewFilter === 'all' || heartbeatViewFilter === 'dev-002') && (
                  <Line
                    type="monotone"
                    dataKey="dev-002"
                    name="dev-002 (ZKTeco Shop Floor)"
                    stroke="#0284c7"
                    strokeWidth={2.5}
                    dot={{ r: 3 }}
                    activeDot={{ r: 5 }}
                  />
                )}
                {(heartbeatViewFilter === 'all' || heartbeatViewFilter === 'dev-003') && (
                  <Line
                    type="monotone"
                    dataKey="dev-003"
                    name="dev-003 (Matrix Stamping Line)"
                    stroke="#f59e0b"
                    strokeWidth={2.5}
                    dot={{ r: 3 }}
                    activeDot={{ r: 5 }}
                  />
                )}
                {(heartbeatViewFilter === 'all' || heartbeatViewFilter === 'dev-004') && (
                  <Line
                    type="monotone"
                    dataKey="dev-004"
                    name="dev-004 (Suprema Warehouse)"
                    stroke="#8b5cf6"
                    strokeWidth={2.5}
                    dot={{ r: 3 }}
                    activeDot={{ r: 5 }}
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          </ChartErrorBoundary>
        </div>
      </div>

      {/* 6. Real-time Device Heartbeat Fleet Status Matrix & Diagnostic Probe Buttons */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-sky-600" />
              <h3 className="text-sm font-bold text-slate-900">
                Connected Hardware Heartbeat Status & IP Terminal Probe Matrix
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Live heartbeat response times, physical port allocations & individual ping testing
            </p>
          </div>

          <button
            onClick={() => triggerFleetHeartbeatProbe(false)}
            disabled={isProbingFleet}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition-colors cursor-pointer self-start sm:self-auto"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-slate-600 ${isProbingFleet ? 'animate-spin' : ''}`} />
            <span>Ping All 4 Terminals</span>
          </button>
        </div>

        {/* Matrix Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-slate-100">
          {devices.map(dev => {
            const lat = dev.syncLatencyMs ?? 46;
            const isPinging = probingDeviceId === dev.id;
            const isCritical = lat > 500 || dev.status === 'Offline';
            const isOptimal = lat < 80;

            return (
              <div key={dev.id} className="p-4 flex flex-col justify-between space-y-3 hover:bg-slate-50/60 transition-colors">
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider bg-slate-100 text-slate-800 border border-slate-200">
                      {dev.vendor} · {dev.id}
                    </span>
                    <span className={`flex items-center gap-1 text-[11px] font-bold ${
                      dev.status === 'Offline'
                        ? 'text-slate-500'
                        : isCritical
                        ? 'text-rose-600'
                        : 'text-emerald-600'
                    }`}>
                      <span className={`w-2 h-2 rounded-full ${
                        dev.status === 'Offline' ? 'bg-slate-400' : isCritical ? 'bg-rose-500 animate-ping' : 'bg-emerald-500 animate-pulse'
                      }`} />
                      <span>{dev.status}</span>
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-slate-900 leading-snug">{dev.name}</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">{dev.location}</p>

                  <div className="mt-2.5 p-2 rounded-xl bg-slate-50 border border-slate-100 text-[11px] space-y-1">
                    <div className="flex justify-between font-mono">
                      <span className="text-slate-400">Endpoint:</span>
                      <span className="text-slate-800">{dev.ipAddress}:{dev.port}</span>
                    </div>
                    <div className="flex justify-between font-mono">
                      <span className="text-slate-400">Model:</span>
                      <span className="text-slate-700 truncate max-w-[120px]">{dev.deviceModel}</span>
                    </div>
                    <div className="flex justify-between font-mono">
                      <span className="text-slate-400">Synced:</span>
                      <span className="text-slate-900 font-bold">{dev.totalSyncedPunches.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* Heartbeat Latency Bar */}
                <div>
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="text-slate-500 flex items-center gap-1">
                      <Zap className="w-3 h-3 text-amber-500" />
                      <span>Pulse Latency:</span>
                    </span>
                    <span className={`font-mono font-black ${
                      isCritical ? 'text-rose-600' : isOptimal ? 'text-emerald-600' : 'text-sky-700'
                    }`}>
                      {dev.status === 'Offline' ? 'OFFLINE' : `${lat}ms`}
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isCritical ? 'bg-rose-500' : isOptimal ? 'bg-emerald-500' : 'bg-sky-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(10, (lat / 500) * 100))}%` }}
                    />
                  </div>
                </div>

                {/* Test Ping Button */}
                <button
                  onClick={() => handleProbeSingleDevice(dev.id)}
                  disabled={isPinging}
                  className="w-full py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 text-xs font-bold border border-sky-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3 h-3 text-sky-600 ${isPinging ? 'animate-spin' : ''}`} />
                  <span>{isPinging ? 'Pinging...' : 'Send Heartbeat Probe'}</span>
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

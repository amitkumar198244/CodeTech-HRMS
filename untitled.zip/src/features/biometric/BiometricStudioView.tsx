// RSTPL HRMS - Biometric Machine Integration Studio & Raw Punch Engine
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  Fingerprint,
  RefreshCw,
  UploadCloud,
  Download,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Server,
  FileSpreadsheet,
  Terminal,
  Activity,
  HeartPulse,
  LayoutDashboard,
  Check,
  X,
  Search,
  ArrowRight
} from 'lucide-react';
import { BiometricDevice, RawPunch, Employee, Shift, AttendanceRecord } from '../../types/hrms';
import { BiometricConnectorManager, SyncResult } from '../../services/biometricService';
import { AttendanceProcessingEngine } from '../../services/attendanceEngine';
import { BiometricHealthMonitorDashboard } from './BiometricHealthMonitorDashboard';

interface BiometricStudioViewProps {
  devices: BiometricDevice[];
  rawPunches: RawPunch[];
  employees: Employee[];
  shifts: Shift[];
  attendance: AttendanceRecord[];
  onUpdateDevices: (devices: BiometricDevice[]) => void;
  onUpdateRawPunches: (punches: RawPunch[]) => void;
  onUpdateAttendance: (attendance: AttendanceRecord[]) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
  onNavigate: (module: string) => void;
}

export const BiometricStudioView: React.FC<BiometricStudioViewProps> = ({
  devices,
  rawPunches,
  employees,
  shifts,
  attendance,
  onUpdateDevices,
  onUpdateRawPunches,
  onUpdateAttendance,
  onLogAudit,
  onNavigate,
}) => {
  const [syncing, setSyncing] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [syncResults, setSyncResults] = useState<SyncResult[]>([]);
  const [csvInput, setCsvInput] = useState('');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadErrors, setUploadErrors] = useState<{ line: number; message: string; raw: string }[]>([]);
  const [filterQuery, setFilterQuery] = useState('');
  const [selectedVendorDoc, setSelectedVendorDoc] = useState<string | null>(null);
  const [studioTab, setStudioTab] = useState<'health-monitor' | 'terminals'>('health-monitor');
  const [showAddIpModal, setShowAddIpModal] = useState(false);
  const [ipAddressInput, setIpAddressInput] = useState('192.168.1.220');
  const [ipPortInput, setIpPortInput] = useState(4370);
  const [ipVendorInput, setIpVendorInput] = useState<'eSSL' | 'ZKTeco' | 'Matrix' | 'Suprema' | 'Realtime' | 'BioMax'>('eSSL');
  const [ipModelInput, setIpModelInput] = useState('SilkBio-101TC Dual Sensor');
  const [ipLocationInput, setIpLocationInput] = useState('Shopfloor Assembly Portal');
  const [ipPingTesting, setIpPingTesting] = useState(false);
  const [ipTestResult, setIpTestResult] = useState<{ success: boolean; latency: number; msg: string } | null>(null);

  const handleTestAndAddTerminal = () => {
    setIpPingTesting(true);
    setIpTestResult(null);

    setTimeout(() => {
      const simulatedLatency = Math.floor(Math.random() * 20) + 25;
      setIpPingTesting(false);
      setIpTestResult({
        success: true,
        latency: simulatedLatency,
        msg: `AI Auto-Link Successful! Handshake established with ${ipVendorInput} terminal at ${ipAddressInput}:${ipPortInput}. Firmware v4.8-IoT verified. Latency: ${simulatedLatency}ms.`,
      });

      const newDev: BiometricDevice = {
        id: `dev-${Date.now()}`,
        orgId: 'org-rstpl-001',
        name: `${ipVendorInput} ${ipModelInput}`,
        deviceModel: ipModelInput,
        vendor: ipVendorInput,
        serialNumber: `${ipVendorInput.toUpperCase()}-${Math.floor(Math.random() * 899999 + 100000)}`,
        ipAddress: ipAddressInput,
        port: ipPortInput,
        location: ipLocationInput,
        unitId: 'un-corp',
        status: 'Online',
        lastSyncAt: new Date().toISOString(),
        totalSyncedPunches: 150,
        syncLatencyMs: simulatedLatency,
        siteName: 'Corporate & Plant Facility',
        zone: ipLocationInput,
        firmwareVersion: 'v4.8-IoT',
      };

      onUpdateDevices([newDev, ...devices]);
      onLogAudit('CONNECT', 'Biometric Studio', `Connected new biometric terminal at IP ${ipAddressInput}:${ipPortInput}`);
    }, 1000);
  };

  // 1. "Sync Attendance" - triggers device handshake & ingest
  const handleSyncAttendance = () => {
    setSyncing(true);
    const newResults: SyncResult[] = [];
    let combinedNewPunches: RawPunch[] = [];

    setTimeout(() => {
      const updatedDevices = devices.map(dev => {
        const { newPunches, result } = BiometricConnectorManager.simulateDeviceSync(dev, employees);
        newResults.push(result);
        combinedNewPunches = [...combinedNewPunches, ...newPunches];
        return {
          ...dev,
          lastSyncAt: new Date().toISOString(),
          totalSyncedPunches: dev.totalSyncedPunches + newPunches.length,
          syncLatencyMs: result.latencyMs,
          status: 'Online' as const,
        };
      });

      onUpdateDevices(updatedDevices);
      onUpdateRawPunches([...combinedNewPunches, ...rawPunches]);
      setSyncResults(newResults);
      setSyncing(false);
      onLogAudit(
        'SYNC',
        'Biometric Integration',
        `Synchronized ${devices.length} biometric devices. Ingested ${combinedNewPunches.length} raw punches.`
      );
    }, 900);
  };

  // 2. "Process Attendance" - run rules engine on raw punches
  const handleProcessAttendance = () => {
    setProcessing(true);
    setTimeout(() => {
      const todayStr = '2026-10-05';
      const processed = AttendanceProcessingEngine.processDailyAttendance({
        date: todayStr,
        employees,
        shifts,
        rawPunches,
        existingAttendance: attendance,
      });

      onUpdateAttendance(processed);
      setProcessing(false);
      onLogAudit(
        'UPDATE',
        'Attendance Engine',
        `Processed attendance records for date ${todayStr} across ${employees.length} personnel.`
      );
    }, 600);
  };

  // 3. "Reprocess Attendance"
  const handleReprocessAttendance = () => {
    setProcessing(true);
    setTimeout(() => {
      const todayStr = '2026-10-05';
      // Force non-finalized records to be recomputed
      const unlocked = attendance.map(a => (a.isFinalized ? a : { ...a, status: 'Present' as const }));
      const processed = AttendanceProcessingEngine.processDailyAttendance({
        date: todayStr,
        employees,
        shifts,
        rawPunches,
        existingAttendance: unlocked,
      });

      onUpdateAttendance(processed);
      setProcessing(false);
      onLogAudit('UPDATE', 'Attendance Engine', `Reprocessed attendance rules for date ${todayStr}.`);
    }, 600);
  };

  // 4. "Download Attendance" - Export CSV
  const handleDownloadAttendanceCSV = () => {
    const headers = ['EmployeeCode,Date,PunchTime,Direction,Device,Source,Status'];
    const rows = rawPunches.map(
      p =>
        `${p.employeeCode},${p.punchTime.split('T')[0]},${p.punchTime.split('T')[1]},${p.punchType},${p.deviceName},${p.source},${p.status}`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `RSTPL_Raw_Punches_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onLogAudit('EXPORT', 'Biometric Integration', `Exported raw attendance punches to CSV.`);
  };

  // 5. "Upload Attendance" - Parse CSV and show errors
  const handleProcessCsvUpload = () => {
    const { validPunches, errors } = BiometricConnectorManager.parseAttendanceCSV(csvInput, employees);
    if (errors.length > 0) {
      setUploadErrors(errors);
      return;
    }

    onUpdateRawPunches([...validPunches, ...rawPunches]);
    setShowUploadModal(false);
    setCsvInput('');
    setUploadErrors([]);
    onLogAudit('CREATE', 'Biometric Integration', `Imported ${validPunches.length} punches via CSV upload.`);
  };

  // Sample CSV template
  const sampleCsvTemplate = `EmployeeCode,Date,Time,Type,Device
RST-1001,2026-10-05,08:58,IN,eSSL Gate 1
RST-1002,2026-10-05,09:10,IN,ZKTeco Reception
RST-1003,2026-10-05,05:55,IN,Matrix Stamping Line
RST-1004,2026-10-05,06:02,IN,eSSL Gate 1`;

  const filteredPunches = rawPunches.filter(
    p =>
      p.employeeCode.toLowerCase().includes(filterQuery.toLowerCase()) ||
      p.deviceName.toLowerCase().includes(filterQuery.toLowerCase()) ||
      p.source.toLowerCase().includes(filterQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Header & Hardware Action Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-800">
              <Fingerprint className="w-5 h-5 text-sky-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                Biometric Machine Integration Studio
              </h2>
              <p className="text-xs text-slate-500">
                Multi-vendor IoT biometric terminal synchronization & raw punch validation engine
              </p>
            </div>
          </div>
        </div>

        {/* 6 Required Operation Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Sync Attendance */}
          <button
            onClick={handleSyncAttendance}
            disabled={syncing}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer disabled:opacity-50"
            title="Poll connected biometric terminals via TCP/IP"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
            <span>Sync Attendance</span>
          </button>

          {/* Download Attendance */}
          <button
            onClick={handleDownloadAttendanceCSV}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors cursor-pointer"
            title="Export raw punch table to CSV"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Download Attendance</span>
          </button>

          {/* Upload Attendance */}
          <button
            onClick={() => {
              setCsvInput(sampleCsvTemplate);
              setShowUploadModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold border border-slate-200 transition-colors cursor-pointer"
            title="Batch import punches via CSV"
          >
            <UploadCloud className="w-3.5 h-3.5 text-slate-500" />
            <span>Upload Attendance</span>
          </button>

          {/* Process Attendance */}
          <button
            onClick={handleProcessAttendance}
            disabled={processing}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer disabled:opacity-50"
            title="Run rules engine against shifts"
          >
            <Play className={`w-3.5 h-3.5 ${processing ? 'animate-pulse' : ''}`} />
            <span>Process Attendance</span>
          </button>

          {/* Reprocess Attendance */}
          <button
            onClick={handleReprocessAttendance}
            disabled={processing}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-colors cursor-pointer disabled:opacity-50"
            title="Recalculate attendance records"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reprocess Attendance</span>
          </button>

          {/* Finalize Attendance */}
          <button
            onClick={() => onNavigate('finalization')}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
            title="Go to finalization locking engine"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Finalize Attendance</span>
          </button>

          {/* Quick Connect by IP */}
          <button
            onClick={() => {
              setIpTestResult(null);
              setShowAddIpModal(true);
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
            title="Connect Biometric Machine via TCP/IP"
          >
            <Fingerprint className="w-3.5 h-3.5 text-indigo-200" />
            <span>+ Add Machine by IP</span>
          </button>
        </div>
      </div>

      {/* Sync Status Banner if recently synced */}
      {syncResults.length > 0 && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-xs text-emerald-900 flex items-center justify-between">
          <div className="flex items-center gap-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              Device sync finished at {new Date(syncResults[0].timestamp).toLocaleTimeString()}: All {syncResults.length} terminals reported online.
            </span>
          </div>
          <span className="font-mono text-[11px] text-emerald-700 font-bold">
            Total punches ingested: {syncResults.reduce((acc, r) => acc + r.punchesIngested, 0)}
          </span>
        </div>
      )}

      {/* Studio View Navigation Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2 p-1 rounded-xl bg-slate-100 border border-slate-200 self-start">
          <button
            onClick={() => setStudioTab('health-monitor')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              studioTab === 'health-monitor'
                ? 'bg-white text-sky-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <HeartPulse className="w-4 h-4 text-rose-500 animate-pulse" />
            <span>Biometric Health Monitor</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
              studioTab === 'health-monitor' ? 'bg-sky-100 text-sky-800' : 'bg-slate-200 text-slate-700'
            }`}>
              Recharts Live
            </span>
          </button>

          <button
            onClick={() => setStudioTab('terminals')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              studioTab === 'terminals'
                ? 'bg-white text-sky-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Server className="w-4 h-4 text-sky-600" />
            <span>Terminal Fleet & Raw Buffer</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
              studioTab === 'terminals' ? 'bg-sky-100 text-sky-800' : 'bg-slate-200 text-slate-700'
            }`}>
              {devices.length} Terminals
            </span>
          </button>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>Real-time Hardware Heartbeat Engine Online</span>
        </div>
      </div>

      {/* Conditional View: Biometric Health Monitor Dashboard vs Terminal Operations */}
      {studioTab === 'health-monitor' ? (
        <BiometricHealthMonitorDashboard
          devices={devices}
          rawPunches={rawPunches}
          employees={employees}
          onUpdateDevices={onUpdateDevices}
          onUpdateRawPunches={onUpdateRawPunches}
          onLogAudit={onLogAudit}
          onNavigate={onNavigate}
        />
      ) : (
        <div className="space-y-6">
          {/* Connected Terminals Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {devices.map(dev => (
              <div
                key={dev.id}
                className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-sky-100 text-sky-800 border border-sky-200 font-mono">
                      {dev.vendor}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      {dev.status}
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-slate-900 leading-snug">{dev.name}</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">{dev.deviceModel}</p>

                  <div className="mt-3 space-y-1 text-[11px] text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <div className="flex justify-between">
                      <span className="text-slate-400">IP Address:</span>
                      <span className="font-mono font-medium text-slate-900">{dev.ipAddress}:{dev.port}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Serial No:</span>
                      <span className="font-mono text-slate-700">{dev.serialNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Location:</span>
                      <span className="truncate max-w-[130px]">{dev.location}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Synced: {dev.totalSyncedPunches.toLocaleString()}</span>
                  <button
                    onClick={() => setSelectedVendorDoc(dev.vendor)}
                    className="text-sky-600 hover:underline font-semibold"
                  >
                    Adapter Info
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Raw Punches Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Live Raw Punch Ingestion Buffer</h3>
                <p className="text-[11px] text-slate-500">Unfiltered timestamp punches prior to shift evaluation</p>
              </div>

              <div className="relative">
                <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search code or terminal..."
                  value={filterQuery}
                  onChange={e => setFilterQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-semibold uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="py-2.5 px-4">Punch ID</th>
                    <th className="py-2.5 px-4">Employee Code</th>
                    <th className="py-2.5 px-4">Punch Timestamp</th>
                    <th className="py-2.5 px-4">Direction</th>
                    <th className="py-2.5 px-4">Terminal / Source</th>
                    <th className="py-2.5 px-4">Machine IP</th>
                    <th className="py-2.5 px-4">Ingestion State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredPunches.slice(0, 15).map(punch => (
                    <tr key={punch.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-2.5 px-4 font-mono text-[11px] text-slate-500">{punch.id}</td>
                      <td className="py-2.5 px-4 font-bold text-slate-900 font-mono">{punch.employeeCode}</td>
                      <td className="py-2.5 px-4 font-mono text-[11px] text-slate-600">
                        {new Date(punch.punchTime).toLocaleString('en-IN')}
                      </td>
                      <td className="py-2.5 px-4">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            punch.punchType === 'IN'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-indigo-100 text-indigo-800'
                          }`}
                        >
                          {punch.punchType}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-slate-800 font-medium">{punch.deviceName}</td>
                      <td className="py-2.5 px-4 font-mono text-slate-500 text-[11px]">
                        {punch.ipAddress || '127.0.0.1'}
                      </td>
                      <td className="py-2.5 px-4">
                        <span className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          {punch.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Upload Attendance CSV */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-sky-600" />
                <h3 className="text-base font-bold text-slate-900">Upload Attendance Data (CSV / Excel)</h3>
              </div>
              <button
                onClick={() => {
                  setShowUploadModal(false);
                  setUploadErrors([]);
                }}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 mb-2">
              Paste or inspect your CSV data below. Mandatory headers: <code className="bg-slate-100 px-1 py-0.5 rounded text-sky-800">EmployeeCode,Date,Time,Type,Device</code>
            </p>

            <textarea
              rows={8}
              value={csvInput}
              onChange={e => setCsvInput(e.target.value)}
              className="w-full font-mono text-xs p-3 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20"
            />

            {/* Error Reporting Block */}
            {uploadErrors.length > 0 && (
              <div className="mt-3 p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-rose-900">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  <span>Validation Failed ({uploadErrors.length} errors found):</span>
                </div>
                {uploadErrors.map((err, idx) => (
                  <p key={idx} className="text-[11px]">
                    Line {err.line}: {err.message}
                  </p>
                ))}
              </div>
            )}

            <div className="mt-5 flex items-center justify-end gap-2.5">
              <button
                onClick={() => {
                  setShowUploadModal(false);
                  setUploadErrors([]);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleProcessCsvUpload}
                className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-xl shadow-xs cursor-pointer"
              >
                Validate & Import Punches
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Vendor Protocol Specification Drawer */}
      {selectedVendorDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <h3 className="text-sm font-bold text-slate-900">
                {selectedVendorDoc} Biometric Adapter Protocol
              </h3>
              <button
                onClick={() => setSelectedVendorDoc(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            {(() => {
              const doc = BiometricConnectorManager.getVendorProtocolDocs(selectedVendorDoc);
              return (
                <div className="space-y-3 text-xs text-slate-700">
                  <div>
                    <span className="font-semibold text-slate-500 uppercase text-[10px]">Communication Protocol:</span>
                    <p className="font-mono text-slate-900 mt-0.5">{doc.protocol}</p>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-500 uppercase text-[10px]">Default Hardware Port:</span>
                    <p className="font-mono text-slate-900 mt-0.5">{doc.defaultPort}</p>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-500 uppercase text-[10px]">Recommended Gateway:</span>
                    <p className="text-slate-800 mt-0.5">{doc.recommendedAdapter}</p>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-500 uppercase text-[10px]">Standard Ingest Payload:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {doc.rawFields.map(f => (
                        <span key={f} className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-800 text-[10px] font-mono">
                          {f}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })()}
            <button
              onClick={() => setSelectedVendorDoc(null)}
              className="mt-5 w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Close Technical Specs
            </button>
          </div>
        </div>
      )}

      {/* QUICK ADD MACHINE BY IP MODAL WITH AI AUTO-LINK */}
      {showAddIpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col animate-scale-in">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Fingerprint className="w-4 h-4 text-indigo-700" />
                <h4 className="text-xs font-black uppercase text-slate-900">
                  Quick Add Biometric Terminal by IP Address
                </h4>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowAddIpModal(false);
                  setIpTestResult(null);
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <p className="text-slate-500">
                Connect hardware terminals over TCP/IP LAN/WAN with AI auto-detection of device model and socket handshake test.
              </p>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Terminal IP Address *</label>
                  <input
                    type="text"
                    value={ipAddressInput}
                    onChange={e => setIpAddressInput(e.target.value)}
                    placeholder="e.g. 192.168.1.205"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">TCP/IP Port *</label>
                  <input
                    type="number"
                    value={ipPortInput}
                    onChange={e => setIpPortInput(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Hardware Brand / Vendor</label>
                  <select
                    value={ipVendorInput}
                    onChange={e => setIpVendorInput(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-800"
                  >
                    <option value="eSSL">eSSL Security</option>
                    <option value="ZKTeco">ZKTeco GreenLabel</option>
                    <option value="Matrix">Matrix COSEC</option>
                    <option value="Suprema">Suprema BioEntry</option>
                    <option value="Realtime">Realtime Bio</option>
                    <option value="BioMax">BioMax IoT</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">Device Model</label>
                  <input
                    type="text"
                    value={ipModelInput}
                    onChange={e => setIpModelInput(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Terminal Physical Zone / Turnstile</label>
                <input
                  type="text"
                  value={ipLocationInput}
                  onChange={e => setIpLocationInput(e.target.value)}
                  placeholder="e.g. Main Plant Turnstile Gate A"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                />
              </div>

              {ipTestResult && (
                <div className="p-3.5 rounded-2xl border text-xs bg-emerald-50 border-emerald-200 text-emerald-900 animate-fade-in">
                  <div className="flex items-center gap-2 font-bold mb-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Socket Linked Successfully!</span>
                  </div>
                  <p className="text-[11px] leading-relaxed">{ipTestResult.msg}</p>
                </div>
              )}

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddIpModal(false);
                    setIpTestResult(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-100 font-bold text-slate-700 hover:bg-slate-200 cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={handleTestAndAddTerminal}
                  disabled={ipPingTesting}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-indigo-600 font-bold text-white hover:bg-indigo-700 shadow-md cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${ipPingTesting ? 'animate-spin' : ''}`} />
                  <span>{ipPingTesting ? 'AI Handshake Testing...' : 'AI Auto-Link by IP'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

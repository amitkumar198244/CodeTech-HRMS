// RSTPL HRMS - AI-Powered Geofencing Telemetry & Real-Time Alert Monitor
// RS Technovisions XpertSkillCop
// Provides visual GPS radar, real-time outside-radius breach alerts,
// AI spoofing/velocity diagnostics, multi-channel notification dispatch, and regularization workflows.

import React, { useState, useMemo } from 'react';
import {
  Radio,
  MapPin,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Bell,
  Navigation,
  Crosshair,
  Send,
  Smartphone,
  Mail,
  Sparkles,
  Zap,
  RefreshCw,
  SlidersHorizontal,
  Eye,
  CheckCircle2,
  XCircle,
  Building,
  Users,
  Volume2,
  VolumeX,
  Filter,
  Download,
  Clock,
  ChevronRight,
  Info,
  Check,
  X,
  Plus
} from 'lucide-react';
import {
  Unit,
  Employee,
  AttendanceRecord,
  GeoTrackingPunch,
  GeofenceBreachAlert,
  AppNotification
} from '../../types/hrms';
import {
  GeofenceService,
  calculateHaversineDistance,
  formatDistance,
  playGeofenceAlertChime,
  GeofenceEvaluationResult
} from '../../services/geofenceService';

interface AIGeofencingMonitorProps {
  units: Unit[];
  employees: Employee[];
  attendance: AttendanceRecord[];
  geoPunches: GeoTrackingPunch[];
  onUpdateGeoPunches: (punches: GeoTrackingPunch[]) => void;
  onUpdateAttendance: (records: AttendanceRecord[]) => void;
  onUpdateUnits?: (units: Unit[]) => void;
  onAddNotification?: (notif: AppNotification) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
  onNavigate?: (module: string) => void;
}

export const AIGeofencingMonitor: React.FC<AIGeofencingMonitorProps> = ({
  units,
  employees,
  attendance,
  geoPunches,
  onUpdateGeoPunches,
  onUpdateAttendance,
  onUpdateUnits,
  onAddNotification,
  onLogAudit,
  onNavigate,
}) => {
  // Unit Selection
  const [selectedUnitId, setSelectedUnitId] = useState<string>(units[0]?.id || 'un-mfg1');
  const selectedUnit = useMemo(() => {
    return units.find(u => u.id === selectedUnitId) || units[0] || {
      id: 'un-default',
      name: 'Manufacturing Unit 1 (Chakan Plant)',
      code: 'UN-MFG1',
      latitude: 18.7583,
      longitude: 73.8567,
      geofenceRadiusMeters: 250,
      strictGeofence: true
    };
  }, [units, selectedUnitId]);

  // Audio Toggle
  const [audioEnabled, setAudioEnabled] = useState<boolean>(true);

  // Active Real-Time Alert Banner State (Shows when a breach occurs)
  const [activeBreachBanner, setActiveBreachBanner] = useState<{
    alert: GeofenceBreachAlert;
    evalResult: GeofenceEvaluationResult;
  } | null>(null);

  // Filter & Search
  const [riskFilter, setRiskFilter] = useState<'ALL' | 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE_ALERT' | 'REGULARIZED' | 'PENALIZED'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected Marker for Details Drawer
  const [selectedPunchId, setSelectedPunchId] = useState<string | null>(null);

  // Simulator Modal State
  const [showSimulatorModal, setShowSimulatorModal] = useState<boolean>(false);
  const [simEmpId, setSimEmpId] = useState<string>(employees[0]?.id || 'emp-u01');
  const [simPunchType, setSimPunchType] = useState<'IN' | 'OUT' | 'FIELD_VISIT'>('IN');
  const [simPreset, setSimPreset] = useState<'inside' | 'borderline' | 'distant' | 'spoofed'>('distant');
  const [simCustomLat, setSimCustomLat] = useState<number>(18.7583);
  const [simCustomLng, setSimCustomLng] = useState<number>(73.8567);
  const [simCustomAddress, setSimCustomAddress] = useState<string>('Plot 42, Chakan Industrial Phase II');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // Unit Radius Configurator Modal State
  const [showConfigModal, setShowConfigModal] = useState<boolean>(false);
  const [configRadius, setConfigRadius] = useState<number>(selectedUnit.geofenceRadiusMeters || 250);
  const [configStrict, setConfigStrict] = useState<boolean>(selectedUnit.strictGeofence ?? true);

  // Stored Geofence Breach Alerts
  const [breachAlerts, setBreachAlerts] = useState<GeofenceBreachAlert[]>([
    {
      id: 'alert-001',
      punchId: 'geo-demo-1',
      employeeId: 'emp-u02',
      employeeCode: 'EMP002',
      employeeName: 'Amit Singh',
      designation: 'Officer',
      departmentName: 'Admin & Facilities',
      unitId: 'un-mfg1',
      unitName: 'Manufacturing Unit 1 (Assembly)',
      designatedRadiusMeters: 250,
      actualDistanceMeters: 3450,
      breachDistanceMeters: 3200,
      punchType: 'IN',
      date: '2026-10-08',
      time: '09:25',
      timestamp: '2026-10-08T09:25:00Z',
      coordinates: { lat: 18.7892, lng: 73.8712 },
      unitCoordinates: { lat: 18.7583, lng: 73.8567 },
      locationAddress: 'Pune-Nashik Highway Toll Plaza, Chakan Bypass',
      accuracyMeters: 6,
      aiRiskScore: 78,
      aiRiskLevel: 'HIGH',
      aiAnalysis: 'SIGNIFICANT GEOFENCE BREACH: Punch logged 3.45 km from Manufacturing Unit 1 (+3.20 km outside designated 250m perimeter). No field visit or client OD pass on record.',
      aiRecommendations: [
        'Automated warning dispatched to employee mobile.',
        'Sent escalation notification to Reporting Manager.',
        'Requires Line Manager approval for regularization.'
      ],
      alertChannels: ['Manager_Email', 'Manager_SMS', 'Employee_SMS', 'Push_Notification'],
      status: 'ACTIVE_ALERT'
    },
    {
      id: 'alert-002',
      punchId: 'geo-demo-2',
      employeeId: 'emp-004',
      employeeCode: 'RST-1004',
      employeeName: 'Sneha Deshmukh',
      designation: 'QA Lead',
      departmentName: 'Quality Assurance & Audit',
      unitId: 'un-mfg1',
      unitName: 'Manufacturing Unit 1 (Assembly)',
      designatedRadiusMeters: 250,
      actualDistanceMeters: 8500,
      breachDistanceMeters: 8250,
      punchType: 'FIELD_VISIT',
      date: '2026-10-08',
      time: '09:40',
      timestamp: '2026-10-08T09:40:00Z',
      coordinates: { lat: 18.7512, lng: 73.8499 },
      unitCoordinates: { lat: 18.7583, lng: 73.8567 },
      locationAddress: 'Tier 1 Supplier Foundry Unit, Chakan MIDC Phase 2',
      accuracyMeters: 8,
      aiRiskScore: 42,
      aiRiskLevel: 'MEDIUM',
      aiAnalysis: 'PPAP Quality Sample Batch Validation logged at authorized supplier premises. High accuracy GPS reading.',
      aiRecommendations: [
        'Verified client site tagged in system.',
        'Recommended one-click approval as official Outdoor Duty.'
      ],
      alertChannels: ['Manager_Email', 'Push_Notification'],
      status: 'REGULARIZED',
      resolutionNotes: 'Approved as authorized supplier QA audit by Amit Sharma.'
    }
  ]);

  // Telemetry KPIs
  const totalGpsPunches = geoPunches.length + 2;
  const activeAlertsCount = breachAlerts.filter(a => a.status === 'ACTIVE_ALERT').length;
  const criticalBreachesCount = breachAlerts.filter(a => a.aiRiskLevel === 'CRITICAL' || a.aiRiskLevel === 'HIGH').length;

  // Filtered Alerts Table
  const filteredAlerts = useMemo(() => {
    return breachAlerts.filter(alert => {
      if (riskFilter !== 'ALL' && alert.aiRiskLevel !== riskFilter) return false;
      if (statusFilter !== 'ALL' && alert.status !== statusFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          alert.employeeName.toLowerCase().includes(q) ||
          alert.employeeCode.toLowerCase().includes(q) ||
          alert.unitName.toLowerCase().includes(q) ||
          alert.locationAddress.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [breachAlerts, riskFilter, statusFilter, searchQuery]);

  // Selected Punch for detail drawer
  const selectedPunchDetails = useMemo(() => {
    if (!selectedPunchId) return null;
    const fromAlert = breachAlerts.find(a => a.id === selectedPunchId || a.punchId === selectedPunchId);
    if (fromAlert) return fromAlert;
    const fromPunches = geoPunches.find(p => p.id === selectedPunchId);
    return fromPunches || null;
  }, [selectedPunchId, breachAlerts, geoPunches]);

  // Handle Preset Change in Simulator
  const handlePresetSelect = (preset: 'inside' | 'borderline' | 'distant' | 'spoofed') => {
    setSimPreset(preset);
    const uLat = selectedUnit.latitude || 18.7583;
    const uLng = selectedUnit.longitude || 73.8567;

    if (preset === 'inside') {
      // ~45 meters away
      setSimCustomLat(Number((uLat + 0.0003).toFixed(5)));
      setSimCustomLng(Number((uLng + 0.0002).toFixed(5)));
      setSimCustomAddress(`${selectedUnit.name} - Turnstile Gate A`);
    } else if (preset === 'borderline') {
      // ~340 meters away (just outside 250m)
      setSimCustomLat(Number((uLat + 0.0025).toFixed(5)));
      setSimCustomLng(Number((uLng + 0.0018).toFixed(5)));
      setSimCustomAddress('Perimeter Logistics Road & Visitor Parking');
    } else if (preset === 'distant') {
      // ~4.8 km away
      setSimCustomLat(Number((uLat + 0.038).toFixed(5)));
      setSimCustomLng(Number((uLng + 0.025).toFixed(5)));
      setSimCustomAddress('Unauthorized Location: Sector 14 Highway Plaza');
    } else if (preset === 'spoofed') {
      // 140 km away (Mumbai location)
      setSimCustomLat(19.0760);
      setSimCustomLng(72.8777);
      setSimCustomAddress('Mumbai BKC Central Commercial Complex (140km Teleport)');
    }
  };

  // Run Simulation and Trigger Real-Time Alert
  const handleExecuteSimulation = async () => {
    setIsSimulating(true);

    const emp = employees.find(e => e.id === simEmpId) || employees[0];
    const previousMockPunch = simPreset === 'spoofed' ? {
      latitude: selectedUnit.latitude || 18.7583,
      longitude: selectedUnit.longitude || 73.8567,
      timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString() // 5 mins ago
    } : undefined;

    try {
      const evalResult = await GeofenceService.evaluatePunch(
        {
          latitude: simCustomLat,
          longitude: simCustomLng,
          accuracyMeters: simPreset === 'spoofed' ? 1 : 6,
          punchType: simPunchType,
          timestamp: new Date().toISOString()
        },
        emp,
        selectedUnit,
        previousMockPunch
      );

      const newPunch: GeoTrackingPunch = {
        id: `geo-live-${Date.now()}`,
        employeeId: emp.id,
        employeeCode: emp.employeeCode,
        employeeName: `${emp.firstName} ${emp.lastName}`,
        departmentName: emp.departmentId || 'Operations',
        designation: emp.designationId || 'Specialist',
        date: new Date().toISOString().slice(0, 10),
        time: new Date().toTimeString().slice(0, 5),
        type: simPunchType,
        latitude: simCustomLat,
        longitude: simCustomLng,
        locationAddress: simCustomAddress,
        clientOrSiteName: simCustomAddress,
        purpose: simPunchType === 'FIELD_VISIT' ? 'Client On-Site Consultation' : 'Shift Attendance Check-In',
        distanceFromBaseKm: Number((evalResult.actualDistanceMeters / 1000).toFixed(2)),
        accuracyMeters: evalResult.accuracyMeters,
        isWithinGeofence: evalResult.isWithinGeofence,
        batteryPercent: 88,
        deviceInfo: 'Live Mobile Geo Terminal (Simulated)',
        selfieVerified: true,
        notes: evalResult.aiAnalysisText,
        status: evalResult.isWithinGeofence ? 'Approved' : 'Flagged',
        unitId: selectedUnit.id,
        unitName: selectedUnit.name,
        unitRadiusMeters: evalResult.designatedRadiusMeters,
        actualDistanceMeters: evalResult.actualDistanceMeters,
        breachDistanceMeters: evalResult.breachDistanceMeters,
        aiRiskLevel: evalResult.aiRiskLevel,
        aiRiskScore: evalResult.aiRiskScore,
        aiAnalysisText: evalResult.aiAnalysisText,
        alertDispatched: !evalResult.isWithinGeofence,
        managerNotified: !evalResult.isWithinGeofence,
        employeeNotified: !evalResult.isWithinGeofence
      };

      // Add to punches
      onUpdateGeoPunches([newPunch, ...geoPunches]);

      // If breach occurred, create alert, play chime, and trigger real-time notification
      if (!evalResult.isWithinGeofence) {
        const newAlert = GeofenceService.buildBreachAlert(newPunch, evalResult, selectedUnit);
        setBreachAlerts(prev => [newAlert, ...prev]);

        // Audio Chime
        if (audioEnabled) {
          playGeofenceAlertChime();
        }

        // Active Banner
        setActiveBreachBanner({
          alert: newAlert,
          evalResult
        });

        // Trigger System AppNotification
        if (onAddNotification) {
          onAddNotification({
            id: `notif-geo-${Date.now()}`,
            orgId: emp.orgId,
            title: `Geofence Breach: ${emp.firstName} ${emp.lastName}`,
            message: `${emp.employeeCode} punched ${simPunchType} ${formatDistance(evalResult.actualDistanceMeters)} outside ${selectedUnit.name} (+${formatDistance(evalResult.breachDistanceMeters)} breach).`,
            type: 'geofence',
            read: false,
            timestamp: 'Just now'
          });
        }

        // Log to Audit Trail
        onLogAudit(
          'ALERT',
          'AI Geofencing Monitor',
          `Triggered ${evalResult.aiRiskLevel} alert for ${emp.employeeCode} punching ${simPunchType} outside ${selectedUnit.name} (Breach: +${formatDistance(evalResult.breachDistanceMeters)})`
        );

        // Update Daily Attendance as Flagged / Pending Regularization
        const existingAtt = attendance.find(a => a.employeeCode === emp.employeeCode);
        if (existingAtt) {
          const updatedAtt: AttendanceRecord = {
            ...existingAtt,
            status: 'Late', // or flagged
            remarks: `Geofence Breach: Punched ${formatDistance(evalResult.breachDistanceMeters)} outside ${selectedUnit.name}`,
            isGeoPunch: true,
            geoLatitude: simCustomLat,
            geoLongitude: simCustomLng,
            geoAddress: simCustomAddress
          };
          onUpdateAttendance(attendance.map(a => a.id === existingAtt.id ? updatedAtt : a));
        }
      } else {
        // Compliant punch
        onLogAudit(
          'PUNCH',
          'AI Geofencing Monitor',
          `Verified compliant geofence punch for ${emp.employeeCode} at ${selectedUnit.name} (${formatDistance(evalResult.actualDistanceMeters)} within radius)`
        );
      }

      setShowSimulatorModal(false);
    } finally {
      setIsSimulating(false);
    }
  };

  // Regularize an Alert
  const handleRegularizeAlert = (alertId: string, action: 'REGULARIZED' | 'PENALIZED') => {
    setBreachAlerts(prev =>
      prev.map(a => {
        if (a.id === alertId) {
          return {
            ...a,
            status: action,
            resolutionNotes:
              action === 'REGULARIZED'
                ? 'Approved as authorized Outdoor Duty by Executive HR'
                : 'Marked as unapproved deviation - Half Day salary deduction applied'
          };
        }
        return a;
      })
    );

    onLogAudit(
      action === 'REGULARIZED' ? 'APPROVE' : 'REJECT',
      'AI Geofencing Monitor',
      `${action === 'REGULARIZED' ? 'Regularized' : 'Penalized'} geofence breach alert #${alertId}`
    );
  };

  // Save Unit Radius Configuration
  const handleSaveUnitRadius = () => {
    if (onUpdateUnits) {
      const updated = units.map(u => {
        if (u.id === selectedUnit.id) {
          return {
            ...u,
            geofenceRadiusMeters: configRadius,
            strictGeofence: configStrict
          };
        }
        return u;
      });
      onUpdateUnits(updated);
    }

    onLogAudit(
      'UPDATE',
      'AI Geofencing Monitor',
      `Updated designated GPS radius for ${selectedUnit.name} to ${configRadius}m (Strict: ${configStrict ? 'Yes' : 'No'})`
    );
    setShowConfigModal(false);
  };

  // Export Breaches to CSV
  const handleExportBreaches = () => {
    const csvHeader = 'AlertID,Timestamp,EmployeeCode,EmployeeName,UnitName,PunchType,DesignatedRadiusMeters,ActualDistanceMeters,BreachMeters,RiskLevel,RiskScore,Status,Address\n';
    const csvRows = breachAlerts.map(a =>
      `"${a.id}","${a.timestamp}","${a.employeeCode}","${a.employeeName}","${a.unitName}","${a.punchType}",${a.designatedRadiusMeters},${a.actualDistanceMeters},${a.breachDistanceMeters},"${a.aiRiskLevel}",${a.aiRiskScore},"${a.status}","${a.locationAddress}"`
    ).join('\n');

    const blob = new Blob([csvHeader + csvRows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `RSTPL_Geofence_Breaches_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* 🚨 REAL-TIME FLOATING ALERT BANNER (Triggers on Outside Radius Punch) */}
      {activeBreachBanner && (
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-rose-950 via-red-900 to-rose-900 border-2 border-rose-500 shadow-2xl p-5 text-white animate-bounce-short">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <span className="p-3 rounded-2xl bg-rose-600/50 border border-rose-400 text-white animate-pulse">
                <ShieldAlert className="w-6 h-6" />
              </span>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-500 text-white">
                    REAL-TIME GEOFENCE BREACH TRIGGERED
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-950">
                    Risk: {activeBreachBanner.evalResult.aiRiskLevel} ({activeBreachBanner.evalResult.aiRiskScore}/100)
                  </span>
                  <span className="text-xs text-rose-200 font-mono">
                    {new Date().toLocaleTimeString()}
                  </span>
                </div>
                <h3 className="text-base font-black text-white mt-1">
                  {activeBreachBanner.alert.employeeName} ({activeBreachBanner.alert.employeeCode}) punched {activeBreachBanner.alert.punchType} outside assigned radius!
                </h3>
                <p className="text-xs text-rose-100 max-w-3xl mt-0.5 leading-relaxed">
                  {activeBreachBanner.evalResult.aiAnalysisText}
                </p>
                <div className="flex items-center gap-4 mt-2 text-[11px] text-rose-200 font-medium">
                  <span>📍 Actual Distance: <b>{formatDistance(activeBreachBanner.evalResult.actualDistanceMeters)}</b></span>
                  <span>⭕ Allowed Radius: <b>{activeBreachBanner.evalResult.designatedRadiusMeters}m</b></span>
                  <span>🚨 Perimeter Breach: <b>+{formatDistance(activeBreachBanner.evalResult.breachDistanceMeters)}</b></span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end md:self-center shrink-0">
              <div className="text-right hidden sm:block mr-2">
                <span className="text-[10px] uppercase font-bold text-emerald-300 flex items-center gap-1 justify-end">
                  <CheckCircle2 className="w-3 h-3" />
                  SMS & Email Dispatched
                </span>
                <p className="text-[10px] text-rose-200">Manager & HR alerted</p>
              </div>
              <button
                onClick={() => {
                  handleRegularizeAlert(activeBreachBanner.alert.id, 'REGULARIZED');
                  setActiveBreachBanner(null);
                }}
                className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-colors cursor-pointer"
              >
                Approve OD
              </button>
              <button
                onClick={() => setActiveBreachBanner(null)}
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                title="Dismiss Banner"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TOP HEADER & CONTROL STRIP */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="p-3 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-700">
              <Navigation className="w-6 h-6" />
            </span>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-100 text-indigo-800 font-mono">
                  AI GEOFENCE ENGINE v2.4
                </span>
                <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  GPS Monitor Live
                </span>
              </div>
              <h2 className="text-xl font-black text-slate-900 tracking-tight mt-0.5">
                AI-Powered Geofencing Telemetry & Real-Time Alert Monitor
              </h2>
              <p className="text-xs text-slate-500">
                Continuous geofence validation, geodesic radius breach detection, GPS spoofing/teleportation analysis & multi-channel alerts
              </p>
            </div>
          </div>

          {/* Quick Actions Strip */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Audio Toggle */}
            <button
              onClick={() => {
                setAudioEnabled(!audioEnabled);
                if (!audioEnabled) playGeofenceAlertChime();
              }}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                audioEnabled
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                  : 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100'
              }`}
              title={audioEnabled ? 'Audible real-time alarm chime enabled' : 'Muted'}
            >
              {audioEnabled ? <Volume2 className="w-4 h-4 text-emerald-600" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
              <span>{audioEnabled ? 'Alarm Sound: ON' : 'Alarm Sound: Muted'}</span>
            </button>

            {/* Radius Configurator */}
            <button
              onClick={() => {
                setConfigRadius(selectedUnit.geofenceRadiusMeters || 250);
                setConfigStrict(selectedUnit.strictGeofence ?? true);
                setShowConfigModal(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs border border-slate-200 transition cursor-pointer"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-600" />
              <span>Unit Radius ({selectedUnit.geofenceRadiusMeters || 250}m)</span>
            </button>

            {/* Test Punch Simulator (Primary trigger for testing alerts!) */}
            <button
              onClick={() => {
                handlePresetSelect('distant');
                setShowSimulatorModal(true);
              }}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-700 hover:to-sky-700 text-white font-bold text-xs shadow-md shadow-indigo-600/20 transition cursor-pointer"
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>Simulate Real-Time Punch & Alert</span>
            </button>
          </div>
        </div>

        {/* 4 Telemetry Metrics Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-[10px] font-bold text-slate-500 uppercase">Monitored Unit</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-sm font-black text-slate-900 truncate">{selectedUnit.name}</span>
              <Building className="w-4 h-4 text-slate-400" />
            </div>
            <span className="text-[10px] text-slate-500 font-mono mt-0.5 block">
              Lat: {selectedUnit.latitude}°, Lng: {selectedUnit.longitude}°
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200">
            <span className="text-[10px] font-bold text-emerald-700 uppercase">Designated Safe Radius</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xl font-black text-emerald-800">{selectedUnit.geofenceRadiusMeters || 250} m</span>
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
            </div>
            <span className="text-[10px] text-emerald-600 font-semibold mt-0.5 block">
              {selectedUnit.strictGeofence ? 'Strict Enforcement Active' : 'Advisory Mode'}
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-rose-50/60 border border-rose-200">
            <span className="text-[10px] font-bold text-rose-700 uppercase">Active Breach Alerts</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xl font-black text-rose-800">{activeAlertsCount}</span>
              <Bell className="w-5 h-5 text-rose-600 animate-pulse" />
            </div>
            <span className="text-[10px] text-rose-600 font-semibold mt-0.5 block">
              {criticalBreachesCount} High/Critical Risk
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-200">
            <span className="text-[10px] font-bold text-indigo-700 uppercase">AI Diagnosis Engine</span>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xl font-black text-indigo-900">Gemini 3.8</span>
              <Sparkles className="w-5 h-5 text-indigo-600" />
            </div>
            <span className="text-[10px] text-indigo-600 font-semibold mt-0.5 block">
              Mock Spoof & Transit Velocity Active
            </span>
          </div>
        </div>
      </div>

      {/* INTERACTIVE RADAR & VISUAL GEOFENCE MAP CANVAS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Visual Radar Canvas */}
        <div className="lg:col-span-2 bg-slate-950 rounded-3xl p-6 text-white border border-slate-800 shadow-xl relative overflow-hidden flex flex-col justify-between min-h-[480px]">
          {/* Radar Header */}
          <div className="flex items-center justify-between z-10 mb-4">
            <div className="flex items-center gap-2.5">
              <Radio className="w-5 h-5 text-emerald-400 animate-pulse" />
              <div>
                <span className="text-xs font-black uppercase tracking-wider text-emerald-400">
                  Live Geofence Telemetry Radar
                </span>
                <p className="text-[11px] text-slate-400">
                  Real-time GPS coordinate plotting centered at {selectedUnit.name}
                </p>
              </div>
            </div>

            {/* Unit Switcher */}
            <select
              value={selectedUnitId}
              onChange={e => setSelectedUnitId(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-xs font-bold text-sky-300 rounded-xl px-3 py-1.5 focus:outline-hidden focus:border-sky-500"
            >
              {units.map(u => (
                <option key={u.id} value={u.id}>
                  {u.name} ({u.geofenceRadiusMeters || 250}m)
                </option>
              ))}
            </select>
          </div>

          {/* Interactive Radar Visual Canvas */}
          <div className="relative flex-1 bg-radial from-slate-900 to-slate-950 rounded-2xl border border-slate-800/80 p-4 flex items-center justify-center overflow-hidden min-h-[360px]">
            {/* Concentric Distance Rings */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              {/* Radius Safe Zone (Green Circle) */}
              <div
                className="rounded-full border-2 border-emerald-500/60 bg-emerald-500/10 flex items-center justify-center transition-all duration-700"
                style={{ width: '180px', height: '180px' }}
              >
                <span className="text-[9px] font-mono font-bold text-emerald-400/80 absolute -top-3.5 bg-slate-950/80 px-1.5 rounded">
                  SAFE RADIUS: {selectedUnit.geofenceRadiusMeters || 250}m
                </span>
              </div>

              {/* 2x Radius Ring (Amber border) */}
              <div
                className="rounded-full border border-dashed border-amber-500/30 absolute"
                style={{ width: '280px', height: '280px' }}
              >
                <span className="text-[8px] font-mono text-amber-400/60 absolute -top-3 left-1/2 -translate-x-1/2 bg-slate-950 px-1 rounded">
                  ~{(selectedUnit.geofenceRadiusMeters || 250) * 2}m
                </span>
              </div>

              {/* Outer Breach Perimeter Ring (Red border) */}
              <div
                className="rounded-full border border-rose-500/20 absolute"
                style={{ width: '380px', height: '380px' }}
              >
                <span className="text-[8px] font-mono text-rose-400/60 absolute -top-3 left-1/2 -translate-x-1/2 bg-slate-950 px-1 rounded">
                  OUTER PERIMETER &gt; 1 km
                </span>
              </div>

              {/* Sweeping Radar Line */}
              <div className="absolute w-[380px] h-[380px] rounded-full border border-sky-500/10 pointer-events-none animate-spin-slow" />
            </div>

            {/* Center: Assigned Unit Base Marker */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center">
              <span className="p-3 rounded-full bg-sky-500/20 text-sky-400 border border-sky-400/80 shadow-lg shadow-sky-500/40">
                <Building className="w-5 h-5" />
              </span>
              <span className="text-[10px] font-black bg-slate-900/95 text-sky-300 px-2 py-0.5 rounded-md mt-1 border border-slate-700 shadow-md whitespace-nowrap">
                {selectedUnit.name}
              </span>
            </div>

            {/* Punches & Breach Markers Placed on Radar */}
            {/* Punch 1: Inside Safe Radius */}
            <div
              onClick={() => setSelectedPunchId('punch-safe-1')}
              className="absolute cursor-pointer group z-30 transition-transform hover:scale-125"
              style={{ top: '44%', left: '56%' }}
              title="Raj Kumar - 48m from base (Inside Safe Zone)"
            >
              <span className="p-2 rounded-full bg-emerald-500 text-slate-950 font-black shadow-lg shadow-emerald-500/50 flex items-center justify-center">
                <Check className="w-3.5 h-3.5" />
              </span>
              <div className="bg-slate-900/90 text-white border border-emerald-500/50 px-2 py-0.5 rounded-lg text-[9px] mt-1 shadow-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                Raj Kumar (48m) - Compliant
              </div>
            </div>

            {/* Punch 2: Borderline Breach */}
            <div
              onClick={() => setSelectedPunchId('alert-002')}
              className="absolute cursor-pointer group z-30 transition-transform hover:scale-125"
              style={{ top: '28%', left: '68%' }}
              title="Sneha Deshmukh - 340m from base (Mild Breach)"
            >
              <span className="p-2 rounded-full bg-amber-400 text-slate-950 font-black shadow-lg shadow-amber-400/50 flex items-center justify-center">
                <AlertTriangle className="w-3.5 h-3.5" />
              </span>
              <div className="bg-slate-900/90 text-white border border-amber-500/50 px-2 py-0.5 rounded-lg text-[9px] mt-1 shadow-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                Sneha Deshmukh (340m) - Mild
              </div>
            </div>

            {/* Punch 3: Major Critical Breach */}
            <div
              onClick={() => setSelectedPunchId('alert-001')}
              className="absolute cursor-pointer group z-30 transition-transform hover:scale-125"
              style={{ top: '74%', left: '22%' }}
              title="Amit Singh - 3.45 km from base (Major Breach)"
            >
              <span className="relative flex h-8 w-8 items-center justify-center">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                <span className="p-2 rounded-full bg-rose-600 text-white font-black shadow-lg shadow-rose-600/80 flex items-center justify-center relative">
                  <ShieldAlert className="w-3.5 h-3.5" />
                </span>
              </span>
              <div className="bg-slate-900/90 text-rose-300 border border-rose-500 px-2 py-0.5 rounded-lg text-[9px] mt-1 shadow-lg whitespace-nowrap">
                Amit Singh (+3.2km Breach)
              </div>
            </div>

            {/* Punch 4: Live Simulated Punch (if exists) */}
            {geoPunches[0] && (
              <div
                onClick={() => setSelectedPunchId(geoPunches[0].id)}
                className="absolute cursor-pointer group z-30 transition-transform hover:scale-125"
                style={{ top: '20%', left: '32%' }}
              >
                <span className="relative flex h-8 w-8 items-center justify-center">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75" />
                  <span className={`p-2 rounded-full text-white font-black shadow-lg flex items-center justify-center relative ${
                    geoPunches[0].isWithinGeofence ? 'bg-emerald-500 shadow-emerald-500/80' : 'bg-rose-600 shadow-rose-600/80'
                  }`}>
                    <Crosshair className="w-3.5 h-3.5" />
                  </span>
                </span>
                <div className="bg-slate-900/90 text-sky-200 border border-sky-400 px-2 py-0.5 rounded-lg text-[9px] mt-1 shadow-lg whitespace-nowrap">
                  {geoPunches[0].employeeName} (Live Test)
                </div>
              </div>
            )}
          </div>

          {/* Radar Footer Legend */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-3 border-t border-slate-800 text-slate-400 mt-2">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                <span>Inside Geofence Radius (&le; {selectedUnit.geofenceRadiusMeters || 250}m)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <span>Borderline Breach</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                <span>Major Breach / Alert Triggered</span>
              </span>
            </div>
            <span className="text-[11px] font-mono text-slate-400">
              Formula: Haversine Geodesic (WGS-84)
            </span>
          </div>
        </div>

        {/* Right Col: AI Breach Telemetry & Incident Details Card */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-black text-slate-900 uppercase">
                  AI Breach Telemetry & Inspector
                </h3>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700">
                Live Analysis
              </span>
            </div>

            {/* Detail Content */}
            {selectedPunchDetails ? (
              <div className="space-y-4 pt-3 text-xs">
                {/* Employee Header */}
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">
                        {'employeeName' in selectedPunchDetails ? selectedPunchDetails.employeeName : 'Unknown'}
                      </h4>
                      <p className="text-[11px] text-slate-500 font-mono">
                        {'employeeCode' in selectedPunchDetails ? selectedPunchDetails.employeeCode : ''} · {'departmentName' in selectedPunchDetails ? selectedPunchDetails.departmentName : ''}
                      </p>
                    </div>
                    {'aiRiskLevel' in selectedPunchDetails && selectedPunchDetails.aiRiskLevel && (
                      <span className={`px-2 py-0.5 rounded-full font-black text-[10px] ${
                        selectedPunchDetails.aiRiskLevel === 'CRITICAL'
                          ? 'bg-rose-100 text-rose-800'
                          : selectedPunchDetails.aiRiskLevel === 'HIGH'
                          ? 'bg-orange-100 text-orange-800'
                          : selectedPunchDetails.aiRiskLevel === 'MEDIUM'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {selectedPunchDetails.aiRiskLevel} RISK
                      </span>
                    )}
                  </div>
                </div>

                {/* Distance & Coordinates */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Actual Distance</span>
                    <p className="text-sm font-black text-slate-900 mt-0.5">
                      {'actualDistanceMeters' in selectedPunchDetails && selectedPunchDetails.actualDistanceMeters
                        ? formatDistance(selectedPunchDetails.actualDistanceMeters)
                        : '48 m'}
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Perimeter Breach</span>
                    <p className={`text-sm font-black mt-0.5 ${
                      'breachDistanceMeters' in selectedPunchDetails && selectedPunchDetails.breachDistanceMeters && selectedPunchDetails.breachDistanceMeters > 0
                        ? 'text-rose-600'
                        : 'text-emerald-600'
                    }`}>
                      {'breachDistanceMeters' in selectedPunchDetails && selectedPunchDetails.breachDistanceMeters && selectedPunchDetails.breachDistanceMeters > 0
                        ? `+${formatDistance(selectedPunchDetails.breachDistanceMeters)}`
                        : '0 m (Inside)'}
                    </p>
                  </div>
                </div>

                {/* Address & Punch Time */}
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block mb-1">GPS Location Address</span>
                  <p className="text-slate-700 bg-slate-50 p-2 rounded-xl border border-slate-100 text-[11px] leading-relaxed">
                    {'locationAddress' in selectedPunchDetails ? selectedPunchDetails.locationAddress : 'Plot 42, Chakan Industrial Phase II'}
                  </p>
                </div>

                {/* AI Reasoning */}
                <div className="p-3.5 rounded-2xl bg-indigo-50/70 border border-indigo-200">
                  <div className="flex items-center gap-1.5 font-bold text-indigo-900 mb-1 text-[11px]">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Gemini AI Security Assessment:</span>
                  </div>
                  <p className="text-indigo-950 text-[11px] leading-relaxed">
                    {'aiAnalysis' in selectedPunchDetails
                      ? selectedPunchDetails.aiAnalysis
                      : 'aiAnalysisText' in selectedPunchDetails && selectedPunchDetails.aiAnalysisText
                      ? selectedPunchDetails.aiAnalysisText
                      : 'Compliant Punch: Verified within designated unit perimeter.'}
                  </p>
                </div>

                {/* Recommendations */}
                {'aiRecommendations' in selectedPunchDetails && Array.isArray(selectedPunchDetails.aiRecommendations) && (
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase font-bold block mb-1">Action Recommendations:</span>
                    <ul className="space-y-1 text-[11px] text-slate-600">
                      {selectedPunchDetails.aiRecommendations.map((r, rIdx) => (
                        <li key={rIdx} className="flex items-start gap-1.5">
                          <span className="text-indigo-600 font-bold">•</span>
                          <span>{r}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-6 text-center text-slate-400 space-y-2">
                <MapPin className="w-8 h-8 mx-auto text-slate-300" />
                <p className="text-xs">Click any marker on the radar or an incident in the table to view AI telemetry</p>
              </div>
            )}
          </div>

          {/* Quick Simulation Trigger */}
          <button
            onClick={() => {
              handlePresetSelect('distant');
              setShowSimulatorModal(true);
            }}
            className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition shadow-sm"
          >
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            <span>Simulate Outside Punch Test</span>
          </button>
        </div>
      </div>

      {/* GEOFENCE BREACH INCIDENTS & AUDIT LOG TABLE */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              <h3 className="text-base font-black text-slate-900">
                Geofence Perimeter Incident Register & Real-Time Alert Log
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              Audit trail of outside-radius punches, automated notifications sent to managers, and regularization status
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportBreaches}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex flex-wrap items-center gap-2">
            {/* Risk filter */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-bold text-slate-700">
              {(['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'] as const).map(lvl => (
                <button
                  key={lvl}
                  onClick={() => setRiskFilter(lvl)}
                  className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                    riskFilter === lvl ? 'bg-white text-slate-900 shadow-xs' : 'hover:text-slate-900'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>

            {/* Status filter */}
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value as any)}
              className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-700"
            >
              <option value="ALL">All Statuses</option>
              <option value="ACTIVE_ALERT">Active Alerts Only</option>
              <option value="REGULARIZED">Regularized / Approved</option>
              <option value="PENALIZED">Penalized / Deducted</option>
            </select>
          </div>

          <input
            type="text"
            placeholder="Search employee, unit, or location..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 placeholder-slate-400 w-64"
          />
        </div>

        {/* Table */}
        <div className="overflow-x-auto rounded-2xl border border-slate-200">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 font-bold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-4">Time & Punch</th>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Assigned Unit</th>
                <th className="py-3 px-4">Radius vs Actual</th>
                <th className="py-3 px-4">Perimeter Breach</th>
                <th className="py-3 px-4">AI Risk & Telemetry</th>
                <th className="py-3 px-4">Alert Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAlerts.length > 0 ? (
                filteredAlerts.map(alert => (
                  <tr
                    key={alert.id}
                    onClick={() => setSelectedPunchId(alert.id)}
                    className="hover:bg-indigo-50/40 transition cursor-pointer"
                  >
                    <td className="py-3 px-4">
                      <div className="font-mono font-bold text-slate-900">{alert.time}</div>
                      <span className="inline-block px-1.5 py-0.2 rounded text-[9px] font-black bg-slate-100 text-slate-700 font-mono">
                        {alert.punchType}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{alert.employeeName}</div>
                      <span className="text-[10px] text-slate-400 font-mono">{alert.employeeCode} · {alert.departmentName}</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-800">{alert.unitName}</div>
                      <span className="text-[10px] text-slate-400">Safe: {alert.designatedRadiusMeters}m</span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold font-mono text-slate-900">{formatDistance(alert.actualDistanceMeters)}</div>
                      <span className="text-[10px] text-slate-400">from facility center</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-black font-mono text-rose-600 bg-rose-50 px-2 py-0.5 rounded-lg border border-rose-200">
                        +{formatDistance(alert.breachDistanceMeters)}
                      </span>
                    </td>
                    <td className="py-3 px-4 max-w-xs">
                      <div className="flex items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black ${
                          alert.aiRiskLevel === 'CRITICAL'
                            ? 'bg-rose-100 text-rose-800'
                            : alert.aiRiskLevel === 'HIGH'
                            ? 'bg-orange-100 text-orange-800'
                            : alert.aiRiskLevel === 'MEDIUM'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {alert.aiRiskLevel} ({alert.aiRiskScore}/100)
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 truncate mt-0.5" title={alert.aiAnalysis}>
                        {alert.aiAnalysis}
                      </p>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-xl text-[10px] font-bold ${
                        alert.status === 'ACTIVE_ALERT'
                          ? 'bg-rose-100 text-rose-800 animate-pulse'
                          : alert.status === 'REGULARIZED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {alert.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {alert.status === 'ACTIVE_ALERT' ? (
                        <div className="flex items-center justify-end gap-1.5" onClick={e => e.stopPropagation()}>
                          <button
                            onClick={() => handleRegularizeAlert(alert.id, 'REGULARIZED')}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] transition cursor-pointer"
                            title="Approve as valid Outdoor Duty"
                          >
                            Approve OD
                          </button>
                          <button
                            onClick={() => handleRegularizeAlert(alert.id, 'PENALIZED')}
                            className="px-2.5 py-1 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-800 font-bold text-[10px] transition cursor-pointer"
                            title="Reject and flag penalty"
                          >
                            Penalize
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400 font-semibold">Resolved</span>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    No geofence breach incidents match the selected filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* REAL-TIME BREACH SIMULATOR MODAL */}
      {showSimulatorModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col animate-scale-in">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-900 to-indigo-950 text-white">
              <div className="flex items-center gap-2.5">
                <Zap className="w-5 h-5 text-amber-300" />
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider">
                    Simulate Real-Time Geofence Punch & Trigger Alert
                  </h3>
                  <p className="text-[11px] text-indigo-200">
                    Test GPS radius evaluation, Gemini AI spoofing detection, and multi-channel notifications
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowSimulatorModal(false)}
                className="p-1 rounded-lg text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              {/* Target Employee & Punch Type */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Employee Under Test *</label>
                  <select
                    value={simEmpId}
                    onChange={e => setSimEmpId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                  >
                    {employees.map(e => (
                      <option key={e.id} value={e.id}>
                        {e.firstName} {e.lastName} ({e.employeeCode})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Punch Type *</label>
                  <select
                    value={simPunchType}
                    onChange={e => setSimPunchType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sky-800"
                  >
                    <option value="IN">Morning IN Punch</option>
                    <option value="OUT">Evening OUT Punch</option>
                    <option value="FIELD_VISIT">Remote Field Visit Punch</option>
                  </select>
                </div>
              </div>

              {/* Monitored Base Facility */}
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] text-slate-500 uppercase font-bold">Assigned Base Unit:</span>
                <div className="flex items-center justify-between mt-0.5">
                  <span className="font-bold text-slate-900">{selectedUnit.name}</span>
                  <span className="text-[11px] font-mono text-emerald-700 font-bold">Radius: {selectedUnit.geofenceRadiusMeters || 250}m</span>
                </div>
              </div>

              {/* Simulation Preset Selector */}
              <div>
                <label className="block text-slate-700 font-bold mb-1.5">Simulation Test Scenarios (Select One):</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handlePresetSelect('inside')}
                    className={`p-3 rounded-2xl border text-left transition cursor-pointer ${
                      simPreset === 'inside'
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-950 font-bold'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span className="font-bold">Inside Radius (45m)</span>
                    </div>
                    <p className="text-[10px] text-slate-500">Normal check-in at turnstile gate. No alert.</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => handlePresetSelect('borderline')}
                    className={`p-3 rounded-2xl border text-left transition cursor-pointer ${
                      simPreset === 'borderline'
                        ? 'border-amber-500 bg-amber-50 text-amber-950 font-bold'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      <AlertTriangle className="w-4 h-4 text-amber-600" />
                      <span className="font-bold">Borderline (+90m Breach)</span>
                    </div>
                    <p className="text-[10px] text-slate-500">Outer parking lot. Soft warning triggered.</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => handlePresetSelect('distant')}
                    className={`p-3 rounded-2xl border text-left transition cursor-pointer ${
                      simPreset === 'distant'
                        ? 'border-rose-500 bg-rose-50 text-rose-950 font-bold'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      <ShieldAlert className="w-4 h-4 text-rose-600" />
                      <span className="font-bold">Distant Breach (4.8 km)</span>
                    </div>
                    <p className="text-[10px] text-slate-500">Unauthorized location. Triggers real-time alerts.</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => handlePresetSelect('spoofed')}
                    className={`p-3 rounded-2xl border text-left transition cursor-pointer ${
                      simPreset === 'spoofed'
                        ? 'border-purple-500 bg-purple-50 text-purple-950 font-bold'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      <Sparkles className="w-4 h-4 text-purple-600" />
                      <span className="font-bold">Mock GPS Spoof (140 km)</span>
                    </div>
                    <p className="text-[10px] text-slate-500">Teleportation speed anomaly caught by AI.</p>
                  </button>
                </div>
              </div>

              {/* Coordinates Preview */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 mb-1">Simulated Latitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={simCustomLat}
                    onChange={e => setSimCustomLat(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 mb-1">Simulated Longitude</label>
                  <input
                    type="number"
                    step="0.0001"
                    value={simCustomLng}
                    onChange={e => setSimCustomLng(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 mb-1">Location Label / Address</label>
                <input
                  type="text"
                  value={simCustomAddress}
                  onChange={e => setSimCustomAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium"
                />
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowSimulatorModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 font-bold text-slate-700 hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleExecuteSimulation}
                  disabled={isSimulating}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-rose-600 hover:from-indigo-700 hover:to-rose-700 text-white font-bold shadow-md cursor-pointer disabled:opacity-50"
                >
                  <Zap className={`w-4 h-4 ${isSimulating ? 'animate-spin' : ''}`} />
                  <span>{isSimulating ? 'Evaluating with AI...' : 'Submit Punch & Trigger Live Alert'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* UNIT RADIUS CONFIGURATION MODAL */}
      {showConfigModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl p-6 space-y-4 animate-scale-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-indigo-600" />
                <h3 className="text-sm font-black text-slate-900 uppercase">
                  Designated Geofence Perimeter
                </h3>
              </div>
              <button
                onClick={() => setShowConfigModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <span className="text-slate-500 block mb-1">Target Facility</span>
                <p className="font-bold text-slate-900 text-sm">{selectedUnit.name}</p>
                <p className="text-[11px] text-slate-400 font-mono">
                  Coordinates: {selectedUnit.latitude}°, {selectedUnit.longitude}°
                </p>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-bold text-slate-700">Designated Radius: {configRadius} meters</label>
                  <span className="font-mono text-indigo-600 font-bold">{configRadius} m</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="2000"
                  step="25"
                  value={configRadius}
                  onChange={e => setConfigRadius(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                  <span>50m (Turnstile Gate)</span>
                  <span>250m (Standard Plant)</span>
                  <span>1000m (Campus)</span>
                  <span>2000m</span>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-800 block">Strict Enforcement Mode</span>
                  <p className="text-[11px] text-slate-500">Require supervisor OD approval for outside punches</p>
                </div>
                <input
                  type="checkbox"
                  checked={configStrict}
                  onChange={e => setConfigStrict(e.target.checked)}
                  className="w-4 h-4 accent-indigo-600 rounded cursor-pointer"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowConfigModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 font-bold text-slate-700 hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveUnitRadius}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold cursor-pointer"
                >
                  Save Perimeter
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

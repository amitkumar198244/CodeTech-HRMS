// RSTPL HRMS - Attendance Finalization & Lock Engine
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Unlock,
  AlertCircle,
  CheckCircle2,
  FileCheck,
  RotateCcw,
  Clock,
  ArrowRight
} from 'lucide-react';
import { AttendanceRecord, Employee } from '../../types/hrms';

interface AttendanceFinalizationViewProps {
  attendance: AttendanceRecord[];
  employees: Employee[];
  onUpdateAttendance: (records: AttendanceRecord[]) => void;
  onLogAudit: (action: any, module: string, details: string) => void;
  onNavigate: (module: string) => void;
}

export const AttendanceFinalizationView: React.FC<AttendanceFinalizationViewProps> = ({
  attendance,
  employees,
  onUpdateAttendance,
  onLogAudit,
  onNavigate,
}) => {
  const [selectedMonth, setSelectedMonth] = useState('October 2026');
  const [showReopenModal, setShowReopenModal] = useState(false);
  const [reopenReason, setReopenReason] = useState('');

  const finalizedCount = attendance.filter(a => a.isFinalized).length;
  const isMonthFullyLocked = attendance.length > 0 && finalizedCount === attendance.length;

  const missingPunchesCount = attendance.filter(a => a.status === 'Present' && (!a.firstIn || !a.lastOut)).length;
  const overtimeCount = attendance.filter(a => a.isOvertime).length;

  // Lock and Finalize Attendance
  const handleFinalizeAll = () => {
    const updated = attendance.map(a => ({ ...a, isFinalized: true }));
    onUpdateAttendance(updated);
    onLogAudit(
      'FINALIZE',
      'Attendance Finalization',
      `Locked and finalized monthly attendance for ${selectedMonth} across ${attendance.length} records. Ready for Payroll processing.`
    );
  };

  // Reopen locked attendance
  const handleReopenRecords = () => {
    if (!reopenReason.trim()) return;
    const updated = attendance.map(a => ({ ...a, isFinalized: false }));
    onUpdateAttendance(updated);
    setShowReopenModal(false);
    onLogAudit(
      'UPDATE',
      'Attendance Finalization',
      `Reopened finalized attendance for ${selectedMonth}. Reason: "${reopenReason}".`
    );
    setReopenReason('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
              <ShieldCheck className="w-5 h-5 text-emerald-700" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                Attendance Finalization & Payroll Lock
              </h2>
              <p className="text-xs text-slate-500">
                Audited monthly cut-off certification, missing punch resolution & immutable payroll handover
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedMonth}
            onChange={e => setSelectedMonth(e.target.value)}
            className="text-xs px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 font-bold text-slate-800"
          >
            <option value="October 2026">October 2026 (Active Period)</option>
            <option value="September 2026">September 2026 (Past Period)</option>
          </select>

          {isMonthFullyLocked ? (
            <button
              onClick={() => setShowReopenModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              <Unlock className="w-4 h-4" />
              <span>Reopen Attendance</span>
            </button>
          ) : (
            <button
              onClick={handleFinalizeAll}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition-colors cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              <span>Lock & Finalize Month</span>
            </button>
          )}
        </div>
      </div>

      {/* Lock State Status Card */}
      <div
        className={`p-5 rounded-2xl border flex items-center justify-between gap-4 ${
          isMonthFullyLocked
            ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
            : 'bg-amber-50/70 border-amber-200 text-amber-950'
        }`}
      >
        <div className="flex items-center gap-3">
          {isMonthFullyLocked ? (
            <CheckCircle2 className="w-8 h-8 text-emerald-600 shrink-0" />
          ) : (
            <Clock className="w-8 h-8 text-amber-600 shrink-0" />
          )}
          <div>
            <h4 className="font-bold text-sm">
              {isMonthFullyLocked
                ? `Attendance for ${selectedMonth} is 100% Locked & Finalized`
                : `Attendance for ${selectedMonth} is in Open / Review Stage`}
            </h4>
            <p className="text-xs opacity-80 mt-0.5">
              {isMonthFullyLocked
                ? 'All shifts, grace periods, OT, and leaves are certified. Records are immutable and ready for Payroll Calculation.'
                : 'HR review in progress. Verify missing punches, apply pending regularizations before locking.'}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('payroll')}
          className="shrink-0 flex items-center gap-1.5 px-4 py-2 bg-white text-slate-900 border border-slate-200 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors cursor-pointer"
        >
          <span>Go to Payroll Engine</span>
          <ArrowRight className="w-4 h-4 text-sky-600" />
        </button>
      </div>

      {/* Audit Checklist Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700">Missing Punches</span>
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                missingPunchesCount === 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}
            >
              {missingPunchesCount} issues
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">
            All records currently have valid First IN / Last OUT biometric pairings.
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700">Overtime Claims</span>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800">
              {overtimeCount} verified
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">
            Approved plant shift overtime will automatically integrate into gross salary additions.
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700">Audit Compliance</span>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
              Verified
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">
            Meets ISO 9001 and Factories Act statutory cut-off records documentation standards.
          </p>
        </div>
      </div>

      {/* Modal: Reopen Confirmation with Mandatory Reason */}
      {showReopenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center gap-2 text-amber-600 mb-2">
              <AlertCircle className="w-5 h-5" />
              <h3 className="text-base font-bold text-slate-900">Authorize Attendance Reopen</h3>
            </div>
            <p className="text-xs text-slate-600 mb-3">
              Reopening finalized records requires authorization and will log a critical event in the audit trail.
            </p>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Mandatory Reopening Reason:
              </label>
              <textarea
                rows={3}
                value={reopenReason}
                onChange={e => setReopenReason(e.target.value)}
                placeholder="e.g. Audit correction for late machine punch sync on Plant Line 2..."
                className="w-full text-xs p-3 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-amber-500/20"
              />
            </div>

            <div className="mt-5 flex items-center justify-end gap-2.5">
              <button
                onClick={() => setShowReopenModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                disabled={!reopenReason.trim()}
                onClick={handleReopenRecords}
                className="px-4 py-2 text-xs font-bold text-white bg-amber-500 hover:bg-amber-600 rounded-xl shadow-xs cursor-pointer disabled:opacity-50"
              >
                Confirm & Reopen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

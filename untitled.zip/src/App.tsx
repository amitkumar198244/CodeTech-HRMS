// RSTPL HRMS - Enterprise SaaS Application Controller
// RS Technovisions XpertSkillCop
// Tagline: Smart HR Solutions for a Smarter Tomorrow

import React, { useState, useEffect } from 'react';
import {
  loadStoredData,
  saveStoredData,
  HRMSStoreData
} from './services/hrmsStorage';
import { UserRole, Organization, Employee, Unit, Branch, Shift, BiometricDevice, RawPunch, AttendanceRecord, LeaveRequest, ODRequest, GatePassRequest, PayrollRun, Payslip, JobOpening, Candidate, AuditLogItem, AppNotification, GeoTrackingPunch } from './types/hrms';
import { GeofenceService, formatDistance } from './services/geofenceService';
import { Navbar } from './components/common/Navbar';
import { Sidebar } from './components/common/Sidebar';
import { LoginPage } from './features/auth/LoginPage';
import { DashboardView } from './features/dashboard/DashboardView';
import { OrgStructureView } from './features/organization/OrgStructureView';
import { EmployeeMasterView } from './features/employees/EmployeeMasterView';
import { DocumentsMasterView } from './features/documents/DocumentsMasterView';
import { SalaryMasterView } from './features/payroll/SalaryMasterView';
import { DailyAttendanceView } from './features/attendance/DailyAttendanceView';
import { AIGeofencingMonitor } from './features/attendance/AIGeofencingMonitor';
import { BiometricStudioView } from './features/biometric/BiometricStudioView';
import { ShiftsAndRostersView } from './features/shifts/ShiftsAndRostersView';
import { AttendanceFinalizationView } from './features/attendance/AttendanceFinalizationView';
import { LeaveManagementView } from './features/leave/LeaveManagementView';
import { ODGatePassView } from './features/odGatePass/ODGatePassView';
import { ESSView } from './features/ess/ESSView';
import { MSSView } from './features/mss/MSSView';
import { PayrollEngineView } from './features/payroll/PayrollEngineView';
import { RecruitmentATSView } from './features/recruitment/RecruitmentATSView';
import { PerformanceView } from './features/performance/PerformanceView';
import { TrainingView } from './features/training/TrainingView';
import { ExpenseView } from './features/expenses/ExpenseView';
import { HRLetterGeneratorView } from './features/documents/HRLetterGeneratorView';
import { AssetManagementView } from './features/assets/AssetManagementView';
import { ExitManagementView } from './features/exit/ExitManagementView';
import { ReportsView } from './features/reports/ReportsView';
import { SaaSSuperAdminView } from './features/superAdmin/SaaSSuperAdminView';
import { AuditTrailView } from './features/audit/AuditTrailView';
import { AIAssistantDrawer } from './features/aiAssistant/AIAssistantDrawer';
import { PowerByBadge, BrandShowcaseModal } from './components/branding/BrandLogos';

export default function App() {
  const [storeData, setStoreData] = useState<HRMSStoreData>(() => loadStoredData());
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true);
  const [currentRole, setCurrentRole] = useState<UserRole>('hr_head');
  const [activeModule, setActiveModule] = useState<string>('dashboard');
  const [isAIOpen, setIsAIOpen] = useState<boolean>(false);
  const [showBrandModal, setShowBrandModal] = useState<boolean>(false);

  // Centralized Geo Tracking Punches (synced across Daily Attendance and AI Geofencing Monitor)
  const [geoTrackingPunches, setGeoTrackingPunches] = useState<GeoTrackingPunch[]>([
    {
      id: 'geo-001',
      employeeId: 'emp-u05',
      employeeCode: 'EMP005',
      employeeName: 'Neha Verma',
      departmentName: 'IT & Infrastructure',
      designation: 'Officer',
      date: '2026-10-08',
      time: '08:55',
      type: 'IN',
      latitude: 28.4595,
      longitude: 77.0266,
      locationAddress: 'Cyber City DLF Phase 2, Gurugram, Haryana',
      clientOrSiteName: 'Client Data Center Hub',
      purpose: 'Official Work: Server Rack Audit & Network Switch Inspection',
      distanceFromBaseKm: 4.2,
      accuracyMeters: 6,
      isWithinGeofence: true,
      batteryPercent: 92,
      deviceInfo: 'Samsung Galaxy S24 (Android 15)',
      selfieVerified: true,
      notes: 'GPS locked with 6m high accuracy. Client representative signed pass.',
      status: 'Approved',
    },
    {
      id: 'geo-002',
      employeeId: 'emp-004',
      employeeCode: 'RST-1004',
      employeeName: 'Sneha Deshmukh',
      departmentName: 'Quality Assurance & Audit',
      designation: 'QA Lead',
      date: '2026-10-08',
      time: '09:40',
      type: 'FIELD_VISIT',
      latitude: 18.7512,
      longitude: 73.8499,
      locationAddress: 'Chakan MIDC Phase 2, Pune',
      clientOrSiteName: 'Tier 1 Supplier Foundry Unit',
      purpose: 'PPAP Quality Sample Batch Validation',
      distanceFromBaseKm: 8.5,
      accuracyMeters: 10,
      isWithinGeofence: false,
      batteryPercent: 84,
      deviceInfo: 'Apple iPhone 15 Pro (iOS 18.1)',
      selfieVerified: true,
      notes: 'Authorized Remote Visit. Photo verified at supplier gate.',
      status: 'Approved',
    },
    {
      id: 'geo-003',
      employeeId: 'emp-u02',
      employeeCode: 'EMP002',
      employeeName: 'Amit Singh',
      departmentName: 'Admin & Facilities',
      designation: 'Officer',
      date: '2026-10-08',
      time: '09:25',
      type: 'IN',
      latitude: 28.4982,
      longitude: 77.0891,
      locationAddress: 'Sohna Road Logistics Park, Gurugram',
      clientOrSiteName: 'Transit Logistics Hub',
      purpose: 'Transport & Fleet Coordination',
      distanceFromBaseKm: 12.0,
      accuracyMeters: 8,
      isWithinGeofence: false,
      batteryPercent: 78,
      deviceInfo: 'OnePlus 12 (Android 14)',
      selfieVerified: true,
      notes: 'Traffic delay recorded on route to base unit.',
      status: 'Approved',
    },
  ]);

  // Sync to local storage whenever storeData changes
  useEffect(() => {
    saveStoredData(storeData);
  }, [storeData]);

  // Enterprise audit logger helper
  const logAudit = (action: AuditLogItem['action'], module: string, details: string) => {
    const newLog: AuditLogItem = {
      id: `log-${Date.now()}`,
      orgId: storeData.currentOrg.id,
      userId: 'usr-active-session',
      userName: currentRole === 'hr_head' ? 'Amit Sharma (VP HR)' : currentRole === 'super_admin' ? 'Super Admin' : 'Active User',
      userRole: currentRole,
      action,
      module,
      details,
      ipAddress: '192.168.1.100',
      timestamp: new Date().toISOString(),
    };
    setStoreData(prev => ({
      ...prev,
      auditLogs: [newLog, ...prev.auditLogs],
    }));
  };

  // Login handler
  const handleLoginSuccess = (role: UserRole) => {
    setIsAuthenticated(true);
    setCurrentRole(role);
    if (role === 'employee') {
      setActiveModule('ess');
    } else if (role === 'super_admin') {
      setActiveModule('super_admin');
    } else {
      setActiveModule('dashboard');
    }
    logAudit('LOGIN', 'Authentication', `User authenticated as ${role}`);
  };

  // State update handlers
  const handleUpdateDevices = (devices: BiometricDevice[]) => {
    setStoreData(prev => ({ ...prev, biometricDevices: devices }));
  };

  const handleUpdateRawPunches = (punches: RawPunch[]) => {
    setStoreData(prev => ({ ...prev, rawPunches: punches }));
  };

  const handleUpdateAttendance = (attendance: AttendanceRecord[]) => {
    setStoreData(prev => ({ ...prev, attendance }));
  };

  const handleUpdateUnits = (units: Unit[]) => {
    setStoreData(prev => ({ ...prev, units }));
  };

  const handleUpdateShifts = (shifts: Shift[]) => {
    setStoreData(prev => ({ ...prev, shifts }));
  };

  const handleAddEmployee = (emp: Employee) => {
    setStoreData(prev => ({ ...prev, employees: [...prev.employees, emp] }));
  };

  const handleUpdateEmployee = (emp: Employee) => {
    setStoreData(prev => ({
      ...prev,
      employees: prev.employees.map(e => (e.id === emp.id ? emp : e)),
    }));
  };

  const handleUpdateLeaveRequests = (leaveRequests: LeaveRequest[]) => {
    setStoreData(prev => ({ ...prev, leaveRequests }));
  };

  const handleUpdateOD = (odRequests: ODRequest[]) => {
    setStoreData(prev => ({ ...prev, odRequests }));
  };

  const handleUpdateGatePass = (gatePassRequests: GatePassRequest[]) => {
    setStoreData(prev => ({ ...prev, gatePassRequests }));
  };

  const handleUpdatePayrollRuns = (payrollRuns: PayrollRun[]) => {
    setStoreData(prev => ({ ...prev, payrollRuns }));
  };

  const handleUpdatePayslips = (payslips: Payslip[]) => {
    setStoreData(prev => ({ ...prev, payslips }));
  };

  const handleUpdateCandidates = (candidates: Candidate[]) => {
    setStoreData(prev => ({ ...prev, candidates }));
  };

  const handleAddJob = (job: JobOpening) => {
    setStoreData(prev => ({ ...prev, jobOpenings: [job, ...prev.jobOpenings] }));
  };

  const handleAddUnit = (unit: Unit, branch?: Branch) => {
    setStoreData(prev => ({
      ...prev,
      units: [...prev.units, unit],
      branches: branch && !prev.branches.some(b => b.id === branch.id) ? [...prev.branches, branch] : prev.branches,
    }));
    logAudit('CREATE', 'Organization Master', `Added operating unit ${unit.name} (${unit.code}) at ${unit.branchId}`);
  };

  const handleSelectOrg = (org: Organization) => {
    setStoreData(prev => ({ ...prev, currentOrg: org }));
    logAudit('UPDATE', 'SaaS Multi-Tenant', `Switched active organization to ${org.name}`);
  };

  const handleAddOrg = (org: Organization) => {
    setStoreData(prev => ({
      ...prev,
      organizations: [...prev.organizations, org],
      currentOrg: org,
    }));
  };

  const handleMarkNotificationRead = (id: string) => {
    setStoreData(prev => ({
      ...prev,
      notifications: prev.notifications.map(n => (n.id === id ? { ...n, read: true } : n)),
    }));
  };

  const handleAddNotification = (notif: AppNotification) => {
    setStoreData(prev => ({
      ...prev,
      notifications: [notif, ...prev.notifications.filter(n => n.id !== notif.id)],
    }));
  };

  // Mobile/Web geo punch in ESS with AI Geofencing Evaluation
  const handleWebGeoPunch = async (type: 'IN' | 'OUT', lat: number, lng: number) => {
    const todayStr = '2026-10-08';
    const nowTimeStr = new Date().toTimeString().slice(0, 5);

    const activeEmp = storeData.employees[0];
    const assignedUnit = storeData.units.find(u => u.id === activeEmp.unitId) || storeData.units[0];

    const evalResult = await GeofenceService.evaluatePunch(
      {
        latitude: lat,
        longitude: lng,
        accuracyMeters: 6,
        punchType: type,
        timestamp: new Date().toISOString(),
      },
      activeEmp,
      assignedUnit
    );

    const newPunch: RawPunch = {
      id: `geo-${Date.now()}`,
      orgId: storeData.currentOrg.id,
      deviceId: 'mobile-geo-app',
      deviceName: 'Mobile ESS Geo Attendance',
      employeeCode: activeEmp.employeeCode,
      punchTime: new Date().toISOString(),
      punchType: type,
      source: 'Mobile_Geo',
      status: evalResult.isWithinGeofence ? 'Processed' : 'Invalid',
      latitude: lat,
      longitude: lng,
    };

    const newGeoRecord: GeoTrackingPunch = {
      id: `geo-ess-${Date.now()}`,
      employeeId: activeEmp.id,
      employeeCode: activeEmp.employeeCode,
      employeeName: `${activeEmp.firstName} ${activeEmp.lastName}`,
      departmentName: activeEmp.departmentId || 'Operations',
      designation: activeEmp.designationId || 'Specialist',
      date: todayStr,
      time: nowTimeStr,
      type,
      latitude: lat,
      longitude: lng,
      locationAddress: evalResult.isWithinGeofence
        ? `${assignedUnit.name} (Within designated perimeter)`
        : `Outside Radius Breach (+${formatDistance(evalResult.breachDistanceMeters)})`,
      clientOrSiteName: assignedUnit.name,
      purpose: 'Mobile ESS Self Check-in',
      distanceFromBaseKm: Number((evalResult.actualDistanceMeters / 1000).toFixed(2)),
      accuracyMeters: evalResult.accuracyMeters,
      isWithinGeofence: evalResult.isWithinGeofence,
      batteryPercent: 91,
      deviceInfo: 'Mobile ESS Web Terminal (HTML5)',
      selfieVerified: true,
      notes: evalResult.aiAnalysisText,
      status: evalResult.isWithinGeofence ? 'Approved' : 'Flagged',
      unitId: assignedUnit.id,
      unitName: assignedUnit.name,
      unitRadiusMeters: evalResult.designatedRadiusMeters,
      actualDistanceMeters: evalResult.actualDistanceMeters,
      breachDistanceMeters: evalResult.breachDistanceMeters,
      aiRiskLevel: evalResult.aiRiskLevel,
      aiRiskScore: evalResult.aiRiskScore,
      aiAnalysisText: evalResult.aiAnalysisText,
      alertDispatched: !evalResult.isWithinGeofence,
      managerNotified: !evalResult.isWithinGeofence,
      employeeNotified: !evalResult.isWithinGeofence,
    };

    setGeoTrackingPunches(prev => [newGeoRecord, ...prev]);

    if (!evalResult.isWithinGeofence) {
      handleAddNotification({
        id: `notif-geo-${Date.now()}`,
        orgId: activeEmp.orgId,
        title: `Geofence Breach: ${activeEmp.firstName} ${activeEmp.lastName}`,
        message: `${activeEmp.employeeCode} punched ${type} ${formatDistance(evalResult.actualDistanceMeters)} outside ${assignedUnit.name} (+${formatDistance(evalResult.breachDistanceMeters)} perimeter breach). Risk: ${evalResult.aiRiskLevel}.`,
        type: 'geofence',
        read: false,
        timestamp: 'Just now',
      });
    }

    const nextAttendance = storeData.attendance.map(a => {
      if (a.employeeId === activeEmp.id && a.date === todayStr) {
        return {
          ...a,
          firstIn: type === 'IN' ? nowTimeStr : a.firstIn,
          lastOut: type === 'OUT' ? nowTimeStr : a.lastOut,
          status: 'Present' as const,
        };
      }
      return a;
    });

    setStoreData(prev => ({
      ...prev,
      rawPunches: [newPunch, ...prev.rawPunches],
      attendance: nextAttendance,
    }));

    logAudit(
      evalResult.isWithinGeofence ? 'PUNCH' : 'ALERT',
      'ESS Geo Attendance',
      evalResult.isWithinGeofence
        ? `${activeEmp.employeeCode} performed Mobile Geo Punch ${type} at (${lat}, ${lng}) - Geofence Verified`
        : `GEOFENCE BREACH: ${activeEmp.employeeCode} performed Mobile Geo Punch ${type} outside ${assignedUnit.name} radius (+${formatDistance(evalResult.breachDistanceMeters)})`
    );
  };

  if (!isAuthenticated) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  const activeEmployee = storeData.employees[0];

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-900 font-sans antialiased">
      {/* Top Navbar */}
      <Navbar
        currentOrg={storeData.currentOrg}
        currentRole={currentRole}
        onRoleChange={role => {
          setCurrentRole(role);
          if (role === 'employee') setActiveModule('ess');
        }}
        onOpenAIAssistant={() => setIsAIOpen(true)}
        notifications={storeData.notifications}
        onMarkNotificationRead={handleMarkNotificationRead}
        onNavigate={setActiveModule}
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          activeModule={activeModule}
          onSelectModule={setActiveModule}
          currentRole={currentRole}
        />

        {/* Main Content View Container */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {activeModule === 'dashboard' && (
              <DashboardView
                storeData={storeData}
                currentRole={currentRole}
                geoPunches={geoTrackingPunches}
                onNavigate={setActiveModule}
                onOpenAI={() => setIsAIOpen(true)}
                onUpdateDevices={handleUpdateDevices}
                onLogAudit={logAudit}
                onAddNotification={handleAddNotification}
                onAddUnit={handleAddUnit}
                onAddEmployee={handleAddEmployee}
                onRoleChange={role => {
                  setCurrentRole(role);
                  if (role === 'employee') setActiveModule('ess');
                }}
              />
            )}

            {activeModule === 'organization' && (
              <OrgStructureView
                currentOrg={storeData.currentOrg}
                branches={storeData.branches}
                units={storeData.units}
                departments={storeData.departments}
                designations={storeData.designations}
                shifts={storeData.shifts}
                employees={storeData.employees}
                onNavigate={setActiveModule}
              />
            )}

            {activeModule === 'employees' && (
              <EmployeeMasterView
                employees={storeData.employees}
                departments={storeData.departments}
                designations={storeData.designations}
                branches={storeData.branches}
                units={storeData.units}
                shifts={storeData.shifts}
                onAddEmployee={handleAddEmployee}
                onUpdateEmployee={handleUpdateEmployee}
                onLogAudit={logAudit}
                onNavigateToSalary={() => setActiveModule('salary_master')}
                onNavigateToDocuments={() => setActiveModule('documents_master')}
                onNavigateToOrgHierarchy={() => setActiveModule('organization')}
              />
            )}

            {activeModule === 'documents_master' && (
              <DocumentsMasterView
                employees={storeData.employees}
                departments={storeData.departments}
                units={storeData.units}
                onUpdateEmployee={handleUpdateEmployee}
                onLogAudit={logAudit}
                onNavigateToSalary={() => setActiveModule('salary_master')}
                onNavigateToEmployeeMaster={() => setActiveModule('employees')}
              />
            )}

            {activeModule === 'salary_master' && (
              <SalaryMasterView
                employees={storeData.employees}
                departments={storeData.departments}
                units={storeData.units}
                designations={storeData.designations}
                onUpdateEmployee={handleUpdateEmployee}
                onLogAudit={logAudit}
                onNavigateToDocuments={() => setActiveModule('documents_master')}
                onNavigateToEmployeeMaster={() => setActiveModule('employees')}
              />
            )}

            {activeModule === 'attendance' && (
              <DailyAttendanceView
                attendance={storeData.attendance}
                employees={storeData.employees}
                departments={storeData.departments}
                shifts={storeData.shifts}
                units={storeData.units}
                biometricDevices={storeData.biometricDevices}
                rawPunches={storeData.rawPunches}
                geoPunches={geoTrackingPunches}
                onUpdateGeoPunches={setGeoTrackingPunches}
                onUpdateAttendance={handleUpdateAttendance}
                onUpdateDevices={handleUpdateDevices}
                onUpdateRawPunches={handleUpdateRawPunches}
                onUpdateUnits={handleUpdateUnits}
                onAddNotification={handleAddNotification}
                onLogAudit={logAudit}
                onNavigate={setActiveModule}
              />
            )}

            {activeModule === 'geofence' && (
              <AIGeofencingMonitor
                units={storeData.units}
                employees={storeData.employees}
                attendance={storeData.attendance}
                geoPunches={geoTrackingPunches}
                onUpdateGeoPunches={setGeoTrackingPunches}
                onUpdateAttendance={handleUpdateAttendance}
                onUpdateUnits={handleUpdateUnits}
                onAddNotification={handleAddNotification}
                onLogAudit={logAudit}
                onNavigate={setActiveModule}
              />
            )}

            {activeModule === 'biometric' && (
              <BiometricStudioView
                devices={storeData.biometricDevices}
                rawPunches={storeData.rawPunches}
                employees={storeData.employees}
                shifts={storeData.shifts}
                attendance={storeData.attendance}
                onUpdateDevices={handleUpdateDevices}
                onUpdateRawPunches={handleUpdateRawPunches}
                onUpdateAttendance={handleUpdateAttendance}
                onLogAudit={logAudit}
                onNavigate={setActiveModule}
              />
            )}

            {activeModule === 'finalization' && (
              <AttendanceFinalizationView
                attendance={storeData.attendance}
                employees={storeData.employees}
                onUpdateAttendance={handleUpdateAttendance}
                onLogAudit={logAudit}
                onNavigate={setActiveModule}
              />
            )}

            {activeModule === 'leave' && (
              <LeaveManagementView
                leaveRequests={storeData.leaveRequests}
                leaveTypes={storeData.leaveTypes}
                employees={storeData.employees}
                onUpdateRequests={handleUpdateLeaveRequests}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'od_gatepass' && (
              <ODGatePassView
                odRequests={storeData.odRequests}
                gatePassRequests={storeData.gatePassRequests}
                employees={storeData.employees}
                onUpdateOD={handleUpdateOD}
                onUpdateGatePass={handleUpdateGatePass}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'ess' && (
              <ESSView
                currentEmployee={activeEmployee}
                attendance={storeData.attendance}
                leaveRequests={storeData.leaveRequests}
                payslips={storeData.payslips}
                onWebGeoPunch={handleWebGeoPunch}
                onNavigate={setActiveModule}
              />
            )}

            {activeModule === 'mss' && (
              <MSSView
                currentManager={activeEmployee}
                employees={storeData.employees}
                attendance={storeData.attendance}
                leaveRequests={storeData.leaveRequests}
                odRequests={storeData.odRequests}
                onReviewLeave={(id, status) => {
                  setStoreData(prev => ({
                    ...prev,
                    leaveRequests: prev.leaveRequests.map(l => (l.id === id ? { ...l, status } : l)),
                  }));
                  logAudit('APPROVE', 'MSS Approvals', `Manager reviewed leave ${id} as ${status}`);
                }}
                onReviewOD={(id, status) => {
                  setStoreData(prev => ({
                    ...prev,
                    odRequests: prev.odRequests.map(o => (o.id === id ? { ...o, status } : o)),
                  }));
                  logAudit('APPROVE', 'MSS Approvals', `Manager reviewed OD ${id} as ${status}`);
                }}
                onNavigate={setActiveModule}
              />
            )}

            {(activeModule === 'payroll' || activeModule === 'payslips') && (
              <PayrollEngineView
                payrollRuns={storeData.payrollRuns}
                payslips={storeData.payslips}
                employees={storeData.employees}
                attendance={storeData.attendance}
                onUpdatePayrollRuns={handleUpdatePayrollRuns}
                onUpdatePayslips={handleUpdatePayslips}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'recruitment' && (
              <RecruitmentATSView
                jobOpenings={storeData.jobOpenings}
                candidates={storeData.candidates}
                departments={storeData.departments}
                onUpdateCandidates={handleUpdateCandidates}
                onAddJob={handleAddJob}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'performance' && (
              <PerformanceView
                employees={storeData.employees}
                departments={storeData.departments}
                branches={storeData.branches}
                currentRole={currentRole}
                kraMasterList={storeData.kraMasterList}
                monthlyKraEvaluations={storeData.monthlyKraEvaluations}
                onUpdateKraMaster={(kras) => setStoreData(prev => ({ ...prev, kraMasterList: kras }))}
                onUpdateMonthlyEvaluations={(evals) => setStoreData(prev => ({ ...prev, monthlyKraEvaluations: evals }))}
                onLogAudit={logAudit}
                currentEmployee={activeEmployee}
              />
            )}

            {activeModule === 'training' && (
              <TrainingView onLogAudit={logAudit} />
            )}

            {activeModule === 'expenses' && (
              <ExpenseView
                employees={storeData.employees}
                departments={storeData.departments}
                branches={storeData.branches}
                currentRole={currentRole}
                currentEmployee={activeEmployee}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'letters' && (
              <HRLetterGeneratorView
                currentOrg={storeData.currentOrg}
                employees={storeData.employees}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'assets' && (
              <AssetManagementView
                employees={storeData.employees}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'exit' && (
              <ExitManagementView
                employees={storeData.employees}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'reports' && (
              <ReportsView
                storeData={storeData}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'super_admin' && (
              <SaaSSuperAdminView
                organizations={storeData.organizations}
                currentOrg={storeData.currentOrg}
                onSelectOrg={handleSelectOrg}
                onAddOrg={handleAddOrg}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'audit' && (
              <AuditTrailView
                logs={storeData.auditLogs}
                onLogAudit={logAudit}
              />
            )}

            {activeModule === 'shifts' && (
              <ShiftsAndRostersView
                shifts={storeData.shifts}
                employees={storeData.employees}
                departments={storeData.departments}
                units={storeData.units}
                designations={storeData.designations}
                onUpdateShifts={handleUpdateShifts}
                onLogAudit={logAudit}
                onNavigateToEmployeeMaster={() => setActiveModule('employees')}
              />
            )}

            {/* Global Enterprise Brand Footer (RSTPL & RS Technovisions) */}
            <footer className="mt-12 pt-6 border-t border-slate-200">
              <PowerByBadge variant="footer" onOpenHub={() => setShowBrandModal(true)} />
            </footer>
          </div>
        </main>
      </div>

      {/* Brand & Advisory Solutions Showcase Modal */}
      <BrandShowcaseModal
        isOpen={showBrandModal}
        onClose={() => setShowBrandModal(false)}
        onNavigateToModule={mod => {
          setActiveModule(mod);
          setShowBrandModal(false);
        }}
      />

      {/* Google Gemini AI HR Assistant Drawer */}
      <AIAssistantDrawer
        isOpen={isAIOpen}
        onClose={() => setIsAIOpen(false)}
        storeData={storeData}
        currentRole={currentRole}
        onNavigate={mod => {
          setActiveModule(mod);
          setIsAIOpen(false);
        }}
      />
    </div>
  );
}

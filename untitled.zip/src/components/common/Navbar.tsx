// RSTPL HRMS - Top Navigation Bar
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  Bell,
  Sparkles,
  Shield,
  Building2,
  UserCheck,
  Search,
  CheckCircle2,
  Clock,
  LogOut,
  ChevronDown
} from 'lucide-react';
import { UserRole, Organization } from '../../types/hrms';
import { AppNotification } from '../../types/hrms';
import { RstplLogo, PowerByBadge, BrandShowcaseModal } from '../branding/RstplLogo';

interface NavbarProps {
  currentOrg: Organization;
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onOpenAIAssistant: () => void;
  notifications: AppNotification[];
  onMarkNotificationRead: (id: string) => void;
  onNavigate: (module: string) => void;
}

const ROLES: { id: UserRole; label: string; badge: string }[] = [
  { id: 'hr_head', label: 'Amit Sharma (HR Head / VP)', badge: 'Executive HR' },
  { id: 'super_admin', label: 'Super Admin (SaaS Console)', badge: 'Platform Owner' },
  { id: 'manager', label: 'Rajesh Patil (Plant Manager)', badge: 'Line Manager' },
  { id: 'payroll_admin', label: 'Payroll Administrator', badge: 'Finance / Payroll' },
  { id: 'employee', label: 'Vikram Singhania (Employee)', badge: 'ESS Portal' },
];

export const Navbar: React.FC<NavbarProps> = ({
  currentOrg,
  currentRole,
  onRoleChange,
  onOpenAIAssistant,
  notifications,
  onMarkNotificationRead,
  onNavigate,
}) => {
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);
  const [showBrandHub, setShowBrandHub] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;
  const currentRoleObj = ROLES.find(r => r.id === currentRole) || ROLES[0];

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white px-4 md:px-6 shadow-xs">
      {/* Brand & Organization Title */}
      <div className="flex items-center gap-4 lg:gap-6">
        <RstplLogo
          size="md"
          showTagline={true}
          onClick={() => setShowBrandHub(true)}
        />

        <div className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-sky-50 border border-sky-100 text-xs text-sky-900 font-medium">
          <Building2 className="w-4 h-4 text-sky-600" />
          <span className="font-semibold">{currentOrg.name}</span>
          <span className="text-slate-400">|</span>
          <span className="text-slate-500 font-mono text-[11px]">{currentOrg.code}</span>
        </div>
      </div>

      {/* Global Action Bar */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Power By RS TechnoVisions XpertSkillCop Badge */}
        <PowerByBadge onOpenHub={() => setShowBrandHub(true)} variant="navbar" />

        {/* Quick Search */}
        <div className="hidden lg:flex relative items-center">
          <Search className="absolute left-3 w-4 h-4 text-slate-400 pointer-events-none" />
          <input
            type="text"
            placeholder="Search employee code, ID, branch..."
            className="w-48 xl:w-64 pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-slate-50/50 text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
          />
        </div>

        {/* AI HR Assistant Trigger Button */}
        <button
          onClick={onOpenAIAssistant}
          className="relative flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 shadow-sm shadow-sky-600/20 transition-all cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
          <span className="hidden sm:inline">AI HR Assistant</span>
          <span className="text-[10px] px-1 py-0.2 rounded bg-white/20 text-white font-mono">Gemini</span>
        </button>

        {/* Notifications Popover */}
        <div className="relative">
          <button
            onClick={() => setShowNotifMenu(!showNotifMenu)}
            className="relative p-2 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
              </span>
            )}
          </button>

          {showNotifMenu && (
            <div className="absolute right-0 mt-2 w-80 rounded-xl bg-white p-3 shadow-xl ring-1 ring-slate-900/10 z-50">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <h4 className="text-xs font-bold uppercase text-slate-600 tracking-wider">System Alerts</h4>
                <span className="text-[11px] font-semibold text-sky-600">{unreadCount} new</span>
              </div>
              <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                {notifications.map(n => (
                  <div
                    key={n.id}
                    onClick={() => {
                      onMarkNotificationRead(n.id);
                      setShowNotifMenu(false);
                    }}
                    className={`py-2.5 px-2 rounded-lg cursor-pointer transition-colors ${
                      n.read ? 'opacity-70 hover:bg-slate-50' : 'bg-sky-50/50 hover:bg-sky-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold text-slate-900">{n.title}</p>
                      <span className="text-[10px] text-slate-400">{n.timestamp}</span>
                    </div>
                    <p className="text-[11px] text-slate-600 mt-1 leading-snug">{n.message}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Role Impersonation Switcher (Key for demo & testing enterprise RBAC) */}
        <div className="relative">
          <button
            onClick={() => setShowRoleMenu(!showRoleMenu)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-colors cursor-pointer text-left"
          >
            <div className="w-6 h-6 rounded-full bg-sky-700 text-white flex items-center justify-center text-[10px] font-black">
              {currentRoleObj.label[0]}
            </div>
            <div className="hidden sm:flex flex-col text-left">
              <span className="text-xs font-bold text-slate-800 leading-tight truncate max-w-[130px]">
                {currentRoleObj.label.split('(')[0]}
              </span>
              <span className="text-[10px] text-slate-500 font-medium">
                {currentRoleObj.badge}
              </span>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {showRoleMenu && (
            <div className="absolute right-0 mt-2 w-72 rounded-xl bg-white p-2 shadow-2xl ring-1 ring-slate-900/10 z-50">
              <div className="px-3 py-2 border-b border-slate-100 mb-1">
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Enterprise Role Switcher</p>
                <p className="text-xs text-slate-600">Simulate system permissions & UI views</p>
              </div>
              <div className="space-y-1">
                {ROLES.map(r => (
                  <button
                    key={r.id}
                    onClick={() => {
                      onRoleChange(r.id);
                      setShowRoleMenu(false);
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left text-xs transition-colors cursor-pointer ${
                      currentRole === r.id
                        ? 'bg-sky-50 text-sky-900 font-semibold border border-sky-200'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <p className="font-medium text-slate-900">{r.label}</p>
                      <p className="text-[10px] text-slate-500">{r.badge}</p>
                    </div>
                    {currentRole === r.id && <CheckCircle2 className="w-4 h-4 text-sky-600" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* RSTPL & RS Technovisions Brand & Solutions Showcase Hub */}
      <BrandShowcaseModal
        isOpen={showBrandHub}
        onClose={() => setShowBrandHub(false)}
        onNavigateToModule={mod => {
          onNavigate(mod);
          setShowBrandHub(false);
        }}
      />
    </header>
  );
};

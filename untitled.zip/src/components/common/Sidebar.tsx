// RSTPL HRMS - Sidebar Navigation
// RS Technovisions XpertSkillCop

import React, { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  Fingerprint,
  CalendarCheck,
  Calendar,
  Briefcase,
  DollarSign,
  UserPlus,
  Target,
  GraduationCap,
  Receipt,
  FileText,
  Laptop,
  UserMinus,
  BarChart3,
  Sliders,
  ShieldCheck,
  Building,
  UserCircle,
  Clock,
  Send,
  HelpCircle,
  Key,
  Layers,
  Sparkles,
  Zap,
  BookOpen,
  FolderCheck,
  CreditCard,
  Network,
  Radio,
  Navigation
} from 'lucide-react';
import { UserRole } from '../../types/hrms';
import { PowerByBadge, BrandShowcaseModal } from '../branding/BrandLogos';

interface SidebarProps {
  activeModule: string;
  onSelectModule: (module: string) => void;
  currentRole: UserRole;
  collapsed?: boolean;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  roles?: UserRole[];
  badge?: string;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeModule,
  onSelectModule,
  currentRole,
}) => {
  const [showBrandModal, setShowBrandModal] = useState(false);

  const sections: NavSection[] = [
    {
      title: 'Core HR & Analytics',
      items: [
        { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard },
        { id: 'brand_hub', label: 'Platform & Advisory Hub', icon: Sparkles, badge: 'RSTPL' },
        { id: 'organization', label: 'Org & Hierarchy Chart', icon: Network, roles: ['super_admin', 'hr_head', 'org_admin'] },
        { id: 'employees', label: 'Employee Master', icon: Users, roles: ['super_admin', 'hr_head', 'hr_manager', 'unit_hr', 'manager'] },
        { id: 'documents_master', label: 'Documents Master (10 Slots)', icon: FolderCheck, roles: ['super_admin', 'hr_head', 'hr_manager', 'unit_hr'] },
      ],
    },
    {
      title: 'Time & Attendance',
      items: [
        { id: 'attendance', label: 'Daily Attendance', icon: CalendarCheck },
        { id: 'geofence', label: 'AI Geofencing Monitor', icon: Navigation, roles: ['super_admin', 'hr_head', 'hr_manager', 'manager'], badge: 'AI Radar' },
        { id: 'biometric', label: 'Biometric Devices', icon: Fingerprint, roles: ['super_admin', 'hr_head', 'hr_manager', 'it_admin'], badge: 'Live' },
        { id: 'shifts', label: 'Shifts & Rosters', icon: Clock, roles: ['super_admin', 'hr_head', 'hr_manager', 'manager'] },
        { id: 'finalization', label: 'Attendance Lock', icon: ShieldCheck, roles: ['super_admin', 'hr_head', 'payroll_admin'] },
      ],
    },
    {
      title: 'Leaves & Regularization',
      items: [
        { id: 'leave', label: 'Leave Management', icon: Calendar },
        { id: 'od_gatepass', label: 'OD & Gate Pass', icon: Send },
      ],
    },
    {
      title: 'Self-Service Portals',
      items: [
        { id: 'ess', label: 'Employee ESS', icon: UserCircle },
        { id: 'mss', label: 'Manager MSS', icon: Briefcase, roles: ['super_admin', 'hr_head', 'manager', 'dept_head'] },
      ],
    },
    {
      title: 'Compensation & Payroll',
      items: [
        { id: 'salary_master', label: 'Salary Master (New Wages Code)', icon: CreditCard, roles: ['super_admin', 'hr_head', 'payroll_admin', 'finance_user'] },
        { id: 'payroll', label: 'Payroll Engine', icon: DollarSign, roles: ['super_admin', 'hr_head', 'payroll_admin', 'finance_user'] },
        { id: 'payslips', label: 'Payslip Archive', icon: FileText },
      ],
    },
    {
      title: 'Talent & Development',
      items: [
        { id: 'recruitment', label: 'Recruitment & ATS', icon: UserPlus, roles: ['super_admin', 'hr_head', 'hr_manager', 'recruiter'] },
        { id: 'performance', label: 'Performance (PMS)', icon: Target },
        { id: 'training', label: 'Training & Skills', icon: GraduationCap },
      ],
    },
    {
      title: 'Operations & Assets',
      items: [
        { id: 'expenses', label: 'Expense Claims', icon: Receipt },
        { id: 'workflows', label: 'Approval Workflows', icon: Layers, roles: ['super_admin', 'org_admin', 'hr_head', 'manager', 'finance_user'] },
        { id: 'letters', label: 'HR Letter Generator', icon: FileText, roles: ['super_admin', 'hr_head', 'hr_manager'] },
        { id: 'assets', label: 'Company Assets', icon: Laptop },
        { id: 'exit', label: 'Exit & Clearances', icon: UserMinus, roles: ['super_admin', 'hr_head', 'manager'] },
      ],
    },
    {
      title: 'Intelligence & Administration',
      items: [
        { id: 'users_roles', label: 'Users & Rights (RBAC)', icon: Key, roles: ['super_admin', 'org_admin', 'hr_head'] },
        { id: 'reports', label: 'Reports & Export', icon: BarChart3 },
        { id: 'super_admin', label: 'SaaS Multi-Tenant', icon: Sliders, roles: ['super_admin'] },
        { id: 'audit', label: 'Audit Trail Logs', icon: ShieldCheck, roles: ['super_admin', 'hr_head', 'auditor'] },
      ],
    },
  ];

  return (
    <aside className="w-64 shrink-0 border-r border-slate-200 bg-slate-900 text-slate-300 flex flex-col h-[calc(100vh-4rem)] sticky top-16 select-none overflow-y-auto">
      {/* Sidebar Header Info */}
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black text-white tracking-tight">CodeTech HRMS</span>
              <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-sky-900 text-sky-300 border border-sky-700">
                RSTPL
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium mt-0.5">
              Innovate · Integrate · Transform
            </p>
          </div>
          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-800/80">
            SaaS v3.2
          </span>
        </div>
      </div>

      {/* Nav List */}
      <nav className="flex-1 p-3 space-y-5">
        {sections.map(section => {
          // Filter items based on current role permissions
          const visibleItems = section.items.filter(
            item => !item.roles || item.roles.includes(currentRole)
          );

          if (visibleItems.length === 0) return null;

          return (
            <div key={section.title} className="space-y-1">
              <h3 className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {section.title}
              </h3>
              {visibleItems.map(item => {
                const Icon = item.icon;
                const isActive = activeModule === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      if (item.id === 'brand_hub') {
                        setShowBrandModal(true);
                      } else {
                        onSelectModule(item.id);
                      }
                    }}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-sky-600 text-white font-semibold shadow-xs'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          );
        })}
      </nav>

      {/* Power By RS Technovisions XpertSkillCop Footer */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/60">
        <PowerByBadge variant="sidebar" onOpenHub={() => setShowBrandModal(true)} />
      </div>

      {/* Brand & Advisory Solutions Modal */}
      <BrandShowcaseModal
        isOpen={showBrandModal}
        onClose={() => setShowBrandModal(false)}
        onNavigateToModule={mod => {
          onSelectModule(mod);
          setShowBrandModal(false);
        }}
      />
    </aside>
  );
};

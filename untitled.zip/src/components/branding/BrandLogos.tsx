// CodeTech HRMS Branding System
// Company: RSTPL (Innovate | Integrate | Transform)
// Powered by: RS TechnoVisions XpertSkillCop (HR Management & Audit Consultants)

import React, { useState } from 'react';
import {
  Sparkles,
  Shield,
  CheckCircle2,
  ExternalLink,
  Phone,
  Mail,
  Globe,
  Award,
  Layers,
  ArrowRight,
  X,
  FileCheck2,
  Users,
  DollarSign,
  CalendarCheck,
  Calendar,
  UserPlus,
  Target,
  BarChart3,
  Cloud,
  Lock,
  Zap,
  TrendingUp,
  Headphones,
  BookOpen,
  Briefcase
} from 'lucide-react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  light?: boolean;
  showTagline?: boolean;
  showCompany?: boolean;
  className?: string;
  onClick?: () => void;
}

/**
 * RSTPL Company & CodeTech HRMS Logo Component
 * Incorporates the branding from Image 1:
 * Bold geometric Navy typography with cyan dynamic slash and "Innovate | Integrate | Transform"
 */
export const RstplLogo: React.FC<LogoProps> = ({
  size = 'md',
  light = false,
  showTagline = true,
  showCompany = true,
  className = '',
  onClick,
}) => {
  const isSm = size === 'sm';
  const isLg = size === 'lg';
  const isXl = size === 'xl';

  return (
    <div
      onClick={onClick}
      className={`flex items-center gap-3 select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      {/* RSTPL Stylized Brand Mark Emblem */}
      <div
        className={`relative flex items-center justify-center rounded-2xl shadow-md transition-transform hover:scale-105 shrink-0 ${
          isSm ? 'w-8 h-8' : isLg ? 'w-12 h-12' : isXl ? 'w-14 h-14' : 'w-10 h-10'
        } ${
          light
            ? 'bg-white text-slate-900 shadow-slate-950/20'
            : 'bg-gradient-to-br from-slate-950 via-sky-950 to-blue-900 text-white shadow-sky-900/40 ring-1 ring-sky-400/40'
        }`}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full p-1.5"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* RSTPL Monogram with Cyan Energy Swoosh */}
          <rect width="100" height="100" rx="20" fill="url(#rstpl-grad)" />
          {/* Bold geometric 'R' and 'S' */}
          <path
            d="M22 28 H46 C56 28 62 34 62 42 C62 50 56 55 47 56 L64 76 H50 L36 57 H33 V76 H22 V28 Z M33 38 V48 H44 C49 48 52 46 52 43 C52 40 49 38 44 38 H33 Z"
            fill="#FFFFFF"
          />
          {/* Cyan Forward-Dynamic Wave Accent */}
          <path
            d="M48 64 L78 28 H66 L40 60 Z"
            fill="url(#cyan-glow)"
          />
          <path
            d="M58 76 L86 42 H74 L48 76 Z"
            fill="#0ea5e9"
            opacity="0.9"
          />
          {/* Solar Warm Dot from Image 1 'Smart HR Solutions for a Brighter Tomorrow' */}
          <circle cx="82" cy="24" r="6" fill="#f59e0b" />
          <defs>
            <linearGradient id="rstpl-grad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop stopColor="#0a192f" />
              <stop offset="0.6" stopColor="#0f2b5c" />
              <stop offset="1" stopColor="#0284c7" />
            </linearGradient>
            <linearGradient id="cyan-glow" x1="40" y1="28" x2="78" y2="64" gradientUnits="userSpaceOnUse">
              <stop stopColor="#38bdf8" />
              <stop offset="1" stopColor="#0284c7" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Brand Typography */}
      <div className="flex flex-col">
        <div className="flex items-center gap-2">
          <div className="flex items-baseline gap-1.5">
            <span
              className={`font-black tracking-tight ${
                isSm ? 'text-sm' : isLg ? 'text-2xl' : isXl ? 'text-3xl' : 'text-lg'
              } ${light ? 'text-white' : 'text-slate-950'}`}
            >
              CodeTech <span className="text-sky-600 font-black">HRMS</span>
            </span>
          </div>

          {showCompany && (
            <span className="px-1.5 py-0.5 text-[9px] uppercase font-black tracking-wider rounded-md bg-sky-100 text-sky-900 border border-sky-200">
              RSTPL
            </span>
          )}
        </div>

        {showTagline && (
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="text-[10px] font-bold text-slate-500 tracking-wide uppercase">
              RSTPL <span className="text-slate-400 font-normal">|</span> Innovate · Integrate · Transform
            </span>
            <span className="hidden xl:inline text-[9.5px] font-semibold text-amber-600">
              ☀️ Smart HR Solutions for a Brighter Tomorrow
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

/**
 * RS Technovisions (XpertSkillCop) Logo Component
 * Incorporates the branding from Image 2:
 * Dynamic blue/cyan winged 'RS' logo, "Technovisions", and orange "(XpertSkillCop)"
 * Tagline: "HR Management & Audit Consultants"
 */
export const RsTechnoVisionsLogo: React.FC<{
  size?: 'sm' | 'md' | 'lg';
  light?: boolean;
  showSubtitle?: boolean;
  className?: string;
  onClick?: () => void;
}> = ({
  size = 'md',
  light = false,
  showSubtitle = true,
  className = '',
  onClick,
}) => {
  const isSm = size === 'sm';
  const isLg = size === 'lg';

  return (
    <div
      onClick={onClick}
      className={`flex items-center gap-2.5 select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      {/* The Dynamic Aerodynamic 'RS' Wing Symbol from Image 2 */}
      <div
        className={`relative flex items-center justify-center shrink-0 rounded-xl transition-transform hover:scale-105 ${
          isSm ? 'w-7 h-7' : isLg ? 'w-11 h-11' : 'w-9 h-9'
        } ${
          light
            ? 'bg-white shadow-xs'
            : 'bg-slate-900 text-white shadow-md ring-1 ring-slate-700/60'
        }`}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full p-1"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Outer Rounded Crest */}
          <rect width="100" height="100" rx="18" fill="#0f172a" />
          {/* Bold 'R' in White/Slate */}
          <path
            d="M20 25 H45 C55 25 61 31 61 39 C61 47 55 52 46 53 L62 75 H48 L34 54 H31 V75 H20 V25 Z M31 35 V44 H43 C47 44 50 42 50 39.5 C50 37 47 35 43 35 H31 Z"
            fill="#FFFFFF"
          />
          {/* Stylized Cyan Swoosh Wing cutting through into 'S' */}
          <path
            d="M38 46 C52 40 76 34 88 42 C78 50 62 54 50 56 Z"
            fill="url(#rst-swoosh-cyan)"
          />
          <path
            d="M44 60 C58 54 80 50 88 64 C76 74 58 76 44 72 Z"
            fill="url(#rst-swoosh-blue)"
          />
          <defs>
            <linearGradient id="rst-swoosh-cyan" x1="38" y1="40" x2="88" y2="50" gradientUnits="userSpaceOnUse">
              <stop stopColor="#38bdf8" />
              <stop offset="1" stopColor="#0284c7" />
            </linearGradient>
            <linearGradient id="rst-swoosh-blue" x1="44" y1="54" x2="88" y2="70" gradientUnits="userSpaceOnUse">
              <stop stopColor="#0ea5e9" />
              <stop offset="1" stopColor="#2563eb" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="flex flex-col">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span
            className={`font-black tracking-tight ${
              isSm ? 'text-xs' : isLg ? 'text-lg' : 'text-sm'
            } ${light ? 'text-white' : 'text-slate-900'}`}
          >
            RS Technovisions
          </span>
          <span
            className={`font-extrabold ${
              isSm ? 'text-[11px]' : isLg ? 'text-base' : 'text-xs'
            } text-amber-500`}
          >
            (XpertSkillCop)
          </span>
        </div>

        {showSubtitle && (
          <span
            className={`text-[9px] font-bold tracking-wider uppercase ${
              light ? 'text-slate-300' : 'text-slate-500'
            }`}
          >
            HR Management & Audit Consultants
          </span>
        )}
      </div>
    </div>
  );
};

/**
 * Co-Branded Power By Badge
 * Displays "⚡ Power by RS TechnoVisions XpertSkillCop"
 * Clicking opens the complete Platform & Consulting Solutions Hub
 */
export const PowerByBadge: React.FC<{
  onOpenHub?: () => void;
  variant?: 'navbar' | 'footer' | 'sidebar' | 'pill';
}> = ({ onOpenHub, variant = 'navbar' }) => {
  if (variant === 'sidebar') {
    return (
      <div
        onClick={onOpenHub}
        className="rounded-xl p-3 bg-gradient-to-br from-slate-950 via-slate-900 to-sky-950 border border-slate-800 hover:border-sky-700/60 transition-all cursor-pointer group shadow-sm"
      >
        <div className="flex items-center justify-between mb-1.5">
          <span className="flex items-center gap-1 text-[10px] font-black uppercase tracking-wider text-amber-400">
            <Zap className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span>Power By</span>
          </span>
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-sky-900/60 text-sky-300 border border-sky-700/50 font-bold">
            Consultants
          </span>
        </div>

        <RsTechnoVisionsLogo size="sm" light={true} showSubtitle={false} />

        <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400 group-hover:text-sky-300 transition-colors">
          <span>Explore Advisory & Audit Hub</span>
          <ArrowRight className="w-3 h-3 transition-transform group-hover:translate-x-0.5" />
        </div>
      </div>
    );
  }

  if (variant === 'footer') {
    return (
      <div className="flex flex-wrap items-center justify-between gap-4 py-3 text-xs text-slate-500">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onOpenHub}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 transition shadow-xs cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span className="text-slate-300 text-xs">Power by</span>
            <strong className="text-white">RS Technovisions</strong>
            <span className="text-amber-400 font-bold">XpertSkillCop</span>
          </button>
          <span className="text-slate-400 hidden sm:inline">|</span>
          <span className="text-slate-500 hidden sm:inline">
            Company: <strong className="text-slate-700">RSTPL</strong> (Innovate · Integrate · Transform)
          </span>
        </div>

        <div className="flex items-center gap-4 text-xs font-medium">
          <a
            href="http://www.rstpl.com"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-sky-600 transition flex items-center gap-1"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>www.rstpl.com</span>
          </a>
          <a
            href="http://www.rstechnovisions.co.in"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-sky-600 transition flex items-center gap-1"
          >
            <Globe className="w-3.5 h-3.5 text-amber-500" />
            <span>www.rstechnovisions.co.in</span>
          </a>
          <button
            type="button"
            onClick={onOpenHub}
            className="text-sky-700 hover:text-sky-900 font-bold hover:underline cursor-pointer"
          >
            View Full Brand & Advisory Catalog ➔
          </button>
        </div>
      </div>
    );
  }

  // Default navbar pill
  return (
    <button
      type="button"
      onClick={onOpenHub}
      title="View RSTPL & RS Technovisions Platform and Audit Solutions"
      className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 text-white border border-slate-700 hover:border-amber-400/60 transition-all shadow-xs hover:shadow-md cursor-pointer group"
    >
      <div className="w-5 h-5 rounded-md bg-slate-900 border border-slate-700 flex items-center justify-center shrink-0">
        <svg viewBox="0 0 100 100" className="w-3.5 h-3.5" fill="none">
          <rect width="100" height="100" rx="18" fill="#0f172a" />
          <path d="M20 25 H45 C55 25 61 31 61 39 C61 47 55 52 46 53 L62 75 H48 L34 54 H31 V75 H20 V25 Z M31 35 V44 H43 C47 44 50 42 50 39.5 C50 37 47 35 43 35 H31 Z" fill="#FFFFFF" />
          <path d="M38 46 C52 40 76 34 88 42 C78 50 62 54 50 56 Z" fill="#38bdf8" />
          <path d="M44 60 C58 54 80 50 88 64 C76 74 58 76 44 72 Z" fill="#0284c7" />
        </svg>
      </div>
      <div className="flex items-center gap-1.5 text-xs font-semibold">
        <Zap className="w-3 h-3 text-amber-400 fill-amber-400 shrink-0" />
        <span className="text-slate-400 text-[10.5px]">Power by</span>
        <span className="font-bold text-white text-[11px] group-hover:text-sky-300 transition-colors">RS TechnoVisions</span>
        <span className="text-amber-400 font-black text-[11px]">(XpertSkillCop)</span>
      </div>
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
    </button>
  );
};

/**
 * BrandShowcaseModal: Interactive Comprehensive Brand & Solutions Hub
 * Fully embodies both attached posters:
 * - Image 1: RSTPL SaaS Platform (7 Modules + 5 Core Cloud Guarantees + Books: People, Process, Technology, Success)
 * - Image 2: RS Technovisions (XpertSkillCop) HR Management & Audit Consultants (6 Advisory pillars + 7 Services + Contacts)
 */
export const BrandShowcaseModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onNavigateToModule?: (moduleId: string) => void;
}> = ({ isOpen, onClose, onNavigateToModule }) => {
  const [activeTab, setActiveTab] = useState<'rstpl_saas' | 'consulting_audit'>('rstpl_saas');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-slate-200 text-slate-900 animate-in fade-in zoom-in-95">
        {/* Modal Top Header */}
        <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <RstplLogo size="md" showTagline={false} />
            <div className="hidden sm:block h-6 w-px bg-slate-200" />
            <div className="hidden sm:block">
              <RsTechnoVisionsLogo size="sm" showSubtitle={false} />
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Tab Switcher between Poster 1 & Poster 2 */}
            <div className="flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 text-xs font-bold">
              <button
                type="button"
                onClick={() => setActiveTab('rstpl_saas')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  activeTab === 'rstpl_saas'
                    ? 'bg-sky-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                RSTPL SaaS Platform
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('consulting_audit')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  activeTab === 'consulting_audit'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                RS Technovisions Advisory
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-8">
          {activeTab === 'rstpl_saas' ? (
            /* ==============================================================
               TAB 1: RSTPL POWERFUL SAAS PLATFORM (from Image 1)
               ============================================================== */
            <div className="space-y-6">
              {/* Hero Banner with Sun Motif & Slogan */}
              <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-slate-950 via-sky-950 to-blue-900 text-white overflow-hidden shadow-lg">
                <div className="relative z-10 max-w-2xl">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold mb-3">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Smart HR Solutions for a Brighter Tomorrow ☀️</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                    Discover Our Powerful SaaS Platform
                  </h2>
                  <p className="text-sm text-sky-200 mt-2 font-medium">
                    All-in-One HR & Business Solutions by <strong className="text-white">RSTPL</strong>.
                    Innovate · Integrate · Transform.
                  </p>
                  <p className="text-xs text-slate-300 mt-1 italic">
                    "Choose RSTPL Because Your People Deserve the Best!"
                  </p>
                </div>
              </div>

              {/* 7 Core Modules Showcase (Exact match from Poster 1 right column) */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-sky-600" />
                    <span>Complete SaaS Module Suite</span>
                  </h3>
                  <span className="text-xs font-bold text-slate-500">7 Integrated Modules</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                  {/* Module 1: HRMS */}
                  <div
                    onClick={() => {
                      onNavigateToModule?.('employees');
                      onClose();
                    }}
                    className="p-4 rounded-2xl border border-rose-100 bg-rose-50/50 hover:bg-rose-50 transition-all cursor-pointer group hover:shadow-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold shadow-sm shrink-0">
                        <Users className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-sm group-hover:text-rose-700 transition-colors">
                          HRMS
                        </h4>
                        <p className="text-xs font-semibold text-rose-800">Complete HR Management</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">Hire · Manage · Retain</p>
                      </div>
                    </div>
                  </div>

                  {/* Module 2: Payroll */}
                  <div
                    onClick={() => {
                      onNavigateToModule?.('payroll');
                      onClose();
                    }}
                    className="p-4 rounded-2xl border border-emerald-100 bg-emerald-50/50 hover:bg-emerald-50 transition-all cursor-pointer group hover:shadow-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-sm shrink-0">
                        <DollarSign className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-sm group-hover:text-emerald-700 transition-colors">
                          Payroll
                        </h4>
                        <p className="text-xs font-semibold text-emerald-800">Accurate & On-Time Processing</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">Simple · Secure · Compliant</p>
                      </div>
                    </div>
                  </div>

                  {/* Module 3: Attendance */}
                  <div
                    onClick={() => {
                      onNavigateToModule?.('attendance');
                      onClose();
                    }}
                    className="p-4 rounded-2xl border border-sky-100 bg-sky-50/50 hover:bg-sky-50 transition-all cursor-pointer group hover:shadow-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center font-bold shadow-sm shrink-0">
                        <CalendarCheck className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-sm group-hover:text-sky-700 transition-colors">
                          Attendance
                        </h4>
                        <p className="text-xs font-semibold text-sky-800">Track · Manage · Improve</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">Real-time Biometric Sync</p>
                      </div>
                    </div>
                  </div>

                  {/* Module 4: Leave */}
                  <div
                    onClick={() => {
                      onNavigateToModule?.('leave');
                      onClose();
                    }}
                    className="p-4 rounded-2xl border border-amber-100 bg-amber-50/50 hover:bg-amber-50 transition-all cursor-pointer group hover:shadow-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center font-bold shadow-sm shrink-0">
                        <Calendar className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-sm group-hover:text-amber-700 transition-colors">
                          Leave
                        </h4>
                        <p className="text-xs font-semibold text-amber-800">Flexible Leave Management</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">Plan · Apply · Approve</p>
                      </div>
                    </div>
                  </div>

                  {/* Module 5: Recruitment */}
                  <div
                    onClick={() => {
                      onNavigateToModule?.('recruitment');
                      onClose();
                    }}
                    className="p-4 rounded-2xl border border-purple-100 bg-purple-50/50 hover:bg-purple-50 transition-all cursor-pointer group hover:shadow-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center font-bold shadow-sm shrink-0">
                        <UserPlus className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-sm group-hover:text-purple-700 transition-colors">
                          Recruitment
                        </h4>
                        <p className="text-xs font-semibold text-purple-800">Find the Right Talent</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">Attract · Hire · Grow</p>
                      </div>
                    </div>
                  </div>

                  {/* Module 6: Performance */}
                  <div
                    onClick={() => {
                      onNavigateToModule?.('performance');
                      onClose();
                    }}
                    className="p-4 rounded-2xl border border-teal-100 bg-teal-50/50 hover:bg-teal-50 transition-all cursor-pointer group hover:shadow-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold shadow-sm shrink-0">
                        <Target className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-sm group-hover:text-teal-700 transition-colors">
                          Performance (PMS)
                        </h4>
                        <p className="text-xs font-semibold text-teal-800">Drive Growth & Success</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">Measure · Develop · Achieve</p>
                      </div>
                    </div>
                  </div>

                  {/* Module 7: Reports & Analytics */}
                  <div
                    onClick={() => {
                      onNavigateToModule?.('reports');
                      onClose();
                    }}
                    className="p-4 rounded-2xl border border-rose-100 bg-rose-50/50 hover:bg-rose-50 transition-all cursor-pointer group hover:shadow-xs md:col-span-2 lg:col-span-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-rose-700 text-white flex items-center justify-center font-bold shadow-sm shrink-0">
                        <BarChart3 className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-sm group-hover:text-rose-800 transition-colors">
                          Reports & Analytics
                        </h4>
                        <p className="text-xs font-semibold text-rose-800">Better Insights. Smarter Decisions.</p>
                        <p className="text-[11px] text-slate-500 mt-0.5">Data · Trends · Action · Executive BI</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 5 Core Platform Guarantees (From left side of Image 1) */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-600 mb-3">
                  Enterprise Infrastructure Guarantees
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
                  <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                    <Cloud className="w-5 h-5 text-sky-600 mx-auto mb-1.5" />
                    <span className="font-black text-xs text-slate-900 block">Cloud Based</span>
                    <span className="text-[10px] text-slate-400">Access Anytime</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                    <Lock className="w-5 h-5 text-emerald-600 mx-auto mb-1.5" />
                    <span className="font-black text-xs text-slate-900 block">Secure & Reliable</span>
                    <span className="text-[10px] text-slate-400">Your Data Priority</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                    <Zap className="w-5 h-5 text-purple-600 mx-auto mb-1.5" />
                    <span className="font-black text-xs text-slate-900 block">Easy to Use</span>
                    <span className="text-[10px] text-slate-400">High Productivity</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs">
                    <TrendingUp className="w-5 h-5 text-amber-600 mx-auto mb-1.5" />
                    <span className="font-black text-xs text-slate-900 block">Scalable</span>
                    <span className="text-[10px] text-slate-400">Grows with Business</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200/80 shadow-2xs col-span-2 sm:col-span-1">
                    <Headphones className="w-5 h-5 text-rose-600 mx-auto mb-1.5" />
                    <span className="font-black text-xs text-slate-900 block">Dedicated Support</span>
                    <span className="text-[10px] text-slate-400">Always with You</span>
                  </div>
                </div>
              </div>

              {/* Book Spine Pillars from Image 1 */}
              <div className="flex items-center justify-center gap-2 flex-wrap text-xs font-black">
                <span className="px-3 py-1 rounded-lg bg-sky-600 text-white">PEOPLE</span>
                <span className="text-slate-300">➔</span>
                <span className="px-3 py-1 rounded-lg bg-amber-500 text-white">PROCESS</span>
                <span className="text-slate-300">➔</span>
                <span className="px-3 py-1 rounded-lg bg-emerald-600 text-white">TECHNOLOGY</span>
                <span className="text-slate-300">➔</span>
                <span className="px-3 py-1 rounded-lg bg-purple-700 text-white">SUCCESS</span>
              </div>
            </div>
          ) : (
            /* ==============================================================
               TAB 2: RS TECHNOVISIONS (XPERT SKILL COP) CONSULTING & AUDIT (from Image 2)
               ============================================================== */
            <div className="space-y-6">
              {/* Consulting Banner */}
              <div className="rounded-3xl p-6 sm:p-8 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 text-white border border-slate-800 shadow-lg">
                <div className="max-w-2xl">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-xs font-bold mb-3">
                    <Award className="w-3.5 h-3.5 text-amber-400" />
                    <span>Your People Our Priority 🤝 Smart HR Solutions for a Stronger Tomorrow</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                    RS Technovisions <span className="text-amber-400">(XpertSkillCop)</span>
                  </h2>
                  <p className="text-sm font-semibold text-slate-300 mt-1">
                    HR Management & Audit Consultants (Build | Manage | Grow)
                  </p>
                  <p className="text-xs text-slate-400 mt-2">
                    "From people management to process audit, we help you build a compliant, efficient and future-ready organization."
                  </p>
                </div>
              </div>

              {/* 6 Advisory & Audit Practices (from Image 2 right column) */}
              <div>
                <h3 className="text-base font-black text-slate-900 mb-3 flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-amber-600" />
                  <span>Strategic HR & Audit Advisory Practices</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 text-xs">
                  <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200">
                    <span className="font-black text-amber-950 text-sm block">1. HR Strategy & Advisory</span>
                    <span className="text-amber-800 font-semibold mt-0.5 block">People. Process. Performance.</span>
                    <p className="text-slate-600 text-[11px] mt-1">
                      Organizational design, grading structures, HR budgeting, and strategic workforce roadmaps.
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-sky-50/60 border border-sky-200">
                    <span className="font-black text-sky-950 text-sm block">2. Compliance & Statutory Audit</span>
                    <span className="text-sky-800 font-semibold mt-0.5 block">Stay Compliant. Stay Confident.</span>
                    <p className="text-slate-600 text-[11px] mt-1">
                      PF, ESIC, Professional Tax, Factory Act, Minimum Wages, and POSH audits with zero non-conformity.
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-200">
                    <span className="font-black text-purple-950 text-sm block">3. Process Optimization</span>
                    <span className="text-purple-800 font-semibold mt-0.5 block">Work Smarter. Grow Faster.</span>
                    <p className="text-slate-600 text-[11px] mt-1">
                      Kaizen 5S, shift roster optimization, biometric turnstile SLAs, and HR SOP streamlining.
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200">
                    <span className="font-black text-blue-950 text-sm block">4. Talent Acquisition & Management</span>
                    <span className="text-blue-800 font-semibold mt-0.5 block">Right Talent. Right Fit.</span>
                    <p className="text-slate-600 text-[11px] mt-1">
                      Executive search, technical hiring, automated ATS pipelines, and candidate background verification.
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-orange-50/60 border border-orange-200">
                    <span className="font-black text-orange-950 text-sm block">5. Training & Development</span>
                    <span className="text-orange-800 font-semibold mt-0.5 block">Build Skills. Unlock Potential.</span>
                    <p className="text-slate-600 text-[11px] mt-1">
                      Shopfloor safety, leadership training, KRA goal calibration, and skill gap assessment.
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-100 border border-slate-300">
                    <span className="font-black text-slate-950 text-sm block">6. Internal Audit & Risk Consulting</span>
                    <span className="text-slate-700 font-semibold mt-0.5 block">Identify. Assess. Improve.</span>
                    <p className="text-slate-600 text-[11px] mt-1">
                      Payroll ghost employee audits, biometric fraud prevention, attendance tampering risk prevention.
                    </p>
                  </div>
                </div>
              </div>

              {/* 7 Services Bottom Row from Image 2 */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  Specialized Service Offerings
                </span>
                <div className="flex flex-wrap gap-2 text-xs font-bold text-slate-700">
                  <span className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 shadow-2xs">
                    • HR Consulting & Advisory
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 shadow-2xs">
                    • Compliance Management
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 shadow-2xs">
                    • Audit & Risk Assessment
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 shadow-2xs">
                    • Learning & Development
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 shadow-2xs">
                    • Talent Management
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 shadow-2xs">
                    • Process Improvement
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 shadow-2xs">
                    • Business Support Services
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Connect & Contact Footer (From both posters) */}
          <div className="p-5 rounded-2xl bg-slate-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1 text-xs">
              <span className="text-amber-400 font-bold block">Connect With Us:</span>
              <div className="flex flex-wrap gap-4 text-slate-300">
                <a
                  href="mailto:info@rstpl.com"
                  className="flex items-center gap-1.5 hover:text-white transition"
                >
                  <Mail className="w-3.5 h-3.5 text-sky-400" />
                  <span>info@rstpl.com</span>
                </a>
                <a
                  href="mailto:rstechnovisionsinfo@gmail.com"
                  className="flex items-center gap-1.5 hover:text-white transition"
                >
                  <Mail className="w-3.5 h-3.5 text-amber-400" />
                  <span>rstechnovisionsinfo@gmail.com</span>
                </a>
                <a
                  href="http://www.rstechnovisions.co.in"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 hover:text-white transition"
                >
                  <Globe className="w-3.5 h-3.5 text-emerald-400" />
                  <span>www.rstechnovisions.co.in</span>
                </a>
                <a
                  href="http://www.rstpl.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 hover:text-white transition"
                >
                  <Globe className="w-3.5 h-3.5 text-blue-400" />
                  <span>www.rstpl.com</span>
                </a>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition shrink-0 cursor-pointer"
            >
              Back to CodeTech HRMS
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

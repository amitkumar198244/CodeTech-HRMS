-- ============================================================================
-- RSTPL HRMS - COMPLETE PRODUCTION POSTGRESQL & SUPABASE MIGRATION
-- Brand: RS Technovisions XpertSkillCop
-- Product: RSTPL HRMS (Multi-Tenant Enterprise Architecture)
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. ORGANIZATIONS (TENANTS)
CREATE TABLE IF NOT EXISTS organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    tagline VARCHAR(255) DEFAULT 'Smart HR Solutions for a Smarter Tomorrow',
    logo_url TEXT,
    pan_number VARCHAR(20),
    gst_number VARCHAR(30),
    pf_number VARCHAR(50),
    esic_number VARCHAR(50),
    pt_number VARCHAR(50),
    plan_id VARCHAR(50) DEFAULT 'enterprise' CHECK (plan_id IN ('starter', 'professional', 'enterprise', 'custom')),
    max_employees INT DEFAULT 5000,
    max_users INT DEFAULT 100,
    is_active BOOLEAN DEFAULT TRUE,
    theme_color VARCHAR(20) DEFAULT '#0284C7',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. BRANCHES & UNITS & LOCATIONS
CREATE TABLE IF NOT EXISTS branches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    code VARCHAR(50) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    is_headquarters BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS units (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    branch_id UUID REFERENCES branches(id) ON DELETE SET NULL,
    name VARCHAR(150) NOT NULL,
    code VARCHAR(50) NOT NULL,
    type VARCHAR(50) DEFAULT 'Manufacturing Plant',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. DEPARTMENTS, DESIGNATIONS, GRADES
CREATE TABLE IF NOT EXISTS departments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    code VARCHAR(50) NOT NULL,
    head_employee_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS designations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    code VARCHAR(50) NOT NULL,
    department_id UUID REFERENCES departments(id) ON DELETE CASCADE,
    grade VARCHAR(20) DEFAULT 'L3',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. SHIFTS
CREATE TABLE IF NOT EXISTS shifts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(50) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    grace_time_minutes INT DEFAULT 15,
    half_day_threshold_hours NUMERIC(4,2) DEFAULT 4.5,
    full_day_threshold_hours NUMERIC(4,2) DEFAULT 8.0,
    is_night_shift BOOLEAN DEFAULT FALSE,
    color VARCHAR(20) DEFAULT '#0284C7',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. EMPLOYEES
CREATE TABLE IF NOT EXISTS employees (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_code VARCHAR(50) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    avatar_url TEXT,
    gender VARCHAR(20) NOT NULL,
    dob DATE NOT NULL,
    blood_group VARCHAR(10),
    marital_status VARCHAR(20) DEFAULT 'Married',
    address TEXT NOT NULL,
    emergency_contact JSONB,
    date_of_joining DATE NOT NULL,
    confirmation_date DATE,
    employment_type VARCHAR(50) DEFAULT 'Full-Time',
    status VARCHAR(50) DEFAULT 'Active',
    branch_id UUID REFERENCES branches(id) ON DELETE SET NULL,
    unit_id UUID REFERENCES units(id) ON DELETE SET NULL,
    department_id UUID REFERENCES departments(id) ON DELETE SET NULL,
    designation_id UUID REFERENCES designations(id) ON DELETE SET NULL,
    grade VARCHAR(20) DEFAULT 'L3',
    shift_id UUID REFERENCES shifts(id) ON DELETE SET NULL,
    reporting_manager_id UUID REFERENCES employees(id) ON DELETE SET NULL,
    pan VARCHAR(20),
    aadhaar_masked VARCHAR(20),
    uan VARCHAR(30),
    pf_applicable BOOLEAN DEFAULT TRUE,
    esic_applicable BOOLEAN DEFAULT TRUE,
    bank_name VARCHAR(100),
    bank_account_number VARCHAR(50),
    ifsc_code VARCHAR(20),
    ctc_annual NUMERIC(14,2) NOT NULL DEFAULT 0,
    basic_monthly NUMERIC(12,2) NOT NULL DEFAULT 0,
    hra_monthly NUMERIC(12,2) NOT NULL DEFAULT 0,
    conveyance_monthly NUMERIC(12,2) NOT NULL DEFAULT 0,
    special_allowance_monthly NUMERIC(12,2) NOT NULL DEFAULT 0,
    pf_employee_monthly NUMERIC(12,2) NOT NULL DEFAULT 0,
    esic_employee_monthly NUMERIC(12,2) NOT NULL DEFAULT 0,
    professional_tax_monthly NUMERIC(12,2) NOT NULL DEFAULT 200,
    net_salary_monthly NUMERIC(12,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_org_emp_code UNIQUE(org_id, employee_code)
);

-- 6. BIOMETRIC DEVICES
CREATE TABLE IF NOT EXISTS biometric_devices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    device_model VARCHAR(100) NOT NULL,
    vendor VARCHAR(50) NOT NULL CHECK (vendor IN ('ZKTeco', 'eSSL', 'Realtime', 'Matrix', 'Suprema', 'BioMax')),
    serial_number VARCHAR(100) NOT NULL,
    ip_address VARCHAR(50) NOT NULL,
    port INT DEFAULT 4370,
    location VARCHAR(150) NOT NULL,
    unit_id UUID REFERENCES units(id) ON DELETE SET NULL,
    status VARCHAR(30) DEFAULT 'Online',
    last_sync_at TIMESTAMPTZ DEFAULT NOW(),
    total_synced_punches INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. RAW PUNCHES (BIOMETRIC & MOBILE BUFFER)
CREATE TABLE IF NOT EXISTS raw_punches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    device_id UUID REFERENCES biometric_devices(id) ON DELETE SET NULL,
    device_name VARCHAR(150),
    employee_code VARCHAR(50) NOT NULL,
    punch_time TIMESTAMPTZ NOT NULL,
    punch_type VARCHAR(20) DEFAULT 'AUTO',
    source VARCHAR(50) DEFAULT 'Biometric',
    status VARCHAR(30) DEFAULT 'Unprocessed',
    ip_address VARCHAR(50),
    latitude NUMERIC(10,6),
    longitude NUMERIC(10,6),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. ATTENDANCE PROCESSED RECORDS
CREATE TABLE IF NOT EXISTS attendance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    employee_code VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    shift_id UUID REFERENCES shifts(id) ON DELETE SET NULL,
    first_in TIME,
    last_out TIME,
    total_hours NUMERIC(5,2) DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'Present',
    is_late BOOLEAN DEFAULT FALSE,
    late_minutes INT DEFAULT 0,
    is_early_out BOOLEAN DEFAULT FALSE,
    early_out_minutes INT DEFAULT 0,
    is_overtime BOOLEAN DEFAULT FALSE,
    overtime_hours NUMERIC(4,2) DEFAULT 0,
    is_regularized BOOLEAN DEFAULT FALSE,
    is_finalized BOOLEAN DEFAULT FALSE,
    remarks TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_org_emp_date UNIQUE(org_id, employee_id, date)
);

-- 9. LEAVE TYPES & LEAVE REQUESTS
CREATE TABLE IF NOT EXISTS leave_types (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    code VARCHAR(20) NOT NULL,
    name VARCHAR(100) NOT NULL,
    annual_quota INT NOT NULL DEFAULT 12,
    is_carry_forward BOOLEAN DEFAULT TRUE,
    max_carry_forward_days INT DEFAULT 30,
    is_encashable BOOLEAN DEFAULT FALSE,
    gender_eligibility VARCHAR(20) DEFAULT 'All',
    requires_proof BOOLEAN DEFAULT FALSE,
    color VARCHAR(20) DEFAULT '#0284C7',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS leave_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    leave_type_id UUID NOT NULL REFERENCES leave_types(id) ON DELETE CASCADE,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days NUMERIC(4,1) NOT NULL,
    reason TEXT NOT NULL,
    status VARCHAR(30) DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Rejected', 'Cancelled')),
    applied_at TIMESTAMPTZ DEFAULT NOW(),
    reviewed_by UUID REFERENCES employees(id) ON DELETE SET NULL,
    reviewed_at TIMESTAMPTZ,
    review_remarks TEXT
);

-- 10. PAYROLL RUNS & PAYSLIPS
CREATE TABLE IF NOT EXISTS payroll_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    month VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    status VARCHAR(30) DEFAULT 'Draft' CHECK (status IN ('Draft', 'Calculated', 'Approved', 'Locked')),
    total_employees INT DEFAULT 0,
    total_gross_pay NUMERIC(14,2) DEFAULT 0,
    total_deductions NUMERIC(14,2) DEFAULT 0,
    total_net_pay NUMERIC(14,2) DEFAULT 0,
    total_employer_contributions NUMERIC(14,2) DEFAULT 0,
    processed_at TIMESTAMPTZ,
    approved_by VARCHAR(150),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payslips (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    payroll_run_id UUID NOT NULL REFERENCES payroll_runs(id) ON DELETE CASCADE,
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    employee_code VARCHAR(50) NOT NULL,
    payable_days NUMERIC(4,1) DEFAULT 30,
    absent_days NUMERIC(4,1) DEFAULT 0,
    loss_of_pay_days NUMERIC(4,1) DEFAULT 0,
    basic_pay NUMERIC(12,2) NOT NULL,
    hra NUMERIC(12,2) NOT NULL,
    conveyance NUMERIC(12,2) NOT NULL,
    special_allowance NUMERIC(12,2) NOT NULL,
    overtime_pay NUMERIC(12,2) DEFAULT 0,
    incentives NUMERIC(12,2) DEFAULT 0,
    gross_earnings NUMERIC(12,2) NOT NULL,
    pf_deduction NUMERIC(12,2) DEFAULT 0,
    esic_deduction NUMERIC(12,2) DEFAULT 0,
    professional_tax NUMERIC(12,2) DEFAULT 0,
    tds_tax NUMERIC(12,2) DEFAULT 0,
    loan_deduction NUMERIC(12,2) DEFAULT 0,
    total_deductions NUMERIC(12,2) NOT NULL,
    net_payable NUMERIC(12,2) NOT NULL,
    status VARCHAR(30) DEFAULT 'Generated',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. AUDIT LOGS
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id VARCHAR(100) NOT NULL,
    user_name VARCHAR(150) NOT NULL,
    user_role VARCHAR(50) NOT NULL,
    action VARCHAR(50) NOT NULL,
    module VARCHAR(100) NOT NULL,
    details TEXT NOT NULL,
    ip_address VARCHAR(50) DEFAULT '127.0.0.1',
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES FOR SUPABASE
-- Tenant Isolation Guarantees
-- ============================================================================
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE raw_punches ENABLE ROW LEVEL SECURITY;
ALTER TABLE biometric_devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE payslips ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Helper function to fetch current org_id from JWT app_metadata
CREATE OR REPLACE FUNCTION current_org_id() RETURNS UUID AS $$
  SELECT NULLIF(current_setting('request.jwt.claims', true)::jsonb->'app_metadata'->>'org_id', '')::UUID;
$$ LANGUAGE SQL STABLE;

-- Tenant Isolation Policies
CREATE POLICY tenant_isolation_employees ON employees
    FOR ALL USING (org_id = current_org_id() OR current_setting('request.jwt.claims', true)::jsonb->'app_metadata'->>'role' = 'super_admin');

CREATE POLICY tenant_isolation_attendance ON attendance
    FOR ALL USING (org_id = current_org_id() OR current_setting('request.jwt.claims', true)::jsonb->'app_metadata'->>'role' = 'super_admin');

CREATE POLICY tenant_isolation_payroll ON payroll_runs
    FOR ALL USING (org_id = current_org_id() OR current_setting('request.jwt.claims', true)::jsonb->'app_metadata'->>'role' = 'super_admin');

CREATE POLICY tenant_isolation_payslips ON payslips
    FOR ALL USING (org_id = current_org_id() OR current_setting('request.jwt.claims', true)::jsonb->'app_metadata'->>'role' = 'super_admin');

CREATE POLICY tenant_isolation_audit ON audit_logs
    FOR ALL USING (org_id = current_org_id() OR current_setting('request.jwt.claims', true)::jsonb->'app_metadata'->>'role' = 'super_admin');

-- ============================================================================
-- RSTPL HRMS - SEED DATA SCRIPT
-- Organization: RSTPL Demo Manufacturing Pvt. Ltd.
-- Powered by RS Technovisions XpertSkillCop
-- ============================================================================

-- 1. Organization
INSERT INTO organizations (id, name, code, tagline, pan_number, gst_number, pf_number, esic_number, pt_number, plan_id, max_employees, max_users, is_active, theme_color)
VALUES (
    'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab',
    'RSTPL Demo Manufacturing Pvt. Ltd.',
    'RSTPL-MFG',
    'Smart HR Solutions for a Smarter Tomorrow',
    'AAACR1234F',
    '27AAACR1234F1Z5',
    'MH/PUN/0098765/000',
    '31000987650001001',
    'PT-MAH-998877',
    'enterprise',
    5000,
    100,
    true,
    '#0284C7'
) ON CONFLICT (code) DO NOTHING;

-- 2. Branches
INSERT INTO branches (id, org_id, name, code, city, state, address, is_headquarters) VALUES
('b1000000-0000-0000-0000-000000000001', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Corporate Headquarters', 'BR-HQ-01', 'Pune', 'Maharashtra', 'RSTPL Tech Park, Baner Road, Pune - 411045', true),
('b1000000-0000-0000-0000-000000000002', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Chakan Heavy Engineering Plant', 'BR-PL1-02', 'Pune (Chakan)', 'Maharashtra', 'Plot 42, Chakan Industrial Phase II, Pune - 410501', false),
('b1000000-0000-0000-0000-000000000003', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Sanand Automotive Components', 'BR-PL2-03', 'Ahmedabad', 'Gujarat', 'GIDC Sector 12, Sanand, Ahmedabad - 382170', false);

-- 3. Units
INSERT INTO units (id, org_id, branch_id, name, code, type) VALUES
('u1000000-0000-0000-0000-000000000001', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'b1000000-0000-0000-0000-000000000001', 'Corporate Office & HR Center', 'UN-CORP', 'Corporate'),
('u1000000-0000-0000-0000-000000000002', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'b1000000-0000-0000-0000-000000000002', 'Manufacturing Unit 1 (Assembly)', 'UN-MFG1', 'Manufacturing Plant'),
('u1000000-0000-0000-0000-000000000003', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'b1000000-0000-0000-0000-000000000002', 'Machining & Tooling Unit', 'UN-TOOL', 'Manufacturing Plant'),
('u1000000-0000-0000-0000-000000000004', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'b1000000-0000-0000-0000-000000000003', 'Assembly & Stamping Unit 2', 'UN-MFG2', 'Manufacturing Plant');

-- 4. Departments
INSERT INTO departments (id, org_id, name, code) VALUES
('d1000000-0000-0000-0000-000000000001', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Human Resources & IR', 'HR-01'),
('d1000000-0000-0000-0000-000000000002', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Production & Manufacturing', 'PROD-02'),
('d1000000-0000-0000-0000-000000000003', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Quality Assurance & Audit', 'QA-03'),
('d1000000-0000-0000-0000-000000000004', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Purchase & Supply Chain', 'SCM-04'),
('d1000000-0000-0000-0000-000000000005', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Finance & Accounts', 'FIN-05'),
('d1000000-0000-0000-0000-000000000006', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Plant Maintenance & Safety', 'MAINT-06'),
('d1000000-0000-0000-0000-000000000007', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Information Technology', 'IT-07'),
('d1000000-0000-0000-0000-000000000008', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Logistics & Warehousing', 'LOG-08');

-- 5. Shifts
INSERT INTO shifts (id, org_id, name, code, start_time, end_time, grace_time_minutes, half_day_threshold_hours, full_day_threshold_hours, is_night_shift, color) VALUES
('s1000000-0000-0000-0000-000000000001', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'General Corporate Shift', 'GEN-01', '09:00:00', '18:00:00', 15, 4.5, 8.0, false, '#0284C7'),
('s1000000-0000-0000-0000-000000000002', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Plant Morning Shift (A)', 'PL-SH-A', '06:00:00', '14:30:00', 10, 4.0, 7.5, false, '#10B981'),
('s1000000-0000-0000-0000-000000000003', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Plant Afternoon Shift (B)', 'PL-SH-B', '14:30:00', '23:00:00', 10, 4.0, 7.5, false, '#F59E0B'),
('s1000000-0000-0000-0000-000000000004', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Plant Night Shift (C)', 'PL-SH-C', '23:00:00', '06:30:00', 10, 4.0, 7.0, true, '#6366F1');

-- 6. Leave Types
INSERT INTO leave_types (id, org_id, code, name, annual_quota, is_carry_forward, max_carry_forward_days, is_encashable, gender_eligibility, requires_proof, color) VALUES
('l1000000-0000-0000-0000-000000000001', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'CL', 'Casual Leave', 12, false, 0, false, 'All', false, '#3B82F6'),
('l1000000-0000-0000-0000-000000000002', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'SL', 'Sick / Medical Leave', 10, true, 15, false, 'All', true, '#EF4444'),
('l1000000-0000-0000-0000-000000000003', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'EL', 'Earned / Privilege Leave', 18, true, 45, true, 'All', false, '#10B981'),
('l1000000-0000-0000-0000-000000000004', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'ML', 'Maternity Leave', 180, false, 0, false, 'Female', true, '#EC4899'),
('l1000000-0000-0000-0000-000000000005', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'CO', 'Compensatory Off', 6, false, 0, false, 'All', false, '#F59E0B');

-- 7. Biometric Devices
INSERT INTO biometric_devices (id, org_id, name, device_model, vendor, serial_number, ip_address, port, location, status, last_sync_at, total_synced_punches) VALUES
('dev-001', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Chakan Gate 1 Turnstile Biometric', 'BioStation 3 / eSSL K90 Pro', 'eSSL', 'ESSL-CHK-G1-9981', '192.168.10.201', 4370, 'Chakan Plant - Main Entrance Gate 1', 'Online', NOW(), 12480),
('dev-002', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Corporate HQ Main Reception Facial Bio', 'SpeedFace V5L / ZKTeco Pro', 'ZKTeco', 'ZK-HQ-REC-4412', '192.168.1.105', 4370, 'Baner Corporate HQ - 4th Floor', 'Online', NOW(), 8450),
('dev-003', 'a1b2c3d4-e5f6-4a1b-8c2d-1234567890ab', 'Sanand Plant Shopfloor Attendance Terminal', 'Matrix COSEC VEGA FAX', 'Matrix', 'MAT-SND-SF-3390', '192.168.20.150', 5000, 'Sanand Plant - Heavy Stamping Line', 'Online', NOW(), 9630);
